"""the main work is done in this module.
We will read the configuration files, setup the paths and launch
the real application.
"""
import os
import sys
import pkg_resources
from pkg_resources import working_set, Environment
from ConfigParser import SafeConfigParser

# an import just to fool py2exe into including Tkinter
if False:
    import Tkinter

class Launcher(object):
    """the launcher class is a sort of special entry point for
    windows programs to import and launch real applications.
    """

    def __init__(self, config_filename):
        """the config filename that is passed to the class
        must be parseable using the SafeConfigParser implementation
        and must contain a [launcher] section.

        This launcher section must define the python_lib and an
        additionnal_libs directory to be activated.
        """
        
        if not os.path.exists(os.path.abspath(config_filename)):
            # TODO: proper log into a windows logger of some sort would be nice
            print "Cannot find config file: %s" % config_filename
            sys.exit(255)

        self.config_filename = config_filename
        self.config = SafeConfigParser()
        self.config.read(self.config_filename)

    def activate_eggs(self, dirs):
        """activate the egg dirs found in config
        """
        lib_dirlist = dirs
        distributions, errors = working_set.find_plugins(
                Environment(lib_dirlist)
                )
        map(working_set.add, distributions)
        if len(errors) > 0:
            # TODO: real logging should be better
            print "Couldn't load lib %s" % errors

    def launch_callback(self, callback):
        """call a function back when done setting the environment
        """
        self.__common__()
        __requires__ = 'pastescript'
        callback()

    def launch_paster(self):
        """launch the paster command and that's all
        """
        self.__common__()
        __requires__ = 'pastescript'
        pkg_resources.run_script('pastescript', 'paster')

    def launchapp(self):
        """launch the real application
        """
        self.__common__()

        appname = self.config.get('application', 'name')
        module_name, function_name = appname.split('#')
        module_ = __import__(module_name, globals(), locals(),
                [function_name], -1)
        # now launch the function without any argument
        # the process will block here waiting for the program
        # to terminate before giving back control to the caller
        # function
        func = getattr(module_, function_name)
        func()

    def __common__(self):
        """main function to be called by all the others.
        """

        # are we in full-auto mode ?
        fullauto = self.config.getboolean('launcher', 'fullauto')

        if fullauto:
            # this will be something like
            # x:\progs\pylunch_templates\tg2_example\libs\shared.lib
            baselibfile = sys.path[0]
            baselibdir = os.path.dirname(baselibfile)
            basedir, tail = os.path.split(baselibdir)

            python_dir = os.path.join(basedir, 'python')
            libs_dir = os.path.join(python_dir, 'additional_libs')

        else:

            # get our python path
            python_dir = os.path.abspath(
                    self.config.get('launcher', 'python_dir'))

            # get our librairies paths
            libs_dir = self.config.get('launcher', 'additional_libs')

        python_libdir = os.path.join(python_dir, 'Lib')
        sys.path.append(python_libdir)

        # Tkinter apps need this
        tk_libdir = os.path.join(python_libdir, 'lib-tk')
        sys.path.append(tk_libdir)

        # dlls are at the same level as the libs
        dlls = os.path.join(python_dir, 'DLLs')
        sys.path.append(dlls)

        # get the relative site packages path
        site_packages = os.path.join(python_libdir, 'site-packages')
        sys.path.append(site_packages)

        # load the extra python libraries
        self.activate_eggs([libs_dir, site_packages])

