"""a simple program that writes config settings on the registry
for our service
"""
from pylunch.utils import get_configfilename

# std python
import os
import sys
from ConfigParser import SafeConfigParser
import optparse

# win32 specific
import _winreg

# the org name used to store your conf in the registry
organization = "pylunch"

def get_config_regkey(product_name, write=False):
    """return the reg key ready for use, either in read or write mode
    """
    if write:
        return _winreg.CreateKey(_winreg.HKEY_LOCAL_MACHINE,
                'SOFTWARE\\%s\\pasterservice\\%s' % (organization, product_name))

    else:
        return _winreg.OpenKey(_winreg.HKEY_LOCAL_MACHINE, 
                'SOFTWARE\\%s\\pasterservice\\%s' % (organization, product_name))

def get_config_filepath(product_name):
    """find the config file path in the registry
    This path will have been previously setup using the service
    command line utility.
    """
    try:
        reg_key = get_config_regkey(product_name)
        reg_val = _winreg.QueryValueEx(reg_key, 'ConfigFilePath')[0]

    except WindowsError, e:
        logging.exception(str(e))
        reg_val = None

    return reg_val

def set_configfile(product_name, config_filepath):
    """set the config file path in the registry
    """
    reg_key = get_config_regkey(product_name, write=True)
    reg_val = _winreg.SetValueEx(
            reg_key, 'ConfigFilePath', None, _winreg.REG_SZ, config_filepath)

def get_loggingdir(product_name):
    """find the logging directory in the registry
    """
    try:
        reg_key = get_config_regkey(product_name)
        reg_val = _winreg.QueryValueEx(reg_key, 'LoggingDir')[0]

    except WindowsError, e:
        # could not find the config for logging just let go
        # with default value
        reg_val = None

    return reg_val

def set_loggingdir(product_name, loggingdir):
    """set the logging directory path in the registry
    """
    reg_key = get_config_regkey(product_name, write=True)
    reg_val = _winreg.SetValueEx(reg_key, 'LoggingDir', None,
            _winreg.REG_SZ, loggingdir)

def main():
    configfilename = get_configfilename()
    config = SafeConfigParser()
    config.read(configfilename)

    appname = config.get('pasterservice', 'name')

    optparser = optparse.OptionParser()

    optparser.add_option(
        "-c", "--config",
        dest="config_file",
        help="specify the config file path FILE",
        metavar="FILE",
        default=None)

    optparser.add_option(
        "-l", "--logdir",
        dest="logdir",
        help="specify the logging DIRECTORY",
        metavar="DIRECTORY",
        default=None)

    (options, args) = optparser.parse_args()

    error_flag = False
    setup_flag = False

    if options.config_file:
        setup_flag = True
        configfile = options.config_file
        if not os.path.isabs(configfile):
            print "The path should be absolute"
            error_flag = True

        elif not os.path.exists(configfile):
            print "The specified config file does not exist"
            error_flag = True

        set_configfile(appname, configfile)

    if options.logdir:
        setup_flag = True
        logdir = options.logdir
        if not os.path.isabs(logdir):
            print "The path should be absolute"
            error_flag = True

        elif not os.path.exists(logdir):
            print "The specified logging dir does not exist"
            error_flag = True

        set_loggingdir(appname, logdir)

    if error_flag:
        # if we experienced errors, then quit with error flag 
        sys.exit(1)
    
    if setup_flag:
        # if we handle setup tasks, exit with normal flag
        sys.exit(0)

    else:
        print "launch with --help for help"
        sys.exit(0)


if __name__ == '__main__':
    main()
