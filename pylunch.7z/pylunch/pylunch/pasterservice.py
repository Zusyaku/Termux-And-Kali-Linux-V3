"""a windows service that will run in freezed mode a paste server
for any config file you want
"""

# pylunch
from pylunch.launcher import Launcher
from pylunch.utils import get_progname, get_basedir, get_configfilename
from pylunch.serviceutils.controller import get_config_filepath, get_loggingdir

# win32 specific imports
import win32serviceutil
import win32service
import win32event

# std python
import os
import sys
from ConfigParser import SafeConfigParser

class PasterService(win32serviceutil.ServiceFramework):
    """Paster Windows Service.
    _svc_name_ :         The name of the service (used in the Windows registry).
    _svc_display_name_ : The name that will appear in the Windows Service Manager.
    _svc_description_ :  The service description that will appear in the Windows
    Service Manager.
    """

    configfilename = get_configfilename()
    config = SafeConfigParser()
    config.read(configfilename)

    _svc_name_ = config.get('pasterservice', 'name')
    _svc_display_name_ = "paster http server for %s" % _svc_name_
    _svc_description_ = "Paster WSGI compliant HTTP server serving %s" % _svc_name_

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        # create an event that SvcDoRun can wait on and SvcStop can set.
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)

    def SvcDoRun(self):
        self.ReportServiceStatus(win32service.SERVICE_START_PENDING)
        launcher = Launcher(self.configfilename)
        launcher.launch_callback(self.__service_runner)

    def __service_runner(self):
        from paste.script.serve import ServeCommand
        self.__do_run()
        #os.chdir(os.path.dirname(__file__))
        s = ServeCommand(None)
        self.ReportServiceStatus(win32service.SERVICE_RUNNING)
        #win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)
        s.run([get_config_filepath(self._svc_name_)])

    def __do_run(self):
        self.log_dir = get_loggingdir(self._svc_name_)

        if self.log_dir:
            #os.chdir(self.log_dir)
            sys.path.append(self.log_dir)
            # Redirect stdout and stderr to avoid buffer crashes.            
            sys.stdout = open(os.path.join(self.log_dir, 'stdout.log'), 'a')
            sys.stderr = open(os.path.join(self.log_dir, 'stderr.log'), 'a')

        else:
            # this will generate errors in the windows standard logs
            # that any admin can read using the MMC
            raise ValueError("""The logging directory setting is missing.
                                You should set it in the registry using the cmd line.
                                The Windows Service will not run
                                without this setting.""")
    
    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        #win32event.SetEvent(self.stop_event)
        self.ReportServiceStatus(win32service.SERVICE_STOPPED)
        sys.exit()

if __name__ == '__main__':
    # The following are the most common command-line arguments that are used
    # with this module:
    #  service.py install (Installs the service with manual startup)
    #  service.py --startup auto install (Installs the service
    #  with auto startup)
    #  service.py start (Starts the service)
    #  service.py stop (Stops the service)
    #  service.py remove (Removes the service)
    #
    # For a full list of arguments, simply type "service.py".
    win32serviceutil.HandleCommandLine(PasterService)

