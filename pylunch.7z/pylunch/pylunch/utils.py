"""small tools used in different places by pylunch
"""
import sys
import os

def get_progname():
    """returns the program name stripped of its .exe and path
    """
    executable_name, executable_ext = os.path.splitext(
            os.path.basename(sys.executable))
    return executable_name

def get_basedir():
    """this function will return the base dir
    for a program deployed using py2exe.
    """
    # this will be something like
    # x:\progs\pylunch_templates\tg2_example\libs\shared.lib
    baselibfile = sys.path[0]
    baselibdir = os.path.dirname(baselibfile)
    basedir, tail = os.path.split(baselibdir)
    return basedir

def get_configfilename():
    """returns the config filename using
    path tricks
    """
    basedir = get_basedir()
    return os.path.join(basedir, 'config.ini')


