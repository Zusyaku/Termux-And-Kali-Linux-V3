from pylunch.launcher import Launcher
from pylunch.utils import get_basedir
import os
import sys

# config.ini should be present in same dir as the exec dir
launcher = Launcher('%s/config.ini' % get_basedir())

# run the real app
launcher.launch_paster()
