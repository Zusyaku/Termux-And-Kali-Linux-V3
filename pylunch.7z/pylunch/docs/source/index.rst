.. PyLunch documentation master file, created by sphinx-quickstart on Wed Jan 07 15:29:05 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

PyLunch's documentation!
===========================

Foreword
===========

First of all let's say that we have decided from the beginning to have a scope
as focused as possible. This means our goal is to support super easy deployment
of python programs on the windows plateform.

Being long time users of py2exe and before that of MacMillan's installer, we
still needed two important features to fully be happy with the Windows
plateform:

  - python eggs support
  - portable application for windows

PyLunch is a windows solution for easily packaging python applications.
Using this launcher you won't have to worry about creating complicated
py2exe setup.py files. Just create your application as if you released an
egg to the pypi or your own private index, tell PyLunch the name of your
application, the index to use if it is a private one and your're done!

PyLunch even permits to create windows services to run WSGI application
with the paster WSGI server.

We have tested and documented how to create a windows service out of a
TurboGears2 application. Pylons applications should be exactly the same
and should work without problem either.


Requirements
===============

We use py2exe to generate our launcher and paster as our wsgi support server.
So obviously we rely on the following tools:

  - Python_ 2.5 (we did not try yet 2.6 or 3)
  - py2exe_
  - pywin32_
  - pastescript_

.. _Python: http://www.python.org/
.. _py2exe: http://www.py2exe.org/
.. _pywin32: https://sourceforge.net/projects/pywin32/
.. _pastescript: http://pypi.python.org/pypi/PasteScript/

In pylunch we have added helper functions to bundle GTK so that is becomes
extra easy to deploy GUI applications using pygtk. This of course means you
have any requirment you need on the build machine.

With the bundled application produced by pylunch you won't need to install
GTK system wide on the target machine.


Sections
=========

.. toctree::
    :maxdepth: 2

    main/fromsource
    main/simple_demoapp
    main/turbogears

