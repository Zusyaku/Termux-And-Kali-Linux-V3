Basic Hands-on
===============

Ok, so you now have a binary version of the launchers in a nice directory
with all the dlls and resource files, and now you wonder: How do I package
a python application with *this*?

A sample application
~~~~~~~~~~~~~~~~~~~~

Let's create a small demo application just so that you see the whole process.

We will show you how to create a complete application in python from scratch
to a zipped egg ready to by used...

You installed the pastescript requirement right? Then now is the time
to use it, go in a CMD shell, change directory to a place you want to create
your demo application and::

    paster.exe create demoapp

This will prompt you with some questions, you'll find a transcript just below::

    $ paster.exe create demoapp
    Selected and implied templates:
      pastescript#basic_package  A basic setuptools-enabled package

    Variables:
      egg:      demoapp
      package:  demoapp
      project:  demoapp
    Enter version (Version (like 0.1)) ['']: 0.1
    Enter description (One-line description of the package) ['']: demo app
    Enter long_description (Multi-line description (in reST)) ['']: demo app that does nothing special
    Enter keywords (Space-separated keywords/tags) ['']: demo
    Enter author (Author name) ['']: Florent Aide
    Enter author_email (Author email) ['']: my@email.com
    Enter url (URL of homepage) ['']:
    Enter license_name (License name) ['']: MIT
    Enter zip_safe (True/False: if the package can be distributed as a .zip file) [False]: True
    Creating template basic_package
    Creating directory .\demoapp
      Recursing into +package+
        Creating .\demoapp\demoapp/
        Copying __init__.py to .\demoapp\demoapp\__init__.py
      Copying setup.cfg to .\demoapp\setup.cfg
      Copying setup.py_tmpl to .\demoapp\setup.py
    Running c:\Python25\python.exe setup.py egg_info

The result is a new demoapp directory with a small app inside. Our first task will be to add
some minimum code to make sure we see something on the screen when we test is with pylunch.

Create a new file named `core.py` in the `demoapp/demoapp` directory along-side
the lone `__init__.py` file that sits there and add the following
content to it::

    import time

    def main():
        print "demo app running 1"
        time.sleep(1)
        print "demo app running 2"
        time.sleep(1)
        print "demo app running 3"
        time.sleep(1)

The important point here is to make sure you have at least one function
somewhere in your program that takes **no** argument and serves as your entry
point.

Preparing Pylunch for you application
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Go back to the pylunch directory and edit the pylunch.cfg file (a sample is
give in the sources as a template).

Edit the `product` by putting `demoapp` you like, and also set a `version` number,
vendor and copyright can be omitted if you want they are used for the windows
installer autocreation which is another part of the docs :)

This `product` variable will determine the executable name that will be produced.
The exe can be renamed without consequence later on.

For the moment please leave the `embark_gtk` flag to `false`. If you set this to yet,
pylunch will search your system for the gtk dlls and environment and copy them to
the right place in the distribution folder. This is in case you have an application
using pyGTK and you have GTK install on the system and properly installed. We don't
need this in our example.

If you have PIL and require it, set the `embark_PIL` flag to `True`. If you don't
know what is PIL or don't need it, then leave the flag to `False`.

Leave the `makensis_path` empty for the moment. If you have an NSIS script for
the _resulting_ application produced by pylunch, then you'll be able to auto
build the installer using NSIS commands directly during the build process.

In the additionnal_libs section, you'll find the `main_lib` setting. This is the
most important one: Here you need to provide either the full path to an application
directory that contains a proper setup.py that can be used by `easy_install` or
you can alternatively give a name like "MyApp == 0.5".

If you provide an application string you'll need to provide also the `index_url`
information to help pylunch find your application and it's requirements.

In our example we wil give the full path to our application we just created.
We won't need an index. Here is what we will put in additional_libs::

    main_lib = c:/progs/demoapp

If you created your application in another directory, please change accordingly.

Building our application
~~~~~~~~~~~~~~~~~~~~~~~~

To build the portable application you need to run the following command::

    python setup.py py2exe

At this point you should have a new directory called pylunch_dist.

.. image:: ../_static/pylunch_dist_contents.png

The last thing you need to do is to copy the `config.ini-sample`
file that can be found at the root of your laucher directory to
a file named `config.ini` and edit it.

Find the variable named `name` in the `application` section. This should be
the last one of the file. You name to point the launcher to the entry point
function we created earlier in the demo application::

    [application]

    ; the application name should be in the form of a module
    ; and a function name separated by a sharp sign (#)
    ; the function will be called without any argument and will
    ; be responsible to scan the command line for options
    ; to setup its logging functions and load its config
    name = demoapp.core#main

Now double click on the `demoapp_console.exe` file. If everything went
well you should see your prints running on the screen.

.. image:: ../_static/simple_console_app_running.png

You're done with the first example of the pylunch python launcher :)

In case of problem
-------------------

If nothing happens, open-up a CMD console and run the same executable,
you should see some traceback. Read it, and try to correct the error...
