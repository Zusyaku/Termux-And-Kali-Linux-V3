.. toctree::
    :maxdepth: 2

Installation from source
=========================

For those of you who want to build pylunch istself from source, here are the
steps.

First you should clone the Mercurial repository of pylunch itself::

    hg clone http://bitbucket.org/faide/pylunch/

Since most of you will be doing this work on windows, I recommand you
install the most useful TortoiseHG_ program that will give you a nice
GUI front-end to mercurial nicely integrated into the Windows explorer.

.. _TortoiseHG: http://tortoisehg.sourceforge.net/

Here is how it looks using TortoiseHG:

.. image:: ../_static/tortoisehg_clone_01.png
.. image:: ../_static/tortoisehg_clone_02.png

Once you have cloned the source repository you should install all
the prerequisites, evidently Python but also:

    - py2exe_
    - pywin32_
    - setuptools_
    - pastescript_

.. _py2exe: http://www.py2exe.org/
.. _pywin32: https://sourceforge.net/projects/pywin32/
.. _setuptools: http://pypi.python.org/pypi/setuptools/
.. _pastescript: http://pypi.python.org/pypi/PasteScript/

PasteScript should be easy_installed in the python you'll be using
to create your executables::

    easy_install pastescript

Once this is done you are ready to begin the packaging of your application.

