TurboGears2 support
======================

We will describe here a method to bundle a TurboGears2_ application
into a portable windows application. At the end of this document you
will have a windows service ready to launch your application on a
server without human intervention.

So let's pretend you have a TurboGears2_ application that you developped
and which is working correctly. Let's pretend that this application of yours
is called `supertg` and that you want to deploy `supertg` on a sales-person
laptop.

In this document I will quickstart a sample TurboGears2_ application. We
suppose that you already have installed your TurboGears development
environment and all is working.

Create a demonstration application
-----------------------------------

Open up a CMD console, and quickstart a new TurboGears2_ application named
`supertg`::

    paster quickstart -p supertg supertg

Once the application is created you should go inside the directory and test that
it works normally.

If you are sure all you dependencies are declared you can begin to bundle
your application.

Preparing Pylunch for you application
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Go back to the pylunch directory and edit the pylunch.cfg file (a sample is
give in the sources as a template).

Edit the `product` by putting `supertg` you like, and also set a `version`
number, vendor and copyright can be omitted if you want they are used for
the windows installer autocreation which is another part of the docs :)

This `product` variable will determine the executable name that will be
produced.  The exe can be renamed without consequence later on.

For the moment please leave the `embark_gtk` flag to `false`. If you set this
to yet, pylunch will search your system for the gtk dlls and environment and
copy them to the right place in the distribution folder. This is in case you
have an application using pyGTK and you have GTK install on the system and
properly installed. We don't need this in our example.

If you have PIL and require it, set the `embark_PIL` flag to `True`. If you don't
know what is PIL or don't need it, then leave the flag to `False`.

Leave the `makensis_path` empty for the moment. If you have an NSIS script for
the _resulting_ application produced by pylunch, then you'll be able to auto
build the installer using NSIS commands directly during the build process.

In the additionnal_libs section, you'll find the `main_lib` setting. This is the
most important one: Here you need to provide either the full path to an application
directory that contains a proper setup.py that can be used by `easy_install` or
you can alternatively give a name like "MyApp == 0.5".

If you provide an application string you'll need to provide also the `index_url`
information to help pylunch find your application and it's requirements.

In our example we wil give the full path to our application we just created.
We won't need an index. Here is what we will put in additional_libs::

    main_lib = c:/progs/supertg

If you created your application in another directory, please change accordingly.

Building our application
~~~~~~~~~~~~~~~~~~~~~~~~

To build the portable application you need to run the following command::

    python setup.py py2exe

At this point you should have a new directory called pylunch_dist.

Configuring the service
~~~~~~~~~~~~~~~~~~~~~~~~

To control the service *you need to be logged as an administrative account
or to run a shell with an administrative account*.

You have an exe called `paster-service-control.exe` you should run it with
a command like this one::

    paster-service-control.exe -c c:\deployment\supertg\development.ini -l c:\deployment\supertg\logs

the `-c` option must point to your `development.ini` or `production.ini`
configuration file for the supertg application we created in the beginning
of this document. The file can be anywhere you want.

the `-l` should point to a directory where the service can create some log
files. Those logs files are not the ones that you configure for your
application. They are just in case something is written to stdout
and is catched.

Installing the service
~~~~~~~~~~~~~~~~~~~~~~

To install the service you need to be logged as an administrative account or to
run a shell with an administrative account. Then proceed with this commmand::

    paster-service -install

This will add your service to the control panel. Go to the control panel and
start the service... The service is named by the name you have choosen
in the config.ini file that is alongside the paster-service.exe, so if you did
not change this it should be named pasterWSGI.

It is important to note that each service must have a different name under
windows, so if you need to run two such services at the same time, copy
the pylunch_dist directory, and change the service name inside the
config.ini file.

Please also note that the services use the registry keys that are written
by the `paster-service-control.exe`. If you change the name of the service
inside the configuration you will need to also change the registry keys by
running the `paster-service-control.exe` again.

For information, the registry keys are as follows::

    HKEY_LOCAL_MACHINE\SOFTWARE\pylunch\pasterservice\pasterWSGI

where the last part is the service name you have choosen in the config file.

Then you can find the two config parameters that the service will use:

    - ConfigFilePath
    - LoggingDir

.. image:: ../_static/service-registry-keys.png


.. _TurboGears2: http://www.turbogears.org/2.0
