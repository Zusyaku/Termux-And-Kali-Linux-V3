from pylunch.launcher import Launcher

# config.ini should be present in same dir as the exec dir
launcher = Launcher('config.ini')

# run the real app
launcher.launchapp()
