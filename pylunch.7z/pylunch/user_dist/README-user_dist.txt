The content of the user_dist folder will be merged with the root install directory during the build process.

If for any reason you need to deploy a DLL or a data file that would not be found by our setup.py file you could put this here.

You can even drop a full directory structure of whatever kind of files you want and it will be  blended in the root directory during build.
