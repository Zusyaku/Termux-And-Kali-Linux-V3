# python import
import sys
import os
import shutil
import glob
#
from ConfigParser import ConfigParser
from subprocess import Popen
# distutils
from distutils.command.build import build
from distutils.command.clean import clean
from distutils.core import Command
# setup tools
from setuptools import setup, find_packages
from setuptools.command import easy_install
# py2exe
import py2exe

# read the pylunch config
config = ConfigParser()
config.read("setup.cfg")

# read specific user config
user_config = ConfigParser()
user_config.read("pylunch.cfg")

###PYLUNCH CONFIG
PRODUCT = config.get("setup", "name")
VERSION = config.get("setup", "version")
DESCRIPTION = config.get("setup", "description")
LONG_DESCRIPTION = config.get("setup", "long_description")
AUTHOR = config.get("setup", "author")
AUTHOR_EMAIL = config.get("setup", "author_email")
URL = config.get("setup", "url")
LICENSE = config.get("setup", "license")
COPYRIGHT = config.get("setup", "copyright")
COMPANY = config.get("setup", "company")
###PYLUNCH CONFIG

#SETUP CONFIG
BUILD_BASE = "build"
#
DIST_DIR = "%s_dist" % PRODUCT
USER_DIST_DIR = "user_dist"
RT_MANIFEST = 24
#SETUP CONFIG

###NSI CONFIG
MAKENSIS_EXECUTABLE = user_config.get("main", "makensis_path")
NSI_FILE = './installer/pylunch.nsi'
#
USER_PRODUCT = user_config.get("main", "product")
USER_VENDOR = user_config.get("main", "vendor")
#
USER_VERSION = user_config.get("main", "version")
MAJOR_VERSION = USER_VERSION.split(".")[0]
MINOR_VERSION = USER_VERSION.split(".")[1]
###NSI CONFIG

# modules that must be embarked by py2exe
modules = [
        "pywintypes",
        "win32api",
        "win32con",
        "win32evtlog",
        "win32evtlogutil",
        "win32file",
        "win32process",
        "win32security",
        "win32service",
        "winerror",
        ]

# in case we need to include in the freezed application something specific
our_packages = []
#
dll_excludes = []
# we don't want paste.script to be in the frozen app because we
# put it in our requirements with the normal python eggs
excludes = ["paste.script"]

class Clean(clean):
    """a cleaner to make our work easier
    """
    def run(self):
        self.do_clean()

    def do_clean(self):
        top = os.getcwd()
        if os.name == "nt":
            self.__removedirs(os.path.join(top, DIST_DIR))
            self.__removedirs(os.path.join(top, BUILD_BASE))
            self.__removefiles(top, "pyc")

    def __removedirs(self, top):
        for root, dirs, files in os.walk(top, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))
        if os.path.exists(top):
            os.rmdir(top)

    def __removefiles(self, top, suffix):
        for root, dirs, files in os.walk(top):
            for name in files:
                if name.endswith(suffix):
                    os.remove(os.path.join(root, name))

class NSI(Command):

    user_options = [('version', 'V', "Set version")]

    def initialize_options(self):
        self.version = USER_VERSION

    def finalize_options(self):
        pass

    def need_py2exe(self):
        return True

    def run(self):
        """
        """
        #
        src_dir_ = os.path.abspath(DIST_DIR)
        usr_dir_ = os.path.abspath(USER_DIST_DIR)
        dest_dir_ = os.path.abspath('installer')

        #
        call_args = [
                    MAKENSIS_EXECUTABLE,
                    '/DProduct=%s' % USER_PRODUCT,
                    '/DVendor=%s' % USER_VENDOR,
                    '/DVersion=%s' % USER_VERSION,
                    '/DMajorVersion=%s' % MAJOR_VERSION,
                    '/DMinorVersion=%s' % MINOR_VERSION,
                    '/DSRCDIR=%s' % src_dir_,
                    '/DINSTDIR=%s' % dest_dir_,
                    '/DUSRDIR=%s' % usr_dir_,
                    NSI_FILE
                    ]
        #
        Popen(args=call_args)

class Target(object):
    """a basic target for our build system
    """
    def __init__(self, **kw):
        self.__dict__.update(kw)
        # for the versioninfo resources
        self.version = user_config.get("main", "version")
        self.company_name = user_config.get("main", "vendor")
        self.copyright = user_config.get("main", "copyright")
        self.name = user_config.get("main", "product")

class MyBuild(build):
    """redefine where is the build base
    """
    build_base = BUILD_BASE
    sub_commands = []
    sub_commands.extend(build.sub_commands)

    def initialize_options(self):
        build.initialize_options(self)

    def finalize_options(self):
        build.finalize_options(self)

    def run(self):
        build.run(self)

# an xml template file for winXP control
manifest_template = """
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
<assemblyIdentity
    version="5.0.0.0"
    processorArchitecture="x86"
    name="%(prog)s"
    type="win32"
/>
<description>%(prog)s Program</description>
<dependency>
    <dependentAssembly>
        <assemblyIdentity
            type="win32"
            name="Microsoft.Windows.Common-Controls"
            version="6.0.0.0"
            processorArchitecture="X86"
            publicKeyToken="6595b64144ccf1df"
            language="*"
        />
    </dependentAssembly>
</dependency>
</assembly>
"""

def mkdirif(dst):
    if not os.path.exists(dst):
        os.mkdir(dst, 0777)

def get_python_dir():
    python_dir, tail = os.path.split(sys.executable)
    if "Scripts" in python_dir:
        # we are in a virtual-env... we should remove this "Script"
        # element from our path
        # TODO: this is crappy and will surely not survive real life
        newpythondir, tail = os.path.split(python_dir)

    else:
        newpythondir = python_dir

    return newpythondir

def embark_python():
    """copy all the relevant python files to our embarked
    python directory
    """
    print "Copying system python to distribution"

    # we want to bundle the python that is being used to
    # run this script, not another one
    python_dir = get_python_dir()
    
    mkdirif(DIST_DIR)
    python_distdir = os.path.join(DIST_DIR, "python")
    mkdirif(python_distdir)

    mkdirif(os.path.join(python_distdir, "DLLs"))
    mkdirif(os.path.join(python_distdir, "Lib"))
    mkdirif(os.path.join(python_distdir, "additional_libs"))

    # copy all DLLs we want
    source_dlls = glob.glob("%s/DLLs/*" % python_dir)
    for source_dll in source_dlls:
        target_dll = os.path.basename(source_dll)
        shutil.copyfile(source_dll, os.path.join(python_distdir, "DLLs", target_dll))

    # copy all std lib but not the site-packages
    source_stdlibdir = os.path.join(python_dir, "Lib")
    source_stdlibs = os.listdir(source_stdlibdir)

    target_stdlibdir = os.path.join(python_distdir, "Lib")

    for source_stdlib in source_stdlibs:

        if not os.path.isdir(os.path.join(source_stdlibdir, source_stdlib)):
            base_src_file = os.path.basename(source_stdlib)
            shutil.copyfile(
                    os.path.join(source_stdlibdir, source_stdlib),
                    os.path.join(target_stdlibdir, base_src_file)
                    )

        else:
            if not "site-packages" in source_stdlib:
                if not os.path.exists(os.path.join(target_stdlibdir, source_stdlib)):
                    shutil.copytree(
                        os.path.join(source_stdlibdir, source_stdlib),
                        os.path.join(target_stdlibdir, source_stdlib)
                        )

            else:
                sitepackages = os.path.join(
                    target_stdlibdir, "site-packages")

                if not os.path.exists(sitepackages):
                    mkdirif(sitepackages)

def embark_gtk():
    """copy all the relevant gtk files to our embarked
    gtk directory
    """
    print "Copying system gtk to distribution"

    # find the GTK base path first pass
    # ex.: "C:\\GTK" or None
    gtk_base_path_ = os.getenv("GTK_BASEPATH")

    # init bin path var
    gtk_bin_path_ = None

    # add bin sub folder in path
    if gtk_base_path_:
        gtk_bin_path_ = os.path.join(gtk_base_path_, "bin")

    # 2cnd pass
    else:
        # get the env path
        env_path_str_ = os.getenv("PATH")
        # split
        env_path_list_ = env_path_str_.split(";")
        # search..
        for path_ in env_path_list_:
            # we find the path
            if path_.find("GTK") > 0:
                gtk_bin_path_ = path_.strip()
                break

    # no 3rd pass
    if not gtk_bin_path_:
        print "GTK path not found in environment paths!"
        sys.exit(1)

    # copy bin files
    list_bin_files_ = os.listdir(gtk_bin_path_)
    # do copy
    for file_ in list_bin_files_:
        # build source path
        src_path_ = os.path.join(gtk_bin_path_, file_)
        # find a dll to copy
        if os.path.isfile(src_path_) \
        and not os.path.splitext(file_)[1] == ".exe":
            # build copy paths
            dest_path_ = os.path.join(DIST_DIR, file_)
            # copy
            shutil.copyfile(src_path_, dest_path_)

    # etc dirs for copy
    etc_src_dir_ = os.path.join(gtk_bin_path_, "..", "etc")
    etc_dist_dir_ = os.path.join(DIST_DIR, "etc")
    # do etc copy
    if not os.path.isdir(etc_dist_dir_):
        shutil.copytree(etc_src_dir_, etc_dist_dir_)

    # lib dirs for copy
    lib_src_dir_ = os.path.join(gtk_bin_path_, "..", "lib")
    lib_dist_dir_ = os.path.join(DIST_DIR, "lib")
    # do lib copy
    if not os.path.isdir(lib_dist_dir_):
        shutil.copytree(lib_src_dir_, lib_dist_dir_)

    # share dirs for copy
    share_src_dir_ = os.path.join(gtk_bin_path_, "..", "share")
    share_dist_dir_ = os.path.join(DIST_DIR, "share")
    # make dir for specific copy
    if not os.path.isdir(share_dist_dir_):
        mkdirif(share_dist_dir_)
    # share/icons copy
    icons_src_dir_ = os.path.join(share_src_dir_, "icons")
    icons_dist_dir_ = os.path.join(share_dist_dir_, "icons")
    # do icons copy
    if not os.path.isdir(icons_dist_dir_):
        shutil.copytree(icons_src_dir_, icons_dist_dir_)
    # share/themes copy
    themes_src_dir_ = os.path.join(share_src_dir_, "themes")
    themes_dist_dir_ = os.path.join(share_dist_dir_, "themes")
    # do themes copy
    if not os.path.isdir(themes_dist_dir_):
        shutil.copytree(themes_src_dir_, themes_dist_dir_)

def embark_PIL():
    """copy all the relevant PIL files to our embarked
    python directory
    """
    print "Copying PIL to distribution"

    # we want to bundle the python that is being used to
    # run this script, not another one
    python_dir = get_python_dir()


    # get src pil dir
    source_PILdir = os.path.join(python_dir,
            "Lib", "site-packages", "PIL")
    
    # get dest pil dir
    dist_PILdir = os.path.join(DIST_DIR, "python",
            "Lib", "site-packages", "PIL")

    # copy all PIL
    if not os.path.isdir(dist_PILdir):
        shutil.copytree(source_PILdir, dist_PILdir)

def embark_additional_libs():
    """easy install pygtk wrappers in the site-package
    """
    print "Installing additional libs in portable python env"

    # easy install command
    args_ = list()

    try:
        # read index url from config
        index_url_ = user_config.get('additional_libs', 'index-url')
        # use it if exist
        if index_url_:
            args_.append('-i')
            args_.append(index_url_)
    except:
        #print 'No index-url option...'
        pass

    try:
        # are the additionnal libs to be considered zipsafe ?
        zip_safe_ = user_config.getboolean('additional_libs', 'zip-safe')

        # seems not... then we should unzip all of them
        if zip_safe_ == False:
            args_.append('-Z')

    except:
        #print 'No zip-safe option...'
        pass

    # force install all
    args_.append('-a')

    # get dist site packages path for additionnal lib install
    sitepackages_ = os.path.join(DIST_DIR, "python",  "Lib", "site-packages")

    # set the destination path
    args_.append('-d')
    args_.append('%s' % sitepackages_)

    # avoid PYTHONPATH
    ori_python_path_ = os.environ.get('PYTHONPATH', None)
    os.environ['PYTHONPATH'] = sitepackages_

    # set the main lib to be included
    args_.append(user_config.get('additional_libs', 'main_lib'))

    # easy install action
    try:
        # do easy install
        easy_install.main(args_)
        # restore original python path
        if ori_python_path_:
            os.environ['PYTHONPATH'] = ori_python_path_

    except Exception, e:
        print 'Easy install error %s' % e
        sys.exit(1)

    # restore original python path
    if ori_python_path_:
        os.environ['PYTHONPATH'] = ori_python_path_

# pylauncher.exe
pylauncher = Target(
    description = "Launcher application",
    script = "pylauncher.py",
    icon_resources = [(1, "data\\py.ico")],
    other_resources = [(RT_MANIFEST, 1, manifest_template % dict(prog="Python Launcher"))],
    dest_base = USER_PRODUCT)

# pylauncher_console.exe
pylauncher_console = Target(
    description = "Launcher for console applications",
    script = "pylauncher.py",
    icon_resources = [(1, "data\\py.ico")],
    other_resources = [(RT_MANIFEST, 1, manifest_template % dict(prog="Python Launcher"))],
    dest_base = "%s_console" % USER_PRODUCT)

# paster emulation
paster = Target(
    description = "Paster front-end for portable applications",
    script = "pasterlauncher.py",
    icon_resources = [(1, "data\\py.ico")],
    other_resources = [(RT_MANIFEST, 1, manifest_template % dict(prog="paster"))],
    dest_base = "paster")

# this is a service but we package it as a normal EXE, so that we are not
# limited by py2exe simple service system.
pasterservice = Target(
    description = "Paster packaged as a service to start HTTP based apps",
    modules = ["pylunch.pasterservice"],
    icon_resources = [(1, "data\\py.ico")],
    other_resources = [(RT_MANIFEST, 1, manifest_template % dict(prog="paster-service"))],
    dest_base = "paster-service")

# controller for the service to configure it
pasterservicecontrol = Target(
    description = "Paster packaged as a service to start HTTP based apps",
    script = "pylunch/serviceutils/controller.py",
    icon_resources = [(1, "data\\py.ico")],
    other_resources = [(RT_MANIFEST, 1, manifest_template % dict(prog="paster-service"))],
    dest_base = "paster-service-control")


# py2exe invoked. We need to define some default files
if "py2exe" in sys.argv:
    #
    embark_python()

    #
    embark_additional_libs()

    # gtk invoked. We need to add gtk file to be portable
    if user_config.getboolean('main', 'embark_gtk'):
        embark_gtk()

    # User says its application will require PIL... we must include it in our ENV
    if user_config.getboolean('main', 'embark_PIL'):
        embark_PIL()

    
DATA_FILES=[
    (".", (
            "config.ini-sample",
             )),
    ("data", (
            "data/py.ico",
            )),
    ]

setup(
      name=PRODUCT,
      version=VERSION,
      description=DESCRIPTION,
      long_description=LONG_DESCRIPTION,
      classifiers=[],
      keywords="Python Windows Portable",
      author=AUTHOR,
      author_email=AUTHOR_EMAIL,
      url=URL,
      license="MIT",
      packages=find_packages(exclude=["ez_setup", "examples", "tests"]),
      include_package_data=True,
      zip_safe=True,
      install_requires=[
          # -*- Extra requirements: -*-
      ],
      options = {
        "py2exe": {
        "compressed": 1,
        "optimize": 2,
        "packages": our_packages,
        "includes": modules,
        "excludes": excludes,
        "dll_excludes": dll_excludes,
        "dist_dir": DIST_DIR,
        },
      },
      scripts = ["pylauncher.py"],
      zipfile = "libs/shared.lib",
      # pasterservice-control is bundled as a simple exe by py2exe
      console = [pylauncher_console, paster, pasterservicecontrol],
      windows = [pylauncher],
      # the real service
      service = [pasterservice],
      data_files = DATA_FILES,
      cmdclass = {
        'clean': Clean,
        'nsi': NSI,
        },
      entry_points="""
      # -*- Entry points: -*-
      """,
      )
