# AMAZON VALIDATOR

usage ? php start.php