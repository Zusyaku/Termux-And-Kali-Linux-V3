# vBulletin-0Day-Auto-shell
Auto Shell upload &amp; Patch vulnerability
