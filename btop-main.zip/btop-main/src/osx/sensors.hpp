
namespace Cpu {
	class ThermalSensors {
	   public:
		long long getSensors();
	};
}  // namespace Cpu
