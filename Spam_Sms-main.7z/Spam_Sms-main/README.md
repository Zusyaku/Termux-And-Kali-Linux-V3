# Spam_Sms
```python
$ cd Spam_Sms
$ pip install -r requirements.txt
$ python Run.py
```
