
<p align="center">
<img src="https://img.shields.io/badge/Vaim-Samay-green" width="150" height="25"><br>
<img title="Vaim-IP" src="https://img.shields.io/badge/version-1.0-red" width="100" height="25"><br>
<!--img src="vaim-ip.png"><br-->
</center>
</p>

### What is Vaim-Samay-LinkEx?
> This is use for track location or logout all google account using only one click.
> Many times you just want to track or prank.
> If you find yourself in that situation then this Tool is the perfect tool for you!
> this tool made by @vaimpier_ritik x @_vilen_bhoi_ ( samay826 )

- Track Exact Location
- Remove all Google account 
- The author is not responsible for any issues or damage caused by this program and don't use illegel purpose
- This exploit doesn't work in only android google chrome 

<br>

### Installation & Step's in Kali Linux or else
 
> `apt update && apt upgrade`

> `git clone https://github.com/VaimpierOfficial/Vaim-Samay`
 
> `cd Vaim-Samay` 
 
> `bash setup.sh`

<br>

### Opening & Step's
 
> `python3 Vaim-Samay.py`

<br>

### Support Me On
Facebook [@Vaimpier_Ritk](https://www.facebook.com/vaimpier.ritik.143)<br>
Instagram [@Vaimpier_Ritik](https://instagram.com/vaimpier_ritik)<br>
Youtube [@Vaimpier_Ritik](https://www.youtube.com/channel/UCDWhaLh7OIKzH4Bk952l7Iw)

### Support Samay on
Instagram [@Samay](https://instagram.com/_vilen_bhoi_)<br>
Youtube [@Samay](https://www.youtube.com/c/CYBOGHACKERS)

### For Video Tutorial
- <a href="https://www.youtube.com/watch?v=nouYD9aRZrI"> CLICK HERE AND SEE TUTORIAL FOR LAPTOP</a>
- <a href="https://www.youtube.com/watch?v=nouYD9aRZrI"> CLICK HERE AND SEE TUTORIAL FOR ANDROID</a>

