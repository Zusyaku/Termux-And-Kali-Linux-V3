#!/usr/bin/perl

# $|=1;
print "Content-type: text/html\n\n";
$CGI_NAME ='PerList';
$VERSION='2.0';
#                                                                                       #
##############################################################################
# This is a freeware script written by Anas Elhalabi, MD.                                               
# You can change anything you want in it, but let me tell you something                     
# It won't really work if you damage the core of it.                                                        
# Other awsome scripts are available on  http://perlmart.cjb.net                                   
# If you need help installing this script you can always go to                                        
# http://perlmart.cjb.net      or email me at       aelhalabi@hotmail.com
#
# This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA                             
##############################################################################
# Banned Email Addresses.
#
@emails_bannis = ('john@johndoe.xxx','joe@joedoe.xxx');
##############################################################################

# Defaults #
$mailprog = '';
$admin_email='you@your-site.com';
$list_name="My Mailing List";
$passwd="perlist";
$sendto="1";
$temp="1";
$data_dir='perlistdata';
$fichier_inscrits = "$data_dir/list.txt";
$fichier_confirm="$data_dir/temp.txt";
$fichier_conf="$data_dir/config.txt";
##############################################################################
##############################################################################
##############################################################################

##  ##
&init;

## 
if($ENV{'QUERY_STRING'} eq 'admin') { 
  &msgfin('Admin Login:',"<center><form action=\"$script_url\" METHOD=\"POST\">
                                     password:  <input type=\"password\" name=\"passwd\"><BR><BR>
                                     <input type=\"submit\" value=\"Login\"></FORM></center>");
}

# 
if ($ENV{'REQUEST_METHOD'} eq 'POST') {
  %form=&receivepost;
} elsif ($ENV{'QUERY_STRING'} ne '') {
  %form=&receiveget;
} else {
  &msgfin('Information',"No Parameters given, PerList can not run this way.<br>PerList is a mailing list manager written in Perl<br>
           Visitors of your site can subscribe/unsubscribe to your mailing list and you can send periodic newsletter with the ability 
           of archiving them.");
}

## 
if ($form{'passwd'}) {&admin; exit;}

##  ##
if ($form{'confirm'}) { &confirm ($form{'confirm'}); }

## ##
if ($form{'remove'}) { &unsubscribe($form{'remove'}); }

##  ##
if (lc($form{'action'}) eq 'inscription') 	{&subscribe($form{'adresse'});}

## ##
if (lc($form{'action'}) eq 'desinscription') 	{&unsubscribe($form{'adresse'})}
if (lc($form{'action'}) eq 'd�sinscription') 	{&unsubscribe($form{'adresse'})}


## ##
&msgfin('Unknown Command',"Unknown Command<br>PerList is a mailing list manager written in Perl<br>
           Visitors of your site can subscribe/unsubscribe to your mailing list and you can send periodic newsletter with the ability 
           of archiving them.");
1;

#Safi Safi That's it
################################################
############ SUBROUTINES###################
################################################
sub receivepost {
local(%postdata)=();
local ($len,$d,$data,$nom,$valeur)=();

  if ($ENV{'REQUEST_METHOD'} eq 'POST') {
    $len=$ENV{'CONTENT_LENGTH'};       # 
    $data='';                          # 
    if (read(STDIN,$data,$len) !=$len) {       # 
      print ("<H1>error reading post data </H1>");
      die("Error reading 'POST' data\n") ;
    }
    foreach $d (split('&',$data)) {            # 
      ($nom,$valeur)=split('=',$d);      #
      $nom=&url_decode($nom);
      $valeur=&url_decode($valeur);
      if (!$postdata{"$nom"}) {
        $postdata{$nom}=$valeur;                  # 
      } else {
        $postdata{$nom}.=',,'.$valeur;             # 
      }
     }
#    } else {
#      print ("Content-type: text/html\n\n<H1>webmaster says : Post Error in CGI method <BR>GO BACK and TRY again</H1>You can\'t access this way.");
#      exit; 
  }
  return %postdata ;
}
################################################
sub url_decode {
  local ($s)=@_;
  $s=~ tr/+/ /;
  $s=~ s/%([0-9A-F][0-9A-F])/pack("C",oct("0x$1"))/ge;
  $s;
}
################################################
sub receiveget {
local(%postdata)=();
local ($data,$d,$nom,$valeur)=();

  if ($ENV{'REQUEST_METHOD'} eq 'GET') {
    $data=$ENV{'QUERY_STRING'};
    foreach $d (split('&',$data)) {            # 
      ($nom,$valeur)=split('=',$d);      # 
      $nom=&url_decode($nom);
      $valeur=&url_decode($valeur);
      $postdata{$nom}=$valeur;                  # 
    }
  } else {
    print ("Content-type: text/html\n\n<H1>webmaster says : GET Error in CGI method <BR>GO BACK and TRY again</H1>You can\'t access this way.");
    die ("webmaster says : GET Error in CGI method") ; 
  }
  return %postdata ;
}
################################################
sub verifie_email {
  local ($email)=@_;
  if ($email eq '') { return(0);}
  if ($email!~ /\@/) { return(0);}
  if ($email=~ /[\,|\s|\;]/) {return (0)};
  if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/ || 
     ($email !~ /^.+\@localhost$/ && 
      $email !~ /^.+\@\[?(\w|[-.])+\.[a-zA-Z]{2,3}|[0-9]{1,3}\]?$/)) {
    return(0);  # email non valide
  }else{
    return(1);  # email valide
  }
}
################################################
sub msgfin {
local ($titre,$tip)=@_;



  print <<_EOLERROR_;
   <html>
  <head> <title>PerList</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<meta NAME="TITLE" CONTENT="PerlMart PerList By Anas Elhalabi">
<meta NAME="DESCRIPTION" CONTENT="PerList is a powerful mailing list manager in Perl">
<meta NAME="KEYWORDS" CONTENT="Perl,CGI,list,mailing,mailinglist,perlist,Anas,Elhalabi,Perlmart">
<meta HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<meta HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="French, EN-US">
<meta HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Document">
<meta NAME="REVISIT-AFTER" CONTENT="7 days">
<meta name="robots" content="ALL">
<meta name="rating" content="GENERAL">
<meta http-equiv="expires" content="Mon, 31 Dec 2099 00:00:00 GMT">
<meta http-equiv="pragma" content="no-cache">
<meta name="distribution" content="GLOBAL">
<meta name="copyright" content="This code is Copyright (C) 2000-02 Anas Elhalabi">
<style>
a:link    {color: #CCFF00; text-decoration: none; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
a:visited {color: #CCFF00; text-decoration:none; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
a:hover   {color: BLACK; background-color: #ffcc00; text-decoration: underline overline; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
INPUT,SELECT { 

	color : #000000;
	background : #ffffff;
	border-top : 1px solid;
	border-bottom : 1px solid;
	border-left : 1px solid;
	border-right : 1px solid;
	font-family : Verdana;
	font-size : 9px;
	font-weight: bold;
	}
  </style></head>
  <body bgcolor="#537895" text="#000000" link="#FF0000" vlink="#FF0000" alink="#FF0000">

  <p>&nbsp;</p>
  <div align="center"><center>

  <table border="0" width="80%" bgcolor="#C0C0C0">
    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><B><font face="verdana" color="#C0C0C0" size="1">$titre</b></font></B></td>
    </tr>
    <tr>
      <td width="100%" bgcolor="#A6A6FF">
       <p>&nbsp;</p>
       <font face="Verdana" size="1"><b>
       $tip</b></b></font>
       <p>&nbsp;</p>
      </td></tr>


    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><strong>
       <font face="verdana" color="#C0C0C0" size="1">
      $CGI_NAME v$VERSION - &copy;  
      By <a href="http://perlmart.cjb.net">PerlMart</a> </font></strong></td>
    </tr>
  </table>  </center></div>
  </body>
  </html>
_EOLERROR_


  exit(0);                                      # 
}
###############################################
sub init {
local ($line);


@months = ('January','February','March','April','May','June','July','August','September','October','November','December');
@days   = ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
  ($mday,$mon,$year,$wday) = (localtime(time))[3,4,5,6];
  $year += 1900;	
  $date = "$mday\-$months[$mon]\-$year";

  $url = $ENV{'SERVER_NAME'};
  #$script_url = $ENV{'SCRIPT_NAME'}; # modif V2.05
  $script_url=($ENV{'REQUEST_URI'} || $ENV{'SCRIPT_NAME'}); #
  $script_url=~ s/\?.*//gs;

  ########################################
  #
  if (!(-e "$fichier_inscrits")) {
    open (CRW1,">$fichier_inscrits") || (&msgfin('ERROR',"PerList couldn\'t create the text file <b> $fichier_inscrits:$! <br><br> Please create a directory called  <font color=red><b>$data_dir</b></font> and give it 777 Chmod permissions!"));
    close (CRW1);
    eval {chmod (0777,$fichier_inscrits)};
    &msgfin("PerList Installation Wizard<br><font color=\"#FF0000\">Step :  1/4</font>",
            "<center><TABLE width=\"90%\" border=\"0\" ALIGN=\"center\"><TR><TD><p align=\"center\"><font face=\"Verdana\" size=\"2\">
             <b>Welcome !</b></p><p>
             You are running this script for the first time. This wizard will automatically create some files necessary for PerList to run, 
             then you will be asked to setup your preferences, this will save you time trying to configure this script manually.<br>

             </font></TD></TR></TABLE></center>
             <p align=\"center\">The text file that will store your subscribers was successfully created.<br><br>
             <b>Please reload this page to continue.<b><br>
             </p>");
  }

  # 
  if (!(-e "$fichier_confirm")) {
    open (CRW2,">$fichier_confirm") || (&msgfin('ERROR',"PerList couldn\'t create the text file <b> $fichier_confirm:$! <br><br> Please create a directory called  <font color=red><b>$data_dir</b></font> and give it 777 Chmod permissions!"));
    close (CRW2);
    eval {chmod (0777,$fichier_confirm);}
    &msgfin("PerList Installtion Wizard<br><font color=\"#FF0000\">Step :  2/4</font>",
            "<center><TABLE width=\"90%\" border=\"0\" ALIGN=\"center\" bgcolor=\"#000000\" cellspacing=\"1\" cellpadding=\"1\"><TR bgcolor=\"#ffffff\"><TD><p align=\"center\"><font face=\"Tahoma\" size=\"1\" color=\"red\"><b>
             <b><u>License Agreement</u></b></p><p>
	In all outgoing messages a small mention of this script and PerlMart will be displayed, removal of that mention is a clear violation 	of the copyright agreement.
	This program is free software under the terms of the GNU General Public License as published by  
	the Free Software Foundation; either version 2 of the License.<br>
	Copyright (c) 2002 by Anas Elhalabi (aelhalabi@hotmail.com)<br>
	http://perlmart.cjb.net<br></b>
             <br>
             </font></TD></TR></TABLE></center>
             <p align=\"center\">The text file that will store the temporary subscribers email addresses awaiting confirmation has been successfully created.<br><br>
             <b>Please reload this page to continue.<b><br>
             </p>");
  }

  # 
  if (!(-e "$data_dir/log.txt")) {
    open (CRW3,">$data_dir/log.txt") || (&msgfin('ERROR',"PerList couldn\'t create the text file <b> $data_dir/log.txt:$! <br><br> Please create a directory called  <font color=red><b>$data_dir</b></font> and give it 777 Chmod permissions!"));
    close (CRW3);
    eval {chmod (0777,"$data_dir/log.txt");}
    &msgfin("PerList Installtion Wizard<br><font color=\"#FF0000\">Step :  3/4</font>",
            " <p align=\"center\">The text file that will store the archives of all the message you send to your subscribers has been successfully created.<br>
             &nbsp; <br>
             <b>Please reload this page to continue.<b><br>
             </p>");
  }

  # 
  if (!(-e "$data_dir/.htaccess")) {
    open (HTACCESS,">$data_dir/.htaccess") || (&msgfin('ERROR',"Couldn\' t create the security file<font color=red> $data_dir/.htaccess:$! <br><br></font> Please create a directory called  <font color=red><b>$data_dir</b> </font> and give it 777 Chmod permissions!"));
    print HTACCESS "<Limit GET POST>\norder deny,allow\ndeny from all\n</Limit>";
    close (HTACCESS);
    eval {chmod (0666,"$data_dir/.htaccess");}
    &msgfin("PerList Installtion Wizard<br><font color=\"#FF0000\">SECURITY !</font>",
            "<center><TABLE width=\"90%\" border=\"0\" ALIGN=\"center\"><TR><TD><p align=\"center\"><font face=\"Verdana\" size=\"2\">
             <b>Data directory security</b></p><p>
             Certain servers allow listing and viewing of directories and files within the cgi-bin directory .<br>&nbsp;<br>
             In order to stop that from happening to your data directory <b><font color=red>$data_dir</b></font> 
             a .htaccess file is automatically created in with the right permissions depending on your server.<br>&nbsp;<br>
             Sometimes you can\'t view this .htaccess file through FTP (usually on Cobalt servers).<br>
             It will be there after the script has finished installing.<br>
             </font></TD></TR></TABLE></center>
             <p align=\"center\">The security file <font color=red> $data_dir/.htaccess </font> was successfully created.<br><br>
             <b>The last step will let you configure your Mailing-List.
             <br>&nbsp; <br>
             
             <b>Please reload this page to continue.<b><br>
             </p>");
  }

  # 
  if (!(-e "$fichier_conf")) {
    # 
    %form=&receivepost; 
    if ($form{'ORD_change_param_do'}) {		# 
      &admin_change_param_do;			# 
    } else {					# 
      &admin_change_param;			# 
    }
  }
  ################################################
  open (CONFR,"$fichier_conf") || (&msgfin('ERROR',"PerList couldn\' t create the file  $fichier_conf !"));
  while ($line=<CONFR>) {                       # Pour chaque ligne
    chomp($line);
    # 
    if ( ($line!~ /^\#/) && ($line=~ /([^\s]+)\s+(.*)\s*$/) ) {
      ${$1}=$2;
    }
  }
  close (CONFR);

  1;
}
###############################################
sub is_in_list {
local ($tfile,$adresse)=@_;
local ($line)=('');

  # 

  open(LIST,"$tfile") || (&msgfin('ERROR',"PerList couldn\' t create the file  $tfile: $!"));
  flock(LIST,2);
  while ($line=<LIST>) {                        # 
    chomp($line);                               # 
    if ($line eq $adresse) {                    #
      close (LIST);                             # 
      return (1);                               #
    }
  }
  #flock(LIST,8);
  close(LIST);
  return (0);                                   # 
}
################################################
sub del_from_list {
local ($tfile,$adresse)=@_;
local (@adresses,$nb,$buffer);

  # 
  #     #
  open(TLIST,"$tfile") || (&msgfin('ERROR',"PerList couldn\' t create the file  $tfile: $!"));
  flock(TLIST,2);
  @addresses=<TLIST>;                           # 
  #flock(TLIST,8);
  close(TLIST);

  #
  open(WLIST,">$tfile") || (&msgfin('ERROR',"PerList couldn\' t  rewrite the file $tfile.<br>Webmaster:  Check the Chmod permissions (should be 777): $!"));
  flock(WLIST,2);
  foreach $buffer (@addresses) {                # 
    chomp($buffer);                             # 
    if ($buffer eq $adresse) {                  # 
      $nb++;                                    # 
    } else {                                    # 
      print WLIST "$buffer\n";                  # 
    }
  }
  #flock(WLIST,8);
  close (WLIST);
  return $nb;                                   # 
}
################################################
sub add_to_list {
local ($tfile,$adresse)=@_;

  #     #
  open(ADDLIST,">>$tfile") || (&msgfin('ERROR',"PerList couldn\' t  write in the file $tfile.<br>Webmaster: Check the Chmod permissions (should be 777): $!"));
  flock(ADDLIST,2);
  print ADDLIST ("$adresse\n");
  #flock(ADDLIST,8);
  close (ADDLIST);
}
################################################
sub email_admin {
local ($message)=@_;

  open (MAIL, "|$mailprog -t") || (&msgfin('INTERNAL ERROR',"PerList couldn\' t  send Email !<br>Webmaster: Correct the path to Sendmail in the PerList administration page"));
  print MAIL ("To: $admin_email\n");
  print MAIL ("From: $admin_email\n");
  print MAIL ("Subject: $list_name - Notification\n\n");
  print MAIL ("This is an automatic Message from your mailing list:  \"$list_name\"  letting you know that: \n\n");
  print MAIL ("$message\n");
  close (MAIL);
  1;
}
################################################
sub email_visiteur {
local ($destinataire,$message)=@_;

  open (MAIL, "|$mailprog -t") || (&msgfin('INTERNAL ERROR',"PerList couldn\' t  send Email !<br>Webmaster: Correct the path to Sendmail in the PerList administration page"));
  print MAIL ("To: $destinataire\n");
  print MAIL ("From: $admin_email\n");
  print MAIL ("Subject: $list_name\n\n");
  print MAIL ("$message");
  print MAIL ("\n\n\nYou can unsubscribe anytime from our mailing-list\n");
  print MAIL ("by clicking on the link below:\n");
  print MAIL ("http://$url$script_url?remove=$destinataire\n");
  ## WARNING, by deleting the following lines you're violating the Copyright agreement #
  print MAIL ("\n_________________________________________\n");
  print MAIL ("PerList. Mailing List Manager,\n Available for free http://perlmart.cjb.net\n");
  close (MAIL);
  1;
}
################################################
sub confirm {
local ($cadresse)=@_;

  if (&is_in_list($fichier_confirm,$cadresse) ) {      # 
    &add_to_list($fichier_inscrits,$cadresse);         # 
    &del_from_list($fichier_confirm,$cadresse);        # 
    &email_visiteur($cadresse,"Hi, \n\n\nThis is a confirmation of your subscription to $list_name.\n");
    if ($sendto) {
      &email_admin("The Email address  $cadresse has subscribed to your mailing list.");
    }
    &msgfin('SUBSCRIPTION CONFIRMATION !',"Thank your for confirming your subscription with <b>$cadresse</b> to <b>$list_name</b> !<br><br>
            From now on, you will receive our Newsletter! <br><br>See Yah !");
  } elsif (&is_in_list($fichier_inscrits,$cadresse) ){ # 
    &msgfin('Subscription already confirmed !',"Your subscription to  <b>$list_name</b> has already been confirmed.
             You will receive the newsletter.<br>
             If you want to unsubscribe click on the link below : <br>\n<a href=\"http://$url$script_url?remove=$cadresse\">http://$url$script_url?remove=$cadresse</a><br>Thank You ! ");
  } else {						# 
    &msgfin ('Unknown Email Address !',"The Email address <b>$cadresse</b> is neither subscribed or awaiting confirmationn.<br>
             Either you typed a wrong URL or you have already unsubscribed.");
  }
}
################################################


sub subscribe {
local ($newadresse)=@_;

  $newadresse=~ s/^\s+//;	# 
  $newadresse=~ s/\s+$//;	# 
  #                                   #
  if (&verifie_email($newadresse) ==0) {
    &msgfin ('Adresse E-Mail invalide !',"The Email address <b>$newadresse</b> is invalid.<br><br>\n Please Go back and correct that.");
  }

  #          #
  if (&is_in_list($fichier_inscrits,$newadresse)) {
    &msgfin('Inscription d�j� effectu�e !',"The Email address <b>$newadresse</b> is already subscribed (and confirmed) to <b>$list_name</b>.<br><br>
             If you want to unsubscribe directly click <a href=\"http://$url$script_url?remove=$newadresse\">here</a>.");
  }

  #  #
  if (&is_in_list($fichier_confirm,$newadresse)) {
    &email_visiteur($newadresse,"Hi,\n\n You (or someone else) has requested  subscription again to $list_name with the email address  $newadresse.\n
                    This subscription must be confirmed.
                    If you want to do so, go to :\nhttp://$url$script_url?confirm=$newadresse\n");
    &msgfin('Already subscribed, awaiting confirmation!',"The Email address
                      <b>$newadresse</b> has already requested subscription to <b>$list_name</b>.<br>
                      It will be fully subscribed after confirmation of its owner. An email has been sent again to $newadresse.");
  }

  # 
  foreach $buffer (@emails_bannis) {
    if ($buffer eq $newadresse) {
      &msgfin('Banned Email Address !',"Subscription of <b>$newadresse</b> to 
               <b>$list_name</b> has been banned by the administrator !");
    }
  }

  if ($temp eq "1") {				# 
    &add_to_list($fichier_confirm,$newadresse);	# 
    &email_visiteur ($newadresse,"Hi,\n\n  You have requested a subscription to $list_name with $newadresse.\n\n If you want to confirm your subscription please click on the link below:\nhttp://$url$script_url?confirm=$newadresse\n\n      Thank You !");
    &msgfin ('Subscription Request - Confirmation needed',"The email address <b>$newadresse</b> has been added to our temporary list and needs to be confirmed.<br><br>Please confirm your subscription by clicking on the link in the email message that has just been sent to you.");
  } else {					# 
    &add_to_list($fichier_inscrits,$newadresse); # 
    &email_visiteur ($newadresse,"Hi,\n\n  This is a confirmation of your subscription to $list_name with $newadresse.\n\n     Thank You !");
    if ($sendto) {
      &email_admin("The email address: $newadresse\n has been added to our subscribers list.");
    }
    &msgfin('Subscription Confirmation !',"Your subscription to  <b>$list_name</b> with <b>$newadresse</b> has been confirmed !<br><br> Thank You !");
  }
}
################################################
sub unsubscribe {
local ($cadresse)=@_;

  if (&is_in_list($fichier_inscrits,$cadresse)){	# 
    &del_from_list($fichier_inscrits,$cadresse);        # 
    if ($sendto) {
      &email_admin("The Email address $cadresse \n has been unsubscribed.");
    }
    &msgfin('Unsubscription',"The Email address <b>$cadresse</b> has been removed from the subscribers list.<br><br>You will no longer receive email from <b>$list_name</b> !<br><br>Thank You !");
  } elsif (&is_in_list($fichier_confirm,$cadresse)) {   # 
    &del_from_list($fichier_confirm,$cadresse);         # s
    &msgfin('Unsubscription',"The Email address <b>$cadresse</b> has been removed from the list of addresses awaiting confirmation. Your subscription has been canceled !<br>Thank You !");
  } else {
    &msgfin ('ERROR',"<b>Unknown Email Address.</b><br>
             The email address <b>$cadresse</b> is not in our database.<br>
             Either you typed the wrong URL or you have never subscribed to $list_name.");
  }
}
################################################
sub admin {

  ## ADMIN SECTION##

  # 
  if ($crypted_passwd ne '') {
    $passwd=$form{'passwd'};
    if (crypt($passwd,'aa') ne $crypted_passwd) {
      sleep(3);
      #&msgfin('WRONG PASSWORD!',"<b>You have entered a wrong password !");
      &msgfin ('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',"
                <b>The password you have entered is wrong !</b><br><br>
                Go back to the previous page and try again...<br>
                If you can\'t remember your password, the only thing to do is: <br>
	Through FTP, delete the file \"/cgi-bin/perlist/$fichier_conf\", then go to 
                (http://$url$script_url) and reconfigure your list with a new password. 
                This way all your data except your configuration will not be lost.
                (Your subscribers and Archives will not be lost).<br>");
    }
  }

  if ($form{'ORD_change_param'}) {&admin_change_param;}		# 
  if ($form{'ORD_change_param_do'}) {&admin_change_param_do;}	# 
  if ($form{'ORD_add_inscrit'}) {&admin_add_inscrit($form{'adresse'});}	# 
  if ($form{'ORD_gestion_inscrits'}) {&admin_gestion_inscrits;}# 
  if ($form{'ORD_delete_inscrit'}) {&admin_delete_inscrit;}	# 
  if ($form{'ORD_envoi_email'}) {&admin_envoi_email('');}	# 
  if ($form{'ORD_envoi_email_do'}) {&admin_envoi_email_do;}	# 
  if ($form{'ORD_archive'}) {&admin_archive;}			#
  if ($form{'ORD_french'}) {&admin_french;}				#
  if ($form{'ORD_english'}) {&admin_english;}				#


  # #
  &admin_menu;

}
################################################
sub admin_menu {
local ($nb_inscrits,$nb_archives,$buffer,$msg,$d1,$d2,$d3)=();

  # 
  $nb_inscrits='0';
  open(FF1,"$fichier_inscrits") || (&msgfin('ERROR',"PerList couldn\' t create the file  $fichier_inscrits: $!"));
  while (<FF1>) {$nb_inscrits++;}
  close(FF1);

  # 
  $nb_archives='0';
  open(FF2,"$data_dir/log.txt") || (&msgfin('ERROR',"PerList couldn\' t create the file  $data_dir/log.txt:$!"));
  @archives=<FF2>;
  $nb_archives=@archives;	# 
  close(FF2);

  # 
  if ($temp==1) { $d1='Yes';} else { $d1='No';}
  if ($sendto==1) { $d2='Yes';} else { $d2='No';}
  $d3= 'x' x length($form{'passwd'});

  $d4="\n<select name=\"archive\">\n";
  $d4.="<option value=\"\">Select... </option>\n";
  foreach $buffer(@archives) {chomp($buffer); $d4.="<option value=\"$buffer\">$buffer</option>\n"; }
  $d4.="</select>";

  $msg= <<_EOM_;
      <form method="POST" action="$script_url">
      <input type="hidden" name="passwd" value="$passwd"><div align="center"><center><table
      border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td colspan="2"><div align="center"><center><p><font face="Verdana" size="2"
          color="#0000FF"><strong>Mailing List Configuration :</strong></font></td>
        </tr> <tr>
          <td><b><font face="Verdana" size="1">List's Name :</font></td>
          <td><b><font face="Verdana" size="1">$list_name</font></td>
        </tr> <tr>
          <td><b><font face="Verdana" size="1">Administrator's Email :</font></td>
          <td><b><font face="Verdana" size="1">$admin_email</font></td>
        </tr> <tr>
          <td><b><font face="Verdana" size="1">Subscriptions Should Be Confirmed :</font></td>
          <td><b><font face="Verdana" size="1">$d1</font></td>
        </tr> <tr>
          <td><b><font face="Verdana" size="1">Email Notification to The Administrator :</font></td>
          <td><b><font face="Verdana" size="1">$d2</font></td>
        </tr> <tr>
          <td><b><font face="Verdana" size="1">Sendmail Location :</font></td>
          <td><b><font face="Verdana" size="1">$mailprog</font></td>
        </tr> <tr>
          <td><b><font face="Verdana" size="1">Password :</font></td>
          <td><b><font face="Verdana" size="1">$d3</font></td>
        </tr> <tr>
          <td colspan="2"><div align="center"><center><p>
          <input type="submit" value="Change..." name="ORD_change_param"></td>
        </tr>
      </table>
      </center></div><div align="center"><center><p><font face="Verdana" size="2" color="#000000"><strong>You currently have 
      $nb_inscrits subscriber(s) to your Mailing-List, and $nb_archives Archived Message(s).</strong></font></p>
      </center></div><div align="center"><center><table border="0" cellspacing="1">
        <tr>
          <td><div align="center"><center><p><font face="Verdana" size="2" color="#0000FF"><strong>Menu :</strong></font></td>
        </tr>
        <tr>
          <td><font face="Verdana" size="1">
          <input type="submit" value="&gt;&gt;" name="ORD_envoi_email"><B> Send Newsletter to all subscribers.</B><br>
          <input type="submit" value="&gt;&gt;" name="ORD_add_inscrit"><B> Add a subscriber: </B><input type="text" name="adresse" value="" size="20"> <br>
          <input type="submit" value="&gt;&gt;" name="ORD_gestion_inscrits"><B> View/Delete a subscriber.</B><br>
          <input type="submit" value="&gt;&gt;" name="ORD_archive"><B> View/Resend this message:</B> $d4<br>
          <input type="submit" value="&gt;&gt;" name="ORD_change_param"><B> Change Passsword.</B><br>
          <input type="submit" value="&gt;&gt;" name="ORD_french"><B>Formulaire en Francais</B><br>
          <input type="submit" value="&gt;&gt;" name="ORD_english"><B>Form in English</B></font><br><br>

		<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST">
		<input type=hidden name="ID" value="16386">
<font face=verdana size=1><b>Rate this script
</font></b><select name="rate" size="1" style="color: #ff0000; font-family: Verdana; font-size: 10px">
                <option value="5" selected>Excellent!</option>
                <option value="5">Very Good</option>
                <option value="5">Good</option>
                <option value="5">Fair</option>
                <option value="5">Poor</option>
        </select></font><font color="#CCCCCC">
        <input type="submit" value="Rate It!">
        </font></form>

</td></font>
        </tr>
      </table>
      </center></div>
    </form>


_EOM_

  # 
  &msgfin ('<b>PerList &nbsp; - &nbsp; Administration<br><font size="2">PerList, Mailing List Manager</font></strong>',$msg);

}
################################################
sub admin_change_param {
local ($d1,$d2,$buf,$d_guess_sendmail)=();


  # 
  if ($temp) {$d1='checked';} else {$d1='';}
  if ($sendto) {$d2='checked';} else {$d2='';}

  # 
  #
  foreach $buf ('/usr/lib/sendmail','/usr/bin/sendmail','/bin/sendmail','/usr/sbin/sendmail','/usr/local/bin/sendmail','/usr/local/lib/sendmail') {
    if ((-e "$buf") && (-x "$buf")) {		# 
      $d_guess_sendmail.="- $buf<br>";		# 
    }
  }
  if ($d_guess_sendmail eq'') { $d_guess_sendmail='Aucun';} # 

 $msg=<<_EOM_;
     <form method="POST" action="$script_url">
      <input type="hidden" name="passwd" value="$passwd"><div align="center"><center><p><font
      face="Tahome" color="#000000" size="2"><u><strong>Mailing-List Configuration:</strong></u></font></p>
      </center></div>
        <p></p>
      <div align="center"><center><table border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td><font face="Verdana" size="1"><strong>List Name :<br>
          </strong>This is used in the sent messages subject.<br>
          &nbsp;&nbsp; </font></td>
          <td valign="top"><font face="Verdana" size="1">Mailing-List</font>
          <input type="text" name="d_list_name" size="20" value="$list_name"></td>
        </tr> <tr>
          <td><font face="Verdana" size="1"><strong>Administrator's Email :</strong><br>
          This will appear in all sent messages.<br>
          &nbsp;&nbsp; </font></td>
          <td valign="top">
          <input type="text" name="d_admin_email" size="20" value="$admin_email"></td>
        </tr>
        <tr>
          <td><font face="Verdana" size="1"><strong>New subscriptions confirmation ? :<br>
          </strong>Check if you want PerList to send an email to each subscription request so that only real email addresses will be in your permanenet list and stop people from subscribing others.<br>
          </font>&nbsp;&nbsp; </td>
          <td valign="top">
          <input type="checkbox" name="d_temp" value="1"$d1></td>
        </tr>
        <tr>
          <td><font face="Verdana" size="1"><strong>Administrator Notification:<br>
          </strong>Check if you want to receive notification emails each time someone joins or leaves your mailing list< br>
          If you're expecting a lot of subscribers, don't check this. You'll be flooded with notification emails<br>
          </font>&nbsp;&nbsp; </td>
          <td valign="top">
          <input type="checkbox" name="d_sendto" value="1"$d2></td>
        </tr>
        <tr>
          <td><font face="Verdana" size="1"><strong>Sendmail location :<br>
          </strong>Specify the location of sendmail program in your server. PerList will look in all possible usual locations and display them but in case it can't, we recommend downloading <a href=http://perlmart.cjb.net>ServTest</a>, one of our award winning scripts. It will tell you where sendmail program is located in your server. </font><br>
          &nbsp;&nbsp; </font></td>
          <td valign="top">
          <input type="text" name="d_mailprog" size="20" value="$mailprog">
          <br><font face="Verdana" size="1"><u>Location(s) detected):</u><br><b>
          $d_guess_sendmail
          </b></font></td>
        </tr>
        <tr>
          <td><font face="Verdana" size="1"><strong>Password :<br>
          </strong>Administration password. If you want to change it (You have to if you have just installed PerList). 
          Note: It's stored crypted!<br>
          If you leave these 2 boxes empty, your password will remain the same. In case you forget it, the script will tell you how to reset it.<br>
          &nbsp;&nbsp; </font></td>
          <td valign="top"><input type="text" name="d_passwd" size="20" value=""><br>
          <input type="text" name="d_passwdbis" size="20" value=""></td>
        </tr>
        <tr>
          <td colspan="2"><div align="center"><center><p>
          <input type="submit" value="SAVE !" name="ORD_change_param_do">
          <input type="submit" value="DON'T CHANGE !" name="ORD_menu">
         </td>
        </tr>
      </table>
      </center></div><div align="center"><center><p>&nbsp;</p>
      </center></div>
    </form>


_EOM_

  &msgfin ('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',$msg);

}
################################################
sub admin_change_param_do {
local ($buffer)='';

  # Il faut modifier les param�tres de la Mailing-List
  if ($form{'d_list_name'} eq '') {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "You haven\'t specified the name of your Mailing-List!");
  }
  if ($form{'d_admin_email'} eq '') {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "You haven\'t specified the Administrator\'s Email Address (You!).");
  }
  if (&verifie_email($form{'d_admin_email'}) ==0) {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "The Email address de l\'Administrateur (<b>$form{d_admin_email}</b>) est invalide!");
  }
  if ($form{'d_mailprog'} eq '') {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "You haven\'t specified The path to sendmail. This is mandatory for sending emails. 
            <br> &nbsp;<br>
            <u>Download <a href=http://perlmart.cjb.net>ServTest</a> for more help !</u>");
  }
  if (!(-e "$form{d_mailprog}")) {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "The file $form{d_mailprog} isn\'t available, Please correct this!<br> This is mandatory for sending emails. 
            <br> &nbsp;<br>
            <u>Download <a href=http://perlmart.cjb.net>ServTest</a> for more help !</u>");
  }

  if (($crypted_passwd eq '') && ($form{'d_passwd'} eq '')) {
    &msgfin('ERROR',"This your first use of PerList, you have to choose a password!<br>Go back and choose one!");
  }
  if ($form{'d_passwd'} ne '') {			#
    if ($form{'d_passwd'} ne $form{'d_passwdbis'}) {	#
      &msgfin('ERROR',"Your 2 Passwords don\'t match.");
    } elsif (length($form{'d_passwd'}) < 3) {           # 
      &msgfin('SECURITY ERROR',"Your password  <b>$form{d_passwd}</b> is less than 4 characters. This is dangerous!<br> Please choose a 4 character (min) password.");
    } else {						# 
      $passwd=$form{'d_passwd'};			# 
      $buffer="<br><b>The password has been changed to <font color=\"#FF0000\">$passwd</font>. Note,</b> it\'s saved in a crypted 		format. You can\'t (and this program either) unscramble it. If you forget it, the script will tell you how to reset it.<br>";
    }
  }

  # 
  # Password Scrambling
  $crypted_passwd=crypt($passwd,'aa');
  open (CONFW,">$fichier_conf") || (&msgfin('ERROR',"Couldn\'t write to the file $fichier_conf !"));
  print CONFW ("list_name\t $form{d_list_name}\n");
  print CONFW ("admin_email\t $form{d_admin_email}\n");
  print CONFW ("mailprog\t $form{d_mailprog}\n");
  print CONFW ("crypted_passwd\t $crypted_passwd\n");
  print CONFW ("temp\t $form{d_temp}\n");
  print CONFW ("sendto\t $form{d_sendto}\n");
  close (CONFW);

  &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
          "Your Configuration has been saved successfully! $buffer 
           <center><p align=\"center\"><form action=\"$script_url\" METHOD=\"POST\">\n 
           <input type=\"hidden\" name=\"passwd\" value=\"$passwd\">\n
           <input type=\"submit\" value=\"Continue !\"><br> &nbsp; <br>
           Manual :<br>
           <input type=\"submit\" name=\"ORD_french\" value=\"FRENCH\">
           <input type=\"submit\" name=\"ORD_english\" value=\"ENGLISH\">
           </form></p></center>\n");



}
################################################
sub admin_add_inscrit {
local ($newadresse)=@_;

  $newadresse=~ s/^\s+//;	# 
  $newadresse=~ s/\s+$//;	# 

  #              #
  if (&verifie_email($newadresse) ==0) {
    &msgfin ('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
             "The Email Address <b>$newadresse</b> is not valid.<br><br>\n Go back and correct.");
  }

  #        #
  if (&is_in_list($fichier_inscrits,$newadresse)) {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "The Email Address <b>$newadresse</b> is already subscribed to the Mailing-List <b>$list_name</b>.<br><br>");
  }

  # #
  if (&is_in_list($fichier_confirm,$newadresse)) {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "The Email Address <b>$newadresse</b> has already requested a subscription to the Mailing-List <b>$list_name</b>.<br>
             The subscrition will be effective when its owner will confirm it through the email message sent to him/her<br><br>
             As an Administrator you can override this and confirm it now by clicking <a href=\"http://$url$script_url?confirm=$newadresse\" target=\"_blank\">here</a>.
             (close the window that will pop open).
            <center><p align=\"center\"><form action=\"$script_url\" METHOD=\"POST\">\n 
            <input type=\"hidden\" name=\"passwd\" value=\"$passwd\">\n
            <input type=\"submit\" value=\"Continue!\">\n</form></p></center>");
  }

  &add_to_list($fichier_inscrits,$newadresse);	# 
  &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
          "The Email address <b>$newadresse</b> has been successfully added to the subscribers\' list 
          <b>$list_name</b> ! No Email notifications have been sent.<br><br>
           <center><p align=\"center\"><form action=\"$script_url\" METHOD=\"POST\">\n 
           <input type=\"hidden\" name=\"passwd\" value=\"$passwd\">\n
           <input type=\"submit\" value=\"Continue!\">\n</form></p></center>");
}
################################################
sub admin_gestion_inscrits {
local ($msg,$nb_inscrits,$d1,$buffer)=();

  $nb_inscrits='0';
  open(FF1,"$fichier_inscrits") || (&msgfin('ERROR',"PerList couldn\' t create the file  $fichier_inscrits: $!"));
  while ($d1=<FF1>) {
    chomp ($d1);
    $nb_inscrits++;
    $buffer.="<option value=\"$d1\">$d1</option>\n";
  }
  close(FF1);

  $msg=<<_EOMM_;
     <form method="POST" action="$script_url">
      <input type="hidden" name="passwd" value="$passwd"><div align="center"><center><p><font
      face="Tahoma" color="#000000" size="2"><u><strong>Your Subscribers List :</strong></u></font></p>
      </center></div><blockquote>
        <p><font face="Verdana" size="1">Here's the complete list of your subscribers. If you want to delete an address 
        select it from the list and click on the [Delete] button. <br>
        (for more than 1 address use the "Ctrl" key.)</font></p>
      </blockquote>
      <div align="center"><center>
_EOMM_

  if ($nb_inscrits == 0) {
    $msg.="No Subscribers So Far !";
  } else {
    $msg.="<select name=\"adresse\" size=\"20\" multiple>".$buffer."</select>\n";
  }

  $msg.=<<_EOMMM_;
      </center></div><div align="center"><center><p><strong><font face="Verdana" size="2">You have $nb_inscrits
      subscribers.</font></strong></p>
      </center></div><div align="center"><center><p><input type="submit"
      value="Delete Selected Addresse(s)" name="ORD_delete_inscrit"><input type="submit" value="Go Back, No Deletions." name="ORD_menu"></p>
      </center></div><p>&nbsp;</p>
    </form>
_EOMMM_

  &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',$msg);
}
################################################
sub admin_delete_inscrit {
local (@todelete)=();

  @todelete=(split(',,',$form{'adresse'}));
  foreach $buffer (@todelete) {
    &del_from_list($fichier_inscrits,$buffer);        #
  }

  &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
          "The following addresses have been deleted :<br>\n- ".join("<br>\n- ",@todelete)."
           <center><p align=\"center\"><form action=\"$script_url\" METHOD=\"POST\">\n 
           <input type=\"hidden\" name=\"passwd\" value=\"$passwd\">\n
           <input type=\"submit\" name=\"ORD_gestion_inscrits\" value=\"Continue !\">\n</form></p></center>");
  

}
################################################
sub admin_envoi_email {
local ($html,$titre,$message)=@_;

  &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
     "<form method=\"POST\" action=\"$script_url\">
      <input type=\"hidden\" name=\"passwd\" value=\"$passwd\"><div align=\"center\"><center><p><font
      face=\"Verdana\" color=\"#0000FF\" size=\"3\"><u><strong>Send a NewsLetter to your subscribers :</strong></u></font></p>
      </center></div><blockquote>
        <p><font face=\"Verdana\" size=\"2\">Type in the Subject and the Message you want to send. </font></p>
        <p><font face=\"Verdana\" size=\"2\">- If you want to send a regular message do not check [HTML Format];.<br>
        - If you want to send an HTML message, just type in or paste your code in the Message Body.</font></p>
        <p>Subject : </font><input type=\"text\" name=\"d_titre\" value=\"$titre\"size=\"35\"><font face=\"Verdana\" size=\"2\"></p>
        <p>HTML Format? : <input type=\"checkbox\" name=\"d_html\" value=\"1\" $html></p>
        <div align=\"center\"><center><p><u><strong>Message Body :</strong></u></p>
        </center></div>
      </blockquote>
      <div align=\"center\"><center><p></font><textarea rows=\"19\" name=\"message\" cols=\"70\">$message</textarea><font face=\"Verdana\" size=\"2\"></p>
      </center></div><blockquote>
        <div align=\"center\"><center><p>After sending your message, the script will confirm that the sending process has started. Then PerList clones itself and runs in your server for as long as it takes to send the message to all your subscribers. If you have Tens of Thousands of subscribers this could take hours to finish. In order not to jam the server, PerList takes a 2 second break after each address. Expect at least 2000 seconds for a 1000 addresses. Keep yourself busy doing something else and don\'t bother PerList during this process!<br>
        When this process ends, you will receive a confirmation email telling you that it has finished.<br>
        &nbsp;&nbsp; <br>
        <input type=\"submit\" value=\"Send Now !\" name=\"ORD_envoi_email_do\"><br>
        &nbsp;&nbsp; <br>
        <input type=\"submit\" value=\"Cancel ! Go back to Menu.\" name=\"ORD_menu\"></p>
        </center></div>
      </blockquote>
      <p>&nbsp;</p>
    </form>");

}
################################################
sub admin_envoi_email_do {
local ($d1,$member,$addresses,$nb_sent,$nb_inscrits)=();

  ## c'est la partie d�licate !! ##
  if ($form{'d_titre'} eq '') {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "You haven\'t specified the subject !");
  }
  if ($form{'message'} eq '') {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "Le contenu du message est vide !");
  }
  $d1=$form{'d_titre'};
  $d1=~ s/\s/\_/g;		# 
  $d1=~ s/\W//g;		# 

  $pid = fork();	# 
  $pid;
  if ($pid) {		# 
    # on met en archive.
    open(ARCHADD, ">>$data_dir/log.txt");
    print ARCHADD ("$date\-$d1\n");
    close(ARCHADD);

    open(FILE, ">>$data_dir/$date\-$d1.txt");
    print FILE ("TITRE:\t$form{d_titre}\n");
    print FILE ("HTML:\t$form{d_html}\n");
    print FILE ($form{'message'}."\n");
    close(FILE);
    eval {chmod (0777,"$data_dir/$date\-$d1.txt");}

    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "<font color=\"#FF0000\">The Sending Process has started!</font> <br><br>
             This could be long (2 seconds per subscriber). You will be notified by email when it\'s finished.<br><br>
             If after a long time you don\'t receive this confirmation email, PerList has probably stoped for different possible reasons (Server Rebooting, ...etc).<br>
             In this case you can get the list of the addresses that have received the message by downloading it through FTP from $data_dir/$date\-$d1.log.");

    exit(0);		# 
  } else {		# 
    close (STDOUT);

    $form{'message'}=~ s/<\/body>//i;	# 
    $form{'message'}=~ s/<\/html>//i;	# 
    open(INSCRITS,"$fichier_inscrits");
    @addresses=<INSCRITS>;
    close(INSCRITS);
    $nb_inscrits=@addresses;
    open (LOG,">$data_dir/$date\-$d1.log");
    foreach $member(@addresses) {
      chomp($member);

      open (MAIL, "|$mailprog -t") || die "perlist.PL:Can't open $mailprog: $!\n";
      if ($form{'d_html'}) {
        print MAIL "Content-type:text/html\n";
      }
      print MAIL "Return-Path: $admin_email\n";
      print MAIL "Reply-To: $admin_email\n";
      print MAIL "X-Sender: $admin_email\n";
      print MAIL "From: $admin_email\n";
      print MAIL "To: $member\n";
      print MAIL "Subject: $form{'d_titre'}\n\n";
      print MAIL "$form{'message'}\n\n";


      if ($form{'d_html'}) {
        print MAIL ("<BR><HR>
 If you want to be removed from $list_name click <A HREF=\"http://$url$script_url?remove=$member\"> here.</A><BR><br>
 &nbsp; <br>
 <table border=\"0\" cellspacing=\"1\" width=\"100%\">
 <tr> <td width=\"100%\" bgcolor=\"#C0C0C0\"><p align=\"center\"><font face=\"Verdana\" size=\"1\"><strong>
 PerList: Mailing List Manager. Available for free at <a href=\"http://perlmart.cjb.net\">PerlMart</a>
 </strong></font></td></tr></table>
 </html></body>\n\n");
      } else {
        print MAIL ("
---------------------------------------------------------------------
If you want to be removed from $list_name click on the link below:
http://$url$script_url?remove=$member\n\n
PerList. Mailing List Manager,\n Available for free at http://perlmart.cjb.net");
      }

      close (MAIL);
      print LOG ("OK Sent to $member\n");
      $nb_sent++;

      sleep(2);
    }
    close (LOG);
    &email_admin("PerList: Sending Complete !\n
Congratulations ! \n
Your message has been successfully sent to your Mailing-List $list_name.\n
Number of subscribers: $nb_inscrits
Number of sent emails : $nb_sent\n
Message subject : $form{d_titre}\n. This message was archived.\n End.");
    exit;
  }
}

################################################
sub admin_archive {
local ($line,$titre,$message,$html)=('','','',0);

  if ($form{'archive'} eq '') {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "Please select an archived message !");
  }
  
  if (!(-e "$data_dir/$form{archive}.txt")) {
    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',
            "The file $data_dir/$form{archive}.txt is unavailable for this selection ?!?!?");
  }

  open (ARCHR,"$data_dir/$form{archive}.txt");
  $line=<ARCHR>;
  chomp ($line);
  if ($line=~ /^TITRE:\s+(.*)\s*$/) { $titre=$1;}
  $line=<ARCHR>;
  chomp ($line);
  if ($line=~ /^HTML:\s+(.*)\s*$/) { $html=$1;}
  if ($html != 0) {$html='checked';}
  while (<ARCHR>) {
    $message.=$_;
  }
  close (ARCHR);

  &admin_envoi_email($html,$titre,$message);
}
################################################
sub admin_french {
local ($msg)='';
  $msg=<<_EOMSG_;
    <p align="center"><font face="tahoma" color="#0000FF" size="3"><u><strong>Informations
    sur l'Utilisation :</strong></u></font></p>
    <p><font face="tahoma" size="2"><strong><u>Pour acc�der � la partie Administration</u></strong>
    de votre mailing-list, il vous faut vous rendre � l'URL : <a
    href="http://$url$script_url?admin">http://$url$script_url?admin</a>. Mettez cette URL
    dans vos Favoris pour ne pas l'oublier! Vous devrez alors taper votre mot de passe.</font></p>
    <p><font face="tahoma" size="2"><strong><u>Formulaire d'inscription/d�sinscription :<br>
    </u></strong>Faites un formulaire pour permettre � vos visiteurs de s'inscrire ou se
    d�sinscrire � votre Mailing-List.<br>
    - Voici le code HTML � utiliser pour faire un tel formulaire, � ins�rer dans une page
    HTML :<br>
    </font><strong><font size="2">&lt;form method=&quot;POST&quot;
    action=&quot;http://$url$script_url&quot;&gt;<br>
    &lt;p&gt;Votre adresse E-Mail : &lt;input type=&quot;text&quot; name=&quot;adresse&quot;
    size=&quot;20&quot;&gt;&lt;br&gt;<br>
    &lt;input type=&quot;radio&quot; name=&quot;action&quot; value=&quot;inscription&quot;
    checked&gt;inscription&lt;br&gt;<br>
    &lt;input type=&quot;radio&quot; name=&quot;action&quot;
    value=&quot;desinscription&quot;&gt;d�sinscription&lt;br&gt;<br>
    &lt;input type=&quot;submit&quot; value=&quot;Valider.&quot;&gt;&lt;/p&gt;<br>
    &lt;/form&gt;</font><font face="tahoma" size="2"><br>
    </strong> - Pour faire un formulaire permettant uniquement l'inscription, vous pouvez
    mettre :<br>
    </font><font size="2"><strong>&lt;form method=&quot;POST&quot;
    action=&quot;http://$url$script_url&quot;&gt;<br>
    &lt;p&gt;Votre adresse E-Mail : &lt;input type=&quot;text&quot; name=&quot;adresse&quot;
    size=&quot;20&quot;&gt;&lt;br&gt;<br>
    &lt;input type=&quot;hidden&quot; name=&quot;action&quot; value=&quot;inscription&quot;
    &gt;<br>
    &lt;input type=&quot;submit&quot; value=&quot;Inscription!&quot;&gt;&lt;/p&gt;<br>
    &lt;/form&gt;</strong></font></p>
    <p><font face="tahoma" size="2"><strong><u>Envois d'E-Mails au format HTML � la liste des
    inscrits :<br>
    </u></strong>Il est maintenant courant d'envoyer des E-Mail au format HTML, ce qui permet
    une pr�sentation plus agr�able...<br>
    Pour ce faire, <br>
    1- Cr�ez une page HTML avec votre �diteur HTML favori : soignez ainsi la mise en page,
    et les liens. N'ins�rez des images ou liens hypertextes que si vous indiquez leurs URLs
    compl�tes (http://...), si ce sont des URL non compl�tes, les images/liens seront
    cass�s dans l'E-Mail re�u.<br>
    2- Dans la partie <u>admin</u> de perlist.pl, allez dans la section d'Envoi
    d'E-Mail � la liste, puis cochez la case d'envoie d'E-Mail au format HTML, et
    copier/coller le code HTML de la page que vous avez juste cr��e.<br>
    3- Validez l'Envoi...</font></p>
    <p><font face="tahoma" size="2"><u><strong>Copyright et Licence d'utilisation :<br>
    </strong></u>Merci de ne pas modifier ce script CGI Perl, et surtout de ne pas enlever les
    mentions de l'auteur.<br>
    La licence d'utilisation gratuite de ce Mailing List Manager vous est accord�e,
    � la condition expresse que vous ne fassiez pas de modifications dans le script CGI en
    vue de supprimer ou alt�rer ce type de mention. Dans le cas contraire, son utilisation
    est ill�gale...<br>
    Ce Mailing List Manager est de bonne qualit�, mais vous n'avez pas �
    payer de licence... donc, merci de respecter le travail de l'auteur. <br>
    C'est un �change correct de services rendus :-)</font></p>
    <center><div align="center"><p align="center">
    <form method="POST" action="$script_url">
      <input type="hidden" name="passwd" value="$passwd"><p>&nbsp;</p>
      <input type=\"submit\" value=\"Continue!\"><br> &nbsp; <br>
    </form>
    </p></div></center>

_EOMSG_


    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',$msg);
  1;
}
################################################
################################################
sub admin_english {
local ($msg)='';
  $msg=<<_EOENGLISH_;
    <p align="center"><u><strong><font face="Tahoma" color="#0000FF" size="3">PerList
    Form:</font></strong></u></p>
<p><font face="Tahoma"><strong><u><font size="2">For your Mailing List
Administration page</font></u></strong><font size="2"> go to : <a
    href="http://$url$script_url?admin">http://$url$script_url?admin</a>.
Bookmartk this page.</font></font></p>
    <p><font face="Tahoma"><strong><u><font size="2">Subscription /
    Unsubscription Form :<br>
    </font></u></strong><font size="2">This is an example of the form you should
    add to your website.<br>
    - Regular Form:<br>
    </font><strong><font size="2">&lt;form method=&quot;POST&quot;
    action=&quot;http://$url$script_url&quot;&gt;<br>
    &lt;p&gt;Votre adresse E-Mail : &lt;input type=&quot;text&quot; name=&quot;adresse&quot;
    size=&quot;20&quot;&gt;&lt;br&gt;<br>
  &lt;input type=&quot;radio&quot; name=&quot;action&quot; value=&quot;inscription&quot; 
  checked&gt;Subscribe&lt;br&gt;<br>
    &lt;input type=&quot;radio&quot; name=&quot;action&quot;
    value=&quot;Unsubscribe&quot;&gt;Unsubscribe&lt;br&gt;<br>
    &lt;input type=&quot;submit&quot; value=&quot;Go.&quot;&gt;&lt;/p&gt;<br>
    &lt;/form&gt;</font>
    </strong> </font></p>
    <p><strong><font face="Tahoma" size="2"><br>
  </font> </strong> <font face="Tahoma"><font size="2"> <strong><u>Form with only 
  a Subscription option :</u></strong><br>
    <strong>&lt;form method=&quot;POST&quot;
    action=&quot;http://$url$script_url&quot;&gt;<br>
    &lt;p&gt;Votre adresse E-Mail : &lt;input type=&quot;text&quot; name=&quot;adresse&quot;
    size=&quot;20&quot;&gt;&lt;br&gt;<br>
    &lt;input type=&quot;hidden&quot; name=&quot;action&quot; value=&quot;inscription&quot;
    &gt;<br>
    &lt;input type=&quot;submit&quot; value=&quot;Subscribe!&quot;&gt;&lt;/p&gt;<br>
    &lt;/form&gt;</strong>
    </font></font></p>
    <p>&nbsp;</p>
    <center><div align="center">
    <form method="POST" action="$script_url">
      <input type="hidden" name="passwd" value="$passwd"><p><font face="Tahoma">&nbsp;</font></p>
      <font face="Tahoma">
      <input type=\"submit\" value=\"Continue!\"><br> &nbsp; <br>
      </font>
    </form>
    </div></center>

_EOENGLISH_


    &msgfin('<font size="2"><b>PerList &nbsp; - &nbsp; Administration<br>Mailing List Manager</font></strong>',$msg);
  1;
}