Title: Guestbook
Description: This is a fairly nice guestbook. It includes a descent interface and allows you to configure many of the options online. It offers options such as to log the ip and send email to the owner upon recieving a message. 
You can limit how many guests per page. The guests can even select an option to have the comment invisible so only the owner can view it :)
<BR><BR>All the neccisary files are included here. To see a demo: <BR><BR>http://microprose.hypermart.net/guestbook/config.html<BR><BR>
The password is guestbook.<BR><BR>
Most the options are configured for you. All you'll need to possibly change to run this is the location of the perl compiler. Other than that just stick it on your server and run it :)
<BR><BR>
Updated - Had a couple bugs. They are fixed.<BR><BR>
Updated - I improved some of the security on it and also set it up so it reads off a template instead of having a hardcoded in setup. Just use the included template editor and you can set up how the info is displayed easily :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=149&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
