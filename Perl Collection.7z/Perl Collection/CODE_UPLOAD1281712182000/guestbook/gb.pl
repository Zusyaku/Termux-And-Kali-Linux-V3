#!/usr/local/bin/perl
# ######################################################################### #
# Perl Guestbook: By Ackbar                                                 #
# ######################################################################### #
# This is a simple guestbook script (configured specificly for              #
# http://rebeccasghost.cjb.net						    #
# ######################################################################### #
# This code is free and may be redistributed as you please as long as these #
# comments remain. Otherwise you will be asked to remove it. (unless I say  #
# you can take credits out :)                                               #
# ######################################################################### #

# all options (0 = no) (1 = yes)

$url = "http://rebeccasghost.cjb.net";  # This is the address of the homepage
$faq = "faq.html";                      # This is the address of the faq
$datafile = "guests.dat";		# Where to guests info is stored :)
$data_file = "datastore.dat";		# Where to read the options that aren't hardcoded
$cntfile = "guests.cnt";		# Where the # of guests is stored :)
$gbookurl = "sign.html";		# Address of the guestbook.
$owneremail = "you\@you.com";	# Email addy of the owner of the guestbook :)
$mailprog = '/usr/lib/sendmail';



$showfaq = 1;				# Whether or not to show the faq
$showurl = 1;				# Whether or not to show the url
$logip = 1;				# This logs the ip.
$emailowner = 0;			# Owner will recieve an email when a guest submits a comment
$personalmsg = 1;			# Personal message (allows users to post a message only
					# the owner may see.					
				
					
					
# These are the requirements. Set what you do and don't want required here. 0 = not required
# 1 = required



# don't bother with the owner only comments cause thats optional to the user.					

# Read_Request function. This will let me strip appart pieces and read them so
# I know what is being passed for each piece of info. Then we write it all to
# a nice file.

sub Read_Request{
        if ($ENV{'CONTENT_LENGTH'} > 0){
                read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
                @fields = split (/&/, $buffer);
        } else {
                $_ = "$ENV{'QUERY_STRING'}";
                @fields = split (/&/, $_);
        }
        foreach $field (@fields){
                ($name, $value) = split (/=/, $field);
                 $value =~ tr/+/ /;
                 $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
                 $FORM{$name} = $value;
        }
}
&Read_Request;



$email = $reqemail;
$name = $reqname;
$url = $requrl;
$age = $reqwwwname;
$how = $reqhow;
$comments = $reqcomments;

# Right away we check to see if the person submitted a name and comments.
# if not we give them an error cause that info is sort of neccisary.

open (FILES,"$data_file") || die("Can't Open $datafile - for input\n");
  $data=<FILES>;
  chop($data);
  ($email, $title, $toptable, $bottomtable, $toptext, $bottomtext, $gnumber, $reqemail, $reqname, $requrl, $reqwwwname, $reqfound, $reqcomments, $sendemail, $logip, $topbanner, $bannerwidth, $bannerheight, $banneralt, $viewgrx, $viewwidth, $viewheight, $viewalt, $signgrx, $signwidth, $signheight, $signalt)=split(/�/,$data);  
close(FILES);  

&no_name unless $FORM{name};
&no_email unless $FORM{email};
&no_url unless $FORM{url};
&no_how unless $FORM{how};
&no_age unless $FORM{age};
&no_comments unless $FORM{comments};


# Lets open the data file and see how many lines there are :)
open (FILE,"$datafile") || die ("Can't Open $datafile.\n");
@LINES=<FILE>;
close(FILE);
$SIZE=@LINES;
    

# Now it's time to add onto the actual guestbook dat file :)
# PS. syntax in dat file =:
# Name�Email�Email�Home Page�How Found�Age�Comments�OwnerOnly
# The OwnerOnly will be either a true or a false
# if true then anyone can see the commnet, else only owner can view it



# Read the options data




sub no_comments {
  if ($reqcomments eq '1'){
   print "Content-type: text/html\n\n";
   print "<html><head><title>No Comments</title></head>\n";
   print "<body><h1>Your Comments appear to be blank</h1>\n";
   print "The comment section in the guestbook fillout form appears\n";
   print "to be blank and therefore the guestbook addition was not\n";
   print "added.<p>\n";
   print "<hr>\n";
   print "Return to the <a href=\"$gbookurl\">Guestbook</a>.";
   print "\n</body></html>\n";
   exit;
  }
}

sub no_name {
  if ($reqname eq '1'){
   print "Content-type: text/html\n\n";
   print "<html><head><title>No Name</title></head>\n";
   print "<body><h1>Your Name appears to be blank</h1>\n";
   print "The Name Section in the guestbook fillout form appears to\n";
   print "be blank and therefore your entry to the guestbook was not\n";
   print "added.";
   print "<hr>\n";
   print "Return to the <a href=\"$gbookurl\">Guestbook</a>.";
   print "\n</body></html>\n";
   exit;
  }
}

sub no_email { 
  if ($reqemail eq '1'){
   print "Content-type: text/html\n\n";
   print "<html><head><title>No Email</title></head>\n";
   print "<body><h1>Your Email appears to be blank</h1>\n";
   print "The email Section in the guestbook fillout form appears to\n";
   print "be blank and therefore your entry to the guestbook was not\n";
   print "added.";
   print "<hr>\n";
   print "Return to the <a href=\"$gbookurl\">Guestbook</a>.";
   print "\n</body></html>\n";
   exit;
  }
}

sub no_url {
  if ($requrl eq '1'){
   print "Content-type: text/html\n\n";
   print "<html><head><title>No URL</title></head>\n";
   print "<body><h1>Your url appears to be blank</h1>\n";
   print "The url Section in the guestbook fillout form appears to\n";
   print "be blank and therefore your entry to the guestbook was not\n";
   print "added.";
   print "<hr>\n";
   print "Return to the <a href=\"$gbookurl\">Guestbook</a>.";
   print "\n</body></html>\n";
   exit;
  }
}

sub no_age {
  if ($reqwwwname eq '1'){
   print "Content-type: text/html\n\n";
   print "<html><head><title>No Age</title></head>\n";
   print "<body><h1>Your Age appears to be blank</h1>\n";
   print "The Age Section in the guestbook fillout form appears to\n";
   print "be blank and therefore your entry to the guestbook was not\n";
   print "added.";
   print "<hr>\n";
   print "Return to the <a href=\"$gbookurl\">Guestbook</a>.";
   print "\n</body></html>\n";
   exit;
  }
}

sub no_how {
  if ($reqhow eq '1'){
   print "Content-type: text/html\n\n";
   print "<html><head><title>No How you found this site</title></head>\n";
   print "<body><h1>Your How you found the site appears to be blank</h1>\n";
   print "The How Found Section in the guestbook fillout form appears to\n";
   print "be blank and therefore your entry to the guestbook was not\n";
   print "added.";
   print "<hr>\n";
   print "Return to the <a href=\"$gbookurl\">Guestbook</a>.";
   print "\n</body></html>\n";
   exit;
  }
}
open(OLDGUESTS, "$datafile") || die("Can't open guestbook data file: $datafile - for input.");
     for($i=0;$i<=$SIZE;$i++){
      $tmp_str=<OLDGUESTS>;
      $new_str = "$new_str$tmp_str";
     }
close(OLDGUESTS);

$FORM{comments} =~ s/\n/<br>/ig;
$FORM{comments} =~ s/\r//g;
$DATA =~ s/\r//g;


open(GUESTS, ">$datafile") || die("Can't open guestbook data file: $datafile - for output.");
print GUESTS "$FORM{name}�$FORM{email}�$FORM{url}�$FORM{how}�$FORM{age}�$FORM{comments}�$FORM{forowner}�$ENV{'REMOTE_ADDR'}\n";
print GUESTS "$new_str";
close(GUESTS);
print "Content-type: text/html\n\n";
print "<html>\n";
print "<head>\n";
print "<title>$title</title>\n";
print "</head>\n";
print "<body bgcolor='#000000' text='#C0C0C0'>\n";
print "<center>\n";
print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
print "<table border=0><tr>\n";
print "<td valign=top>\n";
print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
print "</td>\n";
print "<td valign=top>\n";
print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
print "</td></tr>";
print "</table><br>\n";

print "<table border=1 width=700 bordercolor='#C0C0C0' cellspacing=1>\n";
print "<tr>\n";
print "<td bgcolor=#C0C0C0>\n";
print "<font face=verdana size=-1 color=#000000>\n";
print "<B>Name</B>: <a href='mailto:$FORM{email}?subject=Guestbook Entry'>$FORM{name}</a><br>";
print "</font>\n";
print "</td></tr>\n";
print "<tr>\n";
print "<td bgcolor=#5E5E5E>\n";
print "<font face=verdana size=-1 color=#FFFFFF>\n";
print "<B>Website</B>: <a href=$FORM{url}>$FORM{age}</a><br>";
print "<b>How You Found</b>: $FORM{how}<br>";
print "<B>Comments</B>:<BR> $FORM{comments}";
print "</td></tr></table><BR>\n";
print "</center>\n";
print "</body>\n";
print "</html>";

if ($sendemail == 1){
  
   open (MAIL, "|$mailprog $recipient") || die "Can't open $mailprog!\n";

   print MAIL "Reply-to: $FORM{'username'} ($FORM{'realname'})\n";
   print MAIL "From: $FORM{'username'} ($FORM{'realname'})\n";
   print MAIL "Subject: Entry to Guestbook\n\n";
   print MAIL "You have a new entry in your guestbook:\n\n";
   print MAIL "------------------------------------------------------\n";
   print MAIL "$FORM{'comments'}\n";
   print MAIL "$FORM{'realname'}";

   if ( $FORM{'username'} ){
      print MAIL " <$FORM{'username'}>";
   }

   print MAIL "\n";

   if ( $FORM{'city'} ){
      print MAIL "$FORM{'city'},";
   }

   if ( $FORM{'state'} ){
      print MAIL " $FORM{'state'}";
   }

   if ( $FORM{'country'} ){
      print MAIL " $FORM{'country'}";
   }

   print MAIL " - $date\n";
   print MAIL "------------------------------------------------------\n";

   close (MAIL);
}

if ($remote_mail eq '1' && $FORM{'username'}) {
   open (MAIL, "|$mailprog -t") || die "Can't open $mailprog!\n";

   print MAIL "To: $email\n";
   print MAIL "From: $FORM{email}\n";
   print MAIL "Subject: A User Has Signed Your Guestbook\n\n";
   print MAIL "The Following Info Was submitted to your guestbook\n\n";
   print MAIL "------------------------------------------------------\n";
   print MAIL "$FORM{name}\n";
   print MAIL "$FORM{email}\n";
   print MAIL "$FORM{url}\n";
   print MAIL "$FORM{age}\n";
   print MAIL "$FORM{how}\n";
   print MAIL "$FORM{comments}\n";
   print MAIL "$ENV{'REMOTE_ADDR'}\n";
   print MAIL "------------------------------------------------------\n";
   close (MAIL);

}
