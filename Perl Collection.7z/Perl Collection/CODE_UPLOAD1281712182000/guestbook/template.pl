#!/usr/local/bin/perl
# ######################################################################### #
# Perl Guestbook: By Ackbar                                                 #
# ######################################################################### #
# This is a simple guestbook script (configured specificly for              #
# http://rebeccasghost.cjb.net						    #
# ######################################################################### #
# This code is free and may be redistributed as you please as long as these #
# comments remain. Otherwise you will be asked to remove it. (unless I say  #
# you can take credits out :)                                               #
# ######################################################################### #

# all options (0 = no) (1 = yes)

$template = "template.tmp";		# template file
$data_file = "datastore.dat";		# Where to read the options that aren't hardcoded
$pws = "password.psw";			# Location of the password file.
$password = "password.psw";		# Location of the password file.
	
open (FILES,"$data_file") || die("Can't Open $datafile - for input\n");
  $data=<FILES>;
  chop($data);
  ($email, $title, $toptable, $bottomtable, $toptext, $bottomtext, $gnumber, $reqemail, $reqname, $requrl, $reqwwwname, $reqfound, $reqcomments, $sendemail, $logip, $topbanner, $bannerwidth, $bannerheight, $banneralt, $viewgrx, $viewwidth, $viewheight, $viewalt, $signgrx, $signwidth, $signheight, $signalt)=split(/�/,$data);  
close(FILES);  
					
					
# These are the requirements. Set what you do and don't want required here. 0 = not required
# 1 = required



# don't bother with the owner only comments cause thats optional to the user.					

# Read_Request function. This will let me strip appart pieces and read them so
# I know what is being passed for each piece of info. Then we write it all to
# a nice file.

sub Read_Request{
        if ($ENV{'CONTENT_LENGTH'} > 0){
                read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
                @fields = split (/&/, $buffer);
        } else {
                $_ = "$ENV{'QUERY_STRING'}";
                @fields = split (/&/, $_);
        }
        foreach $field (@fields){
                ($name, $value) = split (/=/, $field);
                 $value =~ tr/+/ /;
                 $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
                 $FORM{$name} = $value;
        }
}


&Read_Request;

open (PASSWRD, "$password") || die("Error opening the password file.\n");
  $passstore=<PASSWRD>;
close(PASSWRD);
if ((length($FORM{password}) < 1) || $passstore ne $FORM{password}){
   print "Content-type: text/html\n\n";
   print "<html>\n";
   print "<head>\n";
   print "<title>$title</title>\n";
   print "</head>\n";
   print "<body bgcolor='#000000' text='#C0C0C0'>\n";
   print "<form method='post' action='template.pl'>\n";
   
   print "<table width='100%' height='100%' valign='center' align='center' border='0' cellspacing='0' cellpadding='0'>\n";
   print "<tr><td valign='center' align='center'>\n";
   print "<table border='4' bgcolor='#c0c0c0' cellspacing='0' cellpadding='0' width='500' height='200'>\n";
   print "<tr><td valign='center' align='center'>\n";
   print "<table border='0' cellspacing='0'><tr><td>";
   print "<font face='verdana' size='-1' color='#000000'>Password:</font><BR></td><tr>\n";
   print "<td cols='2'><input type='password' name='password'>\n";
   print "<input type='submit' value='Edit Options'>\n";
   print "</td></tr></table></td></tr></table>\n";
   print "</body></html>\n";
   exit;
}

if ($FORM{data} eq 'write'){
  if (length($FORM{temp}) < 1){
    print "Content-type: text/html\n\n";
    print "<html>\n";
    print "<head>\n";
    print "<title>$title</title>\n";
    print "</head>\n";
    print "<body bgcolor='#000000' text='#C0C0C0'>\n";
    print "<center>\n";
    print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
    print "<table border=0><tr>\n";
    print "<td valign=top>\n";
    print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
    print "</td>\n";
    print "<td valign=top>\n";
    print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
    print "</td></tr>";
    print "</table><br>\n";
    print "Error. You must specify a template.\n";
    print "</body>\n";
    print "</html>\n";
    exit;
  }
  open(PASSFILE, "$pws") || die("Error reading password file.\n");
    $pass_store=<PASSFILE>;
  close(PASSFILE);
  if ($FORM{password} ne $pass_store){
    print "Content-type: text/html\n\n";
    print "<html>\n";
    print "<head>\n";
    print "<title>$title</title>\n";
    print "</head>\n";
    print "<body bgcolor='#000000' text='#C0C0C0'>\n";
    print "<center>\n";
    print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
    print "<table border=0><tr>\n";
    print "<td valign=top>\n";
    print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
    print "</td>\n";
    print "<td valign=top>\n";
    print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
    print "</td></tr>";
    print "</table><br>\n";
    print "Error. Incorrect password entered.\n";
    print "</body>\n";
    print "</html>\n";
    exit;  	
  }  
    open(TEMPLATEFILE, ">$template") || die("Error opening template file for output.\n");
      print TEMPLATEFILE $FORM{temp};
      print "Content-type: text/html\n\n";
      print "<html>\n";
      print "<head>\n";
      print "<title>$title</title>\n";
      print "</head>\n";
      print "<body bgcolor='#000000' text='#C0C0C0'>\n";
      print "<center>\n";
      print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
      print "<table border=0><tr>\n";
      print "<td valign=top>\n";
      print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
      print "</td>\n";
      print "<td valign=top>\n";
      print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
      print "</td></tr>";
      print "</table><br>\n";
      print "Template Succesfully written to.\n";
      print "</body>\n";
      print "</html>\n";
      exit;
    close(TEMPLATEFILE);
}
else {
  open(TEMPLATEFILE, "$template") || die("Error reading template file.\n");
  @DATA=<TEMPLATEFILE>;
  $SIZE=@DATA;
  for($i=0;$i<=$SIZE;$i++){
    $newdata="$newdata$DATA[$i]";
  }
  close(TEMPLATEFILE);
  print "Content-type: text/html\n\n";
  print "<html>\n";
  print "<head>\n";
  print "<title>$title</title>\n";
  print "<script language='javascript'>\n";
  print "function doemail(){\n";
  print "  document.forms[0].elements['temp'].value = document.forms[0].elements['temp'].value + ':email'\n";
  print "}\n";
  print "function doname(){\n";
  print "  document.forms[0].elements['temp'].value = document.forms[0].elements['temp'].value + ':name'\n";
  print "}\n";
  print "function dourl(){\n";
  print "  document.forms[0].elements['temp'].value = document.forms[0].elements['temp'].value + ':url'\n";
  print "}\n";
  print "function dowwwname(){\n";
  print "  document.forms[0].elements['temp'].value = document.forms[0].elements['temp'].value + ':wwwname'\n";
  print "}\n";
  print "function dohow(){\n";
  print "  document.forms[0].elements['temp'].value = document.forms[0].elements['temp'].value + ':how'\n";
  print "}\n";
  print "function doip(){\n";
  print "  document.forms[0].elements['temp'].value = document.forms[0].elements['temp'].value + ':ip'\n";
  print "}\n";
          
  print "</script>\n";
  print "</head>\n";
  print "<body bgcolor='#000000' text='#C0C0C0'>\n";
  print "<center>\n";
  print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
  print "<table border='1' cellspacing='2' cellpadding='4'>\n";
  print "<tr>\n";
  print "<td bgcolor='#C0C0C0' valign='top' colspan='2'>\n";
  print "<font face='verdana' size='-1' color='#000000'>Use this form to modify the template.</td>\n";
  print "</tr><tr>\n";
  print "<td bgcolor='#C0C0C0' valign='top' colspan='2'>\n";
  print "<input type='submit' value='Email' onClick='doemail()'>\n";
  print "<input type='submit' value='Name' onClick='doname()'>\n";
  print "<input type='submit' value='URL' onClick='dourl()'>\n";
  print "<input type='submit' value='Website Name' onClick='dowwwname()'>\n";
  print "<input type='submit' value='How You Found' onClick='dohow()'>\n";
  print "<input type='submit' value='Ip Addy' onClick='doip()'>\n";
  print "</td></tr>\n";
  print "<td bgcolor='#5e5e5e' colspan='2' valign='top'>\n";
  print "<form method='POST' action='template.pl'>\n";
  print "<font face='verdana' size='-1' color='#ffffff'>\n";
  print "<input type='hidden' name='data' value='write'>\n";
  print "<textarea rows='20' cols='95' name='temp'>$newdata</textarea>\n";
  print "</td></tr><tr><td bgcolor='C0C0C0' valign='top' colspan='2'>\n";
  print "<font face='verdana' size='-1' color='#000000'>Password:<BR><input type='password' name='password'>\n";  
  print "<input type='submit' value='Use This Template'>\n";
  print "<input type='reset' value='Restore to before :)'>\n";
  print "</form>\n";
  print "</td></tr></table>\n";
  print "</form>\n";
  print "</body>\n";  
  print "</html>\n";
  exit;
}

