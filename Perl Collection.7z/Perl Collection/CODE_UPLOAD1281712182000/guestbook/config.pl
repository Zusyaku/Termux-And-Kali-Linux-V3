#!/usr/local/bin/perl
# ######################################################################### #
# Perl Guestbook: By Calypso                                                #
# ######################################################################### #
# This is a simple guestbook script (configured specificly for              #
# http://rebeccasghost.cjb.net						    #
# ######################################################################### #
# This code is free and may be redistributed as you please as long as these #
# comments remain. Otherwise you will be asked to remove it. (unless I say  #
# you can take credits out :)                                               #
# ######################################################################### #

# all options (0 = no) (1 = yes)

# This is a simple online configuration tool. With it you can set some of
# the common things on the site.

$datafile = "datastore.dat";		# Where the data will be stored
$passfile = "password.psw";		# Where the password is stored :)

sub Read_Request{
        if ($ENV{'CONTENT_LENGTH'} > 0){
                read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
                @fields = split (/&/, $buffer);
        } else {
                $_ = "$ENV{'QUERY_STRING'}";
                @fields = split (/&/, $_);
        }
        foreach $field (@fields){
                ($name, $value) = split (/=/, $field);
                $value =~ tr/+/ /;
                $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
                $FORM{$name} = $value;
        }
}
&Read_Request;

# &no_toptable unless $FORM{toptable};
# &no_toptable unless $FORM{bottomtable};
# &no_toptable unless $FORM{reqemail};
# &no_toptable unless $FORM{reqname};
# &no_toptable unless $FORM{requrl};
# &no_toptable unless $FORM{reqwwwname};
# &no_toptable unless $FORM{reqfound};
# &no_toptable unless $FORM{reqcomments};
# &no_toptable unless $FORM{topbanner};
# &no_toptable unless $FORM{bannerwidth};
# &no_toptable unless $FORM{bannerheight};
# &no_toptable unless $FORM{viewgrx};
# &no_toptable unless $FORM{viewwidth};
# &no_toptable unless $FORM{viewheight};
# &no_toptable unless $FORM{signgrx};
# &no_toptable unless $FORM{signwidth};
# &no_toptable unless $FORM{signheight};
# &no_toptable unless $FORM{oldpassword};
# &no_toptable unless $FORM{newpassword};
# &no_toptable unless $FORM{newpassword};

# first we verify the supplied pw matches the stored admin pw :)
open (FILE,"$passfile") || die("Can't Open $passfile - for input!\n");
$pass_store=<FILE>;
close(FILE);

$pass_info = "$FORM{oldpw}";


if ($pass_info eq $pass_store){  
  open (FILE,">$datafile") || die("Can't Open $datafile - for output\n");
  print FILE "$FORM{email}�";
  print FILE "$FORM{title}�";
  print FILE "$FORM{toptable}�";
  print FILE "$FORM{bottomtable}�";
  print FILE "$FORM{toptext}�";
  print FILE "$FORM{bottomtext}�";
  print FILE "$FORM{gnumber}�";  
  print FILE "$FORM{reqemail}�";
  print FILE "$FORM{reqname}�";
  print FILE "$FORM{requrl}�";
  print FILE "$FORM{reqwwwname}�";
  print FILE "$FORM{reqfound}�";
  print FILE "$FORM{reqcomments}�";
  print FILE "$FORM{sendemail}�";
  print FILE "$FORM{logip}�";
  print FILE "$FORM{topbanner}�";
  print FILE "$FORM{bannerwidth}�";
  print FILE "$FORM{bannerheight}�";
  print FILE "$FORM{banneralt}�";
  print FILE "$FORM{viewgrx}�";
  print FILE "$FORM{viewwidth}�";
  print FILE "$FORM{viewheight}�";
  print FILE "$FORM{viewalt}�";
  print FILE "$FORM{signgrx}�";
  print FILE "$FORM{signwidth}�";
  print FILE "$FORM{signheight}�";
  print FILE "$FORM{signalt}�";
  close(FILE);

  # Print out the recieved Info
  print "Content-type: text/html\n\n$num"; 
  print "Owners Email: $FORM{email}<BR>\n";	
  print "Title Of Guestbook: $FORM{title}<BR>\n";
  print "Top Table Color: $FORM{toptable}<BR>\n";
  print "Bottom Table Color: $FORM{bottomtable}<BR>\n";
  print "Top Table Text Color: $FORM{bottomtext}<BR>\n";
  print "Bottom Table Text Color: $FORM{bottomtext}<BR>\n";
  print "Max Guests Per Page: $FORM{gnumber}<BR>\n";
  print "Require Email: $FORM{reqemail}<BR>\n";
  print "Require Name: $FORM{reqname}<BR>\n";
  print "Require URL: $FORM{requrl}<BR>\n";
  print "Require WWW Name: $FORM{reqwwwname}<BR>\n";
  print "Require Where Found: $FORM{reqfound}<BR>\n";
  print "Require Comments: $FORM{reqcomments}<BR>\n";
  print "Top Banner URL: $FORM{topbanner}<BR>\n";
  print "Top Banner Width: $FORM{bannerwidth}<BR>\n";
  print "Top Banner Height: $FORM{bannerheight}<BR>\n";
  print "Top Banner Alt Tag: $FORM{banneralt}<BR>\n";
  print "View Graphic URL:$FORM{viewgrx}<BR>\n";
  print "View Graphic Width: $FORM{viewwidth}<BR>\n";
  print "View Graphic Height: $FORM{viewheight}<BR>\n";
  print "View Graphic Alt Tag: $FORM{viewalt}<BR>\n";
  print "Sign Graphic URL: $FORM{signgrx}<BR>\n";
  print "Sign Graphic Width: $FORM{signwidth}<BR>\n";
  print "Sign Graphic Height: $FORM{signheight}<BR>\n";
  print "Sign Graphic Alt Tag: $FORM{signalt}<BR><BR>\n";
  if (length($FORM{newpw}) > 0) {
    if (length($FORM{newpw2}) <= 0){
    	print "Passwords do not match.\n";
    	exit;
    }
    
    if($FORM{newpw} eq $FORM{newpw2}){
    	print "Password has been successfully changed.\n";
    	open (PWFILE,">$passfile") || die("Can't Open $passfile - for input!\n");
    	print PWFILE $FORM{newpw};
    	exit;
    }
    else {
   	print "Passwords do not match.\n";
    	exit;
    }    	
  }
}
else {
  print "Content-type: text/html\n\n$num"; 
  print "<h1>Incorrect Password Supplied.</h1>\n";
  exit;
}	