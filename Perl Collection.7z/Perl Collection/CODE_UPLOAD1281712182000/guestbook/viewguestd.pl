#!/usr/local/bin/perl
# ######################################################################### #
# Perl Guestbook: By Ackbar                                                 #
# ######################################################################### #
# This is a simple guestbook script (configured specificly for              #
# http://rebeccasghost.cjb.net						    #
# ######################################################################### #
# This code is free and may be redistributed as you please as long as these #
# comments remain. Otherwise you will be asked to remove it. (unless I say  #
# you can take credits out :)                                               #
# ######################################################################### #

# all options (0 = no) (1 = yes)
$datafile = "guests.dat";		# Where to guests info is stored :)
$data_file = "datastore.dat";		# Where the options are stored.
$template = "template.tmp";		# Stores the url of the template file :)
$password = "password.psw";		# Stores the location of the password file.

# Lets read off the settings
open (FILE,"$data_file") || die("Can't Open $datafile - for input\n");
  $data=<FILE>;
  chop($data);
  ($email, $title, $toptable, $bottomtable, $toptext, $bottomtext, $gnumber, $reqemail, $reqname, $requrl, $reqwwwname, $reqfound, $reqcomments, $sendemail, $logip, $topbanner, $bannerwidth, $bannerheight, $banneralt, $viewgrx, $viewwidth, $viewheight, $viewalt, $signgrx, $signwidth, $signheight, $signalt)=split(/�/,$data);  
close(FILE); 

sub Read_Request{
        if ($ENV{'CONTENT_LENGTH'} > 0){
                read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
                @fields = split (/&/, $buffer);
        } else {
                $_ = "$ENV{'QUERY_STRING'}";
                @fields = split (/&/, $_);
        }
        foreach $field (@fields){
                ($name, $value) = split (/=/, $field);
                $value =~ tr/+/ /;
                $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
                $FORM{$name} = $value;
        }
}
&Read_Request;

open (PASSWRD, "$password") || die("Error opening the password file.\n");
  $passstore=<PASSWRD>;
close(PASSWRD);
if ((length($FORM{password}) < 1) || $passstore ne $FORM{password}){
   print "Content-type: text/html\n\n";
   print "<html>\n";
   print "<head>\n";
   print "<title>$title</title>\n";
   print "</head>\n";
   print "<body bgcolor='#000000' text='#C0C0C0'>\n";
   print "<form method='post' action='viewguestd.pl'>\n";
   
   print "<table width='100%' height='100%' valign='center' align='center' border='0' cellspacing='0' cellpadding='0'>\n";
   print "<tr><td valign='center' align='center'>\n";
   print "<table border='4' bgcolor='#c0c0c0' cellspacing='0' cellpadding='0' width='500' height='200'>\n";
   print "<tr><td valign='center' align='center'>\n";
   print "<table border='0' cellspacing='0'><tr><td>";
   print "<font face='verdana' size='-1' color='#000000'>Password:</font><BR></td><tr>\n";
   print "<td cols='2'><input type='password' name='password'>\n";
   print "<input type='submit' value='Edit Options'>\n";
   print "</td></tr></table></td></tr></table>\n";
   print "</body></html>\n";
   exit;
}

open (FILE,"$datafile") || die("Can't Open $datafile - for input!\n");
@LINES=<FILE>;
$SIZE=@LINES;
$raw_data = <FILE>;
close(FILE);

open (FILED, "$template") || die("Could not open template file for input.\n");
  @LINESD=<FILED>;
  $SIZEIT=@LINESD;
  @LINESS=@LINESD;
close(FILED);


if ($FORM{min} && $FORM{max}){
   $minnum = $FORM{min};
   $maxnum = $FORM{max};
}
else {
   $minnum = 0;
   $maxnum = $gnumber;
}
if ($maxnum > $SIZE){
  $maxnum = $SIZE;
}
if ($minnum < 0){
  $minnum = 0;
}
print "Content-type: text/html\n\n";
print "<html>\n";
print "<head>\n";
print "<title>$title</title>\n";
print "</head>\n";
print "<body bgcolor='#000000' text='#C0C0C0'>\n";
print "<center>\n";
print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
print "<table border=0><tr>\n";
print "<td valign=top>\n";
print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
print "</td>\n";
print "<td valign=top>\n";
print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
print "</td></tr>";
print "<tr><td colspan='2'><center><font face='verdana' size='-1' color='#C0C0C0'>Guests $minnum - $maxnum of $SIZE   </font></center></td></tr>\n";
print "</table><br>\n";

print "</center>\n";
$linenum=0;
open (FILES,"$datafile") || die("Can't Open $datafile - for input!\n");
$nextnum = ($minnum + $gnumber);
if ($nextnum > $SIZE){
  $nextnum = $SIZE;
}

for($f=$minnum;$f<$nextnum;$f++)
{
 $linenum++;

     $guest = $LINES[$f];
     chop($guests);
     ($name, $email, $url, $how, $age, $comments, $forowner, $ip)=split(/�/,$guest);
     $ownerstr = "$comments<br>\n";
     $ownerstr = "$ownerstr <form method='POST' action=deleteitem.pl>\n";
     $ownerstr = "$ownerstr <input type='hidden' name='itemid' value='$i'>\n";
     $ownerstr = "$ownerstr <font face='verdana' color='#c0c0c0' size='-1'>Password:</font><BR>\n";
     $ownerstr = "$ownerstr <input type='password' name='password'STYLE='background:#000000;color:lime;border-style:groove'>&nbsp;\n";
     $ownerstr = "$ownerstr <input type='submit' value='Delete'STYLE='background:#000000;color:lime;border-style:groove'>\n";  
     $ownerstr = "$ownerstr </form>\n";
     $ownerstr = "$ownerstr </td></tr></table>\n";
     $ownerstr = "$ownerstr </td></tr></table><BR>\n";    
      @LINESD=@LINESS;
      for ($i=0;$i<=$SIZEIT;$i++){
      
        $LINESD[$i] =~ s/:email/$email/ig;
        $LINESD[$i] =~ s/:name/$name/ig;
        $LINESD[$i] =~ s/:url/$url/ig;
        $LINESD[$i] =~ s/:wwwname/$age/ig;
        $LINESD[$i] =~ s/:comments/$ownerstr/ig;  
        if ($logip eq '1'){
          $LINESD[$i] =~ s/:ip/ - $ip/ig;
        }
        else {
          $LINESD[$i] =~ s/:ip//ig;
        }
        $LINESD[$i] =~ s/:how/$how/ig;
        $strng=$LINESD[$i];
        print "$strng\n";
      }

     print "</font>\n";
     print "</center>\n";
}
print "<center>\n";
print "<table border='0' width='300'>\n";
print "<tr>\n";
print "<td valign='top'>\n";
print "<form method='POST' action='viewguest.pl'>\n";
$newmin1 = $minnum + $gnumber;
$newmax1 = $maxnum + $gnumber;
$newmin2 = $minnum - $gnumber;
$newmax2 = $maxnum - $gnumber;

print "<input type='hidden' name='min' value='$newmin2'>\n";
print "<input type='hidden' name='max' value='$newmax2'>\n";
print "<p align='right'>\n";
if ($newmin2 >= 0){
  print "<input type='submit' value='      <<<      '>\n";
}
print "</form>\n";
print "</td>\n";
print "<td valign='top'>\n";
print "<form method='POST' action='viewguest.pl'>\n";
print "<input type='hidden' name='min' value='$newmin1'>\n";
print "<input type='hidden' name='max' value='$newmax1'>\n";
if ($newmin1 <= $SIZE){
print "<input type='submit' value='      >>>      '>\n";
}
print "</form>\n";
print "</td>\n";
print "</tr>\n";
print "</table>\n";
print "</center>\n";
close(FILES);
print "</body>\n";
print "</html>\n";

