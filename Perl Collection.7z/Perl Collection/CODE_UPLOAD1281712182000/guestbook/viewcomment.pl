#!/usr/local/bin/perl
# ######################################################################### #
# Perl Guestbook: By Ackbar                                                 #
# ######################################################################### #
# This is a simple guestbook script (configured specificly for              #
# http://rebeccasghost.cjb.net						    #
# ######################################################################### #
# This code is free and may be redistributed as you please as long as these #
# comments remain. Otherwise you will be asked to remove it. (unless I say  #
# you can take credits out :)                                               #
# ######################################################################### #

# all options (0 = no) (1 = yes)
$passfile = "password.psw";		# stores your password which gives you access
					# to the owner only comments.
$datafile = "guests.dat";		# stores the data file.
$template = "template.tmp";		# Stores the url of the template file :)
$data_file = "datastore.dat";		# Where the options are stored.


# Lets read off the settings
open (FILE,"$data_file") || die("Can't Open $datafile - for input\n");
  $data=<FILE>;
  chop($data);
  ($email, $title, $toptable, $bottomtable, $toptext, $bottomtext, $gnumber, $reqemail, $reqname, $requrl, $reqwwwname, $reqfound, $reqcomments, $sendemail, $logip, $topbanner, $bannerwidth, $bannerheight, $banneralt, $viewgrx, $viewwidth, $viewheight, $viewalt, $signgrx, $signwidth, $signheight, $signalt)=split(/�/,$data);  
close(FILE); 
					
sub Read_Request{
        if ($ENV{'CONTENT_LENGTH'} > 0){
                read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
                @fields = split (/&/, $buffer);
        } else {
                $_ = "$ENV{'QUERY_STRING'}";
                @fields = split (/&/, $_);
        }
        foreach $field (@fields){
                ($name, $value) = split (/=/, $field);
                $value =~ tr/+/ /;
                $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
                $FORM{$name} = $value;
        }
}
&Read_Request;
 

&no_num unless $FORM{goup};
open (FILE,"$passfile") || die("Can't Open $datafile - for input!\n");
$pass_store=<FILE>;
close(FILE);

$pass_info = "$FORM{password}";
if ($pass_info eq $pass_store){  
  $store_num = $FORM{goup};
  $store_num-=1;
 open (FILES,"$datafile") || die("Can't Open $datafile - for input!\n");  
  for($i=0;$i<=$store_num;$i++){
    $data_store=<FILES>;
  }
  chop($data_store);
 ($name, $email, $url, $how, $age, $comments, $forowner, $ip)=split(/�/,$data_store);
print "Content-type: text/html\n\n";
print "<html>\n";
print "<head>\n";
print "<title>$title</title>\n";
print "</head>\n";
print "<body bgcolor='#000000' text='#C0C0C0'>\n";
print "<center>\n";
print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
print "<table border=0><tr>\n";
print "<td valign=top>\n";
print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
print "</td>\n";
print "<td valign=top>\n";
print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
print "</td></tr>";
print "</table><br>\n";
open (FILED, "$template") || die("Could not open template file for input.\n");
@LINES=<FILED>;
$SIZEIT=@LINES;

for ($i=0;$i<=$SIZEIT;$i++){
  $LINES[$i] =~ s/:email/$email/ig;
  $LINES[$i] =~ s/:name/$name/ig;
  $LINES[$i] =~ s/:url/$url/ig;
  $LINES[$i] =~ s/:wwwname/$age/ig;
  $LINES[$i] =~ s/:comments/$comments/ig;
  $LINES[$i] =~ s/:ho/$how/ig;
  $strng=$LINES[$i];
  print "$strng\n";
  
}
close(FILED);
print "</html>";
exit;
}
sub no_num {
  print "Content-type: text/html\n\n$num"; 	
  print "<html><head><title>I'm afraid something did not work</title></head>\n";
  print "<body bgcolor='#000000' text='#C0C0C0'>\n";
  print "<img src='$topbanner' width='bannerwidth' height='bannerheight' alt='banneralt'><BR>\n";
  print "<font face='verdana' size='-1'>I'm afraid something did not work correctly. Please\n";
  print "try again shortly.</font>\n";
  print "</body>\n";
  print "</html>\n";
  exit;
}
