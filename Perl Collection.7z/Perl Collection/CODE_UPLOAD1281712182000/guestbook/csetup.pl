#!/usr/local/bin/perl
# ######################################################################### #
# Perl Guestbook: By Calypso                                                #
# ######################################################################### #
# This is a simple guestbook script (configured specificly for              #
# http://rebeccasghost.cjb.net						    #
# ######################################################################### #
# This code is free and may be redistributed as you please as long as these #
# comments remain. Otherwise you will be asked to remove it. (unless I say  #
# you can take credits out :)                                               #
# ######################################################################### #

# all options (0 = no) (1 = yes)

# This is a simple online configuration tool. With it you can set some of
# the common things on the site.
$datafile = "datastore.dat";		# This is where we store all the options for the guestbook.
$password = "password.psw";		# location of the password file.

sub Read_Request{
        if ($ENV{'CONTENT_LENGTH'} > 0){
                read (STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
                @fields = split (/&/, $buffer);
        } else {
                $_ = "$ENV{'QUERY_STRING'}";
                @fields = split (/&/, $_);
        }
        foreach $field (@fields){
                ($name, $value) = split (/=/, $field);
                $value =~ tr/+/ /;
                $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
                $FORM{$name} = $value;
        }
}
&Read_Request;
open (PASSWRD, "$password") || die("Error opening the password file.\n");
  $passstore=<PASSWRD>;
close(PASSWRD);
if ((length($FORM{password}) < 1) || $passstore ne $FORM{password}){
   print "Content-type: text/html\n\n";
   print "<html>\n";
   print "<head>\n";
   print "<title>$title</title>\n";
   print "</head>\n";
   print "<body bgcolor='#000000' text='#C0C0C0'>\n";
   print "<form method='post' action='csetup.pl'>\n";
   
   print "<table width='100%' height='100%' valign='center' align='center' border='0' cellspacing='0' cellpadding='0'>\n";
   print "<tr><td valign='center' align='center'>\n";
   print "<table border='4' bgcolor='#c0c0c0' cellspacing='0' cellpadding='0' width='500' height='200'>\n";
   print "<tr><td valign='center' align='center'>\n";
   print "<table border='0' cellspacing='0'><tr><td>";
   print "<font face='verdana' size='-1' color='#000000'>Password:</font><BR></td><tr>\n";
   print "<td cols='2'><input type='password' name='password'>\n";
   print "<input type='submit' value='Edit Options'>\n";
   print "</td></tr></table></td></tr></table>\n";
   print "</body></html>\n";
   exit;
}

# now we read it all out of the file.
open (FILE,"$datafile") || die("Can't Open $datafile - for input\n");
  $data=<FILE>;
  chop($data);
  ($email, $title, $toptable, $bottomtable, $toptext, $bottomtext, $gnumber, $reqemail, $reqname, $requrl, $reqwwwname, $reqfound, $reqcomments, $sendemail, $logip, $topbanner, $bannerwidth, $bannerheight, $banneralt, $viewgrx, $viewwidth, $viewheight, $viewalt, $signgrx, $signwidth, $signheight, $signalt)=split(/�/,$data);  
close(FILE);  

print "Content-type: text/html\n\n";
print "<html>\n";
print "<head>\n";
print "<title>$title</title>\n";
print "</head>\n";
print "<body bgcolor='#000000' text='#C0C0C0'>\n";
print "<img src='$topbanner' width='$bannerwidth' height='$bannerheight' alt='$banneralt'><BR>\n";
print "<table border=0><tr>\n";
print "<td valign=top>\n";
print "<a href=sign.html><img src='$signgrx' width='$signwidth' height='$signheight' border='0' alt='$signalt'></a>\n";
print "</td>\n";
print "<td valign=top>\n";
print "<a href=viewguest.pl><img src='$viewgrx' width='$viewwidth' height='$viewheight' border='0' alt='$viewalt'></a>\n";
print "</td></tr>";
print "</table><br>\n";


print "<form method='POST' action='config.pl'>\n";
print "<table border='0' cellspacing='2' width='600'><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='500'><font face='verdana' size='-1' color='#a8a8a8'>Owners Email Address</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='email' value='$email' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='500'><font face='verdana' size='-1' color='#a8a8a8'>Title Of Guestbook</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='title' value='$title' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='500'><font face='verdana' size='-1' color='#a8a8a8'>Top Portion Of Table Color</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='toptable' value='$toptable' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Bottom Portion Of Table Color</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='bottomtable' value='$bottomtable' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Text Color (Top Table)</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='toptext' value='$toptext' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Text Color (Bottom Table)</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='bottomtext' value='$bottomtext' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Number Of Guests Per Page</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='gnumber' value='$gnumber' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Require Name?</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='reqname' value='$reqname' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Require Email?</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='reqemail' value='$reqemail' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Require WWW URL?</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='requrl' value='$requrl' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Require WWW Name?</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='reqwwwname' value='$reqwwwname' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Require How They Found Your Site?</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='reqfound' value='$reqfound' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Require Comments?</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='reqcomments' value='$reqcomments' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Send Email To Owner When Book Is Signed.</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='sendemail' value='$sendemail' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Include Users IP Address</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='logip' value='$logip' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>URL Of Top Banner</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='topbanner' value='$topbanner' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Top Banner Width</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='bannerwidth' value='$bannerwidth' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Top Banner Height</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='bannerheight' value='$bannerheight' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Banner Alt Tag</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='banneralt' value='$banneralt' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Sign Guestbook Graphic URL</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='signgrx' value='$signgrx' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Sign Guestbook Graphic Width</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='signwidth' value='$signwidth' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Sign Guestbook Graphic Height</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='signheight' value='$signheight' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Sign Graphic Alt Tag</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='signalt' value='$signalt' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>View Guestbook Graphic URL</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='viewgrx' value='$viewgrx' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>View Guestbook Graphic Width</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='viewwidth' value='$viewwidth' width='10'></td></tr><tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>View Guestbook Graphic Height</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='viewheight' value='$viewheight' width='10'></td></tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>View Graphic Alt Tag</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='text' name='viewalt' value='$viewalt' width='10'></td></tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Old Password (Required for update)</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='password' name='oldpw' width='10'></td></tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>New Password</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='password' name='newpw' width='10'></td></tr>\n";
print "  <td valign='top' bgcolor='#4e4e4e' width='400'><font face='verdana' size='-1' color='#a8a8a8'>Confirm New Password</font></td>\n";
print "  <td valign='top' width='100' bgcolor='#696969'><font face='verdana' size='-1' color='#ffffff'><input type='password' name='newpw2' width='10'></td></tr>\n";
print "  </table><BR>\n";
print "  <input type='submit' value='submit'>&nbsp;<input type='reset' value='Reset :)'></td></tr></table>\n";
print "</form>\n";
print "</body>\n";
print "</html>\n";