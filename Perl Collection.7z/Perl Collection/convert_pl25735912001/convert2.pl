
#!/usr/local/bin/perl
use strict;
use  warnings;

#clear screen
system ("cls");

#declare all variables


#Introduction
print "\n******* Sequence converter for patent applications ********\n";
print "\n******* Written by Tzahi Arazi, LP2264\@HOTMAIL.COM ********\n\n";
print "\nThis program converts DNA sequence in FASTA format to nucleotide & amino acid   sequences as submitted in patent applications\n\n";

print "What is FASTA format?\n\n";
print "A DNA sequence in FASTA format begins with a single-line description, followed  by lines"; 
print " of sequence data. The description line must begin with a greater-than  symbol in the"; 
print " first column.\n\nExample of DNA sequence in FASTA format:\n\n"; 
print ">U03518 Aspergillus awamori internal transcribed spacer\n";
print"AACCTGCGGAAGGATCATTACCGAGTGCGGGTCCTTTGGGCCCAACCTCCCAT\n";
print"CTGTTGCTTCGGCGGGCCCGCCGCTTGTCGGCCGCCGGGGGGGCGCCTCTGCC\n\n";

# initilize program continue flag
my ($flag);
$flag="y";

#main program

do {for_seq ();}
while ($flag eq "y");
print "\n\n Thank you for using sequence converter by Tzahi Arazi";

#Analyse seq subrutine

sub for_seq {

my ($seq_file, $seq_name, $sequence, $seq_length);
my ($line, $patentseq,$codon,$count,$filename,%genetic_code,$residue_count,$spaces,$rows,$nucleotide,$error,$number_line, $result_file);

%genetic_code = ("GGG" => "Gly",       
                "GGA" => "Gly",
		"GGT" => "Gly",
		"GGC" => "Gly", 
		"GAT" => "Asp",
                 "GAC" => "Asp",
                 "GAA" => "Glu",
                 "GAG" => "Glu",
                 "GTG" => "Val",
		 "GTA" => "Val",
		 "GTT" => "Val",
		"GTC" => "Val",
		 "GCG" => "Ala",
		 "GCA" => "Ala",
		 "GCT" => "Ala",
		 "GCC" => "Ala",
		 "CGC" => "Arg","CGA" => "Arg", "CGT" => "Arg",
		 "AGG" => "Arg", "AGA" => "Arg", "CGG" => "Arg",
		"AGT" => "Ser", "AGC" => "Ser","TCG" => "Ser",
		 "TCA" => "Ser","TCT" => "Ser", "TCC" => "Ser",
		"AAG" => "Lys", "AAA" => "Lys",
		"AAT" => "Asn", "AAC" => "Asn",
		"ATG" => "Met", 
		"ATC" => "Ile", "ATT" => "Ile", "ATA" => "Ile",
		"ACC" => "Thr", "ACT" => "Thr","ACA" => "Thr", "ACG" => "Thr",
		"TGG"=> "Trp",
		"TGA" => "Amb", "TAA" => "Och","TAG" => "Opa",
		"TGC" => "Cys", "TGT" => "Cys",
		 "TAC" => "Tyr", "TAT" => "Tyr",
		"CTG" => "Leu", "TTA" => "Leu","TTG" => "Leu", 
		"CTC" => "Leu","CTT" => "Leu", "CTA" => "Leu",
		"TTC" => "Phe", "TTT" => "Phe",
		"CAA" => "Gln", "CAG" => "Gln",
		"CAC" => "His", "CAT" => "His",
		"CCC" => "Pro", "CCT" => "Pro","CCA" => "Pro", "CCG" => "Pro",
);



print "Please enter your sequence (FASTA format) file name or path: ";
$seq_file = <STDIN>;
chop ($seq_file);

open (SEQ, $seq_file) || die "cannot open \"$seq_file\": $!";

#read sequence name and description from first line

$seq_name = <SEQ>;
chop ($seq_name);

#initialize a variable to contain the entire sequence

$sequence = "";

#read sequence lines from file

while ($line = <SEQ>) {
   chop ($line);
   $sequence .= $line;     #add line to $sequence
}
#close file

close (SEQ);
#convert to upper case
$sequence =~ s/a/A/g;
$sequence =~ s/t/T/g;
$sequence =~ s/g/G/g;
$sequence =~ s/c/C/g;

#open result file

print "Please enter file name to contain PATENT formatted sequence: ";
$filename = <STDIN>;
chop ($filename);

#checking if file exists
$result_file = process ($filename,$seq_name);

open (RESULT_SEQ, ">$result_file")|| die "cannot open $result_file: $!";
print RESULT_SEQ "$seq_name\n\n";
print RESULT_SEQ "Formatted amino acid sequence:\n\n";

#Format protein sequence

$error="";
$codon="";
$seq_length = length ($sequence);

$residue_count=0;
for ($count=0;$count<=$seq_length-3;$count+=3){
    print ".";
    $residue_count++;
    $codon = substr ($sequence,$count, 3);
    unless ($genetic_code{$codon})
    {$patentseq .=  "XXX ";
 $error.= "\nAttention !!!, illegal code on residue number: $residue_count";
}
    else {$patentseq .=  "$genetic_code{$codon} ";}
    $number_line .='   ';
    unless ($residue_count%5)
    {
	if ($residue_count==5)
	{$number_line .= "   $residue_count ";}
	elsif ($residue_count<100){$number_line.= "  $residue_count ";}
    
	   elsif ($residue_count>=100 and $residue_count<1000)
	    {$number_line.= " $residue_count ";}
    
	    elsif ($residue_count>=1000){$number_line.= "$residue_count ";}
	}
    
  
#going down one line
 unless ($residue_count%15)   
{
	$patentseq .= "\n";
	$number_line .="\n";
	print RESULT_SEQ $patentseq;
	print RESULT_SEQ $number_line;
	$patentseq="";
	$number_line="";
}
}
#print the last residues 
print RESULT_SEQ "$patentseq\n";
print RESULT_SEQ "$number_line\n";
print RESULT_SEQ "\n$error\n";
# Format DNA sequence;

$error="";
$patentseq="";

for ($count=1;$count<=$seq_length;$count+=1){
    $nucleotide = substr ($sequence,$count-1, 1);
unless ($nucleotide=~ /[AGTC]/) {$error.= "\nAttention !!!, illegal code on bp number: $count";}
$patentseq .=  $nucleotide;

    unless ($count%10){$patentseq .= " "}
    unless ($count%50){$patentseq .= " $count\n"}
}
# number of spaces and spaces between rows
if ($seq_length%50){
$spaces=int($seq_length/50+1)*50-$seq_length;
$rows=int($spaces/10);

#adding spaces and counter in last line

for ($count=1;$count<=$spaces+$rows;$count+=1){
    $patentseq .=" ";
}
unless ($spaces%10){$patentseq .= " $seq_length"}
elsif ($spaces+$rows){$patentseq .= "  $seq_length"}

}
print RESULT_SEQ "\n\nFormatted DNA sequence:\n\n";
print RESULT_SEQ "$patentseq\n";
print RESULT_SEQ "$error\n\n";
close (RESULT_SEQ);
#do you want to continue?
print "\n\nDo you want to format another seq? type y (yes) or any key (quit)\n";
$flag = <STDIN>;
chop ($flag);
return ();
}

sub process {

        my($filename,$seq_name) = @_;
	my ($answer, $newname);
        while (-e $filename){
	do
{
    $answer="";
    print "$filename exists, do you want to replace? n (no) \n";  
    $answer = <STDIN>;
    chop ($answer);
    if ($answer eq "n"){
   print "Please enter new file name to contain PATENT formatted $seq_name: ";
	    $newname = <STDIN>;
	    chop ($newname);
	$filename = $newname;
}else {return ($filename)};
}   
}

return ($filename);

}
