#!/usr/bin/perl
use strict;
use constant TAB => ' ' x 4;

my $VERSION = '1.0.0';

my (@filename, $dirname);

if ($ARGV[0] eq '-d')
{
	$dirname = $ARGV[1];

	opendir(DIR, $dirname) or die "Unable to open directory $dirname. $!";
	@filename = sort grep { $_ =~ /\.(?:pl|pm|cgi)$/ } readdir DIR;
	closedir DIR;

	die "There does not appear to be any perl scripts (*.pl|*.pm|*.cgi) in $dirname" if ! @filename;

	my $slash = $dirname =~ /\\/ ? '\\' : '/';
	$dirname .= $slash if $dirname !~ /[\\\/]$/;
}
else
{
	usage() if $ARGV[0] =~ /^-.$/ && $ARGV[0] ne '-f';

	my $idx_begin = $ARGV[0] eq '-f' ? 1 : 0;

	for my $i ($idx_begin .. $#ARGV)
	{
		push @filename, $ARGV[$i] if trim($ARGV[$i]);
	}
}

usage() if ! @filename;

my $num_files          = scalar(@filename);
my $line_cnt_ttl       = 0;
my $perl_code_cnt_ttl  = 0;
my $perl_blank_cnt_ttl = 0;
my $brace_only_cnt_ttl = 0;
my $blank_cnt_ttl      = 0;
my $comment_cnt_ttl    = 0;
my $pod_cnt_ttl        = 0;
my $pod_blank_cnt_ttl  = 0;
my $end_cnt_ttl        = 0;

foreach my $file (@filename)
{
	my $in_pod         = 0;
	my $post_end       = 0;
	my $line_cnt       = 0;
	my $perl_code_cnt  = 0;
	my $perl_blank_cnt = 0;
	my $brace_only_cnt = 0;
	my $blank_cnt      = 0;
	my $comment_cnt    = 0;
	my $pod_cnt        = 0;
	my $pod_blank_cnt  = 0;
	my $end_cnt        = 0;

	open(IN, "$dirname$file") or die "Unable to open $file for reading. $!";

	while (my $line = <IN>)
	{
		chomp $line;
		$line_cnt++;
		my $is_blank = $line =~ /^\s*$/;
		$blank_cnt++ if $is_blank;

		if ($line =~ /^__(?:END|DATA)__$/)
		{
			$post_end = 1;
			$end_cnt++;
		}
		elsif ($post_end)
		{
			$end_cnt++;
		}

		if ($line =~ /^=(?:pod|begin|head\d|item|for|over)/)
		{
			$in_pod = 1;
			$pod_cnt++;
		}
		elsif ($in_pod)
		{
			$pod_cnt++;
			$pod_blank_cnt++ if $is_blank;
			$in_pod = 0 if $line =~ /^=cut$/;
		}

		if (!$in_pod && !$post_end)
		{
			if ($line =~ /^\s*#/)
			{
				$comment_cnt++;
			}
			else
			{
				$perl_code_cnt++;
				$brace_only_cnt++ if $line =~ /^\s*[\{\}]$/;
				$perl_blank_cnt++ if $is_blank;
			}
		}
	}

	close IN;

	print "$file\n";
	printf "@{[TAB]}Length:     %5d lines\n", $line_cnt;
	printf "@{[TAB]}Blank:      %5d lines\n", $blank_cnt;
	printf "@{[TAB]}Perl code:  %5d lines\n", $perl_code_cnt;
	printf "@{[TAB]}Perl blank: %5d lines\n", $perl_blank_cnt;
	printf "@{[TAB]}Brace only: %5d lines\n", $brace_only_cnt;
	printf "@{[TAB]}Comment:    %5d lines\n", $comment_cnt;
	printf "@{[TAB]}POD:        %5d lines\n", $pod_cnt;
	printf "@{[TAB]}POD blank:  %5d lines\n", $pod_blank_cnt;
	printf "@{[TAB]}__END__:    %5d lines\n\n", $end_cnt;
	printf "@{[TAB]}Code density: %.0f%\n", ((($perl_code_cnt - $perl_blank_cnt) - $brace_only_cnt) / $line_cnt) * 100;
	print "\n";

	if ($num_files > 1)
	{
		$line_cnt_ttl       += $line_cnt;
		$perl_code_cnt_ttl  += $perl_code_cnt;
		$perl_blank_cnt_ttl += $perl_blank_cnt;
		$brace_only_cnt_ttl += $brace_only_cnt;
		$blank_cnt_ttl      += $blank_cnt;
		$comment_cnt_ttl    += $comment_cnt;
		$pod_cnt_ttl        += $pod_cnt;
		$pod_blank_cnt_ttl  += $pod_blank_cnt;
		$end_cnt_ttl        += $end_cnt;
	}
}

if ($num_files > 1)
{
	print "+--------------------------+\n",
		"| Totals:                  |\n",
		"+--------------------------+\n";
	printf "| Files:      %6d       |\n", $num_files;
	printf "| Length:     %6d lines |\n", $line_cnt_ttl;
	printf "| Blank:      %6d lines |\n", $blank_cnt_ttl;
	printf "| Perl code:  %6d lines |\n", $perl_code_cnt_ttl;
	printf "| Perl blank: %6d lines |\n", $perl_blank_cnt_ttl;
	printf "| Brace only: %6d lines |\n", $brace_only_cnt_ttl;
	printf "| Comment:    %6d lines |\n", $comment_cnt_ttl;
	printf "| POD:        %6d lines |\n", $pod_cnt_ttl;
	printf "| POD blank:  %6d lines |\n", $pod_blank_cnt_ttl;
	printf "| __END__:    %6d lines |\n", $end_cnt_ttl;
	print "|                          |\n";
	printf "| Code density:  %3d%      |\n", sprintf("%.0f", ((($perl_code_cnt_ttl - $perl_blank_cnt_ttl) - $brace_only_cnt_ttl) / $line_cnt_ttl) * 100);
	print "+--------------------------+\n";
}

exit;

sub trim
{
	## removes all whitespace chars from beginning and end of $str
	my $str = shift;

	$str =~ s/^\s+//;
	$str =~ s/\s+$//;

	return $str;
}

sub usage
{
	print "\nUsage: plnct.pl [-f] filename OR plnct.pl -d dirname\n";
	exit 1;
}

__END__

=pod

=head1 NAME

Perl Line Counter - F<plnct.pl>

=head1 SYNOPSIS

Counts the number of various types of lines in a Perl script or all Perl scripts in a given directory.

=head1 USAGE

plnct.pl [-f] F<filename> [F<filename2>, ...]

or

plnct.pl -d F<dirname>

=over

=item B<-f>

Specify one or more files after this flag. Note: when specifying filenames the B<-f> may be omitted.

=item B<-d>

Use this flag to specify a directory. The program will act on all Perl files in the directory (*.pl, *.pm, *.cgi). It does not recurse into sub-directories.

=back

=head1 DESCRIPTION

Outputs line counts on the following:

=over

=item Total Lines:

Total number of lines in the file.

=item Blank lines:

Total number of lines that are blank or contain only whitespace.

=item Perl Code:

Lines of Perl code.

=item Perl Blank:

Blank lines within the Perl code.

=item Brace Only:

Lines that contain only an open or close curly brace.

=item Comments:

Number of lines that contain only comments.

=item POD:

Number of lines of plain old documentation.

=item POD Blank:

Number of blank lines within the POD.

=item __END__:

Number of lines after __END__ or __DATA__ (including the __END|DATA__ line).

=item Code Density:

A percentage that indicates how dense the Perl code is in relation to the whole file. (Overly dense code may be difficult to read and therefore maintain.)

Code Density Equation:

(((lines of Perl code - Perl blank lines) - brace-only lines) / lines in the file) * 100 = density percentage

=back

If more than one file is processed, then a "totals" report will also be given at the end.

=head1 BUGS

This program does not check to see whether or not trigger text is embedded in a string. So a string that contains a C<#> at the beginning of a line will trigger the comment counter. Likewise with POD directives or other such things.

=head1 TO DO

=over

=item *

Add option to recurse into sub-directories when using the directory option.

=head1 AUTHOR

John William Winger III

=head1 COPYRIGHT

This program is free software. You may copy or redistribute it under the same terms as Perl itself.

=cut
