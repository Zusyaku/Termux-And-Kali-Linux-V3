Title: Image Gallery
Description: Image gallery is an image upload/display system. Many people out there are paying hosts to be used for photo galleries just because it saves our time from messing with all the html and creating thumbnails/links to our images.<p>
There are two scripts:<p>
1) Image upload<br>
browser-based image uploading system where you select file and add your image details.
2) Image display<p>
Displays 20 images per page in reverse insertion order (newest will always be on the top right, older ones will be pushed downwards or to the next page).<br>
All images are thumbnailed to 100x100 and linked to a window that opens to the exact size of the actual image.<br>
Underneath the image is printed the image filename, image title, image description and image size dimensions.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=505&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
