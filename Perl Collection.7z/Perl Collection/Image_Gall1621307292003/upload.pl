#!/usr/bin/perl -w

#
# IMAGES FOLDER MUST BE CHMOD TO 777 otherwise script fails
#


use warnings;
use CGI qw/:standard/;

use POSIX;

use DB_File;

my %upload;
my $upload = "imagegallery.db";

tie %upload, "DB_File", "$upload", O_CREAT|O_RDWR, 0644, $DB_BTREE
	or die "Cannot open file 'upload': $!\n";



my $mode = 0755;

print header, start_html('Upload Form!');

print "Upload formats allowed: jpg, gif, bmp.<br>";

print start_form(
    -method  => 'post',
    -enctype => 'multipart/form-data'
  ),
  table(
   Tr(
   		td(""),
   		td("Please keep filenames, descriptions and titles short to preserve a more uniformed appearance (under 20 chars)"),
   		),
   Tr(
    	td("Image Title: "),
    	td(
    		textfield(
    			-name		=>  'title',
    			-size		=>  50,
    			-maxlength	=>  80
    		),
    	),
    ),
    Tr(
    	td("Short Description: "),
    	td(
    		textfield(
    			-name		=>  'desc',
    			-size		=>  50,
    			-maxlength	=>  80
    		),
    	),
    ),
    Tr(
        td("File: "),
        td(
            filefield(
                -name      => 'upload',
                -size      => 50,
                -maxlength => 80
            ),
        ),
    ),
    Tr( td(), td( submit( 'button', 'submit' ), ) )
  ),
  end_form(), hr;




if ( param() ) {



    # take form data
    my $remotefile = param('upload');

    my $desc = param('desc');
    $desc =~ s/::/\&\#58\;\&\#58\;/g; # remove semicolons
    
    my $title = param('title');
	$title =~ s/::/\&\#58\;\&\#58\;/g; # remove semicolons

    # make new variable to prevent overwriting of form data
    my $filename = $remotefile;

    # remove all directories in the file name path
    $filename =~ s/^.*[\\\/]//;
    $filename =~ s/::/\&\#58\;\&\#58\;/g; # remove semicolons

foreach (keys %upload) {
my ( $filename1, $title, $desc, $width, $height ) = split ( /::/, $upload{$_} );
if ($filename1 eq $filename) {
print qq(<font color="red">A file with that name already exists.  Upload aborted.</font>);
exit;
}
}
  

    # full file path to upload directory (must include filename)
    my $localfile = "/home/sulfericacid/public_html/gallery/images/$filename";

    # full url to upload directory (cannot include filename or an end slash /)
    my $url = "http://sulfericacid.perlmonk.org/gallery/images";

    my $type = uploadInfo($remotefile)->{'Content-Type'};
    unless ( $type eq 'image/pjpeg' || $type eq 'image/gif' || $type eq 'image/bmp') {
        print "Wrong!  This is not a supported file type.";
        exit;
    }



    # open a new file and transfer bit by bit from what's in the buffer
    open( SAVED, ">>$localfile" );    # || die $!;
    while ( $bytesread = read( $remotefile, $buffer, 1024 ) ) {
        print SAVED $buffer;
    }
    close SAVED;

    chmod $mode, "$localfile";        # or die "can't chmod: $!";
    print "-----------------------------<br>";
    print
qq(File was uploaded to <a href="$url\/$filename">$url\/$filename</a>);


    # required since module was not preinstalled on server
    use lib "/home/sulfericacid/public_html/lib/";
    use Image::Info qw(image_info dim);
  
    # assigning info to a filename (better be an image)
    my $info =image_info("$localfile");
   # if for any reason we can't open the file, this error trap should pick it up
    if ( my $error = $info->{error} ) {
        #die "Can't parse image info: $error\n";
    }

    # declaring the width and heighth of your image
    my ( $w, $h ) = dim($info);


my $combo = join("::", $filename, $title, $desc, $w, $h);
$upload{localtime()} = "$combo";


    print "<br><br><br>";
    print "Image code:<br>";
    print
qq(&lt;p style =\"background:url\($url\/$filename\)\;width:$w\;height:$h\;\"&gt;);
print "<br>-----------------------------<br>";


}
