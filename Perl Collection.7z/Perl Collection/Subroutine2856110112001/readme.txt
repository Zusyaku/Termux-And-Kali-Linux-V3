########################################################################
#
# suber.pl
#
# Version 1.0, Sept., 2001.
#
# By Glen Yeager | scripts@distantrealm.com | http://www.distantrealm.com
# Copyright 2001, Glen Yeager
#
#
# Suber is a free tool that will allow you to easily break apart those big 
# Scripts into individual files each containing one of the Subroutines from 
# the original file. A require file is also built to allow you to add it's 
# contents into the newly created filename_main.pl and this will allow the 
# file to run in its "broken-out" state. Suber is provided in a .zip format 
# for NT systems, as that is the only platform that is has been tested under.
#
#
# For more recent version of this script, download from sites.
# For customization of this script or other cgi you require, contact
# Glen Yeager at the address above. (that's not free!!)
#
# This is freeware. You must not remove this credit. You must not 
# sell, redistribute or modify this script. Each copy of this script must be 
# downloaded from www.distantrealm.com.
#
# Requirements: Perl 5.0 or higher. 
#
# Usage: suber.pl file.ext 
# File = the file to be processed 
# Ext  = the perl extention (.pl or .cgi)
# The output will be placed into a newly created
# directory named after the File.
#
#
# IMPORTANT: I offer no warranties with this freeware. Use it at your own 
# risk. Glen Yeager is not responsible for any damage or injury  
# received through the use of this software. I don't know how you'd injure
# yourself, however - Don't read this and drive at the same time!
#
########################################################################