Title: Subroutine splitter
Description: Suber is a free tool that will allow you to easily break apart those big Scripts into individual files each containing one of the Subroutines from the original file. A require file is also built to allow you to add it's contents into the newly created filename_main.pl and this will allow the file to run in its "broken-out" state. Suber is provided in a .zip format for NT systems, as that is the only platform that is has been tested under.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=241&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
