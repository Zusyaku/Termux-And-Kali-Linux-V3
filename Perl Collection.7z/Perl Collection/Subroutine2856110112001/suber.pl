#!/usr/bin/perl5

########################################################################
# On a unix system, make sure the first line has the true path to perl 5
# on your system!
#
# suber.pl
#
# Version 1.0, Sept., 2001.
#
# By Glen Yeager | info@distantrealm.com | http://www.distantrealm.com
# Copyright 2001, Glen Yeager
#
#
# For more recent version of this script, download from sites.
# For customization of this script or other cgi you require, contact
# Glen Yeager at the address above. (that's not free!!)
#
# This is freeware. You must not remove this credit. You must not 
# sell, redistribute or modify this script. Each copy of this script must be 
# downloaded from www.distantrealm.com.
#
# Requirements: Perl 5.0 or higher. 
#
# Usage: suber.pl file.ext 
# File = the file to be processed 
# Ext  = the perl extention (.pl or .cgi)
# The output will be placed into a newly created
# directory named after the File.
#
#
# IMPORTANT: I offer no warranties with this freeware. Use it at your own 
# risk. Glen Yeager is not responsible for any damage or injury  
# received through the use of this software. I don't know how you'd injure
# yourself, however - Don't read this and drive at the same time!
#
########################################################################

if ($ARGV[0] eq "") {die "Please provide filename to process or /h for help\n";}

if ($ARGV[0] eq "?"){die qq~
Usage: suber file.ext 
File = the file to be processed 
Ext  = the perl extention (.pl or .cgi)
The output will be placed into a newly created
directory named after the File.

~;
}

if ($ARGV[0] ne "?"){ $datafile = $ARGV[0];
($filen,$ext) = split(/\./, $datafile);
print "$filen\,$ext";
$subflag = 0 ;
$mainflag = 1;
$cmd = "md $filen\n";	
open(CMD, "|$cmd");
close(CMD);

open(MAIN,"$datafile") || die $!;

@main = <MAIN>;
close(MAIN);
open(OUTFILE,">$filen\\requirelist.$ext") || die $!;
print OUTFILE qq~


###################################################################################
##
## 	Add this to the beginning of the newly created file called $filen\_main.$ext
##   and it will properly include all the indivdule files back into the script
##
###################################################################################

~;

foreach $main_line (@main)
{
	
	chop($main_line);
	$num = substr($main_line,0,3);
	$num1 = substr($main_line,0,1);
	
	if (($subflag == 1) && ($num =~ "sub"))
	{
		$subflag = 0;
	}
	
	if (($subflag == 0) && ($num =~ "sub"))
	{
		print NUMBER "1\;\n";
		close(NUMBER);
		$subflag = 1;
		$mainflag = 0;
		($s1, $subname, $s2) = split(/ /, $main_line);
		open(NUMBER,">$filen\\$subname.$ext");
		print "Processing - $subname\n";
		print OUTFILE "require \"$subname\.$ext\"\;\n";
	}
	
	if ($subflag == 1)
	{
		print NUMBER "$main_line\n";
	}
	
	if ($mainflag == 1)
	{
		$mainflag = 2;
		open(NUMBER,">> $filen\\$filen\_main.$ext");
		print "Processing - $filen\_main.$ext\n";
	}
	
	if ($mainflag == 2)
	{
		
		print NUMBER "$main_line\n";
	}
	
	
}

print NUMBER "1\;\n";
close(NUMBER);
close(OUTFILE);
print "Output files have been saved into the $filen directory.";
}