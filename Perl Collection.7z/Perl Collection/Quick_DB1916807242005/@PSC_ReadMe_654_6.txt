Title: Quick DB
Description: Simple and Quick DataBase creation and interface.
Takes an 'HTML' file with dynamic information placed in braces .. '{Field1}' and creates a form and can generate a static HTML page with the field data inserted. Can even handle multiple records. No kidding! - Starting builing a Flat-File Text DB withing minutes. CGI will automatically look for HTML files ending in '_template.html' as its source. Generated html files will use name less '_template'. Example in screen shot included as test files (and data)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=654&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
