#!/usr/bin/perl
use strict;
use Socket;
use IO::Handle;
my($bytes_out,$bytes_in) = (0,0);
my $host = shift || 'localhost';
my $port = shift || getservbyname('echo','tcp');	
my $protocol = getprotobyname('tcp');
$host = inet_aton($host) or die "$host: unknow host ";
socket(SOCK,AF_INET,SOCK_STREAM,$protocol) or die "socket() failed: $!";
my $des_addr = sockaddr_in($port,$host);
connect(SOCK,$des_addr) or die "connect() failed: $!";
SOCK->autoflush(1);
print "very easy network calc by Hussachai Puripunpinyo\n";
print "student id : 45010898\n";
print "input >>>";
while(my $msg_out =<> ){
	print SOCK $msg_out;
	my $msg_in = <SOCK>;
	print $msg_in;
	$bytes_out += length($msg_out);
	$bytes_in += length($msg_in);
	print "input >>>";
}
close SOCK;
print STDERR "bytes_sent = $bytes_out, bytes_recieved = $bytes_in\n";