#!/usr/bin/perl
#by Hussachai Puripunpinyo class:4F ID:45010898
use strict;
use Socket;
use IO::Handle;
use constant MY_ECHO_PORT => 2007;
my ($bytes_out,$bytes_in) = (0,0);
my ($result,@operand,@operator);
my $port = shift || MY_ECHO_PORT;
my $protocol = getprotobyname('tcp');
$SIG{'INT'} = sub {
	print STDERR "bytes_sent = $bytes_out , bytes_recieved = $bytes_in \n";
	exit 0;
};
socket(SOCK,AF_INET,SOCK_STREAM,$protocol) or die "socket() failed: $!";
setsockopt(SOCK,SOL_SOCKET,SO_REUSEADDR,1) or die "Can't set SO_REUSEADDR: $!";
my $my_addr = sockaddr_in($port,INADDR_ANY);
bind(SOCK,$my_addr) or die "bind() failed: $!";
listen(SOCK,SOMAXCONN) or die "listen() failed: $!";
warn "waiting for incoming connections on port $port ...\n";
while(1){
	next unless my $remote_addr = accept(SESSION,SOCK);
	my ($port,$hisaddr) = sockaddr_in($remote_addr);
	warn "Connection from [",inet_ntoa($hisaddr),",$port]\n";
	SESSION -> autoflush(1);
	while (<SESSION>){	
		$bytes_in += length($_);
		chomp;
		my $exp = scalar $_;
		print $exp;
		@operand = split(/[+|-]|[*|\/]/,$exp);
		$operator[0] = substr($_,length($operand[0]),1);
		doExpression($operator[0],$operand[0],$operand[1]);
		$result = "Result is $result \n";
		print SESSION $result;
		$bytes_out += length($result);	
	}
	warn "Connection from [",inet_ntoa($hisaddr),",$port]
	finished \n";
	close SESSION;
}	
close SOCK;
sub doExpression{
	my $i=$_[0];
	if($operator[$i] eq "+"){
		$result = $_[1]+$_[2];
	}elsif($operator[$i] eq "-"){
		$result = $_[1]-$_[2];
	}elsif($operator[$i] eq "*"){
		$result = $_[1]*$_[2];
	}elsif($operator[$i] eq "/"){
		if($_[2]!=0){
			$result = $_[1]/$_[2];
		}else{
			$result = "Devide by zero!";
		}
	}else{
		$result = "Error:Not supported operator or not yet implement\n";
	}
}