Title: Mock CLS
Description: The purpose is to create a cls or clear screen function for html output in perl. I found a posting here on planetsourcecode "A Clear Screen Function" Submitted on: 2/9/2003 By: Jaime Muscatelli that was an Active Perl specific system call (I need unix). After some thought, it occured to me that a screen cover up (or mock cls) would achieve the same result. 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=760&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
