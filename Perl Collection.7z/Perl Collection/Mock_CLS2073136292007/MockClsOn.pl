#!/usr/bin/perl
#
#  "Mock CLS" for html output
#
#  Written by Mark Luquette (mark@buildabyte.com)on 6-28-2007 (copyright)
#
#  Background and Purpose:
#  I wrote a program that had a processing portion that took a variable
#  amount of time as it relied on third party servers, and in development, 
#  I did not want to wait for time outs. I wanted to know if the whole script 
#  crashed or if it was just processing slow. So I wrote in some html to print 
#  at various ponits in the script, so that I knew where I was in the running
#  program. This worked fine, and the serial messages piled up one after the other
#  on the monitor. I decided to use the same reporting in another program, but 
#  it had no significant delays in processing, so the first and second messages
#  (I'll refer to as the "first html print" and the "second html print") popped
#  up with so little delay between them that it appeared odd to have the first message
#  say wait for the second. If the user did not realize the second message was already
#  there, they might unnecessarily wait. So, why not cls (clear screen) between the 
#  two messages, and the first would never be seen unless there was a problem.
#  Since my messages report to the user in html, I looked for a cls there. The ASCII
#  codes are largely transportable to html, but not the form feed command. The perl
#  \f also did not work for me. I then figured out that I could just cover the first
#  message by the second one by using div tags around the second message, essentially
#  painting a box over it. If the box color and body bgcolor are the same, the cover up
#  is seamless. 
#
#  General points to check-remember (mostly for beginners):
#
#   1. Make sure header path to perl (above-first line of script)is correct.
#      If you use a web hosting company that allows perl - they can tell you.
#      or just do a "hello world" with #!/usr/bin/perl or #!/usr/local/bin/perl
#	 the 2 most likely in unix. #!C:/Perl/bin/perl for Win.
#   2. ftp transfer must be set for ascii not auto or binary, auto will default
#      to binary and invisible binary junk will trash your header. A habit to
#      check this on every transfer will be rewarded.Mouse over the little box 
#      that hangs out under the arrows (in WS-FTP, the ftp program I use) and see
#      the state. Clicking it cycles through auto-ascii-binary.
#   3. Make sure the script is permissioned (chmod) as 755 which means owner 
#      has read-write-execute and the group and everyone have read-execute.
#	 Logging into your control panel at the web host is time consuming. If you 
#      use WS-FTP (and others?) as an ftp program, a right click "Ftp Commands"
#      then "CHMOD" then put in 755, may allow you a quick change to permissions.
#   4. Removal or editing of the line ... print "Content-type: text/html\n\n"; ...
#      while leaving in the html will render the script non-functional
#   
#   WARNING: Use this script at your own risk - I assume no leability if it damages or 
#   corrrupts your computer, network, or someone else's equipment while running 
#   under your command. 
#
##############################################################################  
#
# INSERT HERE any perl code you want to run before the first message.
#
# First message ====>>> 

print "Content-type: text/html\n\n ";

#  mesg1, used below, is arbitrarily chosen text to act as a flag to stop the perl print.
#  Note that none of the html lines that follow require line termination with a 
#  semi-colon. This example directs messages to "Wild Bill", but the actual program
#  uses $contents{'name'} to supply a form supplied, perl pasrsed name.

print <<"mesg1";  
<HTML><HEAD><TITLE>submission in progress</TITLE></HEAD>
<BODY bgcolor="#6699dd"><center>
<TABLE bgcolor=black border=3 cellpadding=6>
<TR><TD bgcolor="#CCCCCC" align="center"><BR>             
<FONT SIZE="4" COLOR="#000099"><B>Wild Bill<HR><BR>
Your submission is processing</B></FONT><BR><BR>
Please wait till the &quot;Continue &quot; button appears<BR><BR></center><HR align="center">
</TD></TR></TABLE>
</BODY></HTML>
mesg1
	
#
#  INSERT HERE any perl code you want to run between the first
#  and second messages.
#

#  To see the effect of the Mock CLS, comment out the 2 lines of <style>
#  info and the <Div> and </Div> tags and see the Mock CLS go away!
#  Remember to use the html comment tags <!--  -->, not the # for perl
#
#  This example uses a box width of 600 px. If you make your browser window wide enough, 
#  you can draw message one out from behind message two. This is because, in this example
#  message 2 is held in the box, and message one is positioned by <center> tags.

print <<"mesg2";
<HTML><HEAD><TITLE>Entry finished</TITLE>

<style> #mockcls {position:absolute;  width:600;  height:400;  top:0;
right:auto;  bottom:auto;  left:0;  background-color:#6699dd;}</style>

</HEAD>
<BODY bgcolor="#6699dd"><center>
<DIV id="mockcls" style="WIDTH: 600px; HEIGHT: 600px">
<BR><BR>
<TABLE bgcolor=black border=3 cellpadding=6>
  <TR>
    <TD bgcolor="#CCCCCC" align="center"><BR>             

    <FONT SIZE="4" COLOR="#000099">
    &nbsp;&nbsp;&nbsp;You Have Successfully Submitted Your Protocol</B></FONT>
    &nbsp;&nbsp;&nbsp;<BR><BR>
    If you do not receive email confirmation of your submission<BR> in 
    48 hours, please contact THE MAN at Slipery-Ops.Inc<BR><BR>

    <!-- This is a nested table to form a button -->
    <TABLE align="center" bgcolor="#000000">
    <TR bgcolor="#6600FF" border=3><TD>
    <A HREF="http://www.buildabyte.com">
    <FONT SIZE="4" COLOR="#FFFF00"><B>&nbsp;&nbsp;Click Here to Go To Author's Website
    &nbsp;&nbsp;</B></FONT>  
    </A></TD></TR></TABLE>

</TD></TR></TABLE>

</CENTER></div></BODY></HTML>
mesg2

##################### END ###########################>>>>>>>>>>>>>>
