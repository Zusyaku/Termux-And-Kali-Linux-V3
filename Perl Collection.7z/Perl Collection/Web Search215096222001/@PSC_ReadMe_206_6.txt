Title: Web Search engine - Searches the web **UPDATED**
Description: This code is a basic search engine that uses the Open Directory Project for it's results. This allows you to add the entire internet to your site instantly. It is very easy to configure and works off templates and has a small code base. No need to edit the script, everything is in templates. SEe the Readme.txt file for more details. Vary fast, always updated, only requires CGI access. Enjoy! 
***UPDATE***
New features added!
************
(a). Now has the ability to use LWP or plain sockets (works both on NT AND unix)
(b). Debugging has been improved, autofix systems added
If people are interested, I'll develope an admin area, plus page caching etc for it. ALso, templates have been updated.
NOTE: A demo is up at http://www.cgifreebies.com/odp/

UPDATE: I have fixed some small issues with no results being returned and some issues with just using sockets. Don't forget to look at the demo. [June 22, 2001]
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=206&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
