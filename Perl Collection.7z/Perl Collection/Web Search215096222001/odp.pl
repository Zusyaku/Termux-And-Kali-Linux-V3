#!/usr/local/bin/perl
###############################
# Open Directory Project Puller, Release 1
# Designed by Dustin A. Lambert
# Please keep this header, all questions & comments send to dustin@midsouthweb.com
#########################################
#					#
#       BEGIN CONFIGURATION SECTION     #
#					#
#########################################
$script = $ENV{'SCRIPT_NAME'}; # url of the program
$mainurl1 = "http://cgifreebies.com/odp/"; # The main page for your directory
$base = "CGI Freebies"; #name of the directory
$title = "Search Results"; # HEader of search results
$title2 = "Search Catergories"; # Header of category lists...
$dmoz_search = "http://search.dmoz.org/cgi-bin/search"; # Do not touch this
$dmoz_Search_urlext = "";
$template = "search.temp"; # Filename of template (may have to use path on Win32)
$starimage = ""; # Image to replace the "hot" sites on odp
$uselwp = 0; # Set to 1 to use LWP (faster), set to 0 to use sockets
$debug = 1; # Allow debug, 2 = always on, 1 = yes, 0 = no, - NOTE: To use debug, set debug=1 in the url
#########################################
#					#
#       END CONFIGURATION SECTION       #
#					#
#########################################
# Do not touch past here!
$odpname = $base;
($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time - 10700);
@month=(January,Febuary,March,April,May,June,July,August,September,October,November,December); # define months
@day=(Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday); #define days
$wday=$day[$wday];
$mon=$month[$mon];
$year = $year + 1900; # fix year...
$date = "$wday, $mon $mday, $year";
# End Advanced Configuration #
&urls(); # set query_string into $url{'key'} = $value
if ( $uselwp < 1 ) {
use Socket;
} else {
use LWP::Simple;
}
#$url{'search'} =~ s/uc sprintf("%%%02x",ord($1))//g; # Pack the strings..
#$url{'search'} =~s/%(..)/pack("c",hex($1))/ge;
#$url{'search'} =~ s/\+/ /g;
#$url{'search'} =~ s/</&lt;/g;
#$url{'search'} =~ s/>/&gt;/g;
&html(); # Call html header
debugprint("Online");
debugprint("[Initial tests]: TIME: $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst");
if ( $url{'search'} ) { # If we are searching, do this
debugprint("[Search]: Search string is true, value=$url{'search'}");
    if ( length($url{'search'}) > 45 ) { # Make sure no one is trying to hack us, so we rebuild the string
        foreach $url(split(//, $url{'search'})) {
        $newsearch .= $url;
        }
        $url{'search'} = $newsearch;
    }
    if ( $url{'morecat'} ) { # More categories info, make sure we know it
	debugprint("[Search]: Morecat ( More Categories ) has been called, value=$url{'morecat'}");
        $url = "$dmoz_search?search=$url{'search'}&morecat=$url{'morecat'}";
    }
    elsif ( $url{'jsites'} ) { # Next pages...Page 2,3,4,5,6
	debugprint("[Search]: Jsites (Next pages in results) has been called, value=$url{'jsites'}");
        $search = $url{'search'};
        $jsites = $url{'jsites'};
        $cool = 1;
        $url="$dmoz_search?search=$search&jsites=$jsites";
    }
    elsif (!( $url{'jstart'} ) ) { # If we don't have next page, then lets just search
	debugprint("[Search]: Search url built as $dmoz_search?search=$url{'search'}");
        $url = "$dmoz_search?search=$url{'search'}";
    } 
    elsif ( $url{'jstart'} )  { # Same as jsites
        $url="$dmoz_search?search=$url{'search'}&jstart=$url{'jstart'}";
    }
 #   $url =~ s/ //g; # spaces go byebye
    $url =~ s/\n//g; # get messy stuff out of my way!
    debugprint("[Search]: Searching with url $url");
    $html = getpage("$url"); # Search for it...
    
	if ( $html =~ /<\/table>/ ) { 
        ($junk,$html)=split(/<\/table>/, $html); # Prepare html for editting
    } 
    else { # Bad results, exit immediatly
#error("No results returned");	
debugprint("[Search]: Critical error, unable to parse html, exiting...");
	debugprint("[Search]: HTML DUMP IN PROGRESS...");
	debugprint("[HTML DUMP]: $html");
        &getout();
    }
    if ( $html =~ /<TABLE cellpadding=0/ ) {
        ($html,$junk)=split(/<TABLE cellpadding=0/, $html);  # found the html we needed, split it up
    } 
    else {
	debugprint("[Search]: Critical error, unable to parse html, exiting...");
	debugprint("[Search]: HTML DUMP IN PROGRESS...");
	debugprint("[HTML DUMP]: $html");
        &getout(); # Bad results! Get out of here now!
    }
	debugprint("[Search]: HTML parsed successfully, fixing up page...");
    $html =~ s/http:\/\/dmoz.org/$script?browse=/g; # Fix categories so they browse with us 
    $html =~ s/search\?/$script?/g; # Replace formpost wiht our stuff
    $html =~ s/Open Directory Sites/$title/g; # Replace titles baby
    $html =~ s/Open Directory Categories/$title2/g; # Replace more titles baby
    %f = (
    date => $date,
    results => $html,
    );
	debugprint("[Search]: Now printing results to template... Template value: $template");
    print template("$template", \%f); # Print the template
    exit;
}
if ( $url{'browse'} ) {
	debugprint("[Browse]: Browsing system initiated....");
	debugprint("[Browse]: Path to browse value=$url{'browse'}");
    $html = getpage("http://www.dmoz.org/$url{'browse'}");
    if ( $html =~ /Error 404/ ) {
	debugprint("[Browse]: Bad category (404 not found detected)");
        $html = "The category you are trying to access does not exists. Please do <b>NOT</b> attempt making your own catergories";
        %f = (
        date => $date,
        results => $html,
        );
        print template("$template", \%f);
        exit;
    }
#Build new cat
    foreach $cat (split(/\//, $url{'browse'})) { # Don't mess with this, crazy coding
        if ( length($cat) > 0 ) {
            if ( $cate ) {
                $cate = "$cate/$cat";
            } else {
            $cate = "$cat";
            }
        }
    }
    $cate =~ s/'/%27/g;
    if ( $url{'browse'} eq "/Science/Psychology/" ) {
        $cate = "Science/Social_Sciences/Psychology/";
    }
    if ( $html =~ /<input type=hidden name=cat value="$cate">/ ) {
        ($junk,$html)=split(/<input type=hidden name=cat value="$cate">/ , $html);
    } 
    else {
        ($junk,$html)=split(/<\/form>\n/, $html);
    }
    foreach $line (split(/\n/, $html )) {
        if ( $line =~ /&nbsp;search&nbsp;on:/ ) {
            if ( ! ( $ttt )  ) {
                $block++;
                $ttt++;
                next;
            } 
        }
        if (!($block)) {
            $html2 .= "$line\n";
        }
    }
debugprint("[Browse]: Parsing html source, please hold...");
    $html = $html2;
    $html =~ s/<table bgcolor="#f0f0f0" cellspacing=0 cellpadding=4 valign=top><tr><td align=center><b><a href="desc.html">Description<\/a><\/b><\/td><\/tr><tr><td align=center><\/table>//g;
    $html =~ s/href="\/"/href="$main"/g;
    $html =~ s/href="\//href="$script?browse=\//g;
    $html =~ s/src="\/img\/star.gif"/src="$starimage"/g;
    $html =~ s/<td align=right valign=top><table bgcolor="#f0f0f0" cellspacing=0 cellpadding=4 valign=top><tr><td align=center><b><a href="desc.html">Description<\/a><\/b><\/td><\/tr><tr><td align=center><b><a href="faq.html">FAQ<\/a><\/b><\/td><\/tr><\/table><\/td>//g;
 $html =~ s/Top<\/a>:/$base<\/a>:/g;

debugprint("[Browse]: Printing html");
    %f = (
    date => $date,
    results => $html,
    );
    print template("$template", \%f);
    exit;
}
html();
print "Invalid Call";
exit;
sub getpage {
if ( $uselwp > 0 ) {
$_[0] =~ s/http:\/\///g;
$_[0] =~ s/\/\//\//g;
$_[0] = "http://$_[0]";
$_[0] =~ s/ /\+/g;
    debugprint("Using LWP - $_[0]");
    $response = get("$_[0]");
    debugprint($response);
    return $response;

} else {
debugprint("NO LWP, Using Sockets");
my($junk,$temp,$query,$response);
my($url) = $_[0];
($junk,$temp)=split(/\/\//, $url);
($domain,$temp)=split(/\//, $temp);
$domain =~ s/\///g;
$ext = $url;
$ext =~ s/$domain//g;
$ext =~ s/http:\/\///g;
($url,$query)=split(/\?/, $ext);
$ext =~ s/\?//g;
$ext =~ s/$query//g;
$ext =~ s/\/\///g;
$ext = "/$ext";
$domain =~ s/www.//g;
#$domain = "http://$domain";
$ext = "$ext/index.html" if ($url{'browse'});
$ext =~ s/\/\//\//g;
$ext =~ s/\+//g;
$temp = $query;
$temp =~ s/\+//g;
$ext =~ s/$temp//g;
debugprint("$domain - $ext - $query");
$response = &HTTPGet("$ext?$query", "$domain", 80, "$query");
debugprint($response);
return $response;
}
}

sub getout {
    if ( $html =~ /No sites matching/ ) {
        $html =~ s/dmoz.org/$mainurl1/g;
        $html =~ s/Open Directory/$odpname/g;
        %f = (
        date => $date,
        results => $html,
        );
        print template("$template", \%f);
        exit;
    }
    &error("Define other search engine");
    exit;
}

########################## Added routines ##############################
###################################################
# Query strings by vivitron - 11/26/98
###################################################
# Usage:
# &urls;
###################################################
sub urls {
    $data=$ENV{'QUERY_STRING'};
    @fields = split(/&/,$data);
        foreach $fields(@fields){
           ($field_name,$field_val)=split(/=/,$fields);
            $url{$field_name}=$field_val;
        }
}
###################################################
# Laziness HTML headers by vivitron on one big boring day
###################################################
# Usage:
# &html();
###################################################
sub html {
if (!($already)) { # only allow us to print this once because of error handling
$already = 1;
    print "Content-type: text/html \n\n";
    return;
}
}
##########################################################################
###################################################
# Error routine breaker by vivitron - 11/30/98
###################################################
# Usage:
# &error("Error here");
# Set $base for custom template
###################################################
sub error {
    if ( $_[0] =~ /Define/ ) {
        print :"Location: http://search.dmoz.org/cgi-bin/search?search=$url{'search'}\n\n";
        exit;
    }
    if ( -e "$base/error.temp") {
        open (F, "< $base/error.temp");
        @text = <F>;
        close(F);
        &html();
        foreach $te (@text) {
            $te =~ s/%%error%%/$_[0]/g;
            $te =~ s/\%%error%%/$_[0]/g;
            print "$te";
        }
    exit;
    }
    else {
    #We want a generic thing here
    &html();
    print qq|<html><head><title>System Failure Error</title></head>
    <br>
    <h1 align="center">System Failure</h1>
    <br>
    We are sorry to inform you that there has been a critical error, we will try to take care of this shortly!
    Please, to help us, contact us and tell us how you encountered this error.<br>
    The error is: $_[0]
    <br>|;
    exit;
    }
}###################################################
# Template parser by vivitron - 2/03/99
###################################################
# Usage:
# print template("file", \%fields);
###################################################
sub template {
&html();
my ($filename, $fillings) = @_;
my $text;
local $/;
local *F;
open (F, "< $filename\0")                       || &error("Cannot open $filename because: $!");
$text = <F>;
close(F);
$text =~ s{ %% ( .*? ) %% }
                     { exists( $fillings->{$1} )
                       ? $fillings->{$1}
                       : ""
                       }gsex;
        

             return $text;
}
sub debugprint {
my $debu = $_[0];
if (( $url{'debug'} ) && ( $debug eq 1))  {
print "[ODP Debug]: $debu <br>\n";
}
if ( $debug eq 2 ) {
print "[ODP Debug]: $debu <br>\n";
}
return;
}

#Rewrite

############################################################
#
# subroutine: HTTPGet
#   Usage:
#     $buf = &HTTPGet("/index.html", "www.eff.org", 80,
#	"var1=value1&var2=value2&etc=etc);
#
#   Parameters:
#     $url = URL To Connect To Relative to the host
#     $hostname = HostName of WebSite to Connect To
#     $port = port to connect to (normally 80)
#     $in = Form Values To Mimic sending to the site
#
#   Output:
#     HTML Code Output from the Web Server.
#
############################################################
sub HTTPGet {
	 local($url, $hostname, $port, $in, $proxy_server) = @_;
	 local($form_vars, $x, $socket);
	 local ($buf);
	 local ($error);
debugprint("LWP Disabled, using sockets...");

	 if ($proxy_server) {
		($error, $socket) = &OpenSocket($proxy_server, $port);
		$url = "http://$hostname$url" if ($url !~ m/^http/);
	}
	else {
		($error, $socket) = &OpenSocket($hostname, $port);
	}
	 return $error if ($error);


	 $form_vars = &FormatFormVars($in);
# we need to add the ? to the front of the passed
# form variables
	 $url .= "?" . $form_vars if ($from_vars);

# The following sends the information to the HTTP Server.
debugprint("Socket openned, sending header info");
	 print  $socket <<__END_OF_SOCKET__;
GET $url HTTP/1.1
Host: $hostname
Accept: text/html
Accept: text/plain
Accept: image/gif
Accept: image/jpg
Accept: image/png
User-Agent: HAMweather/2.0
Connection: close


__END_OF_SOCKET__

# RetrieveHTTP retrieves the HTML code
	 $buf = &RetrieveHTTP($socket);
	 if ($buf eq "" || !(defined $buf)) {
		debugprint("WARNING: HTML contains NOTHING, bytes = 0");
	}
debugprint("Done, sending html back to system");
	 $buf;

} #end of HTTPGet

############################################################
#
# subroutine: FormatFormVars
#   Usage:
#     $formvars = &FormatFormVars($in);
#
#   Parameters:
#     $in = form variables to process
#
#   Output:
#     Processed form variables.  Illegal characters
#     are replaced with their %Hexcode equivalents.
#     Currently the routine only handles spaces but
#     could be expanded for more.
#
############################################################

sub FormatFormVars {
	 local ($in) = @_;

	 $in =~ s/ /%20/g;

	 $in;
} # FormatFormVars

############################################################
#
# subroutine: RetrieveHTTP
#   Usage:
#     $buf = &RetrieveHTTP($socket_handle);
#
#   Parameters:
#     $socket = Handle to the socket we are communicating
#               with
#
#   Output:
#     Buffer containing the output of the HTTP Server
#
############################################################

sub RetrieveHTTP {
	 local ($socket) = @_;
	 local ($buf,$x, $split_length);

	 $buf = read_sock($socket, 6);
# if the buffer has a status code of 200 in it,
# then we know its safe to read in the rest of the document

	 if ($buf =~ /200/) {
		  while(<$socket>) {
				$buf .= $_;
		  }
	 }

# We strip off the HTTP header by looking for
# two newlines or two newlines preceeded with
# carriage returns.  Different Web Servers use
# different delimiters sometimes.
#
	 $x = index($buf, "\r\n\r\n");
	 $split_length = 4;

	 if ($x == -1) {
		  $x = index($buf, "\n\n");
		  $split_length = 2;
	 }
#
# The following actually splits the header off
	 if ($x > -1) {
		  $buf = substr($buf,$x + $split_length);
	 }

	 close $socket;

$buf;
} # End of RetrieveHTTP

############################################################
#
# subroutine: OpenSocket
#   Usage:
#     $socket_handle = &OpenSocket($host, $port);
#
#   Parameters:
#     $host = host name to connect to
#     $port = port to connect to
#
#   Output:
#     Handle to socket that was opened
#
############################################################

sub OpenSocket {
	 local($hostname, $port) = @_;

	 local($ipaddress, $fullipaddress, $packconnectip);
	 local($packthishostip);
	 local($AF_INET, $SOCK_STREAM, $SOCK_ADDR);
	 local($PROTOCOL, $HTTP_PORT);

# The following variables are set using values defined in
# The sockets.pm library.  If your version of perl (v4) does
# not have the sockets library, you can substitute some
# default values such as 2 for AF_INIT, and 1 for SOCK_STREAM.
# if 1 does not work for SOCK_STREAM, try using 2.
#
# AF_INET defines the internet class of addressing
#
# SOCK_STREAM is a variable telling the program to use
# a socket connection.  This varies from using SOCK_DGRAM
# which would send UDP datagrams using a connectionless paradigm
# instead.
#
# PROTOCOL is TCPIP (6).
#
# PORT Should generally be 80 for HTTP Access, some sites use
# alternative ports such as 8080.
#
# SOCK_ADDR is the packeted format of the full socket address
# including the AF_INIT value, HTTP_PORT, and IP ADDRESS in that order
#

	 $AF_INET = AF_INET;
	 $SOCK_STREAM = SOCK_STREAM;

	 $SOCK_ADDR = "S n a4 x8";

# The following routines get the protocol information
#

	 $PROTOCOL = (getprotobyname('tcp'))[2];

	 $HTTP_PORT = $port;
	 $HTTP_PORT = 80 unless ($HTTP_PORT =~ /^\d+$/);
	 $PROTOCOL = 6 unless ($PROTOCOL =~ /^\d+$/);

# Ip address is the Address of the host that we need to connect
# to
	 $ipaddress = (gethostbyname($hostname))[4];

	 $fullipaddress = join (".", unpack("C4", $ipaddress));

	 $packconnectip = pack($SOCK_ADDR, $AF_INET,
			$HTTP_PORT, $ipaddress);
	 $packthishostip = pack($SOCK_ADDR,
			 $AF_INET, 0, "\0\0\0\0");

# First we allocate the socket
	 socket (S, $AF_INET, $SOCK_STREAM, $PROTOCOL) || return ( "-hwERR Can't make socket:$!\n");

# Then we bind the socket to the local host
	 bind (S,$packthishostip) ||   return( "-hwERR Can't bind:$!\n");
# Then we connect the socket to the remote host
	 connect(S, $packconnectip) || return( "-hwERR Can't connect socket:$!\n");

# The following selects the socket handle and turns off
# output buffering
#
	 select(S);
	 $| = 1;
	 select (STDOUT);

	return (0, S);
} # End of OpenSocket

############################################################
#
# subroutine: read_sock
#   Usage:
#     &read_socket(SOCKET_HANDLE, $timeout);
#
#   Parameters:
#     SOCKET_HANDLE = Handle to an allocated Socket
#     $timeout = amount of time read_sock is allowed to
#                wait for input before timing out
#                (measured in seconds)
#
#   Output:
#     Buffer containing what was read from the socket
#
############################################################

sub read_sock {
	 local($handle, $endtime) = @_;
	 local($localbuf,$buf);
	 local($rin,$rout,$nfound);

# Set endtime to be time + endtime.
	 $endtime += time;

# Clear buffer
	 $buf = "";

# Clear $rin (Read Input variable)
	 $rin = '';
# Set $rin to be a vector of the socket file handle
	 vec($rin, fileno($handle), 1) = 1;

# nfound is 0 since we have not read anything yet
	 $nfound = 0;

# Loop until we time out or something was read
read_socket:
while (($endtime > time) && ($nfound <= 0)) {
# Read 1024 bytes at a time
	 $length = 1024;
# Preallocate buffer
	 $localbuf = " " x 1025;
	# NT does not support select for polling to see if
	# There are characters to be received.  This is important
	# Because we dont want to block if there is nothing
	# being received.
	 $nfound = 1;
	 $http_os = "UNIX";
	 if ($http_os ne "NT") {
# The following polls to see if there is anything in the input
# buffer to read.  If there is, we will later call the sysread routine
	$nfound = select($rout=$rin, undef, undef,.2);
		 }
}

# If we found something in the read socket, we should
# get it using sysread.
	 if ($nfound > 0) {
	$length = sysread($handle, $localbuf, 1024);
	if ($length > 0) {
		 $buf .= $localbuf;
		 }
	 }

# Return the contents of the buffer
$buf;
}
