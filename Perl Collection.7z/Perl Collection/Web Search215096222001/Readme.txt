##############################
# OPEN DIRECTORY PROJECT     #
#         2001               #
#    Dustin A. Lambert       #
#  dustin@midsouthweb.com    #
##############################

THE OPEN DIRECTORY PROJECT
CUSTOM PARSER - RELEASE 2

DEMO AVAILABLE AT: http://www.cgifreebies.com/odp/

Hello one and all! Well, I see you downloaded my little program...
Anyhow, down to business...

This is simply a search engine, nothing more, nothing less. Somethings have changed. Now you can specify whether to use LWP or sockets. Some people do not have LWP, so if you are not sure if you do or not, just sockets. Everyone should have those. Look in the config section for details. IF I get a response, I'll continue developement.
You have four files in the zip file, this one, search.temp, index.html, and odp.pl
ODP.pl - Main program
search.temp - Template for all search results
index.html - Main "search" page
ODP.pl is simply a parser of the odp project, once it has the results
It outputs them to search.temp
In search.temp you see the variables %%date%% and %%results%%
ODP.pl replaces those variables with the correct values. That is it!
The program has many features, it allows you to browse the project, and much more, you have to see it to get the full effect...
Here are a couple notes:
-A generic error page is printed when there is an error, to create your own error page for it, simply create an html file in the SAME DIRECTORY as the program and format it as you like. Put the variable %%error%% in where you want the error printed (most erros are about 7-10 words long)
-This program has a VERY detailed debug system built into it. There is a variable in the header of the program called $debug. When set to the value of "2", the debug information will ALWAYS be printed which is nice if you want to see what it is doing. When set to the value of "1", the debug information will ONLY be printed when "debug=1" is in the url. When set to the value of "0", the debug information will never be shown. 
-Configuration of variables:
	$base - This variable is the name of your site, i.e. Bob's Website ( It will appear in cats, 		$base:Science)
	$title1 - This variable is the title of search results (i.e. Your results)
	$title2 - This variable is the title of the category pages
	$dmoz_Search - This variable is the url to the dmoz core, leave it alone unless you know what your 		       doing
	$template - The template for search results (default: search.temp)
	$starimage - The URL for an image for HOT! sites (not included with this program)
	[end config]
That's it! Upload it, use it, have fun! BTW, visit CGI Freebies! - http://www.cgifreebies.org