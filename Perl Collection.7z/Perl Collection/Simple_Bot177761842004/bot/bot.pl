my $email = 'email@domain.com';  #your email
my $pass = 'password'; #your password
my $botname = 'bot'; #your bots name

print "Now Connecting\n";    
use MSN;
    my $msn = MSN->new('',Handle => '$email', Password => '$pass');

    $msn->set_handler(Connected => \&Connected);
    $msn->set_handler(Message   => \&Message);
    $msn->set_handler(Answer    => \&Answer);
    $msn->set_handler(Join    => \&Join);
    $msn->set_handler(Update_Chat_Buddies => \&UpdateBuddies);

    $msn->connect();

    while (1)
    {
        $msn->do_one_loop;
    }
    

    sub Message {
        my ($self, $victim, $name, $msg) = @_;
  
my @one = (
 "Duude...www.you.com is way better!",
 "OMG!  www.you.com is waaaaaay better!",
 "Whoa, thats so far worse than www.you.com!",
 "Getta life :(",
);

my ($one);
my $first = $one [ int(rand(scalar(@one))) ];
my $wwwr = "$first";

if($msg =~ "http") { #Detects if someone types http
$self->sendmsg("$wwwr"); #Our random variable
}

if($msg =~ /^!leave/i) { #Detects if user types !leave
$self->sendmsg("Goodbye."); #Says goodbye
$self->sendrawnoid("OUT\r\n") #Leaves
} 

if($msg =~ /^!menu/i) { #Detects if user types !menu
$self->sendmsg("(li) Menu (li) #Shows Menu caption
!leave - Make the bot leave"); #Shows Main Menu #add more things if you like
}

}



    sub Connected {
        my $self = shift;
    }

    sub Answer {
        my ($self, $username) = @_;
        $self->sendmsg("Hey I am $botname.");
    }

    sub Join {
        my ($self,$user,$friendly) = @_;
        $self->sendmsg("Hiya, I am $botname");
    }

    sub UpdateBuddies
    {
        my $self = shift;
   
    }

    1;
