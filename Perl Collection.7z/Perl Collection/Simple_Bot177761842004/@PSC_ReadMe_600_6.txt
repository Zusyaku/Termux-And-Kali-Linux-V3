Title: Simple Bot in Perl
Description: This Perl script signs onto MSN Messenger, keeps a record of all users that it adds, is able to block people and unblock people and can send messages, it can do alot more to. You can add your own commands to it, its pretty simple.
This bot MAY need some SSL updates from www.bot-depot.com - You also need Active Perl installed then just run bot.pl with active perl and your away.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=600&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
