Title: WinAL
Description: WinAl. Look how WinZip works, and how you can use massive compression in Visual Basic using the Huffman Method! All source code is included, and royalty free. Fully working Zipper/UnZipper (With 2 Compression Methods in 1 .BAS)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=126&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
