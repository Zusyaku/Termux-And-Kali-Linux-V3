create a file named User.mail and one named a.txt change your paths
enter emails into a.txt in the following format the script will mail 
each a unique message

email@mail.com
email@mail.com
email@mail.com
email@mail.com
email@mail.com
