Title: Mass Emailer
Description: This script will email all addresses in a file with a unique email message for each one please read the readme.txt for more information if you use this code please rate it. THIS IS NOT A CGI
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=157&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
