Title: Full Email Spider Multi-Threaded GUI Windows Application
Description: Full Email Spider Multi-Threaded GUI Windows Application and Email Extractor From Files Binary Or Text With Software License Registration System. This program was a commerical application and was sold for $99 until mewsoft (www.mewsoft.com) decided to release it as a GPL. You will learn lots of professional things from this application specially using Win32::GUI for using Perl in Windows GUI appllications and also it includes a system for how to register the software through a very protected system on each computer and also the program includs a tool for extracting emails from binary and text files. Spider emails from any web sites or user search engine like Yahoo and Dmoz to spider targeted sites. This is a full Perl Win32::GUI application that you can turn to .exe using Perl2exe or PerlApp or any other similar tool. To run this program, download and install Active Perl from www.activestate.com and install the required perl modules:
Win32::GUI, Win32::GUI::TabFrame, HTML::SimpleLinkExtor, Win32::OLE, Win32::Mewsoft,
Win32::TieRegistry, Win32::MachineInfo, LWP::UserAgent, BerkeleyDB any may be other modules required.
To run, type:
Perl Spiderawy.cgi
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=653&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
