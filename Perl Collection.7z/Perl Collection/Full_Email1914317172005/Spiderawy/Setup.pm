#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub UseProxyCheckBox_Click{
	
	if ($Global{UseProxyCheckBox}->GetCheck == 1) {
			$Global{Use_Proxy} = 1;
			$Global{ProxyAddress}->Enable;
	}
	else{
			$Global{Use_Proxy} = 0;
			$Global{ProxyAddress}->Disable;
	}
}
#==========================================================
sub UseProxyAuthenCheckBox_Click{
	
	if ($Global{UseProxyAuthenCheckBox}->GetCheck == 1) {
			$Global{Use_Proxy_Authen} = 1;
			$Global{ProxyUsername}->Enable;
			$Global{ProxyPassword}->Enable;
	}
	else{
			$Global{Use_Proxy_Authen} = 0;
			$Global{ProxyUsername}->Disable;
			$Global{ProxyPassword}->Disable;
	}
}
#==========================================================
sub SettingsDefaultsButton_Click{

	$Global{Connection_Port} = 80;
	$Global{Connection_Timeout} = 60;
	$Global{Use_Proxy} = 0;
	$Global{Use_Proxy_Authen} = 0;
	$Global{Proxy_Address} = "";
	$Global{Proxy_Username} = "";
	$Global{Proxy_Password} = "";
	$Global{Proxy_URL} = "";

	$Global{UseProxyCheckBox}->SetCheck($Global{Use_Proxy});
	if (!$Global{Use_Proxy}) {$Global{ProxyAddress}->Disable;}
	
	$Global{UseProxyAuthenCheckBox}->SetCheck($Global{Use_Proxy_Authen});
	if (!$Global{Use_Proxy_Authen}) {$Global{ProxyUsername}->Disable;}

	$Global{ProxyAddress}->Text($Global{Proxy_Address});

	$Global{ProxyUsername}->Text($Global{Proxy_Username});
	$Global{ProxyPassword}->Text($Global{Proxy_Password});

	$Global{ConnectionPort}->Text($Global{Connection_Port});
	$Global{ConnectionTimeout}->Text($Global{Connection_Timeout});

	$Global{SetupWindow}->Update();
	Win32::GUI::DoEvents();
}
#==========================================================
sub SettingsOKButton_Click{
my (%Config);

	undef %Config;

	if ($Global{UseProxyCheckBox}->GetCheck == 1) {
			$Global{Use_Proxy} = 1;
	}
	else{
			$Global{Use_Proxy} = 0;
	}
	$Config{Use_Proxy} = $Global{Use_Proxy};

	if ($Global{UseProxyAuthenCheckBox}->GetCheck == 1) {
			$Global{Use_Proxy_Authen} = 1;
	}
	else{
			$Global{Use_Proxy_Authen} = 0;
	}
	$Config{Use_Proxy_Authen} = $Global{Use_Proxy_Authen};

	$Global{Proxy_Address} = $Global{ProxyAddress}->Text();
	$Global{Proxy_Address} =~ s/^\s+//g;
	$Global{Proxy_Address} =~ s/\s+$//g;
	$Config{Proxy_Address} = $Global{Proxy_Address};
	
	$Global{Proxy_Username} = $Global{ProxyUsername}->Text();
	$Global{Proxy_Username} =~ s/^\s+//g;
	$Global{Proxy_Username} =~ s/\s+$//g;
	$Config{Proxy_Username} = $Global{Proxy_Username};
	
	$Global{Proxy_Password} = $Global{ProxyPassword}->Text();
	$Global{Proxy_Password} =~ s/^\s+//g;
	$Global{Proxy_Password} =~ s/\s+$//g;
	$Config{Proxy_Password} = $Global{Proxy_Password};

	$Global{Connection_Port} = $Global{ConnectionPort}->Text();
	$Global{Connection_Port} =~ s/^\s+//g;
	$Global{Connection_Port} =~ s/\s+$//g;
	$Config{Connection_Port} = $Global{Connection_Port};

	$Global{Connection_Timeout} = $Global{ConnectionTimeout}->Text();
	$Global{Connection_Timeout} =~ s/^\s+//g;
	$Global{Connection_Timeout} =~ s/\s+$//g;
	$Config{Connection_Timeout} = $Global{Connection_Timeout};

	$Global{Proxy_URL} = "";
	$Config{Proxy_URL} = $Global{Proxy_URL};

	&Update_Config(%Config);

	&SetupWindow_Terminate;
}
#==========================================================
sub SettingsCancelButton_Click{
	
	$Global{UseProxyCheckBox}->SetCheck($Global{Use_Proxy});
	if (!$Global{Use_Proxy}) {$Global{ProxyAddress}->Disable;}
	
	$Global{UseProxyAuthenCheckBox}->SetCheck($Global{Use_Proxy_Authen});
	if (!$Global{Use_Proxy_Authen}) {$Global{ProxyUsername}->Disable;}

	$Global{ProxyAddress}->Text($Global{Proxy_Address});

	$Global{ProxyUsername}->Text($Global{Proxy_Username});
	$Global{ProxyPassword}->Text($Global{Proxy_Password});

	$Global{ConnectionPort}->Text($Global{Connection_Port});
	$Global{ConnectionTimeout}->Text($Global{Connection_Timeout});

	&SetupWindow_Terminate;
}
#==========================================================
sub ThreadsSlider_Scroll {
my (%Mem, $Threads, $ReqRAM);
		
#	%Mem = Win32::Mewsoft::MemoryStatus();

	$Threads = $Global{Threads_Slider}->Pos;
	$ReqRAM = $Threads * $Global{Required_Thread_RAM};

	$Global{EngineSelThreads}->Text($Threads);

	#$Mem{MemLoad} = $Mem{MemLoad};
#	$Mem{TotalPhys} = ceil ($Mem{TotalPhys}/(1024*1024)); # in MB
#	$Mem{AvailPhys} = ceil ($Mem{AvailPhys}/(1024*1024));

#	$Global{FreeRAM}->Text($Mem{AvailPhys});
#	$Global{TotalRAM}->Text($Mem{TotalPhys});

	$Global{RequiredRAM}->Text($ReqRAM);

	$Global{SetupWindow}->Update();
	Win32::GUI::DoEvents();
}
#==========================================================
sub ConnectionsSlider_Scroll{

	$Global{ConnectsPerThread}->Text($Global{Connections_Slider}->Pos);
	$Global{SetupWindow}->Update();
	Win32::GUI::DoEvents();
}
#==========================================================
sub EngineOKButton_Click{
my (%Config);
	
	undef %Config;
	$Global{Allowed_Threads} = $Global{Threads_Slider}->Pos;
	$Global{ConnectionsPerThread} = $Global{Connections_Slider}->Pos;
	
	$Config{Allowed_Threads} = $Global{Allowed_Threads};
	$Config{ConnectionsPerThread} = $Global{ConnectionsPerThread};
	
	&Update_Config(%Config);

	&SetupWindow_Terminate;
}
#==========================================================
sub EngineCancelButton_Click{
	&SetupWindow_Terminate;
}
#==========================================================
1;