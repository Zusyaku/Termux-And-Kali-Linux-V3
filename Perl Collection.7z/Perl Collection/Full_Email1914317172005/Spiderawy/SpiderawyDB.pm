#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
use BerkeleyDB; #It only export constants to same package level 1
#==========================================================
sub OpenDB{
my ($Overwrite, $Load) = @_;
my (@Parts, $Filename, $Path, $Name, $Ext, $File);
	
	$Overwrite ||= 0;
	@Parts = split (/[\\|\/]/, $Global{TaskFilename});
	$Filename = pop @Parts;
	$Path = join ("\\", @Parts);
	($Name, $Ext) = split(/\./, $Filename);
	if (!$Name) {return;}

	$Global{Data_Dir} = $Path;
	$Global{Task_Dir} = $Path;

#	$Env = new BerkeleyDB::Env,		-Home => "$Path",		;

	# Create the main task database file
	$File = "$Global{Task_Dir}\\$Name".".TDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderTask;
	$Global{Task_DBH} = tie %SpiderTask, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20,
#										-Pagesize => 2**15,
										-Flags => DB_CREATE,
										#-Env=>$Env,
										|| die "Error: Cannot open file $File\n $! $BerkeleyDB::Error\n". __LINE__ ." " . __FILE__;
	
	$SpiderTask{EmailListFile} = "$Path\\$Name".".txt";

	# Create the Location database file
	$File = "$Global{Data_Dir}\\$Name"."1.SDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderLocations;
	$Global{Location_DBH} = tie %SpiderLocations, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20,
#										-Pagesize => 2**15,
										-Flags => DB_CREATE,
										#-Env=>$Env,
										|| die "Error: Cannot open file $File\n $! $BerkeleyDB::Error\n". __LINE__ ." " . __FILE__;

	# Create the URL database file
	$File = "$Global{Data_Dir}\\$Name"."2.SDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderLinks;
	$Global{URL_DBH} = tie %SpiderLinks, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20, #2**20 = 1MB=1048576
										#Pagesize => 2**15,
										-Flags => DB_CREATE , #DB_RDONLY
										or die "Cannot open file $File: $! $BerkeleyDB::Error\n" ;

	# Create the Level database file
	$File = "$Global{Data_Dir}\\$Name"."3.SDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderLevels;
	$Global{Level_DBH} = tie %SpiderLevels, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20, #2**20 = 1MB=1048576
										#Pagesize => 2**15,
										-Flags => DB_CREATE , #DB_RDONLY
										or die "Cannot open file $File: $! $BerkeleyDB::Error\n" ;

	# Create the Status database file
	$File = "$Global{Data_Dir}\\$Name"."4.SDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderStatus;
	$Global{Status_DBH} = tie %SpiderStatus, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20, #2**20 = 1MB=1048576
										#Pagesize => 2**15,
										-Flags => DB_CREATE , #DB_RDONLY
										or die "Cannot open file $File: $! $BerkeleyDB::Error\n" ;

	# Create the Emails database file
	$File = "$Global{Data_Dir}\\$Name"."5.SDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderEmails;
	$Global{Email_DBH} = tie %SpiderEmails, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20, #2**20 = 1MB=1048576
										#Pagesize => 2**15,
										-Flags => DB_CREATE , #DB_RDONLY
										or die "Cannot open file $File: $! $BerkeleyDB::Error\n" ;

	# Create the Emails by Count database file
	$File = "$Global{Data_Dir}\\$Name"."6.SDB";
	if ($Overwrite) { unlink $File;}
	undef %SpiderEmailsID;
	$Global{EmailID_DBH} = tie %SpiderEmailsID, "BerkeleyDB::Hash", 
										-Filename => $File,
#										-Cachesize => 2**20, #2**20 = 1MB=1048576
										#Pagesize => 2**15,
										-Flags => DB_CREATE , #DB_RDONLY
										or die "Cannot open file $File: $! $BerkeleyDB::Error\n" ;

	# Create the email text  database file
	$File = "$Path\\$Name".".txt";
	if ($Overwrite) { unlink $File;}
	undef $OutputFileHandle;
	if (!open ($OutputFileHandle, ">>$File")){ 
			$Answer = Win32::GUI::MessageBox(0,"Error creating file $File\r\n$!","Error", MB_ICONERROR | MB_OK,);
			return undef;
			if($Answer == 6) {# yes
			} else {# no
			}
	}

	&Load_DB if ($Load);
}
#==========================================================
sub FlushDB{
my ($status);

	$status = $Global{Task_DBH}->db_sync();
	$status = $Global{Location_DBH}->db_sync();
	$status = $Global{URL_DBH}->db_sync();
	$status = $Global{Level_DBH}->db_sync();
	$status = $Global{Status_DBH}->db_sync();
	$status = $Global{Email_DBH}->db_sync();
	$status = $Global{EmailID_DBH}->db_sync();

}
#==========================================================
sub CloseDB{
my ($status);

	close $OutputFileHandle;
	
	$status = $Global{Task_DBH}->db_sync();
	$status = $Global{Location_DBH}->db_sync();
	$status = $Global{URL_DBH}->db_sync();
	$status = $Global{Level_DBH}->db_sync();
	$status = $Global{Status_DBH}->db_sync();
	$status = $Global{Email_DBH}->db_sync();
	$status = $Global{EmailID_DBH}->db_sync();

	undef $Global{Task_DBH};
	undef $Global{Location_DBH};
	undef $Global{URL_DBH};
	undef $Global{Level_DBH};
	undef $Global{Status_DBH};
	undef $Global{Email_DBH};
	undef $Global{EmailID_DBH};

	untie %SpiderTask;
	untie %SpiderLocations;
	untie %SpiderLinks;
	untie %SpiderLevels;
	untie %SpiderStatus;
	untie %SpiderEmails;
	untie %SpiderEmailsID;

	undef %SpiderTask;
	undef %SpiderLocations;
	undef %SpiderLinks;
	undef %SpiderLevels;
	undef %SpiderStatus;
	undef %SpiderEmails;
	undef %SpiderEmailsID;
}
#==========================================================
sub Load_DB{
my ($End, $Count, $Temp, $K, $V);

	&RuningCursor;

	$Global{URLsListView}->Clear();
	$Global{EmailListView}->Clear();
	#$SpiderLocations{$Global{TotalLinksCount}} = $Link;
	#$SpiderLinks{$Link} = $Global{TotalLinksCount};
	#$Level = $SpiderLevels{$Global{TotalLinksCount}};
	#$SpiderStatus{$Global{TotalLinksCount}} = 1;
	$Global{StatusLabel}->Change( -foreground => $Global{DBLoadStatusColor}, -background =>  $Global{DBLoadStatusBkColor});

	$Global{StatusLabel}->Text("Loading Task: [$Global{TaskFilename}] - ");
	#$Global{TotalLinksCount} = scalar keys %SpiderStatus;
	#---------------------------------------------------------------------------------------------------------------
	$Global{TotalLinksCount} = 0;
	$Global{FinishedURLs} = 0;

	while (($K, $V) = each %SpiderStatus) {
				$Global{TotalLinksCount}++;
				if ($V == 2) {
						$Global{FinishedURLs}++;
				}
				if (!($Global{TotalLinksCount} % 5000)) {
							Win32::GUI::DoEvents();
							$Global{StatusLabel}->Text("Loading Task: [$Global{TaskFilename}] - URLs Found: $Global{TotalLinksCount}  - Already Spidered URLs: $Global{FinishedURLs}");
				}
	}
	#---------------------------------------------------------------------------------------------------------------
	#$Global{TotalEmailsCount} = scalar keys %SpiderEmailsID;
	$Global{TotalEmailsCount} = 0;
	while (($K, $V) = each %SpiderEmailsID) {
				$Global{TotalEmailsCount}++;
				if (!($Global{TotalEmailsCount} % 1000)) {
							$Global{StatusLabel}->Text("Loading Task: [$Global{TaskFilename}] - Emails Found: $Global{TotalEmailsCount}");
				}
	}
	#---------------------------------------------------------------------------------------------------------------
	#-----------------------------------Display stats----------------------------------------------------------
	$Global{EmailsFound}->Text(" $Global{TotalEmailsCount}");
	$Global{URLSFound}->Text(" $Global{TotalLinksCount}");
	$Global{URLsFinished}->Text (" $Global{FinishedURLs}");
	$Global{URLsWaiting}->Text (" ". ($Global{TotalLinksCount} - $Global{FinishedURLs}) );
	$Global{StatusLabel}->Text("Task Ready: [$Global{TaskFilename}]");
	$Global{StatusLabel}->Change( -foreground => $Global{StatusFColor}, -background =>  $Global{StatusBkColor});
	#---------------------------------------------------------------------------------------------------------------
	&NormalCursor;
	$Global{MainWindow}->Update();
	$Global{MainWindow}->InvalidateRect(1);
	Win32::GUI::DoEvents();
}
#==========================================================
1;
