#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Register_Window{

	my %BoldFont = Win32::GUI::Font::Info(Win32::GUI::GetStockObject(17));
	$BoldFont{-bold} = 1;
	$Global{Bold_Font} = new Win32::GUI::Font(%BoldFont);

$Global{Register_Window} = Win32::GUI::Window->new(
		-text => "Register",
		-name => "RegisterWindow",
		-pos  => [ 200, 200 ],
		-size => [ 450, 300 ],
		#-parent => $Global{MainWindow},
		#-addstyle => WS_SIZEBOX|WS_MAXIMIZEBOX |WS_OVERLAPPEDWINDOW|WS_GROUP|WS_DLGFRAME|WS_CHILD,
		#-style =>WS_MAXIMIZEBOX,
		#WS_MINIMIZEBOX (0x00020000) or WS_MAXIMIZEBOX , WS_SYSMENU,WS_POPUP,WS_POPUPWINDOW
		-visible=> 01,
#		-menubox => 0,
		-maximizebox => 0,
		-minimizebox =>0,
		-helpbutton => 0,
		-resizable =>0,
	);
$Global{Register_Window}->{'-dialogui'} = 1; #Enable TabStop with 		-tabstop    => 1,
&CenterOnScreen($Global{Register_Window});

$Global{RegLabel} = $Global{Register_Window}->AddButton(
       -text    => "Product Registration",
       -name    => "RegLabel",
       -left    => 10,
       -top     => 5,
		-width  => $Global{Register_Window}->ScaleWidth-20,
		-height => $Global{Register_Window}->ScaleHeight-15,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
#		-pushexstyle => 0x00000020,
    -addexstyle  => WS_TABSTOP,
      );

$Global{RegLabel0} = $Global{Register_Window}->AddLabel(
       -text    => ' Status:',
       -name    => "RegLabel0",
       -left    => 20,
       -top     => 30,
       -width   => 50,
       -height  => 18,
		-sunken => 0,
		-font=>$Global{Bold_Font},
      );

$Global{RegisterStatus} = $Global{Register_Window}->AddLabel(
       -text    => ' ',
       -name    => "RegisterStatus",
       -left    => 70,
       -top     => 30,
       -width   => 250,
       -height  => 18,
		-sunken => 0,
		-font=>$Global{Bold_Font},
      );

if ($Global{License_Status}) {
		$Global{RegisterStatus}->Text("Registered");
}
else{
		$Global{RegisterStatus}->Text("Not Registered");
}

$Global{RegLabel1} = $Global{Register_Window}->AddLabel(
       -text    => "In order to properly register your product, please go online before you press OK, and please be sure to fill in all the information asked for.",
       -name    => "RegLabel1",
       -left    => 20,
       -top     => 60,
       -width   => $Global{Register_Window}->ScaleWidth-40,
       -height  => 40,
       -foreground    => 0,
      );

$Global{RegLabel2} = $Global{Register_Window}->AddLabel(
       -text    => "If you have any problem during the registration process, please contact our support team at support\@mewsoft.com and be sure to include your order full information.",
       -name    => "RegLabel2",
       -left    => 20,
       -top     => 110,
       -width   => $Global{Register_Window}->ScaleWidth-40,
       -height  => 40,
       -foreground    => 0,
      );


$Global{RegLabel3} = $Global{Register_Window}->AddLabel(
       -text    => 'Email address:',
       -name    => "RegLabel3",
       -left    => 20,
       -top     => 170,
       -width   => 200,
       -height  => 15,
      );

$Global{RegisterEmail} = $Global{Register_Window}->AddTextfield(
		-text    => "" ,
		-name    => "RegisterEmail",
		-top     => 170,
		-left    => 120,
		-width   => 250,
		-height  => 20,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip => "Email address used to order the product",
      );

$Global{RegisterButton} = $Global{Register_Window}->AddButton(
       -text    => "Register",
       -name    => "RegisterButton",
       -top     => $Global{Register_Window}->ScaleHeight-50,
       -left    => $Global{Register_Window}->ScaleWidth/2-80,
       -width   => 70,
       -height  => 20,
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 1,
      );

$Global{RegisterCancelButton} = $Global{Register_Window}->AddButton(
       -text    => "Close",
       -name    => "RegisterCancelButton",
       -top     => $Global{Register_Window}->ScaleHeight-50,
       -left    => $Global{Register_Window}->ScaleWidth/2+10,
       -width   => 70,
       -height  => 20,
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 1,
      );

}
#==========================================================
sub RegisterWindow_Terminate{

	$Global{Register_Window}->Hide();
	return 0;
}
#==========================================================
sub RegisterCancelButton_Click{
		&RegisterWindow_Terminate;
}
#==========================================================
sub UnRegister_Window{

	my %BoldFont = Win32::GUI::Font::Info(Win32::GUI::GetStockObject(17));
	$BoldFont{-bold} = 1;
	$Global{Bold_Font} = new Win32::GUI::Font(%BoldFont);

$Global{UnRegister_Window} = Win32::GUI::Window->new(
		-text => "Unregister",
		-name => "UnRegisterWindow",
		-pos  => [ 200, 200 ],
		-size => [ 450, 300 ],
		#-parent => $Global{MainWindow},
		#-addstyle => WS_SIZEBOX|WS_MAXIMIZEBOX |WS_OVERLAPPEDWINDOW|WS_GROUP|WS_DLGFRAME|WS_CHILD,
		#-style =>WS_MAXIMIZEBOX,
		#WS_MINIMIZEBOX (0x00020000) or WS_MAXIMIZEBOX , WS_SYSMENU,WS_POPUP,WS_POPUPWINDOW
		-visible=> 01,
#		-menubox => 0,
		-maximizebox => 0,
		-minimizebox =>0,
		-helpbutton => 0,
		-resizable =>0,
	);
$Global{UnRegister_Window}->{'-dialogui'} = 1; #Enable TabStop with 		-tabstop    => 1,
&CenterOnScreen($Global{UnRegister_Window});

$Global{UnRegLabel} = $Global{UnRegister_Window}->AddButton(
       -text    => "Product UnRegistration",
       -name    => "UnRegLabel",
       -left    => 10,
       -top     => 5,
		-width  => $Global{UnRegister_Window}->ScaleWidth-20,
		-height => $Global{UnRegister_Window}->ScaleHeight-15,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
#		-pushexstyle => 0x00000020,
    -addexstyle  => WS_TABSTOP,
      );

$Global{UnRegLabel0} = $Global{UnRegister_Window}->AddLabel(
       -text    => ' Status:',
       -name    => "UnRegLabel0",
       -left    => 20,
       -top     => 30,
       -width   => 50,
       -height  => 18,
		-sunken => 0,
		-font=>$Global{Bold_Font},
      );

$Global{UnRegisterStatus} = $Global{UnRegister_Window}->AddLabel(
       -text    => ' ',
       -name    => "UnRegisterStatus",
       -left    => 70,
       -top     => 30,
       -width   => 250,
       -height  => 18,
		-sunken => 0,
		-font=>$Global{Bold_Font},
      );

if ($Global{License_Status}) {
		$Global{UnRegisterStatus}->Text("Registered");
}
else{
		$Global{UnRegisterStatus}->Text("Not Registered");
}

$Global{UnRegLabel1} = $Global{UnRegister_Window}->AddLabel(
       -text    => "You need only to unregister your product if you want to install it on another computer. In order to properly unregister your product, please go online before you press OK, and please be sure to fill in all the information asked for.",
       -name    => "RegLabel1",
       -left    => 20,
       -top     => 60,
       -width   => $Global{UnRegister_Window}->ScaleWidth-40,
       -height  => 40,
       -foreground    => 0,
      );

$Global{UnRegLabel2} = $Global{UnRegister_Window}->AddLabel(
       -text    => "If you have any problem during the unregistration process, please contact our support team at support\@mewsoft.com and be sure to include your order full information.",
       -name    => "RegLabel2",
       -left    => 20,
       -top     => 110,
       -width   => $Global{UnRegister_Window}->ScaleWidth-40,
       -height  => 40,
       -foreground    => 0,
      );


$Global{UnRegLabel3} = $Global{UnRegister_Window}->AddLabel(
       -text    => 'Email address:',
       -name    => "UnRegLabel3",
       -left    => 20,
       -top     => 170,
       -width   => 200,
       -height  => 15,
      );

$Global{UnRegisterEmail} = $Global{UnRegister_Window}->AddTextfield(
		-text    => "" ,
		-name    => "UnRegisterEmail",
		-top     => 170,
		-left    => 120,
		-width   => 250,
		-height  => 20,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip => "Email address used to order the product",
      );

$Global{UnRegisterButton} = $Global{UnRegister_Window}->AddButton(
       -text    => "UnRegister",
       -name    => "UnRegisterButton",
       -top     => $Global{UnRegister_Window}->ScaleHeight-50,
       -left    => $Global{UnRegister_Window}->ScaleWidth/2-80,
       -width   => 70,
       -height  => 20,
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 1,
      );

$Global{UnRegisterCancelButton} = $Global{UnRegister_Window}->AddButton(
       -text    => "Close",
       -name    => "UnRegisterCancelButton",
       -top     => $Global{UnRegister_Window}->ScaleHeight-50,
       -left    => $Global{UnRegister_Window}->ScaleWidth/2+10,
       -width   => 70,
       -height  => 20,
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 1,
      );

}
#==========================================================
sub UnRegisterWindow_Terminate{

	$Global{UnRegister_Window}->Hide();
	return 0;
}
#==========================================================
sub UnRegisterCancelButton_Click{
		&UnRegisterWindow_Terminate;
}
#==========================================================

1;