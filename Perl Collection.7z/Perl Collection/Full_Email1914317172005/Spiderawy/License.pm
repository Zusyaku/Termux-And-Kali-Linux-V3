#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub RegisterButton_Click{
my ($Email, $RegData, $Data, %Register, @Data, $K, $V, @Items);
my ($Valid, $Item, $Key, $Value);

	#----------------------------------------------------------------------
	#------------- Get and check the email------------------------ 
	$Email = $Global{RegisterEmail}->Text;
	$Email =~ s/\s+//g;
	if (!&Check_Email_Address($Email)) {
			Win32::GUI::MessageBox(0,"Invalid email address $Email","Error", MB_ICONERROR | MB_OK,);
			$Global{RegisterEmail}->SetFocus();
			return;
	}
	$Global{Product_Email} = $Email;
	#----------------------------------------------------------------------
	$RegData = &Get_Registation_Data;
	#----------------------------------------------------------------------
	$Data = &Web_Server("$Global{Registration_URL}?Cmd=Register&Data=$RegData", "", "", "POST", "");

	if (!$Data || $Data eq "") {
		Win32::GUI::MessageBox(0,"Registration error. Please be sure you are connected to the internet.","Error", MB_ICONERROR | MB_OK,);
		$Global{RegisterEmail}->SetFocus();
		return;
	}
	#----------------------------------------------------------------------
	#$|=1;print "Data: $Data\n";
	$Data = &Web_Decode($Data);
	$Data = &Decrypt($Data, $Global{License_Pass});
	
	undef %Register;
	@Data = split (/\|/, $Data);
	foreach $Data (@Data) {
			if ($Data =~ /\=\=/) {
					($K, $V) = split (/\=\=/, $Data);
					$Register{$K} = $V;
					#$|=1;print "($K=$V)\n";
			}
	}
	#----------------------------------------------------------------------
	#---------------Check user and machine info----------------
	@Items = qw(
						Product_ID
						Product_Email
						Product_SerialNumber
						Product_FullName
						LoginName
						computer_name
						install_date
						install_time
						product_type
						system_root
						registered_organization
						registered_owner
						osversion
					);
	
	Win32::MachineInfo::GetMachineInfo("", \%RegData);

	$RegData{Product_ID} = $Global{Product_ID};
	$RegData{Product_Email} = $Global{Product_Email};
	$RegData{Product_SerialNumber} = $Global{Product_SerialNumber};
	$RegData{Product_FullName} = $Global{Product_FullName};
	$RegData{LoginName} = Win32::LoginName();

	$Valid = 1;
	foreach $Item (@Items) {
			#print "[[$Item, $RegData{$Item}==$Register{$Item}]]\n";
			if ($RegData{$Item} ne $Register{$Item}) {
					$Valid = 0;
					last;
			}
	}
	if (!$Valid) {
		Win32::GUI::MessageBox(0,"Registration error. Information sent and received does not match.","Error", MB_ICONERROR | MB_OK,);
		$Global{RegisterEmail}->SetFocus();
		return;
	}
	#----------------------------------------------------------------------
	#---------------Save the key in the registery----------------
	$Key = &RandTxt ."|";
	while (($Item, $Value) = each %Register) {
			#print "($Item=$Value)\n";
			$Key .= "$Item==$Value|" . &RandTxt ."|";
	}
	
	$Key = &Encrypt($Key, $Global{License_Pass});
	$Key = unpack ("h*", $Key);
	#----------------------------------------------------------------------
	$Registry->Delimiter("/");
    my $HKLM = $Registry->Connect("", "HKEY_LOCAL_MACHINE", {Access=>KEY_ALL_ACCESS}) or return 0;
	$Registry->DualTypes(0);
    $HKLM->SplitMultis(1);
	
	my $Software = $HKLM->{"SOFTWARE/Mewsoft/Spiderawy/$Global{Product_License_Version}/License/"};
	$Software->{"/Key"} = $Key;
	$Registry->Flush();
	#----------------------------------------------------------------------
	$Temp = &Validate_License($Software->{"/Key"});
	#print "License status=$Temp\n";
	if ($Global{License_Status}) {
		$Global{RegisterStatus}->Text("Registered");
		Win32::GUI::MessageBox(0,"Thank you for registration. Your product is working full version now. Thank you.","Successful Registration",  MB_OK,);
	}
	else{
		$Global{RegisterStatus}->Text("Not Registered");
		Win32::GUI::MessageBox(0,"Unable to register. Thank you.","Registeration Failed",  MB_OK,);
	}

}
#==========================================================
sub Get_Registation_Data{
my ($LoginName, $Key, %Info);

	Win32::MachineInfo::GetMachineInfo("", \%Info);
	$LoginName = Win32::LoginName();

$Key = join ("|", (
		&RandTxt,
		"Product_ID==$Global{Product_ID}",
		&RandTxt,
		"Product_Email==$Global{Product_Email}",
		&RandTxt,
		"Product_SerialNumber==$Global{Product_SerialNumber}",
		&RandTxt,
		"Product_FullName==$Global{Product_FullName}",
		&RandTxt,
		"LoginName==$LoginName",
		&RandTxt,
		"computer_name==$Info{computer_name}",
		&RandTxt,
		"install_date==$Info{install_date}",
		&RandTxt,
		"install_time==$Info{install_time}",
		&RandTxt,
		"product_type==$Info{product_type}",
		&RandTxt,
		"system_root==$Info{system_root}",
		&RandTxt,
		"registered_organization==$Info{registered_organization}",
		&RandTxt,
		"registered_owner==$Info{registered_owner}",
		&RandTxt,
		"osversion==$Info{osversion}",
		&RandTxt,
		"Product_Expire==$Global{Product_Expire}",
		&RandTxt,
		"Product_Counter==$Global{Product_Counter}",
		&RandTxt,
		"Product_Msg==$Global{Product_Msg}",
		&RandTxt,
		"Product_Start==$Global{Product_Start}",
		&RandTxt,
		"Product_Counted==$Global{Product_Counted}",
		&RandTxt,
		"Product_Version==$Global{Product_Version}",
		&RandTxt,
		"Product_ReCheck==$Global{Product_ReCheck}",
		&RandTxt,
		"Product_LastCheck==$Global{Product_LastCheck}",
		&RandTxt,
	));
	
	#print "$Key\n\n";
	
	$Key = &Encrypt($Key, $Global{License_Pass});
	$Key = &Web_Encode($Key);

	#print "$Key\n\n";
	#$Key1 = &Web_Decode($Key);
	#$Key1 = &Decrypt($Key1, $Global{License_Pass});
	#print "Key decoded=$Key1\n";

	return $Key;
}	
#==========================================================
sub RandTxt{
	return &Get_Random_Words . &Get_Random_Words;
}
#==========================================================
sub Get_Random_Words{
my($x, @C, $N, $M, $W);

   @C = ("a".."z");
   $N = @C;
   $M= 5 + int(rand(5));
   $W = "";
   for $x(1..$M){$W .= $C[rand($N)];}
   return $W;
}
#==========================================================
#==========================================================
sub Validate_License{
my ($Key) = shift;
my (@Data, %Register, $Item, $K, $V, @Items, %RegData);

	$Global{License_Status} = 0;
	$Key = pack ("h*", $Key);
	$Key = &Decrypt($Key, $Global{License_Pass});

	@Data = split (/\|/, $Key);
	foreach $Item (@Data) {
			if ($Item =~ /\=\=/) {
					($K, $V) = split (/\=\=/, $Item);
					$Register{$K} = $V;
					#print "($K==$V)\n";
			}
	}

	@Items = qw(
						Product_ID
						LoginName
						computer_name
						install_date
						install_time
						product_type
						system_root
						registered_organization
						registered_owner
						osversion
					);
	
	Win32::MachineInfo::GetMachineInfo("", \%RegData);
	$RegData{Product_ID} = $Global{Product_ID};
	$RegData{LoginName} = Win32::LoginName();

	foreach $Item (@Items) {
			#print "[[$Item, $RegData{$Item}==$Register{$Item}]]\n";
			if ($RegData{$Item} ne $Register{$Item}) {
				$Global{License_Status} = 0;
				return 0;
			}
	}
	

	if ($Register{Product_Expire} == -1) { #License expired
			$Global{License_Status} = 0;
			return 0;
	}

	if ($Register{Product_Expire} > 0) { # License should expire in xxx days
			if (time > ($Register{Product_Start} + $Register{Product_Expire} * 86400)) {
					$Global{License_Status} = 0;
					return 0;
			}
	}

	if ($Register{Product_Counter} > 0) { #License should expire after xxx run times
		if ($Register{Product_Counted} > $Register{Product_Counter}) {
			# $Global{License_Status} = 0;
			# return 0;
		}
	}

	if ($Register{Product_ReCheck} > 0) {
			if (time > ($Register{Product_LastCheck} + ($Register{Product_ReCheck} * 86400)) )  {
				&Check_License_Online;
				#$Global{License_Status} = 0;
				#return 0;
			}
	}

	#my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst ) = localtime($Register{Product_Start});
	#$year += 1900;	$mon++;
	#print "($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst )\n";
	#	"Product_License_Reason==$Global{Product_License_Reason}",
	if ($Register{Product_License_Status} == 1) {
				$Global{License_Status} = 1;
	}
	else{
			#"Product_License_Reason==$Global{Product_License_Reason}",
			$Global{License_Status} = 0;
	}

	return $Global{License_Status};
}
#==========================================================
sub Check_License_Online{
my ($RegData, $Data, %Register, @Data, $K, $V, $Valid);
my ($Item, @Items, $Key, $Value, $Temp);


	$RegData = &Get_Registation_Data;
	#----------------------------------------------------------------------
	$Data = &Web_Server("$Global{Registration_URL}?Cmd=Register&Data=$RegData", "", "", "POST", "");

	if (!$Data || $Data eq "") {
		#Win32::GUI::MessageBox(0,"Registration error. Please be sure you are connected to the internet.","Error", MB_ICONERROR | MB_OK,);
		#$Global{RegisterEmail}->SetFocus();
		return;
	}
	#----------------------------------------------------------------------
	#$|=1;print "Data: $Data\n";
	$Data = &Web_Decode($Data);
	$Data = &Decrypt($Data, $Global{License_Pass});
	
	undef %Register;
	@Data = split (/\|/, $Data);
	foreach $Data (@Data) {
			if ($Data =~ /\=\=/) {
					($K, $V) = split (/\=\=/, $Data);
					$Register{$K} = $V;
					#$|=1;print "($K=$V)\n";
			}
	}
	#----------------------------------------------------------------------
	#---------------Check user and machine info----------------
	@Items = qw(
						Product_ID
						Product_Email
						Product_SerialNumber
						Product_FullName
						LoginName
						computer_name
						install_date
						install_time
						product_type
						system_root
						registered_organization
						registered_owner
						osversion
					);
	
	Win32::MachineInfo::GetMachineInfo("", \%RegData);

	$RegData{Product_ID} = $Global{Product_ID};
	$RegData{Product_Email} = $Global{Product_Email};
	$RegData{Product_SerialNumber} = $Global{Product_SerialNumber};
	$RegData{Product_FullName} = $Global{Product_FullName};
	$RegData{LoginName} = Win32::LoginName();

	$Valid = 1;
	foreach $Item (@Items) {
			#print "[[$Item, $RegData{$Item}==$Register{$Item}]]\n";
			if ($RegData{$Item} ne $Register{$Item}) {
					$Valid = 0;
					last;
			}
	}
	if (!$Valid) {
		#Win32::GUI::MessageBox(0,"Registration error. Information sent and received does not match.","Error", MB_ICONERROR | MB_OK,);
		#$Global{RegisterEmail}->SetFocus();
		return;
	}
	#----------------------------------------------------------------------
	#---------------Save the key in the registery----------------
	$Key = &RandTxt ."|";
	while (($Item, $Value) = each %Register) {
			#print "($Item=$Value)\n";
			$Key .= "$Item==$Value|" . &RandTxt ."|";
	}
	
	$Key = &Encrypt($Key, $Global{License_Pass});
	$Key = unpack ("h*", $Key);
	#----------------------------------------------------------------------
	$Registry->Delimiter("/");
    my $HKLM = $Registry->Connect("", "HKEY_LOCAL_MACHINE", {Access=>KEY_ALL_ACCESS}) or return 0;
	$Registry->DualTypes(0);
    $HKLM->SplitMultis(1);
	
	my $Software = $HKLM->{"SOFTWARE/Mewsoft/Spiderawy/License/"};
	$Software->{"/Key"} = $Key;
	$Registry->Flush();
	#----------------------------------------------------------------------
	$Temp = &Validate_License($Software->{"/Key"});
	#print "License status=$Temp\n";
}
#==========================================================
sub Check_License{
	
	# Remove or comment this line to validate the license
	$Global{License_Status} = 1;

	#-------------------------------------------
	return $Global{License_Status};
	#-------------------------------------------

}
#==========================================================
sub UnRegisterButton_Click{
my ($Email, $RegData, $Data, %Register, @Data, $K, $V, @Items);
my ($Valid, $Item, $Key, $Value);

	#----------------------------------------------------------------------
	#------------- Get and check the email------------------------ 
	$Email = $Global{UnRegisterEmail}->Text;
	$Email =~ s/\s+//g;
	if (!&Check_Email_Address($Email)) {
			Win32::GUI::MessageBox(0,"Invalid email address $Email","Error", MB_ICONERROR | MB_OK,);
			$Global{UnRegisterEmail}->SetFocus();
			return;
	}
	$Global{Product_Email} = $Email;
	#----------------------------------------------------------------------
	$RegData = &Get_Registation_Data;
	#----------------------------------------------------------------------
	$Data = &Web_Server("$Global{Registration_URL}?Cmd=UnRegister&Data=$RegData", "", "", "POST", "");

	if (!$Data || $Data eq "") {
		Win32::GUI::MessageBox(0,"Unregistration error. This product is not registered or your information does not exist.","Unregistration Failed", MB_ICONERROR | MB_OK,);
		$Global{UnRegisterEmail}->SetFocus();
		return;
	}
	#----------------------------------------------------------------------
	#$|=1;print "Data: $Data\n";
	$Data = &Web_Decode($Data);
	$Data = &Decrypt($Data, $Global{License_Pass});
	
	undef %Register;
	@Data = split (/\|/, $Data);
	foreach $Data (@Data) {
			if ($Data =~ /\=\=/) {
					($K, $V) = split (/\=\=/, $Data);
					$Register{$K} = $V;
					#$|=1;print "($K=$V)\n";
			}
	}
	#----------------------------------------------------------------------
	#---------------Check user and machine info----------------
	@Items = qw(
						Product_ID
						Product_Email
						Product_SerialNumber
						Product_FullName
						LoginName
						computer_name
						install_date
						install_time
						product_type
						system_root
						registered_organization
						registered_owner
						osversion
					);
	
	Win32::MachineInfo::GetMachineInfo("", \%RegData);

	$RegData{Product_ID} = $Global{Product_ID};
	$RegData{Product_Email} = $Global{Product_Email};
	$RegData{Product_SerialNumber} = $Global{Product_SerialNumber};
	$RegData{Product_FullName} = $Global{Product_FullName};
	$RegData{LoginName} = Win32::LoginName();

	$Valid = 1;
	foreach $Item (@Items) {
			#print "[[$Item, $RegData{$Item}==$Register{$Item}]]\n";
			if ($RegData{$Item} ne $Register{$Item}) {
					$Valid = 0;
					last;
			}
	}
	if (!$Valid) {
		Win32::GUI::MessageBox(0,"UnRegistration error. Information sent and received does not match.","Error", MB_ICONERROR | MB_OK,);
		$Global{RegisterEmail}->SetFocus();
		return;
	}
	#----------------------------------------------------------------------
	#---------------Save the key in the registery----------------
	$Key = &RandTxt ."|";
	while (($Item, $Value) = each %Register) {
			#print "($Item=$Value)\n";
			$Key .= "$Item==$Value|" . &RandTxt ."|";
	}
	
	$Key = &Encrypt($Key, $Global{License_Pass});
	$Key = unpack ("h*", $Key);
	#----------------------------------------------------------------------
	$Registry->Delimiter("/");
    my $HKLM = $Registry->Connect("", "HKEY_LOCAL_MACHINE", {Access=>KEY_ALL_ACCESS}) or return 0;
	$Registry->DualTypes(0);
    $HKLM->SplitMultis(1);
	
	my $Software = $HKLM->{"SOFTWARE/Mewsoft/Spiderawy/$Global{Product_License_Version}/License/"};
	$Software->{"/Key"} = $Key;
	$Registry->Flush();
	#----------------------------------------------------------------------
	$Temp = &Validate_License($Software->{"/Key"});
	#print "License status=$Temp\n";
	if ($Global{License_Status}) {
		$Global{UnRegisterStatus}->Text("Registered");
		Win32::GUI::MessageBox(0,"Unable to UnRegister. Your product is still working full version on this system.","UnRegistration Failed",  MB_OK,);
	}
	else{
		$Global{UnRegisterStatus}->Text("Not Registered");
		Win32::GUI::MessageBox(0,"This product not regsisterd now. Your product is not working in full version.","Succesful UnRegistration",  MB_OK,);
	}

}
#==========================================================

1;