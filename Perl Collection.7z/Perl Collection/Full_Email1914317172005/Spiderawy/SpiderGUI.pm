#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Spider_Window{

$Global{TargetURLsLabel} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "TargetURLsLabel",
       -left    => 220,
       -top     => 70,
       -width   => $Global{MainWindow}->ScaleWidth() - 230,
       -height  => 150,
		-foreground    => $Global{Color},
		-background =>  $Global{TargetURLsBColor},
		-sunken=>1,
      );

$Global{TargetURLsNotesLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Web pages URL(s) to spider:",
       -name    => "TargetURLsNotesLabel",
       -left    => 230,
       -top     => 75,
       -width   => 250
       -height  => 30,
		-foreground    => $Global{Color},
		-background =>  $Global{TargetURLsBColor},
      );

$Global{RestrictDomainCheckBox} = $Global{MainWindow}->AddCheckbox(
       -text    => "Stay within domain",
       -name    => "RestrictDomainCheckBox",
       -left    => $Global{MainWindow}->ScaleWidth() - 220,
       -top     => 78,
       -width   => 120,
       -height  => 15,
		-tabstop    => 1,
		-foreground    => $Global{Color},
		-background =>  $Global{TargetURLsBColor},
		-tip => "Do not travel to other domains.",
      );
$Global{RestrictDomainCheckBox}->SetCheck(0);

$Global{LoadURLsFileButton} = $Global{MainWindow}->AddButton(
       -text    => "Load",
       -name    => "LoadURLsFileButton",
       -left    => $Global{MainWindow}->ScaleWidth() - 100,
       -top     => 75,
       -width   => 40,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Load URL List From File",
		#-bitmap=>$Global{OpenFileImage},
      );
#------------------------------------------------------------------------------------------------
=cuts
$Global{LoadURLsWebButton} = $Global{MainWindow}->AddButton(
       -text    => "Get",
       -name    => "LoadURLsWebButton",
       -left    => $Global{MainWindow}->ScaleWidth() - 60,
       -top     => 75,
       -width   => 40,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Extract URL List From Online Web Page",
		#-bitmap=>$Global{OpenFileImage},
		-foreground    => $Global{Color},
		-background =>  $Global{TargetURLsBColor},
      );
=cut
#------------------------------------------------------------------------------------------------
#http://groups.google.com/groups?dq=&num=100&hl=ar&lr=&ie=UTF-8&group=comp.lang.perl.modules&start=0
$Global{TragetURLs} = $Global{MainWindow}->AddTextfield(
		#-text    => "http://www.mewsoft.com/Contact/\r\nhttp://www.mewsoft.com/\r\nhttp://www.mewsoft.com/Support/",
		-text    => "",
		-name    => "TragetURLs",
       -left    =>230,
       -top     => 100,
       -width   => $Global{MainWindow}->ScaleWidth() - (260),
       -height  => 60,
		-align => 'left',
		-multiline => 1,
		-tabstop    => 0,
		-autohscroll => 1,
		-autovscroll => 1,
		-vscroll   => 1,
		-hscroll   => 1,
#		-dialogui =>1,
		#-style   => WS_CHILD | WS_VSCROLL |WS_HSCROLL | ES_MULTILINE | ES_WANTRETURN,
		-visible=> 1,
		-addstyle   => ES_WANTRETURN,
		-foreground    => $Global{TragetURLsFColor},
		-background => $Global{TragetURLsBFColor},
		-tip=> "Enter the list of domains or web pages URL(s) to spider.",
      );
# maximum allowed is 32k for a single-line Textfield and 64k for a multiline one.
$Global{TragetURLs}->MaxLength(0); # 0: Set to the maximum limit
#foreach my $k (keys %{$Global{TragetURLs}}) {	print "$k=", $Global{TragetURLs}->{$k},"\n";}

$Global{UseSearchLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Search Engine:",
       -name    => "UseSearchLabel",
       -left    => 230,
       -top     => 190,
       -width   => 90,
       -height  => 15,
		-tabstop    => 1,
		-foreground    => $Global{Color},
		-background =>  $Global{TargetURLsBColor},
      );

$Global{UseSearchCombobox} = $Global{MainWindow}->AddCombobox( 
    -name   => "UseSearchCombobox",
    -left   => 310, 
    -top    => 190,
    -width  => 180, 
    -height => 100,
	-tabstop    => 1,
    -addstyle  => WS_VISIBLE | 03 | WS_NOTIFY| WS_TABSTOP,
	-foreground    => $Global{Color},
	-background =>  $Global{TargetURLsBColor},
	-tip=> "Select a search engine to search for keywords and search terms to spider",
);
#$Global{UseSearchCombobox}->Foreground($Global{TargetURLsBColor});

$Global{UseSearchCombobox}->InsertItem("Choose one");
$Global{UseSearchCombobox}->InsertItem("Yahoo");
$Global{UseSearchCombobox}->InsertItem("DMOZ");
#$Global{UseSearchCombobox}->InsertItem("MSN");
$Global{UseSearchCombobox}->Select(0);

$Global{SearchTermLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Search Term:",
       -name    => "SearchTermLabel",
       -left    => 500,
       -top     => 190,
       -width   => 66,
       -height  => 13,
       -foreground    => 0,
		-hottrack => 1,
		-foreground    => $Global{Color},
		-background =>  $Global{TargetURLsBColor},
      );

$Global{UseSearchTermCombobox} = $Global{MainWindow}->AddCombobox( 
	-name   => "UseSearchTermCombobox",
    -left   => 570, 
    -top    => 190,
    -width  => 190, 
    -height => 100,
	-tabstop    => 1,
    -addstyle  => WS_CHILD| WS_VISIBLE | 2 | WS_NOTIFY| WS_TABSTOP|0x0040, # CBS_AUTOHSCROLL=0x0040 in WINUSER.H
	-foreground    => $Global{Color},
	-background =>  $Global{TargetURLsBColor},
	-tip => "Enter the words or search term to search using the selected search engine",
);
$Global{UseSearchTermCombobox}->AddString("web design");
#$Global{UseSearchCombobox}->InsertItem("Choose one");
#========================================================
#------------------------Results area----------------------------------------------------
$Global{ResultsLabel} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "ResultsLabel",
       -left    => 220,
       -top     => 230,
       -width   => $Global{MainWindow}->ScaleWidth() - (230),
       -height  => 295,
		-foreground    => $Global{Color},
		-background => $Global{ResultsBColor},
		-sunken=>1,
      );


$Global{EmailListView} = $Global{MainWindow}->AddListView(
	#-class => $Global{ListviewClass},
       -text    => "Emails",
       -name    => "EmailListView",
       -left    => 230,
       -top     => 240,
       -width   => $Global{MainWindow}->ScaleWidth() - 250,
       -height  => 140,
		-tabstop    => 0,
		-addstyle     => WS_CHILD | WS_VISIBLE | WS_VSCROLL|WS_HSCROLL| 1,
		-fullrowselect => 1,
		-gridlines => 0,
		-checkboxes => 0, # see ItemCheck(INDEX)
	   -tip => "List of none duplicated emails extracted",
      );
$Global{EmailsListViewC1} = $Global{EmailListView}->InsertColumn(
    -index => 0,
    -width => 60,
    -text  => "Location",
);

$Global{EmailsListViewC2} = $Global{EmailListView}->InsertColumn(
    -index => 1,
    -width =>$Global{EmailListView}->ScaleWidth() - 90,
    -text  => "Emails Extracted",
);

$Global{EmailListView}->TextBkColor($Global{EmailListBkColor});
$Global{EmailListView}->TextColor($Global{EmailListColor});
&LV_SetBkColor($Global{EmailListView}, $Global{EmailListBkColor});
#====================================================================
=cuts
#--------------- Email list page browse buttons ----------------------------------------------------------------
$Global{EmailListLastPageButton} = $Global{MainWindow}->AddButton(
       -text    => " >> ",
       -name    => "EmailListLastPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - 80,
       -top     => 345,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Last page",
		#-bitmap=>$Global{OpenFileImage},
      );
$Global{EmailListNextPageButton} = $Global{MainWindow}->AddButton(
       -text    => " > ",
       -name    => "EmailListNextPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - (80+1*25),
       -top     => 345,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Next page",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{EmailListPreviousPageButton} = $Global{MainWindow}->AddButton(
       -text    => " < ",
       -name    => "EmailListPreviousPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - (80+5*25+0),
       -top     => 345,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Previous page",
		#-bitmap=>$Global{OpenFileImage},
      );
$Global{EmailListFirstPageButton} = $Global{MainWindow}->AddButton(
       -text    => " << ",
       -name    => "EmailListFirstPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - (80+6*25+0),
       -top     => 345,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "First page",
		#-bitmap=>$Global{OpenFileImage},
      );
$Global{EmailsPageCombobox} = $Global{MainWindow}->AddCombobox( 
    -name   => "EmailsPageCombobox",
    -left   => $Global{MainWindow}->ScaleWidth() - (80+4*25+0),
    -top    => 345-1,
    -width  => 3*25, 
    -height => 100,
	-tabstop    => 1,
    -addstyle  => WS_VISIBLE | 3 | WS_NOTIFY| WS_TABSTOP,
	-foreground    => $Global{Color},
	-background => $Global{ResultsBColor},
);
$Global{EmailsPageCombobox}->InsertItem("View Page ");
$Global{EmailsPageCombobox}->Select(0);
=cut

=cuts
$Global{EmailsPagesizeCombobox} = $Global{MainWindow}->AddCombobox( 
    -name   => "EmailsPagesizeCombobox",
    -left   => $Global{MainWindow}->ScaleWidth() - (80+10*25+0),
    -top    => 345-1,
    -width  => 3*25, 
    -height => 100,
	-tabstop    => 1,
    -addstyle  => WS_VISIBLE | 3 | WS_NOTIFY| WS_TABSTOP,
	-foreground    => $Global{Color},
	-background => $Global{ResultsBColor},
);
$Global{EmailsPagesizeCombobox}->InsertItem("Page Size");
$Global{EmailsPagesizeCombobox}->Select(0);
=cut
#-------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------
$Global{URLsListView} = $Global{MainWindow}->AddListView(
	#-class => $Global{ListviewClass},
       -text    => "URLs",
       -name    => "URLsListView",
       -left    => 230,
       -top     => 370,
       -width   => $Global{MainWindow}->ScaleWidth() - 230,
       -height  => 130,
		-addstyle     => WS_CHILD | WS_VISIBLE | WS_VSCROLL|WS_HSCROLL| 1,
		-tabstop    => 0,
		-fullrowselect => 1,
		-gridlines => 0,
		-checkboxes => 0, # see ItemCheck(INDEX)
	   -tip => "List of the URL(s) recently finished spidering and the links currently processing",
      );

$Global{URLsListViewC1} = $Global{URLsListView}->InsertColumn(
    -index => 0,
    -width =>60,
    -text  => "Location",
#	-visible=> 0,
);
$Global{URLsListViewC2} = $Global{URLsListView}->InsertColumn(
    -index => 1,
    -width =>45,
    -text  => "Level",
#	-visible=> 0,
);
$Global{URLsListViewC3} = $Global{URLsListView}->InsertColumn(
    -index => 2,
    -width =>$Global{URLsListView}->ScaleWidth() - 200,
    -text  => "URL Web Page",
#	-visible=> 0,
);

$Global{URLsListViewC4} = $Global{URLsListView}->InsertColumn(
    -index => 3,
    -width =>60,
    -text  => "Status",
#	-visible=> 0,
);
#$Global{URLsListView}->ColumnWidth(2, $Global{URLsListView}->ScaleWidth() - 200);
#-addstyle=>WS_VISIBLE | 3 | WS_VSCROLL | WS_TABSTOP

$Global{URLsListView}->TextBkColor($Global{URLsListBkColor});
$Global{URLsListView}->TextColor($Global{URLsListColor});
&LV_SetBkColor($Global{URLsListView}, $Global{URLsListBkColor});
#====================================================================
=cuts
#--------------- URL list page browse buttons ----------------------------------------------------------------
$Global{URLListLastPageButton} = $Global{MainWindow}->AddButton(
       -text    => " >> ",
       -name    => "URLListLastPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - 80,
       -top     => 475,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Last page",
		#-bitmap=>$Global{OpenFileImage},
      );
$Global{URLListNextPageButton} = $Global{MainWindow}->AddButton(
       -text    => " > ",
       -name    => "URLListNextPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - (80+1*25),
       -top     => 475,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Next page",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{URLListPreviousPageButton} = $Global{MainWindow}->AddButton(
       -text    => " < ",
       -name    => "URLListPreviousPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - (80+5*25+0),
       -top     => 475,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "Previous page",
		#-bitmap=>$Global{OpenFileImage},
      );
$Global{URLListFirstPageButton} = $Global{MainWindow}->AddButton(
       -text    => " << ",
       -name    => "URLListFirstPageButton",
       -left    => $Global{MainWindow}->ScaleWidth() - (80+6*25+0),
       -top     => 475,
       -width   => 25,
       -height  => 20,
		-tabstop    => 1,
		-tip => "First page",
		#-bitmap=>$Global{OpenFileImage},
      );
$Global{URLPageCombobox} = $Global{MainWindow}->AddCombobox( 
    -name   => "URLPageCombobox",
    -left   => $Global{MainWindow}->ScaleWidth() - (80+4*25+0),
    -top    => 475-1,
    -width  => 3*25, 
    -height => 100,
	-tabstop    => 1,
    -addstyle  => WS_VISIBLE | 3 | WS_NOTIFY| WS_TABSTOP,
	-foreground    => $Global{Color},
	-background => $Global{ResultsBColor},
);
$Global{URLPageCombobox}->InsertItem("View Page ");
$Global{URLPageCombobox}->Select(0);
=cut
=cuts
$Global{URLPagesizeCombobox} = $Global{MainWindow}->AddCombobox( 
    -name   => "URLPagesizeCombobox",
    -left   => $Global{MainWindow}->ScaleWidth() - (80+10*25+0),
    -top    => 565-1,
    -width  => 3*25, 
    -height => 100,
	-tabstop    => 1,
    -addstyle  => WS_VISIBLE | 3 | WS_NOTIFY| WS_TABSTOP,
	-foreground    => $Global{Color},
	-background => $Global{ResultsBColor},
);
$Global{URLPagesizeCombobox}->InsertItem("Page Size");
$Global{URLPagesizeCombobox}->Select(0);
#===========================================================
$Global{ExecludeDomainCheckBox} = $Global{MainWindow}->AddCheckbox(
       -text    => "Execlude domain links",
       -name    => "ExecludeDomainCheckBox",
       -left    => 340,
       -top     => 470,
       -width   => 140,
       -height  => 15,
		-tabstop    => 1,
		-foreground    => $Global{Color},
		-background => $Global{BColor},
      );
$Global{ExecludeDomainCheckBox}->SetCheck(0);
=cut

$Global{StartButton} = $Global{MainWindow}->AddButton(
       -text    => "Start",
       -name    => "StartButton",
       -left    => int($Global{MainWindow}->ScaleWidth/2)-(3*70)/2,
       -top     => 500,
       -width   => 70,
       -height  => 22,
		-visible=> 0,
		-tabstop    => 1,
		-tip =>"Start spider now",
		#-bitmap=>$Global{SaveAsImage},
		-foreground    => $Global{Color},
		-background => $Global{BColor},
		#-addstyle =>0x00000008|0x00004000|0x00008000,
      );

$Global{PauseButton} = $Global{MainWindow}->AddButton(
       -text    => "Pause",
       -name    => "PauseButton",
       -left    => int($Global{MainWindow}->ScaleWidth/2)-(1*70)/2,
       -top     => 500,
       -width   => 70,
       -height  => 22,
		-visible=> 0,
		-tabstop    => 1,
		-tip =>"Pause spider",
		#-bitmap=>$Global{SaveAsImage},
      );
$Global{PauseButton}->Disable();

$Global{StopButton} = $Global{MainWindow}->AddButton(
       -text    => "Stop",
       -name    => "StopButton",
       -left    => int($Global{MainWindow}->ScaleWidth/2)+(1*70)/2,
       -top     => 520,
       -width   => 70,
       -height  => 22,
		-tabstop    => 1,
		-visible=> 0,
		-tip =>"Pause spider",
		#-bitmap=>$Global{SaveAsImage},
      );
$Global{StopButton}->Disable();

#my ($W, $X, $Y, $W, $V) = @_;
#$Global{Separator1} = &Separator($Global{MainWindow}, 220, 490, $Global{MainWindow}->ScaleWidth - 230, 1);
#===========================================================
#--------------- Stats ----------------------------
$Global{StatsBox} = $Global{MainWindow}->AddLabel( #AddButton AddGroupbox
       -text    => "",
       -name    => "StatsBox",
       -left    => 10,
       -top     => 70,
       -width   => 200,
       -height  => 530,
       #-addstyle  => WS_CHILD | WS_VISIBLE | 7,  # GroupBox
		-background => $Global{StatsBColor},
		-sunken=>1,
      );


#foreach $k (keys %{$Global{StatusLabel}}) {	print "$k=", $Global{StatusLabel}->{$k},"\n";}
$Global{EmailsFoundLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Emails Found:",
       -name    => "EmailsFoundLabel",
       -left    => 15,
       -top     => 85,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
	-sunken   => 0, 
      );

$Global{EmailsFound} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "EmailsFound",
       -left    => 100,
       -top     => 85,
       -width   => 80,
       -height  => 16,
		#-addstyle => ES_READONLY,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY,
		-noprefix => 1,
		-sunken   => 1, 
     #-popstyle      => WS_BORDER,                              # Remove  Border
     #-popexstyle  => WS_EX_CLIENTEDGE ,             # Remove ClientEdge
      );

# Arabic direction  -style =>      DS_SYSMODAL

$Global{LastEmailFoundLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Last Email At :",
       -name    => "LastEmailFoundLabel",
       -left    => 15,
       -top     => 105,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{LastEmailFound} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "LastEmailFound",
       -left    => 100,
       -top     => 105,
       -width   => 80,
       -height  => 16,
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		-noprefix => 1,
		-sunken   => 1, 
      );

$Global{URLsFoundLabel} = $Global{MainWindow}->AddLabel(
       -text    => "URLs Found:",
       -name    => "URLsFoundLabel",
       -left    => 15,
       -top     => 135,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{URLSFound} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "URLSFound",
       -left    => 100,
       -top     => 135,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-noprefix => 1,
		-sunken   => 1, 
      );

$Global{LastURLFoundLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Last URL At:",
       -name    => "LastURLFoundLabel",
       -left    => 15,
       -top     => 155,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{LastURLFound} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "LastURLFound",
       -left    => 100,
       -top     => 155,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-noprefix => 1,
		-sunken   => 1, 
      );

#-----------------------------------------------------------------------------------------------------
$Global{URLsFinishedLabel} = $Global{MainWindow}->AddLabel(
       -text    => "URLs Finished:",
       -name    => "URLsFinishedLabel",
       -left    => 15,
       -top     => 185,
       -width   => 80,
       -height  => 16,
       -foreground    => 0,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{URLsFinished} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "URLsFinished",
       -left    => 100,
       -top     => 185,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-noprefix => 1,
		-sunken   => 1, 
      );

$Global{URLsWaitingLabel} = $Global{MainWindow}->AddLabel(
       -text    => "URLs Waiting:",
       -name    => "URLsWaitingLabel",
       -left    => 15,
       -top     => 205,
       -width   => 80,
       -height  => 16,
       -foreground    => 0,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{URLsWaiting} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "URLsWaiting",
       -left    => 100,
       -top     => 205,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-noprefix => 1,
		-sunken   => 1, 
      );
#-----------------------------------------------------------------------------------------------------
$Global{ConnectionsLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Connections:",
       -name    => "ConnectionsLabel",
       -left    => 15,
       -top     => 255,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{ConnectionsThreads} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "ConnectionsThreads",
       -left    => 100,
       -top     => 255,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-noprefix => 1,
		-sunken   => 1, 
      );

$Global{RuningThreadsLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Runing Threads:",
       -name    => "RuningThreadsLabel",
       -left    => 15,
       -top     => 235,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{RuningThreads} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "RuningThreads",
       -left    => 100,
       -top     => 235,
       -width   => 80,
       -height  => 16,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY|DS_3DLOOK ,
		-noprefix => 1,
		-sunken   => 1, 
      );
#-----------------------------------------------------------------------------------------------------
$Global{CurrentLevelLabel} = $Global{MainWindow}->AddLabel(
       -text    => "Current Level:",
       -name    => "CurrentLevelLabel",
       -left    => 15,
       -top     => 285,
       -width   => 80,
       -height  => 13,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

$Global{CurrentLevel} = $Global{MainWindow}->AddLabel(
       -text    => "",
       -name    => "CurrentLevel",
       -left    => 100,
       -top     => 285,
       -width   => 80,
       -height  => 16,
		-addstyle => ES_READONLY,
		-foreground    => $Global{StatsFieldFColor},
		-background => $Global{StatsFieldBColor},
		#-style => WS_TABSTOP | WS_VISIBLE | ES_LEFT | DS_MODALFRAME|ES_READONLY ,
		-noprefix => 1,
		-sunken   => 1, 
      );

$Global{StatusLabel} = $Global{MainWindow}->AddLabel(
       -text    => " Ready...",
       -name    => "StatusLabel",
       -left    => 10,
       -top     => $Global{MainWindow}->ScaleHeight-22,
       -width   => $Global{MainWindow}->ScaleWidth-10,
       -height  => 20,
		#-noprefix => 1,
		-sunken   => 1, 
		#-addstyle =>ES_READONLY,
		-foreground    => $Global{StatusFColor},
		-background => $Global{StatusBkColor},
		#-remstyle=>WS_BORDER|WS_THICKFRAME,
		-tabstop=>0,
		-wrap=>0,
     #-popstyle      => WS_BORDER,                              # Remove  Border
    # -popexstyle  => WS_EX_CLIENTEDGE ,             # Remove ClientEdge
      );
#================================================================
#----------------------------Threads status------------------------------------------------------------
$Global{ThreadsStatus} = $Global{MainWindow}->AddLabel( #AddGroupbox AddLabel
       -text    => "",
       -name    => "ThreadsStatus",
       -left    => 15,
       -top     => 440,
       -width   => 190,
       -height  => 170,
       #-addstyle  => WS_CHILD | 7,  # GroupBox
		#-style=>WS_BORDER|WS_THICKFRAME|7,
		-foreground    => $Global{StatsFColor},
		-background => $Global{StatsBColor},
      );

my $t=0;# 430;
my $l =0;#15;
my $c = 0;
for my $y(0..9) {
		for my $x(0..9){
				$c++;
				my $k = "StatusImg".$c;
				$Global{$k} = $Global{MainWindow}->AddLabel(
					-parent=>$Global{ThreadsStatus},
				   -text    => "",
				   -name    => $k,
				   -left    => $l+7+($x*18),
				   -top     => $t+10+ ($y*16), #$Global{MainWindow}->ScaleHeight-45,
				   -width   => 17,
				   -height  => 14,
					#-noprefix => 1,
					#-sunken   => 01, 
					-foreground    => $Global{Color},
					-background => $Global{StatsBColor},
					-tabstop=>0,
					-bitmap=>1,
					-visible=>1,
					-group	=> 1,

				  );
				$Global{$k}->SetImage($Global{ReadyImg});
		}
}

}
#==========================================================
sub Separator{
my ($Win, $X, $Y, $W, $V) = @_;
my ($L);

$V ||= 0;
$L = $Win->AddLabel(
			#-fill     => gray , #black/gray/white/none (default none)
			-text   => "",
			-left   => $X,
			-top    => $Y,
			-height => 2,
			-width => $W,
			-frame=> etched, #black/gray/white/etched/none (default none)
			-visible => $V,
			#-sunken   => 1,
		);
	return $L;
}
#==========================================================
#====================================================================
# Set the ListView Background Color
sub LVM_FIRST               (){0x1000} #   ListView messages
sub LVM_SETBKCOLOR (){(&LVM_FIRST + 1)}
sub LV_SetBkColor{
my ($Handle, $Color) = @_;
	$Handle or return undef;
	defined $Color or return;
	return Win32::GUI::SendMessage($Handle, &LVM_SETBKCOLOR, 0, $Color);
}
#====================================================================
sub CCM_FIRST               (){0x2000}
sub CCM_SETBKCOLOR          (){(&CCM_FIRST + 1)}
sub CCM_SetBkColor{
my ($Handle, $Color) = @_;
	$Handle or return undef;
	defined $Color or return;
	return Win32::GUI::SendMessage($Handle, &CCM_SETBKCOLOR, 0, $Color);
}
#====================================================================
sub Change_Spider_Them{
	
	$Global{Color_Them} = !$Global{Color_Them};
	&Update_Config("Color_Them"=>"$Global{Color_Them}");
	&Set_Theme;

$Global{TargetURLsLabel}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});
$Global{TargetURLsNotesLabel}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});
$Global{TragetURLs}->Change( -foreground => $Global{TragetURLsFColor}, -background =>  $Global{TragetURLsBFColor});
$Global{RestrictDomainCheckBox}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});

$Global{UseSearchLabel}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});
$Global{UseSearchCombobox}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});
$Global{SearchTermLabel}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});
$Global{UseSearchTermCombobox}->Change( -foreground => $Global{Color}, -background =>  $Global{TargetURLsBColor});

$Global{ResultsLabel}->Change( -foreground => $Global{Color}, -background =>  $Global{ResultsBColor});

$Global{EmailListView}->TextBkColor($Global{EmailListBkColor});
$Global{EmailListView}->TextColor($Global{EmailListColor});
&LV_SetBkColor($Global{EmailListView}, $Global{EmailListBkColor});

#$Global{EmailsPageCombobox}->Change( -foreground => $Global{Color}, -background =>  $Global{ResultsBColor});
#$Global{EmailsPagesizeCombobox}->Change( -foreground => $Global{Color}, -background =>  $Global{ResultsBColor});

$Global{URLsListView}->TextBkColor($Global{URLsListBkColor});
$Global{URLsListView}->TextColor($Global{URLsListColor});
&LV_SetBkColor($Global{URLsListView}, $Global{URLsListBkColor});

#$Global{URLPageCombobox}->Change( -foreground => $Global{Color}, -background =>  $Global{ResultsBColor});
#$Global{URLPagesizeCombobox}->Change( -foreground => $Global{Color}, -background =>  $Global{ResultsBColor});

#$Global{RestrictDomainCheckBox}->Change( -foreground => $Global{Color}, -background =>  $Global{BColor});
#$Global{ExecludeDomainCheckBox}->Change( -foreground => $Global{Color}, -background =>  $Global{BColor});

$Global{StatsBox}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});

$Global{EmailsFoundLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{EmailsFound}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{LastEmailFoundLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{LastEmailFound}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{URLsFoundLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{URLSFound}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{LastURLFoundLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{LastURLFound}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{URLsFinishedLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{URLsFinished}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{URLsWaitingLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{URLsWaiting}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{RuningThreadsLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{RuningThreads}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{ConnectionsLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{ConnectionsThreads}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{CurrentLevelLabel}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});
$Global{CurrentLevel}->Change( -foreground => $Global{StatsFieldFColor}, -background =>  $Global{StatsFieldBColor});

$Global{ThreadsStatus}->Change( -foreground => $Global{StatsFColor}, -background =>  $Global{StatsBColor});

$Global{StatusLabel}->Change( -foreground => $Global{StatusFColor}, -background =>  $Global{StatusBkColor});

my $c = 0;
for my $y(0..9) {
		for my $x(0..9){
			$c++;
			my $k = "StatusImg". $c;
				$Global{$k}->SetImage($Global{ReadyImg});
				#$Global{$k}->InvalidateRect(1);
				#$Global{$k}->Update();
				#$Global{MainWindow}->Update();
				#Win32::GUI::DoEvents();
		}
}
	$Global{MainWindow}->Update();
	$Global{MainWindow}->InvalidateRect(1);
	Win32::GUI::DoEvents();
	$Global{MainWindow}->Update();
	#&MainProgWindow_Resize;
	Win32::GUI::DoEvents();
	$Global{MainWindow}->SetFocus;

#------------Progress bar colors-----------------------------------------------
# Win32::GUI::SendMessage($Wmain->Progressbar, PBM_SETBARCOLOR, 0, $pbcolor); #change progressbar color
# result = SendMessage($hWndControl, PBM_SETBARCOLOR, 0, $color);
# Win32::GUI::SendMessage($Progress, 0x400 + 9, 0, hex('0000FF'));
#define PBM_SETBARCOLOR         (WM_USER+9)		// lParam = bar color
#define PBM_SETBKCOLOR          CCM_SETBKCOLOR  // lParam = bkColor
#-----------------------------------------------------------------------------------------------

}
#====================================================================
sub Set_Status_Ready_Images{

my $c = 0;
for my $y(0..9) {
		for my $x(0..9){
			$c++;
			my $k = "StatusImg". $c;
				$Global{$k}->SetImage($Global{ReadyImg});
				#$Global{$k}->InvalidateRect(1);
				#$Global{$k}->Update();
				#$Global{MainWindow}->Update();
				#Win32::GUI::DoEvents();
		}
}
	$Global{MainWindow}->Update();
	$Global{MainWindow}->InvalidateRect(1);
	Win32::GUI::DoEvents();
}
#====================================================================

1;
