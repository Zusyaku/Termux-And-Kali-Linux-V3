#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Setup_Window{

 $Global{SetupWindow} = new GUI::Window( #DialogBox
    -name     => "SetupWindow",
    -title    => "Spiderawy Tools",
    -left     => 1, 
    -top      => 1, 
    -width    => 450, 
    -height   => 450,
    -addstyle    => WS_TABSTOP, # |  COLOR_BTNTEXT|COLOR_BACKGROUND| COLOR_GRAYTEXT|COLOR_MENU|COLOR_SCROLLBAR|COLOR_WINDOW,
	-maximizebox => 0,
 	-minimizebox =>0,
 	-helpbutton => 0,
 	-resizable =>01,
	-visible=> 0,
	#-dialogui => 1,
	#-topmost => 1,
	#-toolwindow => 1,
	#-vscroll => 1,               
	#-addexstyle => WS_EX_TOOLWINDOW ,
#	-menubox => 0,
	);
	$Global{SetupWindow}->{'-dialogui'} = 1;
	#-----------------------------------------------------
#my $IL = new Win32::GUI::ImageList(16, 16, 8, 3, 10);
#my $IMG_ONE   = $IL->Add("one.bmp");
#my $IMG_TWO   = $IL->Add("two.bmp");
#my $IMG_THREE = $IL->Add("three.bmp");

&CenterOnScreen($Global{SetupWindow});

 $Global{Setup_Tab} = $Global{SetupWindow}->AddTabFrame (
    -name   => "Setup_Tab",
    -panel  => "Setup",
	-hottrack => 1,
	#-imagelist => $IL,
);

my $TBorder = 0; # 0..5
 $Global{Setup_Tab}->InsertItem(
    -text   => " Engine ",
    -paneltext => "",
    -border => $TBorder,
);
 $Global{Setup_Tab}->InsertItem(
    -text   => " Connection ",
    -paneltext => "",
    -border => $TBorder,
);

$Global{Setup_Page1} = $Global{Setup_Tab}->Setup0;
$Global{Setup_Page2} = $Global{Setup_Tab}->Setup1;

# $Global{Setup_Tab}->InsertItem(
#    -text   => "     Search     ",
#    -paneltext => "Search Local Directories",
#    -border => $TBorder,
#);
#$Global{Setup_Page2} = $Global{Setup_Tab}->Page1;

&SetupWindow_Resize ();
#------------------------------------------------------------------------------------------
#-----------------------------Connection Window----------------------------------
$Global{ProxySetupLabel} = $Global{Setup_Page2}->AddButton(
       -text    => "Proxy setup",
       -name    => "ProxySetupLabel",
       -left    => 10,
       -top     => 10,
       -width   => $Global{Setup_Page2}->ScaleWidth-20,
       -height  => 190,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{UseProxyCheckBox} = $Global{Setup_Page2}->AddCheckbox(
       -text    => "Use Proxy",
       -name    => "UseProxyCheckBox",
       -left    => 30,
       -top     => 42,
       -width   => 70,
       -height  => 15,
		-tabstop    => 1,
		-tip => "Use proxy server to access web page",
		-visible=> 1,
      );
$Global{UseProxyCheckBox}->SetCheck($Global{Use_Proxy});

$Global{ProxyAddress} = $Global{Setup_Page2}->AddTextfield(
		-text    => $Global{Proxy_Address},
		-name    => "ProxyAddress",
		-top     => 40,
		-left    => 100,
		-width   => $Global{Setup_Page2}->ScaleWidth-130,
		-height  => 23,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip => "Proxy server address",
	  #  -addexstyle    => WS_TABSTOP,
      );
if (!$Global{Use_Proxy}) {$Global{ProxyAddress}->Disable;}

$Global{UseProxyAuthenCheckBox} = $Global{Setup_Page2}->AddCheckbox(
       -text    => "Use Authentication",
       -name    => "UseProxyAuthenCheckBox",
       -left    => 30,
       -top     => 90,
       -width   => 140,
       -height  => 15,
		-tabstop    => 1,
		-tip => "Check if authentication is required to access the proxy server",
		-visible=> 1,
      );
$Global{UseProxyAuthenCheckBox}->SetCheck($Global{Use_Proxy_Authen});

$Global{ProxyUsernameLabel} = $Global{Setup_Page2}->AddLabel(
       -text    => "Username:",
       -name    => "ProxyUsernameLabel",
       -left    => 30,
       -top     => 122,
       -width   => 60,
       -height  => 15,
		-tabstop    => 0,
      );
$Global{ProxyUsername} = $Global{Setup_Page2}->AddTextfield(
		-text    => $Global{Proxy_Username},
		-name    => "ProxyUsername",
		-top     => 120,
		-left    => 100,
		-width   => 200,
		-height  => 23,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip => "Username required to login to the proxy server",
	  #  -addexstyle    => WS_TABSTOP,
      );
if (!$Global{Use_Proxy_Authen}) {$Global{ProxyUsername}->Disable;}

$Global{ProxyPasswordLabel} = $Global{Setup_Page2}->AddLabel(
       -text    => "Password:",
       -name    => "ProxyPasswordLabel",
       -left    => 30,
       -top     => 162,
       -width   => 60,
       -height  => 15,
		-tabstop    => 0,
      );
$Global{ProxyPassword} = $Global{Setup_Page2}->AddTextfield(
		-text    => $Global{Proxy_Password},
		-name    => "ProxyPassword",
		-top     => 160,
		-left    => 100,
		-width   => 200,
		-height  => 23,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-password=>1,
		-tip => "Password required to login to the proxy server",
	  #  -addexstyle    => WS_TABSTOP,
      );
if (!$Global{Use_Proxy_Authen}) {$Global{ProxyPassword}->Disable;}
#==========================================================
$Global{ConnectionSettingLabel} = $Global{Setup_Page2}->AddButton(
       -text    => "Connection",
       -name    => "ConnectionSettingLabel",
       -top     => 220,
       -left    => 10,
       -width   => $Global{Setup_Page2}->ScaleWidth-20,
       -height  => 100,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{ConnectionPortLabel} = $Global{Setup_Page2}->AddLabel(
       -text    => "Port:",
       -name    => "ConnectionPortLabel",
       -left    => 30,
       -top     => 248,
       -width   => 40,
       -height  => 15,
		-tabstop    => 0,
      );
$Global{ConnectionPort} = $Global{Setup_Page2}->AddTextfield(
		-text    => $Global{Connection_Port},
		-name    => "ConnectionPort",
		-top     => 245,
		-left    => 100,
		-width   => 100,
		-height  => 23,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip => "Connection port",
	  #  -addexstyle    => WS_TABSTOP,
      );

$Global{ConnectionTimeoutLabel} = $Global{Setup_Page2}->AddLabel(
       -text    => "Timeout:",
       -name    => "ConnectionTimeoutLabel",
       -left    => 30,
       -top     => 273,
       -width   => 40,
       -height  => 15,
		-tabstop    => 0,
      );
$Global{ConnectionTimeout} = $Global{Setup_Page2}->AddTextfield(
		-text    => $Global{Connection_Timeout},
		-name    => "ConnectionTimeout",
		-top     => 270,
		-left    => 100,
		-width   => 100,
		-height  => 23,
		-multiline => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip => "Connection Timeout",
	  #  -addexstyle    => WS_TABSTOP,
      );
$Global{TimeoutSecondsLabel} = $Global{Setup_Page2}->AddLabel(
       -text    => "Seconds",
       -name    => "TimeoutSecondsLabel",
       -left    => 205,
       -top     => 273,
       -width   => 60,
       -height  => 15,
		-tabstop    => 0,
      );

$Global{SettingsDefaultsButton} = $Global{Setup_Page2}->AddButton(
       -text    => " Defaults",
       -name    => "SettingsDefaultsButton",
       -left    => 10,
       -top     => 350,
       -width   => 60,
       -height  => 20,
		-tabstop    => 1,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{SettingsOKButton} = $Global{Setup_Page2}->AddButton(
       -text    => "   OK   ",
       -name    => "SettingsOKButton",
       -left    => 170,
       -top     => 350,
       -width   => 60,
       -height  => 20,
		-tabstop    => 1,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{SettingsCancelButton} = $Global{Setup_Page2}->AddButton(
       -text    => " Cancel ",
       -name    => "SettingsCancelButton",
       -left    => 240,
       -top     => 350,
       -width   => 60,
       -height  => 20,
		-tabstop    => 0,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );
#=======================================================
#--------------------------------------------------------------------------------------------------
#-----------------------Engine settings------------------------------------------------------
$Global{EngineSetupLabel} = $Global{Setup_Page1}->AddButton(
       -text    => "Threads",
       -name    => "EngineSetupLabel",
       -left    => 10,
       -top     => 10,
       -width   => $Global{Setup_Page1}->ScaleWidth-20,
       -height  => 190,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{EngineThreadsLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Please select the number of concurrent threads according to the size of your system free physical memory (RAM). Creating each thread requires about $Global{Required_Thread_RAM} MB of free RAM. Consider each thread as a copy of the program and all copies are runing in parallel. Please also leave a free RAM for the program data and other programs.",
       -name    => "EngineThreadsLabel",
       -left    => 20,
       -top     => 30,
       -width   => $Global{Setup_Page1}->ScaleWidth-40,
       -height  => 70,
		-tabstop    => 0,
      );

$Global{Threads_Slider} = $Global{Setup_Page1}->AddSlider(
    -left   => 20,
    -top    => 100,
    -height => 30,
    -width  => 370,
    -name   => "ThreadsSlider",
);
$Global{Threads_Slider}->Min($Global{Min_Threads});
$Global{Threads_Slider}->Max($Global{Max_Threads});
$Global{Threads_Slider}->Pos(int($Global{Allowed_Threads}));

$Global{EngineSelThreadsLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Threads:",
       -name    => "EngineSelThreadsLabel",
       -left    => 20,
       -top     => 143,
       -width   => 50,
       -height  => 16,
		-tabstop    => 0,
      );

$Global{EngineSelThreads} = $Global{Setup_Page1}->AddLabel(
       -text    => $Global{Allowed_Threads},
       -name    => "EngineSelThreads",
       -left    => 80,
       -top     => 140,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
		-sunken => 1,
      );

#========================================================
#========================================================
=CutHere
$Global{FreeRAMLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Free RAM:",
       -name    => "FreeRAMLabel",
       -left    => 20,
       -top     => 170,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
      );

$Global{FreeRAM} = $Global{Setup_Page1}->AddLabel(
       -text    => "",
       -name    => "FreeRAM",
       -left    => 80,
       -top     => 170,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
		-sunken => 1,
      );

$Global{FreeRAMMBLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "MB",
       -name    => "FreeRAMMBLabel",
       -left    => 145,
       -top     => 170,
       -width   => 20,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
      );

$Global{TotalRAMLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Total RAM:",
       -name    => "TotalRAMLabel",
       -left    => 200,
       -top     => 170,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
      );
$Global{TotalRAM} = $Global{Setup_Page1}->AddLabel(
       -text    => "",
       -name    => "TotalRAM",
       -left    => 275,
       -top     => 170,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
		-sunken => 1,
      );
$Global{TotalRAMMBLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "MB",
       -name    => "TotalRAMMBLabel",
       -left    => 340,
       -top     => 170,
       -width   => 20,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
      );
#------------
$Global{ReqRAMLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Required RAM:",
       -name    => "ReqRAMLabel",
       -left    => 200,
       -top     => 140,
       -width   => 90,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
      );
$Global{RequiredRAM} = $Global{Setup_Page1}->AddLabel(
       -text    => "",
       -name    => "RequiredRAM",
       -left    => 275,
       -top     => 140,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
		-sunken => 1,
      );
$Global{ReqRAMMBLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "MB",
       -name    => "ReqRAMMBLabel",
       -left    => 340,
       -top     => 140,
       -width   => 20,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
      );
=cut
#========================================================
#========================================================
&ThreadsSlider_Scroll;
#-----------------------Connections per thread---------------------------------------
$Global{EngineConnectionsLabel} = $Global{Setup_Page1}->AddButton(
       -text    => "Multiplex",
       -name    => "EngineConnectionsLabel",
       -left    => 10,
       -top     => 210,
       -width   => $Global{Setup_Page1}->ScaleWidth-20,
       -height  => 145,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{EngineConnectionsHlpLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Please select the number of parallel connections per thread. Each thread will connect with that number of sites in parallel at the same time. Parallel connections performs the maximum speed with less system and connection resources and time.",
       -name    => "EngineConnectionsHlpLabel",
       -left    => 20,
       -top     => 230,
       -width   => $Global{Setup_Page1}->ScaleWidth-40,
       -height  => 70,
		-tabstop    => 0,
      );

$Global{Connections_Slider} = $Global{Setup_Page1}->AddSlider(
    -left   => 20,
    -top    => 290,
    -height => 30,
    -width  => 370,
    -name   => "ConnectionsSlider",
);
$Global{Connections_Slider}->Min($Global{Min_Connections});
$Global{Connections_Slider}->Max($Global{Max_Connections});
$Global{Connections_Slider}->Pos(int($Global{ConnectionsPerThread}));

$Global{ConnectionsPerThreadLabel} = $Global{Setup_Page1}->AddLabel(
       -text    => "Connections Per Thread:",
       -name    => "ConnectionsPerThreadLabel",
       -left    => 20,
       -top     => 330,
       -width   => 130,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
      );
$Global{ConnectsPerThread} = $Global{Setup_Page1}->AddLabel(
       -text    => $Global{ConnectionsPerThread},
       -name    => "ConnectsPerThread",
       -left    => 150,
       -top     => 330,
       -width   => 60,
       -height  => 16,
		-tabstop    => 0,
		-noprefix => 1,
		-sunken => 1,
      );
&ConnectionsSlider_Scroll;	

$Global{EngineOKButton} = $Global{Setup_Page1}->AddButton(
       -text    => "   OK   ",
       -name    => "EngineOKButton",
       -left    => 170,
       -top     => 360,
       -width   => 60,
       -height  => 20,
		-tabstop    => 1,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{EngineCancelButton} = $Global{Setup_Page1}->AddButton(
       -text    => " Cancel ",
       -name    => "EngineCancelButton",
       -left    => 240,
       -top     => 360,
       -width   => 60,
       -height  => 20,
		-tabstop    => 1,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );

}
#==========================================================
sub SetupWindow_Resize {
 $Global{Setup_Tab}->Move (5, 5);
 $Global{Setup_Tab}->Resize( $Global{SetupWindow}->ScaleWidth - 10,  $Global{SetupWindow}->ScaleHeight - 10);
}
#==========================================================
sub SetupWindow_Terminate{

	$Global{SetupWindowActive} = 0;
	$Global{SetupWindow}->Hide();
	$Global{MainWindow}->Enable();
	$Global{MainWindow}->BringWindowToTop();
	$Global{MainWindow}->SetFocus();
	return 0; # so that $ModalWindow is not destroyed
}
#==========================================================
sub SetupCloseButton_Click{
	&SetupWindow_Terminate;
}
#==========================================================
#sub Button2_Click {
# $Global{Setup_Tab}->Reset();
#}
#==========================================================
sub SetupWindow_Deactivate {
	$Global{MainWindow}->InvalidateRect(1);
}
#==========================================================
sub SetupWindow_Activate {
	$Global{MainWindow}->SetFocus();
	$Global{SetupWindow}->SetFocus();
	$Global{MainWindow}->InvalidateRect(1);
}
#==========================================================
1;