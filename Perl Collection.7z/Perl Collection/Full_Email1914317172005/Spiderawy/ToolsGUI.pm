#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Tools_Window{

 $Global{ToolsWindow} = new GUI::Window( #DialogBox
 #-parent => $Global{MainWindow}.
	#-class => $Global{MainClass},
    -name     => "ToolsWindow",
    -title    => "Spiderawy Tools",
    -left     => 1, 
    -top      => 1, 
    -width    => 700, 
    -height   => 500,
    -addstyle    => WS_TABSTOP, # |  COLOR_BTNTEXT|COLOR_BACKGROUND| COLOR_GRAYTEXT|COLOR_MENU|COLOR_SCROLLBAR|COLOR_WINDOW,
	-maximizebox => 0,
 	-minimizebox =>0,
 	-helpbutton => 0,
 	-resizable =>01,
	-visible=> 0,
	#-dialogui => 1,
	#-topmost => 1,
	#-toolwindow => 1,
	#-vscroll => 1,               
	#-events => {Terminate => sub { print "Dying\n"; return -1 } },
	#-addexstyle => WS_EX_TOOLWINDOW ,
	#Terminate => sub { return -1 },
#	-menubox => 0,

	);
	#-----------------------------------------------------
#my $IL = new Win32::GUI::ImageList(16, 16, 8, 3, 10);
#my $IMG_ONE   = $IL->Add("one.bmp");
#my $IMG_TWO   = $IL->Add("two.bmp");
#my $IMG_THREE = $IL->Add("three.bmp");

&CenterOnScreen($Global{ToolsWindow});

 $Global{Tools_Tab} = $Global{ToolsWindow}->AddTabFrame (
    -name   => "Tools_Tab",
    -panel  => "Tools",
	-hottrack => 1,
	#-imagelist => $IL,
);

my $TBorder = 0; # 0..5
 $Global{Tools_Tab}->InsertItem(
    -text   => "   Extract  ",
    -paneltext => "Extract From Local Files",
    -border => $TBorder,
);

=cuts
 $Global{Tools_Tab}->InsertItem(
    -text   => "   Export  ",
    -paneltext => "Export Emails and URLs from Spiderawy Task",
    -border => $TBorder,
);
=cut
$Global{Extractor_Window} = $Global{Tools_Tab}->Tools0;
#$Global{Export_Window} = $Global{Tools_Tab}->Tools1;

# $Global{Tools_Tab}->InsertItem(
#    -text   => "     Search     ",
#    -paneltext => "Search Local Directories",
#    -border => $TBorder,
#);
#$Global{Tools_Page2} = $Global{Tools_Tab}->Page1;

&ToolsWindow_Resize ();

$Global{ExtractorLabel} = $Global{Extractor_Window}->AddButton(
       -text    => "",
       -name    => "ExtractorLabel",
       -left    => 10,
       -top     => 5,
		-width  => $Global{Extractor_Window}->ScaleWidth-20,
		-height => $Global{Extractor_Window}->ScaleHeight-10,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
#		-pushexstyle => 0x00000020,
    -addexstyle  => WS_TABSTOP,
      );

$Global{ExtractorHelpLabel} = $Global{Extractor_Window}->AddLabel(
       -text    => "Extract emails and URLs from any text or binary files on your local computer.",
       -name    => "ExtractorHelpLabel",
       -left    => 30,
       -top     => 20,
       -width   => 500,
       -height  => 25,
       -foreground    => 0,
		-visible=> 1,
      );

$Global{BinaryCheckBox} = $Global{Extractor_Window}->AddCheckbox(
       -text    => "Binary Files",
       -name    => "BinaryCheckBox",
       -left    => $Global{Extractor_Window}->ScaleWidth-120,
       -top     => 20,
       -width   => 80,
       -height  => 18,
		-tabstop    => 1,
		-tip => "Extract emails and links from binary files",
		-visible=> 1,
      );

$Global{ExtractorSelectFilesLabel} = $Global{Extractor_Window}->AddButton(
       -text    => "Please select files",
       -name    => "ExtractorSelectFilesLabel",
       -left    => 30,
       -top     => 45,
       -width   => $Global{Extractor_Window}->ScaleWidth-60,
       -height  => 130,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{ExtractorFilesList} = $Global{Extractor_Window}->AddListbox(
       -text    => "",
       -name    => "ExtractorFilesList",
       -left    => 50,
       -top     => 70,
       -width   => $Global{Extractor_Window}->ScaleWidth-170,
       -height  => 100,
		-multisel => 2,
		-addstyle     => WS_CHILD | WS_VSCROLL|WS_HSCROLL| 1,
		-visible=> 1,
		-tabstop    => 1,
      );

$Global{ExtractorFilesButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Add Files",
       -name    => "ExtractorFilesButton",
       -left    => $Global{Extractor_Window}->ScaleWidth-110,
       -top     => 80,
       -width   => 70,
       -height  => 22,
       -foreground    => 0,
		-tabstop => 1,
		-visible=> 1,
		-tabstop    => 1,
		-tip=>"Open files",
      );

$Global{ExtractorRemoveButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Remove",
       -name    => "ExtractorRemoveButton",
       -left    => $Global{Extractor_Window}->ScaleWidth-110,
       -top     => 110,
       -width   => 70,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip=>"Remove selected files",
      );

$Global{ExtractorFilesClearAll} = $Global{Extractor_Window}->AddButton(
       -text    => "Clear All",
       -name    => "ExtractorFilesClearAll",
       -left    => $Global{Extractor_Window}->ScaleWidth-110,
       -top     => 140,
       -width   => 70,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip=>"Remove all files",
      );
#=======================================================
$Global{ExtractorSaveAsLabel} = $Global{Extractor_Window}->AddButton(
       -text    => "Emails Output File",
       -name    => "ExtractorSaveAsLabel",
       -left    => 30,
       -top     => 190,
       -width   =>$Global{Extractor_Window}->ScaleWidth-60,
       -height  => 55,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{ExtractorSaveAsFile} = $Global{Extractor_Window}->AddTextfield(
		-text    => "",
		-name    => "ExtractorSaveAsFile",
		-left    => 50,
		-top     => 210,
		-width   => $Global{Extractor_Window}->ScaleWidth-170,
		-height  => 25,
		-multiline => 1,
		-visible=> 1,
		-tabstop    => 1,
	  #  -addexstyle    => WS_TABSTOP,
      );

$Global{ExtractorSaveAsButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Save As",
       -name    => "ExtractorSaveAsButton",
       -left    => $Global{Extractor_Window}->ScaleWidth-110,
       -top     => 210,
       -width   => 70,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip=>"Save As",
      );
#=======================================================
$Global{ExtractorURLSaveAsLabel} = $Global{Extractor_Window}->AddButton(
       -text    => "URL Output File",
       -name    => "ExtractorURLSaveAsLabel",
       -left    => 30,
       -top     => 260,
       -width   =>$Global{Extractor_Window}->ScaleWidth-60,
       -height  => 55,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{ExtractorURLSaveAsFile} = $Global{Extractor_Window}->AddTextfield(
		-text    => "",
		-name    => "ExtractorURLSaveAsFile",
		-left    => 50,
		-top     => 280,
		-width   => $Global{Extractor_Window}->ScaleWidth-170,
		-height  => 25,
		-multiline => 1,
		-visible=> 1,
		-tabstop    => 1,
	  #  -addexstyle    => WS_TABSTOP,
      );

$Global{ExtractorURLSaveAsButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Save As",
       -name    => "ExtractorURLSaveAsButton",
       -left    => $Global{Extractor_Window}->ScaleWidth-110,
       -top     => 280,
       -width   => 70,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
		-tip=>"Save As",
      );
#=======================================================
$Global{ExtractorEmailsLabel} = $Global{Extractor_Window}->AddLabel(
       -text    => "Emails:",
       -name    => "ExtractorEmailsLabel",
       -left    => 150,
       -top     => 330,
       -width   => 40,
       -height  => 18,
       -foreground    => 0,
		-visible=> 1,
      );

$Global{ExtractorEmailsCount} = $Global{Extractor_Window}->AddLabel(
       -text    => "",
       -name    => "ExtractorEmailsCount",
       -left    => 190,
       -top     => 330,
       -width   => 100,
       -height  => 18,
		-sunken   => 1, 
		-visible=> 1,
      );
#=======================================================
$Global{ExtractorURLsLabel} = $Global{Extractor_Window}->AddLabel(
       -text    => "URLs:",
       -name    => "ExtractorURLsLabel",
       -left    => 340,
       -top     => 330,
       -width   => 40,
       -height  => 18,
       -foreground    => 0,
		-visible=> 1,
      );

$Global{ExtractorURLsCount} = $Global{Extractor_Window}->AddLabel(
       -text    => "",
       -name    => "ExtractorURLsCount",
       -left    => 375,
       -top     => 330,
       -width   => 100,
       -height  => 18,
		-sunken   => 1, 
		-visible=> 1,
      );
#=======================================================
$Global{ExtractorProgBarLabel} = $Global{Extractor_Window}->AddLabel(
       -text    => "Ready:",
       -name    => "ExtractorProgBarLabel",
       -left    => 30,
       -top     => 360,
       -width   => 55,
       -height  => 16,
       -foreground    => 0,
		-visible=> 1,
      );

$Global{ExtractorProgBar} = $Global{Extractor_Window}->AddProgressBar(
		-name   => "ExtractorProgBar",
		-left   => 90,
		-top    => 360,
		-width  => 450,
		-height => 18,
		-smooth => 1,
		-visible=> 1,
		);
 
$Global{ExtractorProgBar}->SetPos(0);
#--------------------------------------------------------------------
$Global{ExtractorStartButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Start",
       -name    => "ExtractorStartButton",
       -left    => 280,
       -top     => 400,
       -width   => 50,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
      );

=cuts
$Global{ExtractorStopButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Stop",
       -name    => "ExtractorStopButton",
       -left    => 330,
       -top     => 400,
       -width   => 50,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
      );
$Global{ExtractorStopButton}->Disable();
=cut

$Global{ExtractorCloseButton} = $Global{Extractor_Window}->AddButton(
       -text    => "Close",
       -name    => "ExtractorCloseButton",
#       -left    => 380,
       -left    => 330,
       -top     => 400,
       -width   => 50,
       -height  => 22,
       -foreground    => 0,
		-visible=> 1,
		-tabstop    => 1,
      );

}
#==========================================================
sub ToolsWindow_Resize {
 $Global{Tools_Tab}->Move (5, 5);
 $Global{Tools_Tab}->Resize($Global{ToolsWindow}->ScaleWidth - 10,  $Global{ToolsWindow}->ScaleHeight - 10);
}
#==========================================================
sub ToolsWindow_Terminate {

	$Global{ToolsWindowActive} = 0;
	$Global{ToolsWindow}->Hide();
	$Global{MainWindow}->Enable();
	$Global{MainWindow}->BringWindowToTop();
	$Global{MainWindow}->SetFocus();
	return 0; # so that $ModalWindow is not destroyed
}
#==========================================================
sub ExtractorCloseButton_Click{
	&ToolsWindow_Terminate;
}
#==========================================================
#sub Button2_Click {
# $Global{Tools_Tab}->Reset();
#}
#==========================================================
sub ToolsWindow_Deactivate {
#&ToolsWindow_Terminate;
	$Global{MainWindow}->InvalidateRect(1);
}
#==========================================================
sub ToolsWindow_Activate {

	$Global{MainWindow}->SetFocus();
	$Global{ToolsWindow}->SetFocus();
	$Global{MainWindow}->InvalidateRect(1);
}
#==========================================================

1;