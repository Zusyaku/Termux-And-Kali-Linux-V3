#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
use Win32::GUI;
# Ensure that the common control DLL is loaded. 
#    InitCommonControls(); 
#========================================================
sub WM_USER (){0x0400;} # 0x0400 = 1024
#========================================================
sub TBCDRF_NOEDGES							{0x00010000;}  # Don't draw button edges
sub TBCDRF_HILITEHOTTRACK			{0x00020000;} # Use color of the button bk when hottracked
sub TBCDRF_NOOFFSET							{0x00040000;}  # Don't offset button if pressed
sub TBCDRF_NOMARK								{0x00080000;}  # Don't draw default highlight of image/text for TBSTATE_MARKED
sub TBCDRF_NOETCHEDEFFECT			{0x00100000;} # Don't draw etched effect for disabled items
#========================================================
sub TB_ENABLEBUTTON							{(&WM_USER + 1);}
sub TB_EnableButton{
my ($Handle, $Button, $State) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_ENABLEBUTTON, $Button, $State);
}
#========================================================
sub TB_CHECKBUTTON							{(&WM_USER + 2);}
sub TB_CheckButton{
my ($Handle, $Button, $State) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_CHECKBUTTON, $Button, $State);
}
#========================================================
sub TB_PRESSBUTTON								{(&WM_USER + 3);}
sub TB_PressButton{
my ($Handle, $Button, $State) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_PRESSBUTTON, $Button, $State);
}
#========================================================
sub TB_HIDEBUTTON								{(&WM_USER + 4);}
sub TB_HideButton{
my ($Handle, $Button, $State) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_HIDEBUTTON, $Button, $State);
}
#========================================================
sub TB_INDETERMINATE						{(&WM_USER + 5);}
sub TB_Indeterminate{
my ($Handle, $Button, $State) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_INDETERMINATE, $Button, $State);
}
#========================================================
sub TB_MARKBUTTON								{(&WM_USER + 6);}
sub TB_MarkButton{
my ($Handle, $Button, $State) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_MARKBUTTON, $Button, $State);
}
#========================================================
sub TB_DELETEBUTTON         {(&WM_USER + 22)}
sub TB_DeleteButton{
my ($Handle, $Button) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_DELETEBUTTON, $Button, 0);
}
#========================================================
sub TB_ISBUTTONENABLED					{(&WM_USER + 9);}
sub TB_ISBUTTONCHECKED					{(&WM_USER + 10);}
sub TB_ISBUTTONPRESSED					{(&WM_USER + 11);}
sub TB_ISBUTTONHIDDEN						{(&WM_USER + 12);}
sub TB_ISBUTTONINDETERMINATE	{(&WM_USER + 13);}
sub TB_ISBUTTONHIGHLIGHTED			{(&WM_USER + 14);}
sub TB_SETSTATE										{(&WM_USER + 17);}
sub TB_GETSTATE										{(&WM_USER + 18);}
#========================================================
#--------------------- Toolbar button states constants---------------------------------------
sub TBSTATE_CHECKED         {0x01;}
sub TBSTATE_PRESSED         {0x02}
sub TBSTATE_ENABLED         {0x04}
sub TBSTATE_HIDDEN          {0x08}
sub TBSTATE_INDETERMINATE   {0x10}
sub TBSTATE_WRAP           { 0x20}
sub TBSTATE_ELLIPSES        {0x40}
sub TBSTATE_MARKED          {0x80}

sub TB_Wrap           {&TB_SetState(@_, &TBSTATE_WRAP);}
sub TB_Ellipses           {&TB_SetState(@_, &TBSTATE_ELLIPSES);}
sub TB_Marked           {&TB_SetState(@_, &TBSTATE_MARKED);}

sub TB_ISButtonEnabled      {&TB_SetState(@_, &TB_ENABLEBUTTON);}
sub TB_ISButtonChecked      {&TB_SetState(@_, &TB_ENABLEBUTTON);}
sub TB_ISButtonPressed      {&TB_SetState(@_, &TB_ENABLEBUTTON);}
sub TB_ISButtonHidden       {&TB_SetState(@_, &TB_ENABLEBUTTON);}
sub TB_ISButtonIndeterminate {&TB_SetState(@_, &TB_ENABLEBUTTON);}
sub TB_ISButtonHighlighted  {&TB_SetState(@_, &TB_ENABLEBUTTON);}

sub TB_SetState{
my ($Handle, $Button, $State) = @_;
	
	$Handle or return undef;
	$Button ||=0;
	$State ||= 1;
	
	return Win32::GUI::SendMessage($Handle, &TB_SETSTATE, $Button, $State);
}
#========================================================
#--------------------- Toolbar styles---------------------------------------------------
sub TBSTYLE_TOOLTIPS        {0x0100}
sub TBSTYLE_WRAPABLE        {0x0200}
sub TBSTYLE_ALTDRAG         {0x0400}
sub TBSTYLE_FLAT            {0x0800}
sub TBSTYLE_LIST            {0x1000}
sub TBSTYLE_CUSTOMERASE     {0x2000}
sub TBSTYLE_REGISTERDROP    {0x4000}
sub TBSTYLE_TRANSPARENT     {0x8000}
sub TBSTYLE_EX_DRAWDDARROWS {0x00000001}

sub TB_SETSTYLE             {(&WM_USER + 56);}
sub TB_GETSTYLE             {(&WM_USER + 57);}

sub ToolbarSetStyle{
my ($Handle, $Style) = @_;

	$Handle or return undef;
	$Style ||= 0;
	
	#return Win32::GUI::SendMessage($Handle, &TB_SETSTYLE, 0, $Style | 1);
	return Win32::GUI::SendMessage($Handle, &TB_SETSTYLE, 0, $Style | &TBGetStyle);
}
#========================================================
sub TBGetStyle{
my ($Handle) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_GETSTYLE, 0, 0);
}
#========================================================
#--------------------- Toolbar button styles---------------------------------------------------
sub TBSTYLE_BUTTON          {0x0000}
sub TBSTYLE_SEP             {0x0001}
sub TBSTYLE_CHECK           {0x0002}
sub TBSTYLE_GROUP           {0x0004}
sub TBSTYLE_CHECKGROUP      {(&TBSTYLE_GROUP | &TBSTYLE_CHECK);}
sub TBSTYLE_DROPDOWN        {0x0008}
sub TBSTYLE_AUTOSIZE        {0x0010} # automatically calculate the cx of the button
sub TBSTYLE_NOPREFIX        {0x0020} # if this button should not have accel prefix

#========================================================
#&ToolbarSetStyle($TB, 0x1000|0x0800);
#&ToolbarSetStyle($TB, &TBSTYLE_FLAT|&TBSTYLE_ALTDRAG);

#sub TBstyle_Transparent{&TBSetStyle(@_, &TBSTYLE_TRANSPARENT);}
#========================================================
#&TBstyle_Transparent($TB, 2);
sub TB_GETINSERTMARK        {(&WM_USER + 79)} 
sub TB_SETINSERTMARK        {(&WM_USER + 80)} 
sub TB_INSERTMARKHITTEST    {(&WM_USER + 81)}
sub TB_MOVEBUTTON           {(&WM_USER + 82);}
sub TB_GETMAXSIZE           {(&WM_USER + 83)}
sub TB_SETEXTENDEDSTYLE     {(&WM_USER + 84)}
sub TB_GETEXTENDEDSTYLE     {(&WM_USER + 85)}
sub TB_GETPADDING           {(&WM_USER + 86)}
sub TB_SETPADDING           {(&WM_USER + 87)}
sub TB_SETINSERTMARKCOLOR   {(&WM_USER + 88)}
sub TB_GETINSERTMARKCOLOR   {(&WM_USER + 89)}

sub TB_MoveButton{
my ($Handle, $OldButton, $NewButton) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_MOVEBUTTON, $OldButton, $NewButton);
}
#========================================================
#&TB_MoveButton ($TB, 01, 5);
#&TBSetStyle($TB, &TBSTYLE_SEP);
#&TBSetStyle($TB, 3, &TBSTYLE_SEP);
#$Style = &TBGetStyle($TB);
#print "Style =", hex $Style, "\n";
#========================================================
sub TB_SETHOTIMAGELIST      {(&WM_USER + 52)}
sub TB_SetHotImageList{
my ($Handle, $himlNewHot) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_SETHOTIMAGELIST, 0, $himlNewHot);
}
#========================================================
#$ImageList = 
#&TB_SetHotImageList($TB, 0, $B);
#========================================================
sub TB_SETIMAGELIST         {(&WM_USER + 48)}
sub TB_SetImageList{
my ($Handle, $himlNew) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_SETIMAGELIST, 0, $himlNew);
}
#========================================================
sub TB_GETIMAGELIST         {(&WM_USER + 49)}
sub TB_GetImageList{
my ($Handle) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_GETIMAGELIST, 0, 0);
}
#========================================================
sub TB_SETDISABLEDIMAGELIST {(&WM_USER + 54)}
sub TB_SetDisabledImageList{
my ($Handle, $himlNewDisabled) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_SETDISABLEDIMAGELIST, 0, $himlNewDisabled);
}
#========================================================
sub TB_GETDISABLEDIMAGELIST {(&WM_USER + 55)}
sub TB_GetDisabledImageList{
my ($Handle) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_GETDISABLEDIMAGELIST, 0, 0);
}
#========================================================
sub TB_CHANGEBITMAP         {(&WM_USER + 43)}
sub TB_ChangeBitmap {
my ($Handle, $Button, $Bitmap) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_CHANGEBITMAP, $Button, $Bitmap);
}
#========================================================
# takes object  new Win32::GUI::Tooltip(PARENT, %OPTIONS) 
sub TB_SETTOOLTIPS          {(&WM_USER + 36)}
sub TB_SetToolTips {
my ($Handle, $hwndToolTip) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TB_SETTOOLTIPS, $hwndToolTip, 0);
}
#========================================================
sub TB_SETPADDING           {(&WM_USER + 87)}
sub TB_SetPadding{
my ($Handle, $X, $Y) = @_;
	$Handle or return undef;
	my $Padding = Win32::GUI::SendMessage($Handle, &TB_SETPADDING,  0, (($Y *65536) & 0xFFFF0000) | $X);
	return ($Padding & 0xFFFF,  ($Padding & 0xFFFF0000)>>16);
}
#========================================================
#====================================================================
#Set the ListView Background Color
sub LVM_FIRST               (){0x1000} #   ListView messages
sub LVM_SETBKCOLOR (){(&LVM_FIRST + 1)}
sub LV_SetBkColor{
my ($Handle, $Color) = @_;
	$Handle or return undef;
	defined $Color or return;
	return Win32::GUI::SendMessage($Handle, &LVM_SETBKCOLOR, 0, $Color);
}
#====================================================================
# Common control shared messages
sub CCM_FIRST               (){0x2000}
sub CCM_SETBKCOLOR          (){(&CCM_FIRST + 1)}
sub CCM_SetBkColor{
my ($Handle, $Color) = @_;
	$Handle or return undef;
	defined $Color or return;
	return Win32::GUI::SendMessage($Handle, &CCM_SETBKCOLOR, 0, $Color);
}
#====================================================================

#($X, $Y) = &TB_SetPadding($TB, 1, 9);print "TB Padding  ($X, $Y) \n";
#($X, $Y) = &TB_SetPadding($TB, 5, 6);print "TB Padding  ($X, $Y) \n";

#&TB_ChangeBitmap($TB, 1, 2);
#TBSTATE_CHECKED  The button has the TBSTYLE_CHECK style and is being clicked. 
#TBSTATE_ELLIPSES  Version 4.70. The button's text is cut off and an ellipsis is displayed. 
#TBSTATE_ENABLED  The button accepts user input. A button that doesn't have this state is grayed. 
#TBSTATE_HIDDEN  The button is not visible and cannot receive user input. 
#TBSTATE_INDETERMINATE  The button is grayed. 
#TBSTATE_MARKED  Version 4.71. The button is marked. The interpretation of a marked item is dependent upon the application.  
#TBSTATE_PRESSED  The button is being clicked. 
#TBSTATE_WRAP  The button is followed by a line break. The button must also have the TBSTATE_ENABLED state. 

#TBSTYLE_AUTOSIZE  Version 4.71. The button's width will be calculated based on the text of the button, not on the size of the image.  
#TBSTYLE_BUTTON  Creates a standard push button.  
#TBSTYLE_CHECK  Creates a button that toggles between the pressed and nonpressed states each time the user clicks it. The button has a different background color when it is in the pressed state. 
#TBSTYLE_CHECKGROUP  Creates a check button that stays pressed until another button in the group is pressed. 
#TBSTYLE_DROPDOWN  Version 4.70. Creates a drop-down list button. Drop-down buttons send the TBN_DROPDOWN notification. If the toolbar has the TBSTYLE_EX_DRAWDDARROWS extended style, drop-down buttons will have a drop-down arrow displayed next to them.  
#TBSTYLE_GROUP  Creates a button that stays pressed until another button in the group is pressed. 
#TBSTYLE_NOPREFIX  Version 4.71. The button text will not have an accelerator prefix associated with it. 
#TBSTYLE_SEP  Creates a separator, providing a small gap between button groups. A button that has this style does not receive user input.  
#-------------------------------------------------------------
#-------------------------------------------------------------

sub TTM_ACTIVATE            (){(&WM_USER + 1);}
sub Tooltip_Activate {
my ($Handle, $Status) = @_;
	$Handle or return undef;
	return Win32::GUI::SendMessage($Handle, &TTM_ACTIVATE, $Status, 0);
}
#========================================================

1;