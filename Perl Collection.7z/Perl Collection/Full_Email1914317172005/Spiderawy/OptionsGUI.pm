#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Options_Window{

 $Global{OptionsWindow} = new GUI::Window( #DialogBox
#-parent => $Global{MainWindow}.
	#-class => $Global{MainClass},
    -name     => "OptionsWindow",
    -title    => "Spiderawy Options",
    -left     => 1, 
    -top      => 1, 
    -width    => 550, 
    -height   => 480,
    -addstyle    => WS_TABSTOP, # |  COLOR_BTNTEXT|COLOR_BACKGROUND| COLOR_GRAYTEXT|COLOR_MENU|COLOR_SCROLLBAR|COLOR_WINDOW,
	-maximizebox => 0,
 	-minimizebox =>0,
 	-helpbutton => 0,
 	-resizable =>01,
	-visible=> 0,
	#-dialogui => 1,
	#-topmost => 1,
	#-toolwindow => 1,
	#-vscroll => 1,               
	#-addexstyle => WS_EX_TOOLWINDOW ,
#	-menubox => 0,
	);
	#-----------------------------------------------------
#my $IL = new Win32::GUI::ImageList(16, 16, 8, 3, 10);
#my $IMG_ONE   = $IL->Add("one.bmp");
#my $IMG_TWO   = $IL->Add("two.bmp");
#my $IMG_THREE = $IL->Add("three.bmp");

&CenterOnScreen($Global{OptionsWindow});

 $Global{Options_Tab} = $Global{OptionsWindow}->AddTabFrame (
    -name   => "Options_Tab",
    -panel  => "Options",
	-hottrack => 1,
	#-imagelist => $IL,
);

my $TBorder = 0; # 0..5
 $Global{Options_Tab}->InsertItem(
    -text   => " URL Filtering ",
    -paneltext => "",
    -border => $TBorder,
);
=cuts
 $Global{Options_Tab}->InsertItem(
    -text   => " Email Filtering ",
    -paneltext => "",
    -border => $TBorder,
);
$Global{Options_Page2} = $Global{Options_Tab}->Options1;
=cut

$Global{URLFilteringWin} = $Global{Options_Tab}->Options0;

&OptionsWindow_Resize ();
#------------------------------------------------------------------------------------------
$Global{URLFilteringLabel} = $Global{URLFilteringWin}->AddButton(
       -text    => "",
       -name    => "URLFiltering",
       -left    => 10,
       -top     => 10,
       -width   => $Global{URLFilteringWin}->ScaleWidth-20,
       -height  => $Global{URLFilteringWin}->ScaleHeight-45,
		-addstyle  => WS_CHILD | 7,  # GroupBox
		#-sunken => 0,
		-visible=> 1,
		-tabstop    => 0,
      );

$Global{URLFilteringMustHaveCheckBox} = $Global{URLFilteringWin}->AddCheckbox(
       -text    => "Must HAVE any of the following keywords within the URL.",
       -name    => "URLFilteringMustHaveCheckBox",
       -left    => 20,
       -top     => 30,
       -width   => 400,
       -height  => 15,
		-tabstop    => 1,
		-tip => "",
		-visible=> 1,
      );
$Global{URLFilteringMustHaveCheckBox}->SetCheck($Global{URLFilteringMustHave});

$Global{URLFilteringMustLabel} = $Global{URLFilteringWin}->AddLabel(
       -text    => "Please enter one keyword or term per line.",
       -name    => "URLFilteringMustLabel",
       -left    => 20,
       -top     => 50,
       -width   => 400,
       -height  => 15,
		-tabstop    => 0,
      );

$Global{URLFilteringMustHaveTerms} = $Global{URLFilteringWin}->AddTextfield(
		#-text    => "http://www.mewsoft.com/Contact/\r\nhttp://www.mewsoft.com/\r\nhttp://www.mewsoft.com/Support/",
		-text    => "",
		-name    => "URLFilteringMustHaveTerms",
       -left    =>20,
       -top     => 70,
       -width   => $Global{URLFilteringWin}->ScaleWidth() - (100),
       -height  => 120,
		-align => 'left',
		-multiline => 1,
		-tabstop    => 0,
		-autohscroll => 1,
		-autovscroll => 1,
		-vscroll   => 1,
		-hscroll   => 1,
#		-dialogui =>1,
		#-style   => WS_CHILD | WS_VSCROLL |WS_HSCROLL | ES_MULTILINE | ES_WANTRETURN,
		-visible=> 1,
		-addstyle   => ES_WANTRETURN,
		#-foreground    => $Global{TragetURLsFColor},
		#-background => $Global{TragetURLsBFColor},
		-tip=> "Enter the keyword(s) that URLs must have.",
      );
# maximum allowed is 32k for a single-line Textfield and 64k for a multiline one.
$Global{URLFilteringMustHaveTerms}->MaxLength(0); # 0: Set to the maximum limit

$Global{URLFilteringMustHaveOpenButton} = $Global{URLFilteringWin}->AddButton(
       -text    => " Open ",
       -name    => "URLFilteringMustHaveOpenButton",
       -left    => $Global{URLFilteringWin}->ScaleWidth() - 70,
       -top     => 80,
       -width   => 50,
       -height  => 25,
		-tabstop    => 1,
		-tip => "Load Keywords From Text File",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{URLFilteringMustHaveSaveButton} = $Global{URLFilteringWin}->AddButton(
       -text    => " Save ",
       -name    => "URLFilteringMustHaveSaveButton",
       -left    => $Global{URLFilteringWin}->ScaleWidth() - 70,
       -top     => 110,
       -width   => 50,
       -height  => 25,
		-tabstop    => 1,
		-tip => "Save Keywords To Text File",
		#-bitmap=>$Global{OpenFileImage},
      );
#------------------------------------------------------------------------------------------
$Global{URLFilteringMustNotHaveCheckBox} = $Global{URLFilteringWin}->AddCheckbox(
       -text    => "Must NOT Have any of the following keywords within the URL",
       -name    => "URLFilteringMustNotHaveCheckBox",
       -left    => 20,
       -top     => 210,
       -width   => 400,
       -height  => 15,
		-tabstop    => 1,
		-tip => "",
		-visible=> 1,
      );
$Global{URLFilteringMustNotHaveCheckBox}->SetCheck($Global{URLFilteringMustNotHave});

$Global{URLFilteringMustLabel} = $Global{URLFilteringWin}->AddLabel(
       -text    => "Please enter one keyword or term per line.",
       -name    => "URLFilteringMustLabel",
       -left    => 20,
       -top     => 235,
       -width   => 400,
       -height  => 15,
		-tabstop    => 0,
      );

$Global{URLFilteringMustNotHaveTerms} = $Global{URLFilteringWin}->AddTextfield(
		#-text    => "http://www.mewsoft.com/Contact/\r\nhttp://www.mewsoft.com/\r\nhttp://www.mewsoft.com/Support/",
		-text    => "",
		-name    => "URLFilteringMustNotHaveTerms",
       -left    =>20,
       -top     => 250,
       -width   => $Global{URLFilteringWin}->ScaleWidth() - 100,
       -height  => 120,
		-align => 'left',
		-multiline => 1,
		-tabstop    => 0,
		-autohscroll => 1,
		-autovscroll => 1,
		-vscroll   => 1,
		-hscroll   => 1,
#		-dialogui =>1,
		#-style   => WS_CHILD | WS_VSCROLL |WS_HSCROLL | ES_MULTILINE | ES_WANTRETURN,
		-visible=> 1,
		-addstyle   => ES_WANTRETURN,
		#-foreground    => $Global{TragetURLsFColor},
		#-background => $Global{TragetURLsBFColor},
		-tip=> "Enter the keyword(s) that URLs must NOT have.",
      );
# maximum allowed is 32k for a single-line Textfield and 64k for a multiline one.
$Global{URLFilteringMustNotHaveTerms}->MaxLength(0); # 0: Set to the maximum limit

$Global{URLFilteringMustNotHaveOpenButton} = $Global{URLFilteringWin}->AddButton(
       -text    => " Open ",
       -name    => "URLFilteringMustNotHaveOpenButton",
       -left    => $Global{URLFilteringWin}->ScaleWidth() - 70,
       -top     => 260,
       -width   => 50,
       -height  => 25,
		-tabstop    => 1,
		-tip => "Load Keywords From Text File",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{URLFilteringMustNotHaveSaveButton} = $Global{URLFilteringWin}->AddButton(
       -text    => " Save ",
       -name    => "URLFilteringMustNotHaveSaveButton",
       -left    => $Global{URLFilteringWin}->ScaleWidth() - 70,
       -top     => 290,
       -width   => 50,
       -height  => 25,
		-tabstop    => 1,
		-tip => "Save Keywords To Text File",
		#-bitmap=>$Global{OpenFileImage},
      );
#------------------------------------------------------------------------------------------
$Global{URLFilteringOKButton} = $Global{URLFilteringWin}->AddButton(
       -text    => "   OK   ",
       -name    => "URLFilteringOKButton",
       -left    => 195,
       -top     => 390,
       -width   => 60,
       -height  => 20,
		-tabstop    => 1,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );

$Global{URLFilteringCancelButton} = $Global{URLFilteringWin}->AddButton(
       -text    => " Cancel ",
       -name    => "URLFilteringCancelButton",
       -left    => 265,
       -top     => 390,
       -width   => 60,
       -height  => 20,
		-tabstop    => 1,
		-tip => "",
		#-bitmap=>$Global{OpenFileImage},
      );

}
#==========================================================
#==========================================================
sub OptionsWindow_Resize {
 $Global{Options_Tab}->Move (5, 5);
 $Global{Options_Tab}->Resize( $Global{OptionsWindow}->ScaleWidth - 10,  $Global{OptionsWindow}->ScaleHeight - 10);
}
#==========================================================
sub OptionsWindow_Terminate{

	$Global{OptionsWindowActive} = 0;
	$Global{OptionsWindow}->Hide();
	$Global{MainWindow}->Enable();
	$Global{MainWindow}->BringWindowToTop();
	$Global{MainWindow}->SetFocus();
	return 0; # so that $ModalWindow is not destroyed
}
#==========================================================
sub URLFilteringCancelButton_Click{
	&OptionsWindow_Terminate;
}
#==========================================================
#sub Button2_Click {
# $Global{Setup_Tab}->Reset();
#}
#==========================================================
sub OptionsWindow_Deactivate {
	$Global{MainWindow}->InvalidateRect(1);
}
#==========================================================
sub OptionsWindow_Activate {
	$Global{MainWindow}->SetFocus();
	$Global{OptionsWindow}->SetFocus();
	$Global{MainWindow}->InvalidateRect(1);
}
#==========================================================
1;