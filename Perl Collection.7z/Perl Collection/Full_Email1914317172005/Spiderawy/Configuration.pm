#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Load_Configuration{
my ($K, $V, $Temp);	

	$Registry->Delimiter("/");
    my $HKLM = $Registry->Connect("", "HKEY_LOCAL_MACHINE", {Access=>KEY_ALL_ACCESS}) or return 0;
	$Registry->DualTypes(0);
    $HKLM->SplitMultis(1);
	
	my $Software = $HKLM->{"SOFTWARE/"};

	my $ProgKey = $HKLM->{"SOFTWARE/Mewsoft/Spiderawy/$Global{Product_License_Version}/"};
	if (!$ProgKey) {
			&Make_Configuration($Software);
	}

	my $SetupKey = $ProgKey->{"Setup/"};
	if (!($SetupKey)) {
			&Make_Configuration($Software);
	}

	foreach $K (keys %{$SetupKey}) {
			$V = $SetupKey->{$K};
			$K =~ s/^\///g;
			$Global{$K} = $V;
			#print "Setup: ($K=$V)\n";
    }
	
	#---------------------------------------------------------------------------------
	# Convert back the numberic values from string values
	$Global{Color_Them} = int($Global{Color_Them});
	$Global{Allowed_Threads} = int ($Global{Allowed_Threads});
	$Global{ConnectionsPerThread} = int($Global{ConnectionsPerThread});
	$Global{URLsViewSize} = int ($Global{URLsViewSize});
	$Global{EmailsViewSize} = int ($Global{EmailsViewSize});
	$Global{Connection_Timeout} = int ($Global{Connection_Timeout});
	$Global{Use_Proxy} = int ($Global{Use_Proxy});
	$Global{Use_Proxy_Authen} = int ($Global{Use_Proxy_Authen});
	$Global{AutoSave_Time} = int ($Global{AutoSave_Time});
	$Global{Main_Width} = int ($Global{Main_Width});
	$Global{Main_Height} = int ($Global{Main_Height});
	#---------------------------------------------------------------------------------

	my $LicenseKey = $ProgKey->{"License/"};
	if (!($LicenseKey)) {
			&Make_Configuration($Software);
	}

	$Temp = &Validate_License($LicenseKey->{Key});
}
#==========================================================
sub Make_Configuration{
my ($Software) = shift;

	my $MewsoftKey = $Software->{"Mewsoft/"} = {
		"Spiderawy/" => {
				"$Global{Product_License_Version}/" => {
									"Setup/" => {
															"/Color_Them" => $Global{Color_Them},
															"/Allowed_Threads" => $Global{Allowed_Threads},
															"/ConnectionsPerThread" => $Global{ConnectionsPerThread},
															"/URLsViewSize" => $Global{URLsViewSize},
															"/EmailsViewSize" => $Global{EmailsViewSize},
															"/Connection_Port" => $Global{Connection_Port},
															"/Connection_Timeout" => $Global{Connection_Timeout},
															"/Use_Proxy" => $Global{Use_Proxy},
															"/Proxy_Address" => $Global{Proxy_Address},
															"/Proxy_Username" => $Global{Proxy_Username},
															"/Proxy_Password" => $Global{Proxy_Password},
															"/Use_Proxy_Authen" => $Global{Use_Proxy_Authen},
															"/Proxy_URL" => $Global{Proxy_URL},
															"/AutoSave_Time" => $Global{AutoSave_Time},
															"/Main_Width" => $Global{Main_Width},
															"/Main_Height" => $Global{Main_Height},
															},
									"License/" =>{
															"/Key" => unpack ("h*", ""),
															},
									}
				}
	};

}
#==========================================================
sub Update_Config{
my (%Config) = @_;
my ($K, $V);

	$Registry->Delimiter("/");
    my $HKLM = $Registry->Connect("", "HKEY_LOCAL_MACHINE", {Access=>KEY_ALL_ACCESS}) or return 0;
	$Registry->DualTypes(0);
    $HKLM->SplitMultis(1);
	
	my $SetupKey = $HKLM->{"SOFTWARE/Mewsoft/Spiderawy/$Global{Product_License_Version}/Setup/"};
	while (($K, $V) = each %Config) {
			$SetupKey->{"/$K"} = $V;
	}

	$Registry->Flush();
}
#==========================================================

1;