#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Init_Program{
#my $resource = Win32::GUI::LoadResource("some.file") || do {open(FILE,"<some.file");binmode(FILE);join('',<FILE>)};
	
	undef %Global;
	undef %ThreadPtr;
	undef %OpenFileOptions;
	undef %SaveFileOptions;

	undef %SpiderLocations;
	undef %SpiderLevels;
	undef %SpiderEmails;
	undef %SpiderLinks;
	undef %SpiderStatus;

	undef %DomainRestrict;
	undef %FilterMustURL;
	undef %FilterMustNotURL;

	undef @Content_type;
	undef @Default_Content_type;
	#--------------------------------------------------
	$Global{About_Window} = undef;

	$Global{Screen_Width}  = Win32::GUI::GetSystemMetrics(0);
	$Global{Screen_Height} = Win32::GUI::GetSystemMetrics(1);
	#--------------------------------------------------
	$Global{Prog_Name} = join ("", qw(S p i d e r a w y));
	$Global{Color_Them} = 0;

	$Global{Prog_Dir} = Win32::GetCwd();
	$Global{Data_Dir} = $Global{Prog_Dir}.'\Data';
	$Global{Task_Dir} = $Global{Prog_Dir}.'\Task';
	$Global{List_Dir} = $Global{Prog_Dir}.'\List';

	undef $OutputFileHandle;
	#----------------------------------------------------------------
	$Global{Required_Thread_RAM} = 10; # RAM per thread in MB
	#----------------------------------------------------------------
	$Global{TotalEmailsCount} = 0;
	$Global{TotalLinksCount} = 0;
	$Global{TotalRawLinksCount} = 0;

	$Global{SpiderJob_Runing} = 0; # 1 if spider job is runing
	$Global{SpiderJobPause} = 0; #1 = paused
	$Global{SpiderJobStop} = 0; # 1 = stop verify job now
	
	$Global{SpiderTaskType} = 0; # 0: none, 1: New, 2: Open
	$Global{Current_Spider_Level} = 0;
	
	$Global{Allowed_Threads} = 5;
	$Global{ConnectionsPerThread} = 1;
	$Global{Min_Threads} = 1;
	$Global{Max_Threads} = 100;
	$Global{Min_Connections} = 1;
	$Global{Max_Connections} = 200;

	$Global{ToolsWindowActive} = 0;
	$Global{AboutWindowActive} = 0;
	$Global{SetupWindowActive} = 0;
	$Global{OptionsWindowActive} = 0;

	@Default_Content_type = ('text/plain', 'text/html', 'text/richtext', 'text/tab-separated-values', 'text/x-setext','text/x-pod', 'message/rfc822', 'message/partial', 'message/external-body', 'message/news', 'application/rtf', 'application/msword','application/x-perl');
	@Content_type = @Default_Content_type;
	#----------------------------------------------------------------
	$Global{FeatchingImg0}  = new GUI::Bitmap('Featching0.bmp',0,15, 12);
	$Global{FeatchedImg0}  = new GUI::Bitmap('Featched0.bmp',0,15, 12);
	$Global{ReadyImg0}  = new GUI::Bitmap('Ready0.bmp',0,15, 12);

	$Global{FeatchingImg1}  = new GUI::Bitmap('Featching.bmp',0,15, 12);
	$Global{FeatchedImg1}  = new GUI::Bitmap('Featched.bmp',0,15, 12);
	$Global{ReadyImg1}  = new GUI::Bitmap('Ready.bmp',0,15, 12);
	#----------------------------------------------------------------
	$Global{YahooSearch} = 0;
	$Global{DMOZSearch} = 0;
	$Global{MSNSearch} = 0;

	$Global{Yahoo_Page_Size} = 10;
	$Global{Search_Engine} = 0;
	$Global{Search_Engine_Max_Links} = 2000;
	$Global{Search_Engine_Check_Break} = 20;

	$Global{Yahoo_Engine_URL} = qq!http://search.yahoo.com/search?p=[-Terms-]&b=[-Page-]!;
	$Global{Yahoo_Engine_URL_Next} = qq!/nexts/\\*\\-http\\:\\/\\/search\\.yahoo\\.com\\/search\\?p!;
	$Global{Yahoo_Engine_BaseURL} = qq!http\\:\\/\\/search\\.yahoo\\.com\\/search\\?p\\=!;

	#http://search.msn.com/pass/results.aspx?ps=&q=web+design&ck_sc=1&ck_af=0
	#http://search.msn.com/pass/results.aspx?ps=ba%3d13(0.)0..1..0.1.0.%26co%3d15(0.1)3.200.2.5.10.1.3.%26pn%3d1%26rd%3d0%26&q=web+design&ck_sc=1&ck_af=0
	#http://search.msn.com/pass/results.aspx?ps=ba%3d28(0.)0..1..0.2.0.%26co%3d15(0.1)3.200.2.5.10.1.3.%26rd%3d0%26pn%3d2%26&q=web+design&ck_sc=1&ck_af=0
	$Global{MSN_Engine_URL} = qq!http://search.msn.com/pass/results.aspx?ps=&q=[-Terms-]!;
	$Global{MSN_Engine_URL_Next} = qq!http\\:\\/\\/search\\.msn\\.com\\/pass\\/results\\.aspx\\?ps=!;

	$Global{DMOZ_Page_Size} = 20;
	#http://search.dmoz.org/cgi-bin/search?search=web+design
	#http://search.dmoz.org/cgi-bin/search?search=web%20design&utf8=1&locale=ar_eg&start=41
	$Global{DMOZ_Engine_URL} = qq!http://search.dmoz.org/cgi\-bin/search\?search=[-Terms-]&start=[-Page-]!;

	$Global{DMOZ_Engine_URL_Next} = qq!http\:\/\/search.dmoz.org\/cgi\-bin\/search\?search=!;
	$Global{DMOZ_Engine_BaseURL} = qq!http\\:\\/\\/search\\.dmoz\\.org\\/cgi\\-bin\\/search\\?search\\=!;
	#----------------------------------------------------------------
	#$Global{EmailsPageSize} = 1000;
	#$Global{URLsPageSize} = 100;
	
	$Global{URLsViewSize} = 10000; # The URL listview window max items
	$Global{EmailsViewSize} = 10000; # The Emails listview window max items
	#----------------------------------------------------------------
	$Global{Connection_Port} = 80;
	$Global{Connection_Timeout} = 60;
	$Global{Use_Proxy} = 0;
	$Global{Proxy_Address} = "";
	$Global{Proxy_Username} = "";
	$Global{Proxy_Password} = "";
	$Global{Use_Proxy_Authen} = 0;
	$Global{Proxy_URL} = "";
	#----------------------------------------------------------------
	$Global{License_Status} = 0; # 1 = full version enabled, 0 = demo
	$Global{Key_Email} = "mskey";
	#----------------------------------------------------------------
	$Global{Registration_URL} = "http://mewsoft.com/cgi-bin/userregister.cgi";
	$Global{Product_ID} = "Spiderawy 2.0";
	$Global{Product_Name} = "Spiderawy";
	$Global{Product_Version} = "2.0";
	$Global{Product_Email} = "";
	$Global{Product_SerialNumber} = "";
	$Global{Product_FullName} = "";
	$Global{Product_License_Version} = "2.0"; #This version for creation of the registery keys only Mewsoft/Spiderawy/version/keysxxx.
	$Global{License_Pass} = "mspassforlicense";
	#----------------------------------------------------------------
	$Global{Stop_URL_Spidering} = 0;
	$Global{AutoSave_Time} = 2*60*1000; 
	#----------------------------------------------------------------
	$Global{URLFilteringMustHave} = 0;
	$Global{URLFilteringMustNotHave} = 0;
	#----------------------------------------------------------------
	#$status = $db->db_put($key, $value [, $flags])
	#$status = $db->db_get($key, $value [, $flags])
	#$status = $db->db_del($key [, $flags])
	#$status = $db->db_sync()

	%OpenTaskOptions = (
				#-owner => $Global{MainWindow},
				-title => "Open Spiderawy Task",
				-filter =>  ['Spiderawy Task(*.TDB)' => '*.TDB'],
				#-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm'],
				-defaultfilter=>1,
				-directory => $Global{Task_Dir},
				-file => "",
				-multisel=>0,
				-defaultextention=> "TDB",
				-filemustexist => 1,
				-pathmustexist => 1,
			);

	%SaveTaskOptions = (
				#-owner => $Global{MainWindow},
				-title => "New Spiderawy Task",
				#-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.awy)' => '*.txt', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm'],
				-filter =>  ['Spiderawy Task(*.TDB)' => '*.TDB'],
				-defaultfilter=>1,
				-directory => $Global{Task_Dir},
				-file => "",
				-defaultextention=> ".TDB",
				-filemustexist => 1,
				-pathmustexist => 1,
				-overdriveprompt => 0, #Overwrite 0/1
			);

	%ExtractorOpenFileOptions = (
				#-owner => $Global{MainWindow},
				-title => "Open Files",
				-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm', 'Outlook(*.dbx)' => '*.dbx'],
				-defaultfilter=>1,
				#-directory => $Global{Task_Dir},
				-file => "",
				-multisel=>1,
				-defaultextention=> "txt",
				-filemustexist => 1,
				-pathmustexist => 1,
			);
	
	%LoadURLOptions = (
				#-owner => $Global{MainWindow},
				-title => "Load URL List From File",
				-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm'],
				-defaultfilter=>1,
				#-directory => $Global{Task_Dir},
				-file => "",
				-multisel=>1,
				-defaultextention=> "txt",
				-filemustexist => 1,
				-pathmustexist => 1,
			);
	%ExtractorSaveFileOptions = (
				#-owner => $Global{MainWindow},
				-title => "Save Email List As",
				-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm'],
				-defaultfilter=>1,
				#-directory => $Global{Task_Dir},
				-file => "",
				-defaultextention=> "txt",
				-filemustexist => 1,
				-pathmustexist => 1,
				-overdriveprompt => 1, #Overwrite 0/1
			);

	%URLFilteringOpen = (
				#-owner => $Global{MainWindow},
				-title => "Load URL Filtering Keywords From Text File",
				-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm'],
				-defaultfilter=>1,
				#-directory => $Global{Task_Dir},
				-file => "",
				-multisel=>0,
				-defaultextention=> "txt",
				-filemustexist => 1,
				-pathmustexist => 1,
			);
	%URLFilteringSave = (
				#-owner => $Global{MainWindow},
				-title => "Save URL Filtering Keywords To Text File",
				-filter =>  [ 'All files(*.*)' => '*.*', 'Text(*.txt)' => '*.txt', 'HTML(*.html,*.htm,*.asp,*.asa,*.shtml,*.stm)' => '*.html;*.htm;*.asp;*.asa;*.shtml;*.stm'],
				-defaultfilter=>1,
				#-directory => $Global{Task_Dir},
				-file => "",
				-multisel=>0,
				-defaultextention=> "txt",
				-filemustexist => 1,
				-pathmustexist => 1,
			);

}
#==========================================================
1;