#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub UseSearchCheckBox_Click{
	
	if ($Global{UseSearchCheckBox}->Checked() == 1) {
		$Global{TragetURLs}->Disable();
		$Global{UseSearchCombobox}->Enable();
		$Global{UseSearchTermCombobox}->Enable();
	}
	else{
		$Global{TragetURLs}->Enable();
		$Global{UseSearchCombobox}->Disable();
		$Global{UseSearchTermCombobox}->Disable();
	}
}
#==========================================================
sub Get_Time_Now{

	my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst )= localtime(time);

	my $AP = ($hour >= 12) ? 'PM' : 'AM';
	if ($hour > 12) { $hour -= 12; } elsif ($hour == 0) { $hour = 12;}

	$sec = sprintf("%02d", $sec);
	$min = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);

   return "$hour\:$min\:$sec";
}
#==========================================================
sub GetOpenTaskFile{
my ($File, @Files, @Parts, $Filename, $Path);

	$OpenTaskOptions{-owner} = $Global{MainWindow};
	@Files = $Global{MainWindow}->GetOpenFileName(%OpenTaskOptions);
	# for single select $Files[0]=full file path name, for multiple select, $Files[0] = path, $Files[1...x] = files names
	if (!@Files) {return undef;}

	@Parts = split (/[\\|\/]/, $Files[0]);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$OpenTaskOptions{-dir} = $Path;

	$Global{MainWindow}->Update();
	$Global{MainWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
	
	return $Files[0];
}
#==========================================================
sub GetNewTaskFile{
my ($File, @Parts, $Filename, $Path, $Count);

	$SaveTaskOptions{-owner} = $Global{MainWindow};
	$File ="Untitled.TDB";
	$Count = 0;
	while (-e $File && -f $File) {
			$Count++;
			$File = "Untitled". $Count . ".TDB";
	}
	$SaveTaskOptions{-file} = $File;
	$SaveTaskOptions{-overdriveprompt} = 1;
	$SaveTaskOptions{-title} = "New Spiderawy Task";
	
	$File = $Global{MainWindow}->GetSaveFileName(%SaveTaskOptions);
	#print "New task file: 	$File \n";
	if (!$File) {return undef;}

	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$SaveTaskOptions{-dir} = $Path;

	$Global{MainWindow}->Update();
	$Global{MainWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();

	return $File;
}
#==========================================================
sub New_Task{
my ($File, $Count, $Temp);
	
	$File = &GetNewTaskFile;
	if (!$File) {return 0;}

	if ($Global{TaskFilename}) {
			&CloseDB;
	}
	$Global{TaskFilename} = $File;
	#------------------------------------------------------------------------------------
	undef $OutputFileHandle;
	$Global{EmailListView}->Clear;
	$Global{URLsListView}->Clear;
	$Global{EmailsFound}->Text("");
	$Global{URLSFound}->Text("");
	$Global{URLsFinished}->Text("");
	$Global{URLsWaiting}->Text (" ");
	$Global{RuningThreads}->Text("");
	$Global{ConnectionsThreads}->Text("");
	$Global{LastEmailFound}->Text("");
	$Global{LastURLFound}->Text("");
	#$Global{SpiderTimerTxt}->Text("");
	$Global{CurrentLevel}->Text("");
	
	$Temp = $Global{TaskFilename};
	$Global{StatusLabel}->Text(" New Task Ready - [$Temp]");

	$Global{TotalEmailsCount} = 0;
	$Global{TotalLinksCount} = 0;
	$Global{FinishedURLs} = 0;
	$Global{YahooSearch} = 0;
	#----------------------------------------------------------------
	&OpenDB(1, 1); #Overwrite, and load to display to clear counts

	$Global{SpiderTaskType} = 1; # New task
	
	$Global{MainWindow}->Update();
	$Global{MainWindow}->InvalidateRect(1);
	$Global{MainWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();

	$Global{MainWindow}->Caption($Global{Prog_Name} . " - [$File]");

	return 1;
}
#==========================================================
sub Open_Task{
my ($File, @Parts, $Filename, $Path);

	$File = &GetOpenTaskFile;
	if (!$File) {return;}
	if (!-e $File || !-f $File) {return;}

	if ($Global{TaskFilename}) {
			&CloseDB;
	}

	$Global{TaskFilename} = $File;

	&OpenDB(0, 1); # do not overwrite, just open, and load to display
	$Global{SpiderTaskType} = 2; #Opening already exists spider task job
	
	$Global{MainWindow}->Caption($Global{Prog_Name} . " - [$File]");
}
#==========================================================
sub CloseTask{

	if (!$Global{TaskFilename}) {
			return;
	}

	&CloseDB;
	undef $Global{TaskFilename};
	$Global{SpiderTaskType} = 0;
	#------------------------------------------------------------------------------------
	undef $OutputFileHandle;
	$Global{EmailListView}->Clear;
	$Global{URLsListView}->Clear;
	$Global{EmailsFound}->Text("");
	$Global{URLSFound}->Text("");
	$Global{URLsFinished}->Text("");
	$Global{URLsWaiting}->Text (" ");
	$Global{RuningThreads}->Text("");
	$Global{ConnectionsThreads}->Text("");
	$Global{LastEmailFound}->Text("");
	$Global{LastURLFound}->Text("");
	#$Global{SpiderTimerTxt}->Text("");
	$Global{CurrentLevel}->Text("");
	$Global{StatusLabel}->Text(" Ready...");

	$Global{TotalEmailsCount} = 0;
	$Global{TotalLinksCount} = 0;
	$Global{FinishedURLs} = 0;
	$Global{YahooSearch} = 0;
	#----------------------------------------------------------------
	$Global{MainWindow}->Caption($Global{Prog_Name});
}
#==========================================================
sub GetSaveAsTaskFile{
my ($File, @Parts, $Filename, $Path, $FH);

	$SaveTaskOptions{-owner} = $Global{MainWindow};
	$File ="Untitled.TDB";
	$Count = 0;
	while (-e $File && -f $File) {
			$Count++;
			$File = "Untitled". $Count . ".TDB";
	}
	$SaveTaskOptions{-file} = $File;
	$SaveTaskOptions{-overdriveprompt} = 0;
	$SaveTaskOptions{-title} = "Save Spiderawy Task As";
	$File = $Global{MainWindow}->GetSaveFileName(%SaveTaskOptions);
	#print "New task file: 	$File \n";
	if (!$File) {return undef;}

	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$SaveTaskOptions{-dir} = $Path;

	$Global{MainWindow}->Update();
	$Global{MainWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();

	return $File;
}
#==========================================================
sub SaveAsTask{
my ($File, @Parts, $SourceName, $SourcePath, $TargetName, $TargetPath);
my ($SourceFile, $TargetFile);
	
	$File = &GetSaveAsTaskFile;
	#print "\$File=$File\n";
	
	if ($File eq $Global{TaskFilename}) {
			return;
	}

	&CloseDB;

	@Parts = split (/[\\|\/]/, $Global{TaskFilename});
	$SourceFile = pop @Parts;
	($SourceName, $Ext) = split(/\./, $SourceFile);
	$SourcePath = join ('\\', @Parts);
	
	@Parts = split (/[\\|\/]/, $File);
	$TargetFile = pop @Parts;
	($TargetName, $Ext) = split(/\./, $TargetFile);
	$TargetPath = join ('\\', @Parts);

	&CopyFile ("$SourcePath\\$SourceName\.TDB", "$TargetPath\\$TargetName\.TDB");
	&CopyFile ("$SourcePath\\$SourceName\.txt", "$TargetPath\\$TargetName\.txt");
	
	&CopyFile ("$SourcePath\\$SourceName"."1.SDB", "$TargetPath\\$TargetName"."1.SDB");
	&CopyFile ("$SourcePath\\$SourceName"."2.SDB", "$TargetPath\\$TargetName"."2.SDB");
	&CopyFile ("$SourcePath\\$SourceName"."3.SDB", "$TargetPath\\$TargetName"."3.SDB");
	&CopyFile ("$SourcePath\\$SourceName"."4.SDB", "$TargetPath\\$TargetName"."4.SDB");
	&CopyFile ("$SourcePath\\$SourceName"."5.SDB", "$TargetPath\\$TargetName"."5.SDB");
	&CopyFile ("$SourcePath\\$SourceName"."6.SDB", "$TargetPath\\$TargetName"."6.SDB");

	$Global{TaskFilename} = $File;
	&OpenDB(0, 0); # do not overwrite, just open, do not reload display
	$Global{SpiderTaskType} = 2; #Opening already exists spider task job
	
	$Global{MainWindow}->Caption($Global{Prog_Name} . " - [$File]");
}
#==========================================================
sub CopyFile{
my ($Source, $Target) = @_;
my ($Size, $ChunkSize, $BytesRead, $Buf);

	#print "($Source, $Target)\n";	
	$Size = -s $Source;
	open (IN, "<$Source") or return 0;
	open (OUT, ">$Target") or return 0;

	binmode IN;
	binmode OUT;
	$ChunkSize = 8192;

	while ($BytesRead = sysread(IN, $Buf, $ChunkSize)) {
			syswrite (OUT, $Buf, $BytesRead);
	}
	
	close IN;
	close OUT;
	undef $Buf;
}
#==========================================================
sub LoadURLsFileButton_Click{
my ($File, @Parts, $Filename, $Path);

	$LoadURLOptions{-owner} = $Global{MainWindow};
	$File = $Global{MainWindow}->GetOpenFileName(%LoadURLOptions);
	# for single select $Files[0]=full file path name, for multiple select, $Files[0] = path, $Files[1...x] = files names
	if (!$File) {return undef;}

	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$LoadURLOptions{-dir} = $Path;

	$Global{MainWindow}->Update();
	$Global{MainWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
	
	&Load_URL_List($File);
	return $File;
}
#==========================================================
sub LoadURLsWebButton_Click{

}
#==========================================================
sub Load_URL_List{
my ($File) = shift;
my ($Answer, $Count, %Links, $Text, @URLs, @Links, $Link, $List);

	if (!$File) {return;}
	
	if (!open (IN, "<$File")){ 
			$Answer = Win32::GUI::MessageBox(0,"Error reading file $File\r\n$!","Error", MB_ICONERROR | MB_OK,);
			return undef;
			if($Answer == 6) {# yes
			} else {# no
			}
	}
	
	&RuningCursor;
	#---------------------------------------------------------------------------
	$Text = "";
	undef %Links;
	@Links  = split (/\n/, $Global{TragetURLs}->Text());
	foreach $Link(@Links) {
			$Link =~ s/\n//g;
			$Link =~ s/\r//g;
			$Link =~ s/\/$//g;
			$Link =~ s/^\s+|\s+$//;
			if ($Link =~ m/mailto:/i ){next;}
			if ($Link =~ m/\.jpg\b|\.gif\b|\.bmp\b|\.png\b/i){next;}

			if (!$Link) {next;	}
			if ($Links{$Link}) {next;}
			$Links{$Link} = 1;
			$Count++;
			$Text .= "$Link\r\n";
	}
	#---------------------------------------------------------------------------
	undef @URLs;
	$Count = 0;
	foreach $Link(<IN>) {
			$Link =~ s/\n//g;
			$Link =~ s/\r//g;
			$Link =~ s/\/$//g;
			$Link =~ s/^\s+|\s+$//;
			if ($Link =~ m/mailto:/i ){next;}
			if ($Link =~ m/\.jpg\b|\.gif\b|\.bmp\b|\.png\b/i){next;}

			if (!$Link) {next;	}
			if ($Links{$Link}) {next;}
			$Links{$Link} = 1;
			$Count++;
			$Text .= "$Link\r\n";
	}
	close IN;
	$Text =~ s/\r\n$//;
	$Global{TragetURLs}->Text($Text);
	undef $Text;
	undef %Links;

	&NormalCursor;
	$Global{MainWindow}->Update();
	$Global{MainWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
}
#==========================================================
sub CenterOnScreen{
my ($win) = shift;  # gets the object which called the method??
my ($desk, $d_width, $d_height, $x, $y, $w, $h);

	$desk = $win->GetDesktopWindow();
	(undef, undef, $x, $y)= Win32::GUI::GetWindowRect($desk);
	($w)= $win->ScaleWidth();
	($h) = $win->ScaleHeight();
	($w)= $win->Width();
	($h) = $win->Height();
	$delta_w = ($x  /2) - ($w/ 2);
	$delta_h = ($y / 2) - ($h/ 2);
	$win->Move($delta_w, $delta_h);
 }
#==========================================================
1;