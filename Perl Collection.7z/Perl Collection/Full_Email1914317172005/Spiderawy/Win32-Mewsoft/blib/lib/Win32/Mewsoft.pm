package Win32::Mewsoft;

#use 5.008002;
use strict;
use warnings;

require Exporter;       # to export the constants to the main:: space
require DynaLoader;     # to dynuhlode the module.
our @ISA = qw( Exporter DynaLoader );

# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# This allows declaration	use Win32::MemoryStatus ':all';
# If you do not need this, moving things directly into @EXPORT or @EXPORT_OK
# will save memory.
our %EXPORT_TAGS = ( 'all' => [ qw(
	
) ] );

our @EXPORT_OK = ( @{ $EXPORT_TAGS{'all'} } );
our @EXPORT = qw(
	
);

our $VERSION = '0.01';

#require XSLoader;
#XSLoader::load('Win32::MemoryStatus', $VERSION);
# kernel32.dll
bootstrap Win32::Mewsoft;

sub MemoryStatus{
	
	my @Mems = &Win32::Mewsoft::MemStatus();
	my %Meminfo;
	undef %Meminfo;
	#print join "\n=",@Mems;

	if ($Mems[7] == 0) {return undef;} #The size in bytes of the MEMORYSTATUS data structure.

	$Meminfo{MemLoad} = int($Mems[0]);
	$Meminfo{TotalPhys} = $Mems[1];
	$Meminfo{AvailPhys} = $Mems[2];
	$Meminfo{TotalPage} = $Mems[3];
	$Meminfo{AvailPage} = $Mems[4];
	$Meminfo{TotalVirtual} = $Mems[5];
	$Meminfo{AvailVirtual} = $Mems[6];
	return %Meminfo;
}

# Preloaded methods go here.

1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Win32::MemoryStatus - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Win32::MemoryStatus;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Win32::MemoryStatus, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

A. U. Thor, E<lt>a.u.thor@a.galaxy.far.far.awayE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2004 by A. U. Thor

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.2 or,
at your option, any later version of Perl 5 you may have available.


=cut
