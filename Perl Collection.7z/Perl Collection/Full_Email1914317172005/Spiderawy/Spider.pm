#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub AddNewLink{
my ($Level, $Link) = @_;
	#@{$All_SubCategories[$All_SubCategories_Count++]}{qw(Category SubCategory ID Active Accept Count SortNum Under_Flag Description)}=split(/\|/, $Line);
	#@{$SpiderLinks[$Global{TotalLinksCount}]}{qw(S L U)} = ("W", $Level, $Link);
	$Global{TotalLinksCount}++;
	
	$SpiderLocations{$Global{TotalLinksCount}} = $Link;
	$SpiderLinks{$Link} = $Global{TotalLinksCount};

	$SpiderLevels{$Global{TotalLinksCount}} = $Level;
	$SpiderStatus{$Global{TotalLinksCount}} = 1; #Means URL Not Spidered Yet
}
#==========================================================
sub UseSearchCombobox_Change{

	return;

	if ($Global{UseSearchCombobox}->SelectedItem() > 0){
			$Global{TragetURLs}->Disable();
	}		
	else{
			$Global{TragetURLs}->Enable();
	}

}
#==========================================================
sub Stop_Spider_Job_Request{
my ($Answer);

	$Global{SpiderJobStop} = 0;
	#$Global{SpiderPauseButton}->Text("Pause");
	
	$Answer = Win32::GUI::MessageBox(0,"Are You Sure You Want To Stop Current Spider Job?","Stop Spider", MB_ICONQUESTION | MB_YESNOCANCEL|MB_DEFBUTTON3,);
	if($Answer == 6) {# yes
			#$Global{MainWindow}->SpiderTimer->Kill();
			return 1;
	}
	return 0;

}
#==========================================================
sub Pause_Spider_Job_Request{
my ($Stop);

	$Global{MainWindow}->SpiderTimer->Kill();
	$Global{MainWindow}->AutoSave->Kill();

	#&TB_DeleteButton($Global{Main_Toolbar}, 4);
	&TB_HideButton($Global{Main_Toolbar}, 4, 01);
	&TB_HideButton($Global{Main_Toolbar}, 5, 0);
	&TB_EnableButton($Global{Main_Toolbar}, 6, 0);
	#&TB_EnableButton($Global{Main_Toolbar}, 5, 0); # Disable pause button
	#$Global{Main_Toolbar}->AddButtons(1,3, 4, 4, 0, 11); # Start
	$Global{MainMenu}->{PauseJob}->Enabled(0); # Disable Pause job menu item
	$Global{MainMenu}->{StartJob}->Enabled(1); # Enable Start job menu item
	$Global{MainMenu}->{StartJob}->Change( -text => "&Resume				Ctrl+E   "); # Change the menu item "Start" to "Resume"

	$Stop = 0;
	while ($Global{SpiderJobPause}) {
		if ($Global{SpiderJobStop} == 1) {
			$Stop = &Stop_Spider_Job_Request;
				if ($Stop == 1) {last;}
		}
		$Global{MainWindow}->Update();
		Win32::GUI::DoEvents();
	}
	&TB_HideButton($Global{Main_Toolbar}, 5, 1);
	&TB_HideButton($Global{Main_Toolbar}, 4, 0);
	&TB_EnableButton($Global{Main_Toolbar}, 6, 1);
	$Global{MainMenu}->{PauseJob}->Enabled(1); # Enable Pause job menu item
	$Global{MainMenu}->{StartJob}->Enabled(0); # Disable Start job menu item
	$Global{MainMenu}->{StartJob}->Change( -text => "&Start				Ctrl+B   "); # Change the menu item "Resume" to "Start"

	$Global{MainWindow}->SpiderTimer->Interval(1000);
	$Global{MainWindow}->AutoSave->Interval($Global{AutoSave_Time});
	
	return $Stop;
}
#==========================================================
sub ParseTargetEngines{
my ($Engine, $Terms);

	$Global{YahooSearch} = 0;
	$Global{MSNSearch} = 0;
	$Global{DMOZSearch} = 0;

	$Global{Search_Engine} = 0;
	#----------------------------------------------------------------------------------------
	#---------------Get the selected search engine--------------------------------
	if ($Global{UseSearchCombobox}->SelectedItem() > 0){
			$Engine = $Global{UseSearchCombobox}->SelectedItem();
	}		
	else{
			return 0;
	}
	#----------------------------------------------------------------------------------------
	#-------------------Get the search terms-----------------------------------------
	if ($Global{UseSearchTermCombobox}->SelectedItem >= 0) {
			$Terms = $Global{UseSearchTermCombobox}->GetString($Global{UseSearchTermCombobox}->SelectedItem);
	}
	else{
			$Terms = $Global{UseSearchTermCombobox}->Text();
	}
	$Terms =~ s/^\s+//;
	$Terms =~ s/\s+$//;

	if ($Terms) {
			$Global{SearchTerm} = $Terms;
			$Global{UseSearchTermCombobox}->InsertItem($Terms);
	}
	
	$Terms =~ s/\s/\+/g;
	#----------------------------------------------------------------------------------------
	#--------------Prepare the selected search engine start ting url----------
	
	if ($Engine ==1) { # Yahoo
					if (!$Terms) {return 0;}
					$Global{Search_Engine} = $Engine;

					#$Link = $Global{Yahoo_Engine_URL}; #$Terms . '&b=1';
					#$Link =~ s/\[\-Terms\-\]/$Terms/;
					#&AddNewLink($Global{Current_Spider_Level}, $Link);
					$Global{YahooSearch} = 1;
					return 1;
	}
	
	if ($Engine ==2) { # dmoz
					if (!$Terms) {return 0;}
					$Global{Search_Engine} = $Engine;

					$Link = $Global{DMOZ_Engine_URL};
					$Link =~ s/\[\-Terms\-\]/$Terms/;
					&AddNewLink($Global{Current_Spider_Level}, $Link);
					$Global{DMOZSearch} = 1;
					return 1;
	}

	if ($Engine ==3) { # MSN
					if (!$Terms) {return 0;}
					$Link = $Global{MSN_Engine_URL};
					$Link =~ s/\[\-Terms\-\]/$Terms/;
					&AddNewLink($Global{Current_Spider_Level}, $Link);
					$Global{MSNSearch} = 1;
					return 1;
	}

}
#==========================================================
sub SpiderSearchEngine{
my ($Count, $Page, $Link);

	$Count = 0;
	$Global{ConnectionsThreads}->Text(" 1");

	if ($Global{Search_Engine} == 1) { #Yahoo
				while (1) {
						$Page = $Count * $Global{Yahoo_Page_Size};
						if ($Page > $Global{Search_Engine_Max_Links}) {
								last;
						}
						$Link = $Global{Yahoo_Engine_URL}; #$Terms . '&b=1';
						$Link =~ s/\[\-Terms\-\]/$Global{SearchTerm}/;
						$Link =~ s/\[\-Page\-\]/$Page/;
						
						if ($Count && !($Count % $Global{Search_Engine_Check_Break})) {
								if (!&CheckEnginePage($Link)) {
									 last;
								}
						}

						&AddNewLink($Global{Current_Spider_Level}, $Link);
						
						$Temp =$Link;
						$Temp =~ s/\&/\&\&/g;
						$Global{StatusLabel}->Text("[$Count] Building Engine Pages: $Temp");
						$Global{URLSFound}->Text(" $Global{TotalLinksCount}");

						$Count++;
				}

	}
	elsif ($Global{Search_Engine} == 2) { #DMOZ
				while (1) {
						$Page = $Count * $Global{DMOZ_Page_Size};
						if ($Page > $Global{Search_Engine_Max_Links}) {
								last;
						}
						$Link = $Global{DMOZ_Engine_URL}; #$Terms . '&b=1';
						$Link =~ s/\[\-Terms\-\]/$Global{SearchTerm}/;
						$Link =~ s/\[\-Page\-\]/$Page/;
						
						if ($Count && !($Count % $Global{Search_Engine_Check_Break})) {
								if (!&CheckEnginePage($Link)) {
									 last;
								}
						}

						&AddNewLink($Global{Current_Spider_Level}, $Link);
						
						$Temp =$Link;
						$Temp =~ s/\&/\&\&/g;
						$Global{StatusLabel}->Text("[$Count] Building Engine Pages: $Temp");
						$Global{URLSFound}->Text(" $Global{TotalLinksCount}");

						$Count++;
				}

	}


}
#==========================================================
sub CheckEnginePage{
my ($URL) =@_;
my ($Page, @Links);

	if ($Global{Search_Engine} == 1) { #Yahoo
			#my($Domain, $URL, $Form_Param, $M, $Referer) = @_;
			$Page = &Web_Server($URL, "", "", "GET", "");
			@Links = &Extract_Yahoo($Page, $URL);
			if (@Links) {undef @Links; return 1;}
			return 0;
	}
	elsif ($Global{Search_Engine} == 2) { #DMOZ
			#my($Domain, $URL, $Form_Param, $M, $Referer) = @_;
			$Page = &Web_Server($URL, "", "", "GET", "");
			@Links = &Extract_DMOZ($Page, $URL);
			if (@Links) {undef @Links; return 1;}
			return 0;
	}
	
	return 1;
}
#==========================================================
sub ParseTargetURLs{
my (@URL, $Link, $Count);

	@URL = split (/\n/, $Global{TragetURLs}->Text());
	$Count = 0;
	foreach $Link (@URL) {
			$Link =~ s/^s+//;
			$Link =~ s/s+$//;
			$Link =~ s/\n//g;
			$Link =~ s/\r//g;
			if (!$Link) {next;}
			
			if ($Link !~ m/^news:/i && $Link !~ /^(f|ht)tp:\/\/\S+\.\S+/i && $Link !~ /^https?:\/\/\S+\.\S+/i) {
						$Link = "http://". $Link;
			}

			if ($SpiderLinks{$Link}) {next;} #Remove duplicated links

			&AddNewLink($Global{Current_Spider_Level}, $Link);
			$Count ++;
	}
	return $Count;
}
#==========================================================
sub PrepareDomainRestrict{
my (@URL, $Link);
my ($Scheme, $Authority, $Path, $Query, $Fragment);

	$Global{RestrictDomain} = 0;
	if ($Global{RestrictDomainCheckBox}->GetCheck == 0) {return;}
	$Global{RestrictDomain} = 1;

	@URL = split (/\n/, $Global{TragetURLs}->Text());
	foreach $Link (@URL) {
			$Link =~ s/^s+//;
			$Link =~ s/s+$//;
			$Link =~ s/\n//g;
			$Link =~ s/\r//g;
			if (!$Link) {next;}
			if ($Link !~ m/^news:/i && $Link !~ /^(f|ht)tp:\/\/\S+\.\S+/i && $Link !~ /^https?:\/\/\S+\.\S+/i) {
						$Link = "http://". $Link;
			}
			($Scheme, $Authority, $Path, $Query, $Fragment) =  $Link =~ m|(?:([^:/?#]+):)?(?://([^/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?|;
			$DomainRestrict{$Authority} = 1;
			#print "Filter must: $Authority\n"
	}

}
#==========================================================
sub Start_Spider_Job{
my ($Item, @URL, $Link, $Current, $Answer, $Total, $Thread, $Terms, $Temp);
my ($UseEngines);
	
	#------------------------------------------------------------------------------------
	# Make sure we have a task file name and if not get one and open the databse files
	if (!$Global{SpiderTaskType}) { # Open or New
			if (!&New_Task) {
				$Global{SpiderJob_Runing} = 0;
				return 0;
			}
	}
	#------------------------------------------------------------------------------------
	&ParseTargetURLs; # Get the web pages URLs to spider
	$UseEngines = &ParseTargetEngines; # Get the search engines to spiders if any
	#------------------------------------------------------------------------------------
	if ($Global{TotalLinksCount} < 1 && !$UseEngines) {
			$Answer = Win32::GUI::MessageBox(0,"Please enter web site(s) URL to spider \r\nor select search engine and enter a search term","Error", MB_ICONERROR | MB_OK,);
			if($Answer == 6) {# yes
			} else {# no
			}
			$Global{SpiderJob_Runing} = 0;
			return;
	}
	#----------------------------------------------------------------
	&PrepareDomainRestrict;
	#----------------------------------------------------------------
	&TB_EnableButton($Global{Main_Toolbar}, 4, 0); # Disable Start button
	&TB_EnableButton($Global{Main_Toolbar}, 6, 1); # Enable Pause button
	&TB_EnableButton($Global{Main_Toolbar}, 7, 1); # Enable Stop button
	&TB_EnableButton($Global{Main_Toolbar}, 1, 0); # Disable New button
	&TB_EnableButton($Global{Main_Toolbar}, 2, 0); # Disable Open button
	&TB_EnableButton($Global{Main_Toolbar}, 3, 0); # Disable Save button

	$Global{MainMenu}->{StartJob}->Enabled(0); # Disable Start job menu item
	$Global{MainMenu}->{PauseJob}->Enabled(1); # Enable Pause job menu item
	$Global{MainMenu}->{StopJob}->Enabled(1); # Enable Stop job menu item

	$Global{MainMenu}->{NewTask}->Enabled(0); # Disable New menu item
	$Global{MainMenu}->{OpenTask}->Enabled(0); # Disable Open menu item
	$Global{MainMenu}->{CloseTask}->Enabled(0); # Disable Save As menu item
	$Global{MainMenu}->{SaveAsTask}->Enabled(0); # Disable Save As menu item
	#----------------------------------------------------------------
	$Global{EmailsFound}->Text(" $Global{TotalEmailsCount}");
	$Global{URLSFound}->Text(" $Global{TotalLinksCount}");
	$Global{SpiderJob_Runing} = 1;
	#----------------------------------------------------------------
	$Global{StartButton}->Disable();
	$Global{PauseButton}->Enable();
	$Global{StopButton}->Enable();
	#------------------------------------------------------------------
	$Global{Spider_Start_Time} = time;
	$Global{Spider_Time_Spent} = 0;
	
	$Global{TotalRawLinksCount} = $Global{TotalLinksCount};

	$Global{URLSFound}->Text(" $Global{TotalLinksCount} ");

	$Global{MainWindow}->AddTimer("SpiderTimer", 1000);
	$Global{MainWindow}->AddTimer("AutoSave", $Global{AutoSave_Time});
	
#	$Global{VerifyProgressBar}->SetRange(0, 100); #(upto 65535 max)
#	$Global{VerifyProgressBar}->SetPos(0);
#	$Global{VerifyProgressBar}->Show();
#	$Global{VerifyProgBarLabel}->Text("Verifying:");
	&RuningCursor;
	#($w, $h) = Win32::GUI::GetTextExtentPoint32($longest);
	#----------------------------------------------------------------
	if (!$Global{Cookie_Jar}) {
		$Global{Cookie_Jar} = HTTP::Cookies->new(
						{
							-file => "Cookies_Spiderawy.txt",
							-autosave =>1
						}
					);
	}
	$Global{Cookie_Jar}->load(); # Load cookies
	#----------------------------------------------------------------
	&Create_Threads;
	$Temp = &Get_All_Threads_Count;
	$Global{RuningThreads}->Text(" $Temp");
	#----------------------------------------------------------------
	undef $Global{UserAgent};
	if ($UseEngines) {
			&SpiderSearchEngine;
	}
	#----------------------------------------------------------------
	$Current = $Global{FinishedURLs};
	$OldConnections = 0;
	&Shutdown_Threads; # Ignore current runing threads connections
	
	while (1) {
			#----------------------------------------------------------------------------------------------
			# Stop current spider job if requested by user
			if ($Global{SpiderJobStop} == 1) {
					if (&Stop_Spider_Job_Request == 1) {last;}
			}
			#----------------------------------------------------------------------------------------------
			# Pause current spider job if requested by user
			if ($Global{SpiderJobPause}) {
						if (&Pause_Spider_Job_Request == 1) {last;}
			}
			#----------------------------------------------------------------------------------------------
			$Total = $Global{TotalLinksCount};

			if ($Current < $Total) {
				foreach  $Thread(&Get_Ready_Threads) {
						$Current += &Start_New_Thread($Thread, $Current, $Total);
						if ($Current > $Total) {$Current = $Total;}
						if ($Current >= $Total) {last;}
				}
			}

			$Connections = &Get_Threads_Connecting_Count * $Global{ConnectionsPerThread}; #Get_Threads_Runing_Count; #Get_Finished_Threads;
			if ($Connections != $OldConnections) {
				$OldConnections = $Connections;
				$Global{ConnectionsThreads}->Text(" $Connections");
			}

			&Process_Finished_Threads;

			$Global{MainWindow}->Update();
			Win32::GUI::DoEvents();
	}
	#----------------------------------------------------------------
	$Global{Cookie_Jar}->save(); # Save cookies

	#&Process_Finished_Threads;
	&Set_Status_Ready_Images;
	&CloseDB;
	&OpenDB(0, 0); # Do not overwrire, Do not reload
	&Shutdown_Threads; # Ignore current runing threads connections

	$Global{MainWindow}->SpiderTimer->Kill();
	$Global{MainWindow}->AutoSave->Kill();
	$Global{StatusLabel}->Text(" Task Ready...");

	$Global{StartButton}->Enable();
	$Global{PauseButton}->Disable();
	$Global{StopButton}->Disable();
	#print "All threads done....\n";
#	$Global{VerifyProgBarLabel}->Text("Ready:");
#	$Global{VerifyProgressBar}->SetPos(0);
#	$Global{VerifyRemoveButton}->Enable();
	#----------------------------------------------------------------
	&TB_EnableButton($Global{Main_Toolbar}, 4, 1); # Enable Start button
	&TB_EnableButton($Global{Main_Toolbar}, 6, 0); # Disable Pause button
	&TB_EnableButton($Global{Main_Toolbar}, 7, 0); # Disable Stop button
	&TB_EnableButton($Global{Main_Toolbar}, 1, 1); # Disable New button
	&TB_EnableButton($Global{Main_Toolbar}, 2, 1); # Disable Open button
	&TB_EnableButton($Global{Main_Toolbar}, 3, 1); # Disable Save button

	$Global{MainMenu}->{StartJob}->Enabled(1); # Enable Start job menu item
	$Global{MainMenu}->{PauseJob}->Enabled(0); # Disable Pause job menu item
	$Global{MainMenu}->{StopJob}->Enabled(0); # Disable Stop job menu item

	$Global{MainMenu}->{NewTask}->Enabled(1); # Enable New menu item
	$Global{MainMenu}->{OpenTask}->Enabled(1); # Enable Open menu item
	$Global{MainMenu}->{CloseTask}->Enabled(1); # Enable Save As menu item
	$Global{MainMenu}->{SaveAsTask}->Enabled(1); # Enable Save As menu item
	#----------------------------------------------------------------
	&NormalCursor;

	$Global{SpiderJob_Runing} = 0;
	$Global{SpiderTaskType} = 2;
}
#==========================================================
sub CheckEmail{
my ($Email) = @_;

	if (length($Email) < 6) {return undef;}
	$Email =~ s/^[^a-zA-Z0-9]//g; #([^a-zA-Z0-9_\.\@\-])
	$Email =~ s/[^a-zA-Z0-9]$//g; #([^a-zA-Z0-9_\.\@\-])
	$Email =~ s/\.+/\./g;
	$Email =~ s/\_+/\_/g;
	$Email =~ s/^\_+//g;
	$Email =~ s/\_+$//g;
	$Email =~ s/\-+/\-/g;
	$Email =~ s/^\-+//g;
	$Email =~ s/\-+$//g;
	$Email =~ s/^\.+//g;
	$Email =~ s/\.+$//g;
	$Email =~ s/\@+/\@/g;
	$Email =~ s/^[^a-zA-Z0-9]//g; #([^a-zA-Z0-9_\.\@\-])
	$Email =~ s/[^a-zA-Z0-9]$//g; #([^a-zA-Z0-9_\.\@\-])

	if (length($Email) < 6) {return undef;}
	return $Email;
}
#==========================================================
sub CryptEmail{
my ($Email) = @_;
	
	$Key = substr($Global{Key_Email}, 0, length($Email));
	return $Email ^ $Key;
}
#==========================================================
sub DomainRestrict{
my ($URL) = @_;
my ($Key);

	if ($Global{RestrictDomain}) {}
	if (!%DomainRestrict) {return 1;}

	foreach $Key (keys %DomainRestrict) {
		if ($URL =~ m/$Key/i) {
				return 1;
		}
	}

	return 0;
}
#==========================================================
sub URLFilteringMustHave{
my ($URL) = @_;
my ($Key);

	if (!$Global{URLFilteringMustHave}) {return 1;}
	if (!%FilterMustURL) {return 1;}

	foreach $Key (keys %FilterMustURL) {
		if ($URL =~ m/$Key/i) {
				return 1;
		}
	}

	return 0;
}
#==========================================================
sub URLFilteringMustNotHave{
my ($URL) = @_;
my ($Key);

	if (!$Global{URLFilteringMustNotHave}) {return 1;}
	if (!%FilterMustNotURL) {return 1;}

	foreach $Key (keys %FilterMustNotURL) {
		if ($URL =~ m/$Key/i) {
				return 0;
		}
	}

	return 1;
}
#==========================================================
sub Extract_Emails{
my ($Location, $Level, $Text, $BaseURL) = @_;
my ($Found, $Email, $Time, $Temp, $TempEmail);
	
	$Found = $Global{TotalEmailsCount};
	
	while ($Text =~ m|([a-zA-Z0-9._-]+\@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)|isg) {
			$Email = $1;
			$Temp = lc($Email);
			$Email = &CheckEmail($Email);
			if (!$Email) {next;}
			#print "Found email: $Email";
			#-----------------------------------------------------------------------
			if (exists $SpiderEmails{$Temp}) {next;}
			$SpiderEmails{$Temp} = $Location;
			print  $OutputFileHandle "$Email\n";
			$Global{TotalEmailsCount}++;
			$SpiderEmailsID{$Global{TotalEmailsCount}} = $Email;
			#-----------------------------------------------------------------------
			$Global{EmailsFound}->Text(" $Global{TotalEmailsCount} ");
			
			$Item = $Global{EmailListView}->Count();
			if ($Item > $Global{EmailsViewSize}) {
					$Global{EmailListView}->DeleteItem(0);
			}
			$Item = $Global{EmailListView}->Count();

			#-----------------------------------------------------------------------------------------
			$Global{EmailListView}->InsertItem(-item  => $Item, -subitem=>0, -text  => $Location);
			$Global{EmailListView}->ChangeItem(-item  => $Item, -subitem=>1, -text  => $Email);
			$Global{MainWindow}->Update();
			Win32::GUI::DoEvents();
	}

	if ($Found != $Global{TotalEmailsCount}) {
			$Time = &Get_Time_Now;
			$Global{LastEmailFound}->Text(" $Time ");
	}

}
#==========================================================
sub Extract_Links{
my ($Text, $BaseURL, $Level) = @_;
my ($Extor, @Links, $Link, $Item, $Found);
my ($Scheme, $Authority, $Path, $Query, $Fragment);

	#Yahoo : http://rds.yahoo.com/S=2766679/K=mewsoft+auction/v=2/SID=w/l=WS1/R=118/H=0/*-http://www.webeverything.co.uk/directory/187685.html
	$Level++;
	
	#$|=1;print "\$BaseURL=$BaseURL\n";

	#$Global{DMOZ_Engine_BaseURL} = qq!http\\:\\/\\/search\\.dmoz\\.org\\/cgi\\-bin\\/search\\?search\\=!;
	if ($Global{YahooSearch} && ($BaseURL =~ m/^$Global{Yahoo_Engine_BaseURL}/)) {
			@Links = &Extract_Yahoo($Text, $BaseURL);
	}
	elsif ($Global{DMOZSearch} && ($BaseURL =~ m/^$Global{DMOZ_Engine_BaseURL}/)) {
			#print "Matched here, \n$BaseURL,\n$Global{DMOZ_Engine_BaseURL}\n\n";
			@Links = &Extract_DMOZ($Text);
	}
	elsif ($Global{MSNSearch} && ($BaseURL =~ m/$Link/)) {
			@Links = &Extract_MSN($Text);
	}
	else{
			$Extor = HTML::SimpleLinkExtor->new($BaseURL);
			$Extor->parse($Text);
			@Links = $Extor->href;
			push @Links, $Extor->frame;
	}
	#print "Found links: ", join "\n", @Links,"\n";
	#print "\nText: $Text\n";

	$Found = $Global{TotalLinksCount};
	
	foreach $Link(@Links) {
			$Link =~ s/\/$//g;
			$Link =~ s/^\s+|\s+$//;
			if ($Link =~ m/^mailto:/i ){next;}
			if ($Link =~ m/\.jpg\b|\.gif\b|\.bmp\b|\.png\b|\.zip\b|\.tar\b|\.tar\.gz\b|\.gz\b/i){next;}
			
			($Scheme, $Authority, $Path, $Query, $Fragment) =  $Link =~ m|(?:([^:/?#]+):)?(?://([^/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?|;
			
			if ($Fragment) {
						$Link =~ s/\(/\\\(/g;
						$Link =~ s/\)/\\\)/g;
						$Link =~ s/\[/\\\[/g;
						$Link =~ s/\]/\\\]/g;
						$Link =~ s/\$/\\\$/g;
						$Link =~ s/\*/\\\*/g;
						$Fragment =~ s/\(/\\\(/g;
						$Fragment =~ s/\)/\\\)/g;
						$Fragment =~ s/\[/\\\[/g;
						$Fragment =~ s/\]/\\\]/g;
						$Fragment =~ s/\$/\\\$/g;
						$Fragment =~ s/\*/\\\*/g;
						eval {$Link =~ s/\#$Fragment$//;};
						$Link =~ s/\\\(/\(/g;
						$Link =~ s/\\\)/\)/g;
						$Link =~ s/\\\[/\[/g;
						$Link =~ s/\\\]/\]/g;
						$Link =~ s/\\\$/\$/g;
						$Link =~ s/\\\*/\*/g;
			}

			if (!$Link) {next;	}
			if ($Scheme =~ m/^Javascript/i) {next;} #Avoid JS links like Javascript: PopWindow();
			
			if (!&DomainRestrict($Link)) {next;	} # URL must have these filters
			if (!&URLFilteringMustHave($Link)) {next;} # URL must have these filters
			if (!&URLFilteringMustNotHave($Link)) {next;} # URL must have these filters
						
			$Global{TotalRawLinksCount}++;
			
			if ($SpiderLinks{$Link}) {next;}

			&AddNewLink($Level, $Link);
	}
	
	$Global{URLSFound}->Text(" $Global{TotalLinksCount} ");
	$Global{MainWindow}->Update();
	Win32::GUI::DoEvents();

	if ($Found != $Global{TotalLinksCount}) {
			$Time = &Get_Time_Now;
			$Global{LastURLFound}->Text(" $Time ");
	}

}
#==========================================================
sub Extract_DMOZ{
my ($Text) =@_;
my (@Links, $Next, $NextURL);

	# <small><i>-- http://www.skylarkdesign.com/ &nbsp; 
	# <a href="search?search=web%20design&utf8=1&start=21">Next</a> &nbsp;
	undef @Links;
	@Links = $Text =~ m|\<small\>\<i\>\-\-\s([^\s]+)|igs;

=cuts
	if ($Text =~ m/\<a\shref=\"search\?search\=([^\"]+)\"\>Next\<\/a\>/) {
		$Next = $1;
		$NextURL = qq!http://search.dmoz.org/cgi-bin/search\?search=$Next!;
		push @Links, $NextURL;
		#print "\$Next =$Next , $NextURL\n";
	}
=cut

	return @Links;
}
#==========================================================
sub Extract_Yahoo{
my ($Text, $BaseURL) =@_;
my ($Extor, @Link, @Links, $Link, $Next, $NextURL);
	
	$Extor = HTML::SimpleLinkExtor->new($BaseURL);
	$Extor->parse($Text);
	@Link = $Extor->href;
	
	undef @Links;
	foreach $Link (@Link) {
			# Next: http://us.rd.yahoo.com/search/navbar/nexts/*-http://search.yahoo.com/search?p=
			if ($Link !~ m/$Global{Yahoo_Engine_URL_Next}/i) { # Next results page link
					if ($Link =~ m|^(.*)\/H\=0\/\*\-|) {
							#Yahoo : http://rds.yahoo.com/S=2766679/K=mewsoft+auction/v=2/SID=w/l=WS1/R=118/H=0/*-http://www.webeverything.co.uk/directory/187685.html
							$Link =~ s|^(.*)H\=0\/\*\-||;
							push @Links, $Link;
					}
					else{#Avoid yahoo local links
							if ($Link =~ /yahoo\.com/i) {next;}
					}

			}
			else{
					#print "Next URL: $Link\n";
					#push @Links, $Link;
			}
	}

	undef @Link;
	undef $Text;
	return @Links;
}
#==========================================================
sub Create_Threads{
my ($Threads, $Thread_ID, $Temp);

	if ($Global{Allowed_Threads} <= 1) {$Global{Allowed_Threads} = 1;}
	
	$Threads = &Get_All_Threads_Count;

	$Thread_ID = 1;
	while ($Threads < $Global{Allowed_Threads}) {
			
			while (defined $Thread_Status{$Thread_ID}) {$Thread_ID++;}
			
			$Global{StatusLabel}->Text(" Preparing: Creating Thread $Thread_ID");
			$Global{MainWindow}->Update();
			Win32::GUI::DoEvents();
			
			$ThreadPtr{$Thread_ID} = threads->new(\&Spider_Thread, $Thread_ID);
			
			$ThreadPtr{$Thread_ID}->detach();
			
			if ($ThreadPtr{$Thread_ID}) {
					$Thread_Status{$Thread_ID} = 1; #Ready thread.
					$Thread_Result{$Thread_ID} = "";
					$Thread_Param{$Thread_ID} = "";
					$Threads++;
			}
			else{ # Can not create threads. May be not enough memory.
					Win32::GUI::MessageBox(0,"Can not create all threads. $Threads Created. May be your system memory is low\nincrease you system memory or reduce the threads in the program options.","Error", MB_ICONERROR | MB_OK,);
					return;
			}
			#$Global{MainWindow}->Update();
			#Win32::GUI::DoEvents();
	}
	
	$Temp = &Get_All_Threads_Count;
	#my @Temp = threads->list();
	#my $Temp = @Temp;
	#print "Threads = $Temp\n";
	$Global{StatusLabel}->Text(" Preparing: Done Creating Threads ($Temp)");
	$Global{MainWindow}->Update();
	Win32::GUI::DoEvents();
}
#==========================================================
sub Shutdown_Threads{
my ($ID, $V);

	while (($ID, $V) = each %Thread_Status) {
			$Thread_Status{$ID} = 1;
	}
}
#==========================================================
sub Get_Threads_Ready_Count{
my ($Count, $ID, $V);

	$Count = 0;
	while (($ID, $V) = each %Thread_Status) {
			if ($V == 1) {$Count ++;}
	}
	return $Count;
}
#==========================================================
sub Get_Threads_Runing_Count{
my ($Count, $ID, $V);

	$Count = 0;
	while (($ID, $V) = each %Thread_Status) {
			if ($V == 2) {$Count ++;}
	}
	return $Count;
}
#==========================================================
sub Get_Threads_Finished_Count{
my ($Count, $ID, $V);

	$Count = 0;
	while (($ID, $V) = each %Thread_Status) {
			if ($V == 3) {$Count ++;}
	}
	return $Count;
}
#==========================================================
sub Get_Threads_Connecting_Count{
my ($Count, $ID, $V);

	$Count = 0;
	while (($ID, $V) = each %Thread_Status) {
			if ($V == 4) {$Count ++;}
	}
	return $Count;
}
#==========================================================
sub Get_Ready_Threads{
my ($Count, $ID, $V, @Ready);

	$Count = 0; undef @Ready;
	while (($ID, $V) = each %Thread_Status) {
			if ($V == 1) {$Ready[$Count++] = $ID;}
	}
	return @Ready;
}
#==========================================================
sub Get_Finished_Threads{
my ($Count, $ID, $V, @Finished);

	$Count = 0; undef @Finished;
	while (($ID, $V) = each %Thread_Status) {
			if ($V == 3) {$Finished[$Count++] = $ID;}
	}
	return @Finished;
}
#==========================================================
sub Get_All_Threads{
my ($Count, $ID, $V, @Threads);

	$Count = 0; undef @Threads;
	while (($ID, $V) = each %Thread_Status) {
			if ($V ==1 || $V== 2 || $V == 3 || $V == 4) {$Threads[$Count++] = $ID;}
	}
	return @Threads;
}
#==========================================================
sub Get_All_Threads_Count{
my ($Count, $ID, $V);

	#my @Temp = threads->list();
	#my $Temp = @Temp;
	#return $Temp;

	$Count = 0;
	while (($ID, $V) = each %Thread_Status) {
			if ($V ==1 || $V== 2 || $V == 3 || $V == 4) {$Count++;}
	}
	return $Count;
}
#==========================================================
sub SpiderTimer_Timer{
my ($Ticks, $sec, $min, $hour, $mday);

#	my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst )= localtime(time);

	$Ticks = $Global{Spider_Time_Spent}++;
	#$Ticks = abs($Global{Verify_Start_Time} - time);
	
	$secs = int($Ticks % 60);

	$Ticks = int($Ticks / 60); # $Ticks in minutes
	$mins = $Ticks % 60;
	
	$Ticks = int($Ticks / 60); #$Ticks in hours
	$hours = $Ticks % 24; 
	
	$days = int($Ticks / 24);

   $secs = "0$secs" if ($secs < 10);
   $mins = "0$mins" if ($mins < 10);
   $hours = "0$hours" if ($hours < 10);
	
#   $Global{SpiderTimerTxt}->Text(" $hours\:$mins\:$secs ");

}
#==========================================================
sub Process_Finished_Threads{
my ($Thread, $Text, $Item, $BaseURL, $Start, $End, %Item);
my ($Count, $Key, $Current, $Link, $Level, $Temp, $Size);

	foreach $Thread (&Get_Finished_Threads){
			my $ImgKey = "StatusImg".$Thread;
			$Global{$ImgKey}->SetImage($Global{FeatchedImg});

			for $Count(1..$Global{ConnectionsPerThread}) {
					$Key = $Thread . "_". $Count;
					#print "\$LinkStatus{$Key}=$LinkStatus{$Key}\n";
					$Global{FinishedURLs}++;

					if ($LinkStatus{$Key} != 10) {
							$LinkStatus{$Key} = 0;
							next;
					}

					$Current = $LinkNum{$Key};
					$Link = $LinkURL{$Key};
					$Level = $LinkLevel{$Key};
					#$LinkContent{$Key} = "";
					$LinkStatus{$Key} = 0;

					$SpiderStatus{$Current} = 2; # Means this URL is Spidered

					$Temp = $LinkBaseURL{$Key};
					$Temp =~ s/\&/\&\&/g;
					$Global{StatusLabel}->Text(" [$Current]($Level){$Thread} Extracting: $Temp");
					
					$Global{URLsFinished}->Text(" $Global{FinishedURLs}");
					$Global{URLsWaiting}->Text (" ". ($Global{TotalLinksCount} - $Global{FinishedURLs}) );
					$Global{MainWindow}->Update();
					Win32::GUI::DoEvents();
					#-----------------------------------------------------------------------------------------------------
					&Extract_Emails($Current, $Link, $LinkContent{$Key}, $LinkBaseURL{$Key});
					#my ($Text, $BaseURL, $Level)
					#print "Link Base URL: $LinkURL{$Key}, $LinkBaseURL{$Key} \n";
					#print "Text: $LinkContent{$Key}\n\n";
					#-----------------------------------------------------------------------------------------------------
					if (!$Global{Stop_URL_Spidering}) {
						&Extract_Links($LinkContent{$Key}, $LinkBaseURL{$Key}, $Level);
					}
					
					#-----------------------------------------------------------------------------------------------------
					$Size = $Global{URLsListView}->Count();
					$Item = $Size;
					for $Temp (0 .. $Size-1) {
							$Item--;
							%Item = $Global{URLsListView}->GetItem($Item, 0); #GetItem($Row, $Column);
							if ($Item{-text} == $Current) { last;}
					}
					$Global{URLsListView}->ChangeItem(-item=>$Item, -subitem=>3, -text=>"Done");
					#-----------------------------------------------------------------------------------------------------

					$Global{MainWindow}->Update();
					Win32::GUI::DoEvents();

			} # End for $Count(1..$Global{ConnectionsPerThread}) {
			
			$Thread_Result{$Thread} = "";
			$Thread_Param{$Thread} = "";
			$Thread_Status{$Thread} = 1; #This thread is now ready for new call
	}# End foreach $Thread (&Get_Finished_Threads){

}
#==========================================================
#&Start_New_Thread($Thread, $Current, $Count, $Total);
sub Start_New_Thread{
my ($Thread, $Start, $Total) = @_;
my ($Item, $Link, $Level, $End);
my ($Count, $Key);
	#$Percent = int(100*($Count/$Total));
	#$Global{VerifyProgressBar}->SetPos($Percent); 
	
	my $ImgKey = "StatusImg".$Thread;
	$Global{$ImgKey}->SetImage($Global{FeatchingImg});
	#---------------------------------------------------------------------------------------
	$Start++;
	$End = $Start + $Global{ConnectionsPerThread}-1;
	if ($End > $Total) { $End = $Total;}
	$Count = 0;
	for $Current ($Start..$End) {
			if ($Current > $Total) {last;}
			
			$Count++;
			$Key = $Thread . "_". $Count;
			
			$Level = $SpiderLevels{$Current};
			$Link = $SpiderLocations{$Current};

			$LinkNum{$Key} = $Current;
			$LinkURL{$Key} = $Link;
			$LinkLevel{$Key} = $Level;
			$LinkStatus{$Key} = 1;
			undef $LinkContent{$Key};

			$Item = $Global{URLsListView}->Count();
			if ($Item > $Global{URLsViewSize}) {
					$Global{URLsListView}->DeleteItem(0);
			}
			$Item = $Global{URLsListView}->Count();
			$Global{URLsListView}->InsertItem(-item  => $Item, -subitem=>0, -text  => $Current);
			$Global{URLsListView}->ChangeItem(-item=>$Item, -subitem=>1, -text=>$Level);
			$Global{URLsListView}->ChangeItem(-item=>$Item, -subitem=>2, -text=>$Link);
			$Global{URLsListView}->ChangeItem(-item=>$Item, -subitem=>3, -text=>"Fetching", -bold => 1);

			#print "Starting : $Current\|$Item{-text}\n";
			if ($Level != $Global{Current_Spider_Level}) {
					$Global{Current_Spider_Level} = $Level;
					$Global{CurrentLevel}->Text(" $Global{Current_Spider_Level} ");
			}
	}
	
	if ($Count > 0) {
			$Thread_Param{$Thread} = $Count;
			$Thread_Status{$Thread} = 2; #Means this thread is started and runing.
			#print "Starting Thread: $Thread_Param{$Thread}\n" 
	}

	$Global{MainWindow}->Update();
	Win32::GUI::DoEvents();

	return $Count;
}
#==========================================================
#==========================================================
sub Spider_Thread{
my ($Self_ID) = @_;
my ($Current, $URL, $Result, $BaseURL, $Level);
my ($UA, $PUA, $Key, $Count, $Total, %LinkKey);

	$PUA = LWP::Parallel::UserAgent->new();
	$PUA->in_order  (0);  # handle requests in order of registration
	$PUA->duplicates(0);  # ignore duplicates
	$PUA->timeout   ($Global{Connection_Timeout});  # in seconds
	$PUA->redirect  (0);  # follow redirects
	$PUA->nonblock(1);
	$PUA->max_hosts(100);
	$PUA->max_req(100);
	
	$PUA->cookie_jar ($Global{Cookie_Jar});
	
	$UA = new LWP::UserAgent();
	$UA->agent('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)');
	$UA->timeout($Global{Connection_Timeout});
	
	$UA->cookie_jar ($Global{Cookie_Jar});
	#local $SIG{__DIE__} ;

	while (1) { # Loop forever
			if ($Thread_Status{$Self_ID} == 2) {
							$Thread_Status{$Self_ID} = 4;
							$Total = $Thread_Param{$Self_ID};
							$PUA->initialize; # Reuse the same PUA

							for $Count(1..$Total) {
									$Key = $Self_ID . "_". $Count;
									$LinkStatus{$Key} = 2;
									
									$Current = $LinkNum{$Key};
									$Link = $LinkURL{$Key};
									$Level = $LinkLevel{$Key};
									
									#$|=1;print  "Spider_Thread: $Link , Total=$Total\n";

									$URL = &PreProcecssLink($UA, $Link);
									if (!$URL || ($URL eq "")) {
											# Prepare this url as finished
											#$LinkContent{$Key} = "";
											$LinkStatus{$Key} = 10; # Finished, error;
											next;
									}
									$LinkStatus{$Key} = 3;
									$LinkKey{$URL} = $Key;
									$LinkBaseURL{$Key} = $URL;
									
										if (my $Res = $PUA->register (HTTP::Request->new('GET', $URL))) {
												#print $Res->error_as_HTML;
										}

									$LinkStatus{$Key} = 4;
							}

							my $Entries = $PUA->wait(40);

							foreach my $Entry(keys %$Entries){
									#$res->code, $res->message;
									my $Res = $Entries->{$Entry}->response;
									#$|=1;print "Answer was ", $Res->code,": ", $Res->message,"\n";
									my $BaseURL = $Res->request->url->as_string;
									$Key = $LinkKey{$BaseURL};
									#print "\$BaseURL=$BaseURL, Key=$Key\n";
									
									#print "Content:", $Res->content(),"\n\n";
									my $Content = $Res->content();
									$LinkContent{$Key} = $Content;
									$LinkBaseURL{$Key} = $BaseURL;
									$LinkStatus{$Key} = 10;
							}
							
							$Thread_Status{$Self_ID} = 3; #Thread finished this call and results ready to pull.

							threads->yield; 
			}
			else{
							sleep 1;
			}
	}
}
#==========================================================
sub PreProcecssLink{
my ($UA, $URL) = @_;
my ($Head, $Code, $Redirect);
my ($Size, $Content_type, $Type, $URLPath);

	if (!$URL || $URL eq "") {return "";}
	if (!&CheckURL($URL)) {return "";}

	# $ua->proxy(['http', 'ftp'] => 'http://username:password@proxy.myorg.com');

	#$UA = new LWP::UserAgent();
	#$UA->cookie_jar ($Global{Cookie_Jar});
	#$UA->agent('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)');
	#$UA->timeout($Global{Connection_Timeout});

	$Head = $UA->head($URL);
	$Code = $Head->code();
	$Redirect = 0;

	$URLPath = $Head->header('Location');
	$Base = $Head->base;
	$NewURL = $HTTP::URI_CLASS->new($URLPath, $Base)->abs($Base);
	
   #RC_MULTIPLE_CHOICES			(300) , containd in HTTP::Status
   #RC_MOVED_PERMANENTLY			(301)
   #RC_FOUND				(302)
   #RC_SEE_OTHER				(303)
   #RC_NOT_MODIFIED			(304)
   #RC_USE_PROXY				(305)
   #RC_TEMPORARY_REDIRECT		(307)

    while ($Code == 301  or $Code == 302 or $Code == 303 or $Code == 307) {
			#my $UA = new LWP::UserAgent();
			#$UA->agent('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)');
			#$UA->timeout($Global{Connection_Timeout});

			$Head = $UA->head($NewURL);
			$Code = $Head->code();

			$URLPath = $Head->header('Location');
			$Base = $Head->base;
			$NewURL = $HTTP::URI_CLASS->new($URLPath, $Base)->abs($Base);

			$Redirect++;
			if ($Redirect > 20) {last;}
	}	
	
	if ($Head->is_success) {
				#$Size = $Head->content_length;
				$Content_type = $Head->content_type;
				foreach $Type (@Content_type) {
							if ($Content_type eq $Type) {
									if (&CheckURL($NewURL->as_string)) {
											return $NewURL->as_string;
									}
									return "";
							}
				}

	}
	else{
				return "";
	}

}
#==========================================================
sub CheckURL{ 
my ($URL) = shift;

   if ($URL !~ /^news:/i && $URL !~ /^(f|ht)tp:\/\/\S+\.\S+/i && $URL !~ /^https?:\/\/\S+\.\S+/i) { 
				return(0); #Invalid URL
	}
	return(1); 
}
#==========================================================
sub AutoSave_Timer{
	&FlushDB;
}
#==========================================================
1;