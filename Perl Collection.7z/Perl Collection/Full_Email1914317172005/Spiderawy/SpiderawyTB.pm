#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Spiderawy_Toolbar{
my ($B);
=cc
$Global{Main_Rebar} = Win32::GUI::Rebar->new(
     $Global{MainWindow},
     -name   => "MainRebar",
     -pos   => [ 0, 0 ],
     -size  => [ 0, 0 ],
	 -bandborders => 0,
	 -fixedorder => 0,
	 -varheight => 0,
	 #-imagelist => ,
	 sunken=>1,
	 frame=>etched,
 );
=cut

$Global{Main_Toolbar} = $Global{MainWindow}->AddToolbar(
#	$Global{MainWindow}->MainRebar,
	-flat      => 0,
	-multiline => 0,
	-nodivider => 0,
    -left   =>  0,   
    -top    => 0, 
    -width  => $Global{MainWindow}->ScaleWidth-1, 
    -height => 60,
    -name   => "MainToolbar",
	#-addstyle => WS_CHILD |WS_VISIBLE|2048| WS_BORDER,
	-addstyle => WS_CHILD |WS_VISIBLE|0x0800| WS_BORDER | WS_TABSTOP|0x0100,
#	-addstyle => WS_CHILD |WS_VISIBLE|2048| WS_BORDER | WS_TABSTOP,
#		-addstyle =>WS_VISIBLE | DS_3DLOOK|3|DS_SETFOREGROUND|WS_CHILD|LR_COLOR|WS_BORDER,
	#-imagelist => $IM,
	-visible =>01,
		-tooltip=>1,
);

#define TTF_CENTERTIP           0x0002
#define TTF_RTLREADING          0x0004
#define TTF_SUBCLASS            0x0010
#if (_WIN32_IE >= 0x0300)
#define TTF_TRACK               0x0020
#define TTF_ABSOLUTE            0x0080
#define TTF_TRANSPARENT         0x0100
#define TTF_DI_SETITEM          0x8000       // valid only on the TTN_NEEDTEXT callback

$Global{ToolTips} = Win32::GUI::Tooltip->new( 
		-name => 'ToolTips',
		-parent => $Global{MainWindow},
		-flags=>0xff
	);

	#&ToolbarSetStyle($Global{Main_Toolbar}, &TBSTYLE_TOOLTIPS);
	&TB_SetToolTips($Global{Main_Toolbar}, $Global{ToolTips}->{-handle});
	#&Tooltip_Activate($Global{ToolTips}->{-handle}, 1);

#$Global{Main_Toolbar}->Disable();
$Global{Toolbar_Image} = new GUI::Bitmap("Spiderawy.bmp");
#$Global{Toolbar_Image} = new GUI::Bitmap(&Read_File_Binary("Spiderawy.bmp"));
$Global{Main_Toolbar}->SetBitmapSize(45, 35);

#$Global{TB_ImgList} = new Win32::GUI::ImageList(45, 35, 1, 11, 11);
#$Global{TB_ImgList}->Add($Global{Toolbar_Image}, 0);
#&TB_SetImageList($Global{Main_Toolbar}, $Global{TB_ImgList}->{-handle});
#----------------------------------------------------------------------------------------------------------
$Global{Main_Toolbar}->AddBitmap($Global{Toolbar_Image}, 15);
#----------------------------------------------------------------------------------------------------------
$Global{Main_Toolbar}->AddString("New");
$Global{Main_Toolbar}->AddString("Open");
$Global{Main_Toolbar}->AddString("Save");

$Global{Main_Toolbar}->AddString("Start");
$Global{Main_Toolbar}->AddString("Resume");
$Global{Main_Toolbar}->AddString("Pause");
$Global{Main_Toolbar}->AddString("Stop");

$Global{Main_Toolbar}->AddString("Options");
$Global{Main_Toolbar}->AddString("Setup");

$Global{Main_Toolbar}->AddString("Tools");
$Global{Main_Toolbar}->AddString("Color");

$Global{Main_Toolbar}->AddString("Upgrade");

$Global{Main_Toolbar}->AddString("Resume");

#$Global{Main_Toolbar}->AddButtons(1,  0, 0, 0, 0x0001, 0);
$Global{Main_Toolbar}->AddButtons(1, 0, 1, 4, 0, 0);
$Global{Main_Toolbar}->AddButtons(1,1, 2, 4, 0, 1);
$Global{Main_Toolbar}->AddButtons(1,2, 3, 4, 0, 2);
$Global{Main_Toolbar}->AddButtons(1,  0, 0, 0, 0x0001, 0); #Separator

$Global{Main_Toolbar}->AddButtons(1,3, 4, 4, 0, 3); # Start
$Global{Main_Toolbar}->AddButtons(1,4, 5, 4, 0, 4); # Resume
$Global{Main_Toolbar}->AddButtons(1,5, 6, 4, 0, 5); # Pause
$Global{Main_Toolbar}->AddButtons(1,6, 7, 4, 0, 6); # Stop
$Global{Main_Toolbar}->AddButtons(1,  0, 0, 0, 0x0001, 0); #Separator

$Global{Main_Toolbar}->AddButtons(1,7, 8, 4, 0, 7);
$Global{Main_Toolbar}->AddButtons(1,8, 9, 4, 0, 8);
#$Global{Main_Toolbar}->AddButtons(1,  0, 0, 0, 0x0001, 0); #Separator
$Global{Main_Toolbar}->AddButtons(1,9, 10, 4, 0, 9);
$Global{Main_Toolbar}->AddButtons(1, 0, 0, 0, 0x0001, 0); #Separator

$Global{Main_Toolbar}->AddButtons(1,10, 11, 4, 0, 10);
#$Global{Main_Toolbar}->AddButtons(1, 0, 0, 0, 0x0001, 0); #Separator
$Global{Main_Toolbar}->AddButtons(1,11, 12, 4, 0, 11);
#$Global{Main_Toolbar}->AddButtons(1, 0, 0, 0, 0x0001, 0); #Separator
&TB_HideButton($Global{Main_Toolbar}, 5, 1);
#ID_INDICATOR_CAPS|ID_INDICATOR_NUM|ID_INDICATOR_SCRL,

$Global{TB_Disabled_Image} = new GUI::Bitmap("SpiderawyTBDis.bmp");
$Global{Main_Toolbar}->SetBitmapSize(45, 35);

$Global{TB_DisImgList} = new Win32::GUI::ImageList(45, 35, 1, 11, 11);
$Global{TB_DisImgList}->Add($Global{TB_Disabled_Image}, 0);
&TB_SetDisabledImageList($Global{Main_Toolbar}, $Global{TB_DisImgList}->{-handle});

}
#==========================================================

1;