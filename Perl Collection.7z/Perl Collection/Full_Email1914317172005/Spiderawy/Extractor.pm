#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Start_Extractor_Job{
my ($Count, $Index, @Files, @URL, @URLs, $SaveAs_File, $Answer, $Cursor);
my ($Text, $Links, $File, $Line, $Email, %Emails, %Links, $URL);
my ($Extor, $TotalSize, $Loaded, $TempFile);

	#------------------------------------------------------------------------------------
	# Get the input files names to be extracted
	$Count = $Global{ExtractorFilesList}->Count();
	if (!$Count) {
			$Global{Job_Runing} = 0;
			#&ToolsWindow_Terminate;
			return;
	}

	$TotalSize = 0;
	for $Index(0..$Count -1) {
				$File = $Global{ExtractorFilesList}->GetString($Index);
				push @Files, $File;
				$TotalSize += -s $File;
	}

	if (!@Files) {
			$Global{Job_Runing} = 0;
			#&ToolsWindow_Terminate;
			return;
	}
	#------------------------------------------------------------------------------------
	#Create the save as file
	$SaveAs_File = $Global{ExtractorSaveAsFile}->Text();
	$SaveAs_File =~ s/^\s+//;
	$SaveAs_File =~ s/\s+$//;
	$Global{ExtractorSaveAsFile}->Text($SaveAs_File);

	$TempFile = time."\.temp\.txt";
	if (!open (Emails, ">$TempFile")){ 
			$Answer = Win32::GUI::MessageBox(0,"Error creating file $TempFile\r\n$!","Error", MB_ICONERROR | MB_OK,);
			$Global{Job_Runing} = 0;
			#&ToolsWindow_Terminate;
			return;
			if($Answer == 6) {# yes
			} else {# no
			}
	}
	#------------------------------------------------------------------------------------
	$SaveURL = $Global{ExtractorURLSaveAsFile}->Text();
	$SaveURL =~ s/^\s+//;
	$SaveURL =~ s/\s+$//;
	$Global{ExtractorURLSaveAsFile}->Text($SaveURL);
	if ($SaveURL) {
			$TempFileURL = time."\.temp-url\.txt";
			if (!open (Links, ">$TempFileURL")){ 
					$Answer = Win32::GUI::MessageBox(0,"Error creating file $TempFileURL\r\n$!","Error", MB_ICONERROR | MB_OK,);
					$Global{Job_Runing} = 0;
					#&ToolsWindow_Terminate;
					return;
					if($Answer == 6) {# yes
					} else {# no
					}
			}
	}
	#------------------------------------------------------------------------------------
	$Global{ExtractorEmailsCount}->Text(0);
	$Global{ExtractorURLsCount}->Text(0);
	
	$Global{ExtractorFilesButton}->Disable();
	$Global{ExtractorRemoveButton}->Disable();
	$Global{ExtractorFilesClearAll}->Disable();
	$Global{ExtractorSaveAsButton}->Disable();
	$Global{ExtractorURLSaveAsButton}->Disable();
	$Global{ExtractorStartButton}->Disable();
	#$Global{ExtractorStopButton}->Enable();

	&RuningCursor;
	#------------------------------------------------------------------
	$Count = 0; $Links = 0; $Loaded = 0;
	undef %Emails;
	undef %Links;
	$| = 1;
	
	if ($Global{BinaryCheckBox}->GetCheck == 1) {
						$ChunkSize = 8192*8;
						foreach $File (@Files) {
								$Global{ExtractorProgBarLabel}->Text("Extracting:");
								$Global{MainWindow}->Update();
								Win32::GUI::DoEvents();

								if (!open (IN, "<$File") ){ 
										$Answer = Win32::GUI::MessageBox(0,"Error opening file $File\r\n$!","Error", MB_ICONERROR | MB_OK,);
										if($Answer == 6) {# yes
										} else {# no
										}
										next;
								}
								
								binmode IN;
								$BytesRead = sysread(IN, $Buf, $ChunkSize);
								$Offset = "";
								while ($BytesRead) {
											$Text = $Offset . $Buf;
											while ($Text =~ m|([a-zA-Z0-9._-]+\@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)|isg) {
													$Email = $1;
													if (!$Emails{$Email}) {
															$Emails{$Email} = 1; #Removes duplicates automatically
															if (&Check_License) {
																	print Emails "$Email\n";
															}
															$Count++;
															if (!($Count % 10)) {
																	$Global{ExtractorEmailsCount}->Text($Count);
															}
													}
											}
											$Offset = substr($Text, -50);
											$BytesRead = sysread(IN, $Buf, $ChunkSize);

										$Loaded += $BytesRead;
										if (!($Loaded % 1024)) {
													$Percent = int(100*($Loaded/$TotalSize));
													$Global{ExtractorProgBar}->SetPos($Percent);
													$Global{MainWindow}->Update();
													Win32::GUI::DoEvents();
										}
								}#while ($BytesRead) {

								close IN;
						}# foreach $File (@Files) {
	}
	else{ # ASCII mode
						foreach $File (@Files) {
								$Global{ExtractorProgBarLabel}->Text("Extracting:");
								$Global{MainWindow}->Update();
								Win32::GUI::DoEvents();

								if (!open (IN, "<$File") ){ 
										$Answer = Win32::GUI::MessageBox(0,"Error opening file $File\r\n$!","Error", MB_ICONERROR | MB_OK,);
										if($Answer == 6) {# yes
										} else {# no
										}
										next;
								}

								foreach $Line(<IN>){
										while ($Line =~ m|([a-zA-Z0-9._-]+\@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)|isg) {
												$Email = $1;
												if (!$Emails{$Email}) {
														$Emails{$Email} = 1; #Removes duplicates automatically
														if (&Check_License) {
																print Emails "$Email\n";
														}
														$Count++;
														if (!($Count % 10)) {
															$Global{ExtractorEmailsCount}->Text($Count);
														}
												}
										}
										
										$Loaded += length($Line)+1;
										if (!($Loaded % 1024)) {
													$Percent = int(100*($Loaded/$TotalSize));
													$Global{ExtractorProgBar}->SetPos($Percent);
													$Global{MainWindow}->Update();
													Win32::GUI::DoEvents();
										}

								}#foreach $Line(<IN>){
								close IN;
						}# foreach $File (@Files) {
	}
	#------------------------------------------------------------------
	close Emails;
	rename ($TempFile, $SaveAs_File);
	unlink ($TempFile);

	if ($SaveURL) {
			$TempFileURL = time."\.temp-url\.txt";
			close Links;
			rename ($TempFileURL, $SaveURL);
			unlink ($TempFileURL);
	}
	#------------------------------------------------------------------
	$Global{ExtractorEmailsCount}->Text($Count);
	$Global{ExtractorProgBarLabel}->Text("Ready:");
	$Global{ExtractorProgBar}->SetPos(0);
	#------------------------------------------------------------------
	$Global{ExtractorFilesButton}->Enable();
	$Global{ExtractorRemoveButton}->Enable();
	$Global{ExtractorFilesClearAll}->Enable();
	$Global{ExtractorSaveAsButton}->Enable();
	$Global{ExtractorURLSaveAsButton}->Enable();
	$Global{ExtractorStartButton}->Enable();

	&NormalCursor;
}
#==========================================================
sub Get_Time_Now{

	my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst )= localtime(time);

   $sec = "0$sec" if ($sec < 10);
   $min = "0$min" if ($min < 10);
   $hour = "0$hour" if ($hour < 10);
   return "$hour\:$min\:$sec";
}
#==========================================================
sub ExtractorFilesButton_Click{
my ($File, @Files, @Parts, $Filename, $Path);

#	$Global{MainWindow}->Disable();
	$ExtractorOpenFileOptions{-owner} = $Global{ToolsWindow};
	@Files = $Global{MainWindow}->GetOpenFileName(%ExtractorOpenFileOptions);
	if (!@Files) {return;}
	if (@Files > 1) {
			$Path = shift @Files;
			$Path =~ s/\\$//; # only happens in root
			@Files = map {$Path . '\\' . $_} @Files;
			$ExtractorOpenFileOptions{-dir} = $Path;
	}
	elsif (@Files == 1) {
			@Parts = split (/[\\|\/]/, $Files[0]);
			$Filename = pop @Parts;
			$Path = join ('\\', @Parts);
			$ExtractorOpenFileOptions{-dir} = $Path;
	}
		
	foreach $File (@Files) {
			$Global{ExtractorFilesList}->AddString($File) 
	}

	$Global{ToolsWindow}->Update();
	$Global{ToolsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
}
#==========================================================
sub ExtractorRemoveButton_Click{
my (@Files, $File);

	@Files = $Global{ExtractorFilesList}->SelectedItems();

	if ($Global{ExtractorFilesList}->SelectCount() > 0)	{
			foreach $File (reverse sort @Files) {
							$Global{ExtractorFilesList}->RemoveItem($File);
			}
	}
	$Global{MainWindow}->Update();
}
#==========================================================
sub ExtractorFilesClearAll_Click{

	$Global{ExtractorFilesList}->Clear();
	$Global{MainWindow}->Update();
}
#==========================================================
sub ExtractorSaveAsButton_Click{
my ($File, @Parts, $Filename, $Path);

	$ExtractorSaveFileOptions{-owner} = $Global{ToolsWindow};
	$File = $Global{MainWindow}->GetSaveFileName(%ExtractorSaveFileOptions);
	if (!$File) {return;}
	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$ExtractorSaveFileOptions{-dir} = $Path;

	$Global{ExtractorSaveAsFile}->Text($File);

	$Global{ToolsWindow}->Update();
	$Global{ToolsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();

}
#==========================================================
sub ExtractorURLSaveAsButton_Click{
my ($File, @Parts, $Filename, $Path);

	$ExtractorSaveFileOptions{-owner} = $Global{ToolsWindow};
	$File = $Global{MainWindow}->GetSaveFileName(%ExtractorSaveFileOptions);
	if (!$File) {return;}
	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$ExtractorSaveFileOptions{-dir} = $Path;

	$Global{ExtractorURLSaveAsFile}->Text($File);

	$Global{ToolsWindow}->Update();
	$Global{ToolsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();

}
#==========================================================
1;