#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub URLFilteringOKButton_Click{
my (@Terms, $Terms, $Term, $Text);

	undef %FilterMustURL;
	undef %FilterMustNotURL;
	
	@Terms = split (/\n/, $Global{URLFilteringMustHaveTerms}->Text());
	$Terms = "";
	foreach $Term (@Terms) {
			$Term =~ s/^s+//;
			$Term =~ s/s+$//;
			$Term =~ s/\n//g;
			$Term =~ s/\r//g;
			if (!$Term) { next;}
			$FilterMustURL{$Term} = 1;
			$Terms .= "$Term\r\n";
	}
	$Global{URLFilteringMustHaveTerms}->Text($Terms);

	@Terms = split (/\n/, $Global{URLFilteringMustNotHaveTerms}->Text());
	$Terms = "";
	foreach $Term (@Terms) {
			$Term =~ s/^s+//;
			$Term =~ s/s+$//;
			$Term =~ s/\n//g;
			$Term =~ s/\r//g;
			if (!$Term) { next;}
			$FilterMustNotURL{$Term} = 1;
			$Terms .= "$Term\r\n";
	}
	$Global{URLFilteringMustNotHaveTerms}->Text($Terms);
	
	if ($Global{URLFilteringMustHaveCheckBox}->GetCheck == 1) {
			$Global{URLFilteringMustHave} = 1;
	}

	if ($Global{URLFilteringMustNotHaveCheckBox}->GetCheck == 1) {
			$Global{URLFilteringMustNotHave} = 1;
	}
	&OptionsWindow_Terminate;
}
#==========================================================
sub URLFilteringMustHaveOpenButton_Click{
my ($File, @Files, @Parts, $Filename, $Path);
my ($Terms, $Line);

	$URLFilteringOpen{-owner} = $Global{OptionsWindow};
	@Files = $Global{MainWindow}->GetOpenFileName(%URLFilteringOpen);
	# for single select $Files[0]=full file path name, for multiple select, $Files[0] = path, $Files[1...x] = files names
	if (!@Files) {return undef;}

	@Parts = split (/[\\|\/]/, $Files[0]);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$URLFilteringOpen{-dir} = $Path;

	$Global{OptionsWindow}->Update();
	$Global{OptionsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
	
	if (!$Files[0]) {return;}

	open (IN, "$Files[0]");
	$Terms = $Global{URLFilteringMustHaveTerms}->Text();
	while ($Line =<IN>) {
			$Line =~ s/^\s+//;
			$Line =~ s/\s+$//;
			if (!$Line) {next;}
			$Terms .= "$Line\r\n";
	}
	$Global{URLFilteringMustHaveTerms}->Text($Terms);
	$Global{OptionsWindow}->Update();
	Win32::GUI::DoEvents();
}
#==========================================================
sub URLFilteringMustHaveSaveButton_Click{
my ($File, @Parts, $Filename, $Path);
my (@Terms, $Term);

#	$Global{MainWindow}->Disable();
	$URLFilteringSave{-owner} = $Global{OptionsWindow};
	$File = $Global{MainWindow}->GetSaveFileName(%URLFilteringSave);
	if (!$File) {return;}
	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$URLFilteringSave{-dir} = $Path;
	
	open OUT, ">$File";

	@Terms = split (/\n/, $Global{URLFilteringMustHaveTerms}->Text());
	foreach $Term (@Terms) {
			$Term =~ s/^s+//;
			$Term =~ s/s+$//;
			$Term =~ s/\n//g;
			$Term =~ s/\r//g;
			if (!$Term) { next;}
			print OUT "$Term\n";
	}

	close OUT;
	$Global{OptionsWindow}->Update();
	$Global{OptionsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
}
#==========================================================
sub URLFilteringMustNotHaveOpenButton_Click{
my ($File, @Files, @Parts, $Filename, $Path);
my ($Terms, $Line);

	$URLFilteringOpen{-owner} = $Global{OptionsWindow};
	@Files = $Global{MainWindow}->GetOpenFileName(%URLFilteringOpen);
	# for single select $Files[0]=full file path name, for multiple select, $Files[0] = path, $Files[1...x] = files names
	if (!@Files) {return undef;}

	@Parts = split (/[\\|\/]/, $Files[0]);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$URLFilteringOpen{-dir} = $Path;

	$Global{OptionsWindow}->Update();
	$Global{OptionsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
	
	if (!$Files[0]) {return;}

	open (IN, "$Files[0]");
	$Terms = $Global{URLFilteringMustNotHaveTerms}->Text();
	while ($Line =<IN>) {
			$Line =~ s/^\s+//;
			$Line =~ s/\s+$//;
			if (!$Line) {next;}
			$Terms .= "$Line\r\n";
	}
	$Global{URLFilteringMustNotHaveTerms}->Text($Terms);
	$Global{OptionsWindow}->Update();
	Win32::GUI::DoEvents();
}
#==========================================================
sub URLFilteringMustNotHaveSaveButton_Click{
my ($File, @Parts, $Filename, $Path);
my (@Terms, $Term);

#	$Global{MainWindow}->Disable();
	$URLFilteringSave{-owner} = $Global{OptionsWindow};
	$File = $Global{MainWindow}->GetSaveFileName(%URLFilteringSave);
	if (!$File) {return;}
	@Parts = split (/[\\|\/]/, $File);
	$Filename = pop @Parts;
	$Path = join ('\\', @Parts);
	$URLFilteringSave{-dir} = $Path;
	
	open OUT, ">$File";

	@Terms = split (/\n/, $Global{URLFilteringMustNotHaveTerms}->Text());
	foreach $Term (@Terms) {
			$Term =~ s/^s+//;
			$Term =~ s/s+$//;
			$Term =~ s/\n//g;
			$Term =~ s/\r//g;
			if (!$Term) { next;}
			print OUT "$Term\n";
	}

	close OUT;
	$Global{OptionsWindow}->Update();
	$Global{OptionsWindow}->SetForegroundWindow();
	Win32::GUI::DoEvents();
}
#==========================================================
1;