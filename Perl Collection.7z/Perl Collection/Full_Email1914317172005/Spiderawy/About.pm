#!C:\perl\bin\perl.exe
=Copyright Infomation
==========================================================
    Program Name    : Mewsoft Spiderawy
    Program Version : 2.0
    Program Author   : Elsheshtawy, A. A.
    Home Page          : http://www.mewsoft.com
	Copyrights � 2004 Mewsoft Corporation. All rights reserved.
==========================================================
License for Mewsoft Spiderawy

Copyright 2004 by Mewsoft Corporation http://www.mewsoft.com

All Rights Reserved 

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that 
both that copyright notice and this permission notice appear in 
supporting documentation. 

Mewsoft Corporation disclaims all warranties with regard to this 
software, including all implied warranties of merchantability 
and fitness, in no event shall Mewsoft be liable for any 
special, indirect or consequential damages or any damages 
whatsoever resulting from loss of use, data or profits, 
whether in an action of contract, negligence or other 
tortious action, arising out of or in connection with the use 
or performance of this software. 

Elsheshtawy A. A.
support@mewsoft.com
http://www.mewsoft.com

=cut
#==========================================================
sub Help_About_Click{

	if (!$Global{About_Window}) {
			&About_Window;
	}

	$Global{MainWindow}->Disable();

	$Global{About_Window}->Show();
	$Global{AboutLabel1}->Show();
	$Global{AboutLabel2}->Show();
	$Global{AboutLabel03}->Show();
	$Global{AboutLabel3}->Show();
	$Global{AboutSupportLink}->Show();
	$Global{AboutLabel05}->Show();
	$Global{AboutLabel5}->Show();
	$Global{AboutOKButton}->Show();
}
#==========================================================
sub AboutOKButton_Click{

	$Global{About_Window}->Hide();

	$Global{AboutLabel1}->Hide();
	$Global{AboutLabel2}->Hide();
	$Global{AboutLabel03}->Hide();
	$Global{AboutLabel3}->Hide();
	$Global{AboutSupportLink}->Hide();
	$Global{AboutLabel05}->Hide();
	$Global{AboutLabel5}->Hide();
	$Global{AboutOKButton}->Hide();

	$Global{MainWindow}->Enable();
	$Global{MainWindow}->BringWindowToTop();
	return 0; # so that $ModalWindow is not destroyed
}
#==========================================================
sub About_Window{

$Global{About_Window} = Win32::GUI::Window->new(
		-text => "About Spiderawy",
		-name => "MainProgWindow",
		-pos  => [ 200, 200 ],
		-size => [ 300, 200 ],
		-parent => $Global{MainWindow},
		#-addstyle => WS_SIZEBOX|WS_MAXIMIZEBOX |WS_OVERLAPPEDWINDOW|WS_GROUP|WS_DLGFRAME|WS_CHILD,
		#-style =>WS_MAXIMIZEBOX,
		#WS_MINIMIZEBOX (0x00020000) or WS_MAXIMIZEBOX , WS_SYSMENU,WS_POPUP,WS_POPUPWINDOW
		-visible=> 0,
		-menubox => 0,
	);
$Global{About_Window}->{'-dialogui'} = 1; #Enable TabStop with 		-tabstop    => 1,

$Global{AboutLabel1} = $Global{About_Window}->AddLabel(
       -text    => "Spiderawy Version 2.0",
       -name    => "AboutLabel1",
       -left    => 30,
       -top     => 26,
       -width   => 235,
       -height  => 13,
       -foreground    => 0,
		-visible=> 0,
      );

$Global{AboutLabel2} = $Global{About_Window}->AddLabel(
       -text    => "Copyright (c) 2004 Mewsoft Corporation",
       -name    => "AboutLabel2",
       -left    => 30,
       -top     => 50,
       -width   => 221,
       -height  => 15,
       -foreground    => 0,
		-visible=> 0,
      );

$Global{AboutLabel03} = $Global{About_Window}->AddLabel(
       -text    => "E-Business Solutions For Everyone",
       -name    => "AboutLabel3",
       -left    => 30,
       -top     => 70,
       -width   => 236,
       -height  => 20,
       -foreground    => 0,
		-visible=> 0,
      );

$Global{AboutLabel3} = $Global{About_Window}->AddLabel(
       -text    => "Support:",
       -name    => "AboutSupportLabel",
       -left    => 30,
       -top     => 90,
       -width   => 60,
       -height  => 15,
       -foreground    => 0,
		-visible=> 0,
      );

$Global{AboutSupportLink} = $Global{About_Window}->AddLabel(
       -text    => 'support@mewsoft.com',
       -name    => "AboutSupportLink",
       -left    => 90,
       -top     => 90,
       -width   => 200,
       -height  => 15,
       -foreground    => 0,
		-visible=> 0,
	 	-notify 		=> 1,
		-class => $Global{Link_Class},
		-font => $Global{Link_Font},
		-foreground => 0xff0000,
      );

$Global{AboutLabel05} = $Global{About_Window}->AddLabel(
       -text    => "Web Site:",
       -name    => "AboutLabel05",
       -left    => 30,
       -top     => 110,
       -width   => 60,
       -height  => 13,
       -foreground    => 0,
		-visible=> 0,
		#-background => $Global{FieldsBGColor},
		#-foreground => $Global{FieldsForColor},
      );

$Global{AboutLabel5} = $Global{About_Window}->AddLabel(
	 	-notify 		=> 1,
		-class => $Global{Link_Class},
		-font => $Global{Link_Font},
       -text    => 'http://www.mewsoft.com',
       -name    => "AboutHomepage",
       -left    => 90,
       -top     => 110,
       -width   => 200,
       -height  => 13,
       -foreground    => 0,
		-visible=> 0,
		#-background => $Global{FieldsBGColor},
		#-foreground => $Global{FieldsForColor},
		-foreground => 0xff0000,
		-tip => "http://www.mewsoft.com. Click to get the latest version and download other products.",
			-accel => "F1",
      );
#$Global{About_Window}->AboutLabel5->Redraw(0x0001 | 0x0100);

$Global{AboutOKButton} = $Global{About_Window}->AddButton(
       -text    => "OK",
       -name    => "AboutOKButton",
       -left    => 120,
       -top     => 140,
       -width   => 80,
       -height  => 22,
       -foreground    => 0,
		-visible=> 0,
      );

	&CenterOnScreen($Global{About_Window});
}
#==========================================================
1;