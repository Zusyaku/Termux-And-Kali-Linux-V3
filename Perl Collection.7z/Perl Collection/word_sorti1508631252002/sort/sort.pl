#!c:/perl/bin/perl.exe
use CGI;
  my $query = new CGI;
  print $query->header( "text/html" );
my @parama = $query->param;
  my %info;
  foreach (@parama) {
    $info{$_} = $query->param($_);
  }

@data = ($info{'one'}, $info{'two'}, $info{'three'}, $info{'four'}, $info{'five'}, $info{'six'}, $info{'seven'}, $info{'eight'}, $info{'nine'}, $info{'ten'}, $info{'eleven'}, $info{'twelve'}, $info{'thirteen'}, $info{'fourteen'}, $info{'fifteen'}, $info{'sixteen'}, $info{'seventeen'}, $info{'nineteen'}, $info{'twenty'}, $info{'twentyone'}, $info{'twentytwo'}, $info{'twentythree'}, $info{'twentyfour'}, $info{'twentyfive'}, $info{'twentysix'}, $info{'twentyseven'}) ;

my @unsorted = @data ;
print "<p>Unsorted: @unsorted</p>";

my @sorted = sort @unsorted;
print "<p>Sorted:   @sorted</p>";

#jacob bijani