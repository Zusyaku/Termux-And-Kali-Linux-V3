Title: joke submit
Description: Allows visitors of my site to submit a joke with there name and e-mail. then i can put there joke on my joke page, if i want. the code rights the information to an html page that can be viewed with a web brouser. zip file includes a form, the script and the saved file. direction on seting it up for use on your site are in the .pl file.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=570&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
