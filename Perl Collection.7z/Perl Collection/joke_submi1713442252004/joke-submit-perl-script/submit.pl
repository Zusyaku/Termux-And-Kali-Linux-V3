#!/perl/bin/perl
    ##########################################################################################
    #                                                                                        #
    # i use this script with perl 5 on a win xp system                                       #
    #                                                                                        #
    # first edit this line to go to the return link page.                                    #
    # print "<a href='http://www.noma.almostmy.com/jokes.html'>Return to jokes page</a>\n";  #
    # then edit the line in submitjoke.html to the address of this script.                   #
    # make sure that submitjoke.html is in your www. folder and submit.pl and,               #
    # joke.html are in the same directory in you cgi-bin.                                    #
    # to view submited jokes go to your cgi directory and view joke.html with your browser.  #
    #                                                                                        #
    # this code may be used in your own scripts, in whole or in part.                        #
    #                                                                                        #
    # all i ask is please place a link on your page that goes to mine.                       #
    # www.noma.almostmy.com                                                                  #
    # questions or coments may be sent to tknx2000@yahoo.com                                 #
    #                                                                                        #
    # have fun!                                                                              #
    #                                                                                        #
    ##########################################################################################
    use CGI qw(:standard);
    $file = "joke.html";
    $name = param("name");
    $email = param("email");
    $joke = param("joke");
    print header;
    print "<html><head><title>Thank you for submitting!</title></head><body>\n";
    print "Thank you for submitting your joke:<br /><br />\n";
    print "$name<br>$email<br>$joke<br>\n";
    ###########################################################################################
    # edit the line below to address of your returne page.                                    #
    ###########################################################################################
    print "<a href='http://www.noma.almostmy.com/jokes.html'>Return to jokes page</a>\n";
    print "</body></html>\n";
    open (file,">>$file") || die "Cannot append file: $!";
    print file "name: $name<br>e-mail: $email<br>joke: $joke<br><P><hr>
\n";
    close (file);



