#!/usr/bin/perl

##############################################################################
# This is a freeware script written by Anas Elhalabi, MD.                                               
# You can change anything you want in it, but let me tell you something                     
# It won't really work if you damage the core of it.                                                        
# Other awsome scripts are available on  http://perlmart.cjb.net                                   
# If you need help installing this script you can always go to                                        
# http://perlmart.cjb.net      or email me at       aelhalabi@hotmail.com
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA                             
#
##     MODIFYING, SELLING, REMOVING THE LINKS, DISTRIBUTING, TRANSLATING THIS SCRIPT IS ILLEGAL.
##     WE REALLY MEAN THAT AND ENFORCE IT !! 
##############################################################################
#
##### CONFIG ##################################
$VERSION='2.0'; # 07/02/2002;	## DO NOT CHANGE ##
$DATA_DIR='perlspy-data';		## DO NOT CHANGE##
############################################

&init;	## ##


## 
if($ENV{'QUERY_STRING'} eq 'admin') { 
  &end_msg("$CGI_DESC<br>Administration Login :","<p>&nbsp;</p>\n<center><form action=\"$CONF{CGI_URL}\" METHOD=\"POST\">
                                     Password:  <input type=\"PASSWORD\" name=\"PASSWD\"><BR><BR>
                                     <input type=\"submit\" value=\"Login\"></FORM></center>\n<p>&nbsp;</p>");
}

#  ##
if ($ENV{'REQUEST_METHOD'} eq 'POST') {
  %form=&receivepost;
} elsif ($ENV{'QUERY_STRING'} ne '') {
  %form=&receiveget;
}

##  ##
if ($form{'PASSWD'}) {&admin; exit(0);}



###########################


  ## 
  my $date=&getdate2;

  my ($rep,$hote_distant)=&convert_ip($ENV{'REMOTE_ADDR'});
  if ($rep==0) {				# 
    $hote_distant='Unknown';			# 
  }

  ## 
  print "Content-type: image/x-xbitmap\n\n";

  ## 

  ##
  print ("\#define count_width 8\n#define count_height 1\n");

  ## 
  if ($CONF{'teswira'} eq 'white') {
   print ("static char count_bits[] = {\n0x00\n};\n");   #
  } else {
   print ("static char count_bits[] = {\n0xff\n};\n");   #
  }

  ## 
  ## 
  my ($mersal)='';
  $mersal.=" Hi !\n\n";
  $mersal.=" Somone visited your page from :\n";
  $mersal.=" ".($ENV{'HTTP_REFERER'} || 'Unknown...')." \n  on $date\n\n";
  if ($form{'referer'} ne '') {
    $mersal.=" The refering URL is :\n";
    $mersal.=" $form{'referer'}\n\n";
  }
  $mersal.=" The IP was  : $ENV{'REMOTE_ADDR'}\n";
  $mersal.=" The host was  : $hote_distant\n";
  $mersal.=" The browser used was    : $ENV{'HTTP_USER_AGENT'}\n";
  if ($ENV{'HTTP_USER_AGENT'}=~ /MSIE/i) {
    $mersal.="                         (Microsoft Internet Explorer)\n";
  } elsif ($ENV{'HTTP_USER_AGENT'}=~ /Mozilla/i) {
    $mersal.="                         (Netscape)\n";
  }
  if ($ENV{'REMOTE_USER'} ne '') {
    $mersal.="Logged in as : $ENV{'REMOTE_USER'}\n";
  }
  $mersal.="\n";
  $mersal.="  Have a nice day !\n";
  $mersal.="\n";
  $mersal.="  Your faithful PerlSpy.\n";
  $mersal.="\n";
  $mersal.="\n";
  $mersal.="\n";
  $mersal.="\n";
  $mersal.="\n";
  $mersal.="________________________________________\n";
  $mersal.="PerlSpy.\n";
  $mersal.="Free from http://perlmart.cjb.net \n";

  ## 
  &send_email($CONF{'EMAIL_WEBMASTER'},$CONF{'EMAIL_WEBMASTER'},'[PerlSpy]',$mersal);
  




################################################
############                   #################
############  SUBROUTINES  #################
############                   #################
################################################
################################################
sub getdate2 {
  my (@nhar)=('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
  my (@shar)=('January','February','March','April','May','June','July','August','September','October','November','December');
  # 
  my ($sec,$min,$saa,$numnhar,$shar,$aam,$nharsem,$nharan,$isdst) =(localtime());
  #     0    1     2      3       4      5       6     7        8
  $shar++;					# 
  $aam+=1900;					# 
  return (sprintf ("%s %d %s %d : %02d h %02d mn %02d s",$nhar[$nharsem],$numnhar,$shar[$shar],$aam,$saa,$min,$sec));
}
################################################
sub convert_ip {
  my ($ip)=@_;
  my (@bytes)=();				# 
  my ($name, $altnames,$ladrissa,$len,$packaddr);
  my ($rep)=0;

  $ip =~ s/^\s+|\s+$//g;			# 
  @bytes = split (/\./, $ip);			# 
  $packaddr = pack ("C4", @bytes);		# 


  #  #
  if (!(($name, $altnames, $ladrissa, $len, @addrlist) =gethostbyaddr ($packaddr, 2))) {
    $rep=0; 					# 
  }else{
    $rep=1;					# 
  }
  return ($rep,$name,$altnames,$ladrissa,$len,@addrlist);  #  #
}
################################################
sub send_email {
  my ($from,$to,$subject,$mersal)=@_;
  open (MAIL, "|$CONF{'MAILPROG'} -t");
  print MAIL ("To: $to\n");
  print MAIL ("From: $from\n");
  print MAIL ("Subject: $subject\n\n");
  print MAIL ("$mersal");
  close (MAIL);
}
################################################
################################################
sub receiveget {
my (%postdata)=();
my ($data,$d,$smiyya,$shhal)=();

  if ($ENV{'REQUEST_METHOD'} eq 'GET') {
    $data=$ENV{'QUERY_STRING'};
    foreach $d (split('&',$data)) {            # 
      ($smiyya,$shhal)=split('=',$d);      # 
      $smiyya=&url_decode($smiyya);
      $shhal=&url_decode($shhal);
      $postdata{$smiyya}=$shhal;                  # 
    }
  } else {
    print ("Content-type: text/html\n\n<H1>webmaster says : GET Error in CGI method <BR>GO BACK and TRY again</H1>.");
    die ("webmaster says : GET Error in CGI method") ; 
  }
  return %postdata ;
}
################################################
sub url_decode {
  my ($s)=@_;
  $s=~ tr/+/ /;
  $s=~ s/%([0-9A-F][0-9A-F])/pack("C",oct("0x$1"))/ge;
  $s;
}
################################################
sub receivepost {
my (%postdata)=();
my ($len,$d,$data,$smiyya,$shhal)=();

  if ($ENV{'REQUEST_METHOD'} eq 'POST') {
    $len=$ENV{'CONTENT_LENGTH'};       # 
    $data='';                          # 
    if (read(STDIN,$data,$len) !=$len) {       #
      print ("<H1>error reading post data </H1>");
      die("Error reading 'POST' data\n") ; 
    }
    foreach $d (split('&',$data)) {            # 
      ($smiyya,$shhal)=split('=',$d);      # 
      $smiyya=&url_decode($smiyya);
      $shhal=&url_decode($shhal);
      $postdata{$smiyya}=$shhal;                  # 
    }
  }
  return %postdata ;
}
################################################
sub verifie_email {
  my ($email)=@_;
  $email=~ s/\.\@/\@/;	# 
  if ($email eq '') { return(0);}
  if ($email!~ /\@/) { return(0);}
  if ($email=~ /[\,|\s|\;]/) {return (0)};
  if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/ || 
     ($email !~ /^.+\@localhost$/ && 
      $email !~ /^.+\@\[?(\w|[-.])+\.[a-zA-Z]{2,3}|[0-9]{1,3}\]?$/)) {
    return(0);  # 
  }else{
    return(1);  # 
  }
}
################################################
sub end_msg {
my ($onwan,$tip)=@_;

  print "Content-type: text/html\n\n";		# 

  print <<_EOM_;
   <html>
  <head> <title>PerlSpy</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<meta NAME="TITLE" CONTENT="PerlSpy By Anas Elhalabi">
<meta NAME="DESCRIPTION" CONTENT="PerlSpy alerts you by email whenever someone visits a special page">
<meta NAME="KEYWORDS" CONTENT="Perl,CGI,spy,perlspy,perlmartAnas,Elhalabi,Perlmart">
<meta HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<meta HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="French, EN-US">
<meta HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Document">
<meta NAME="REVISIT-AFTER" CONTENT="7 days">
<meta name="robots" content="ALL">
<meta name="rating" content="GENERAL">
<meta http-equiv="expires" content="Mon, 31 Dec 2099 00:00:00 GMT">
<meta http-equiv="pragma" content="no-cache">
<meta name="distribution" content="GLOBAL">
<meta name="copyright" content="This code is Copyright (C) 2000-02 Anas Elhalabi">
<style>
a:link    {color: #0000FF; text-decoration: none; font-family: Verdana; font-size: 8 pt; }
a:visited {color: #0000FF; text-decoration:none; font-family: Verdana; font-size: 8 pt; }
a:hover   {color: BLACK; background-color: #ffcc00; text-decoration: underline overline; font-family: Verdana; font-size: 8 pt; }
INPUT { 

	color : #000000;
	background : #ffffff;
	border-top : 1px solid;
	border-bottom : 1px solid;
	border-left : 1px solid;
	border-right : 1px solid;
	font-family : Verdana;
	font-size : 9px;
	font-weight: bold;
	}
  </style></head>
  <body bgcolor="#FFFFFF" text="#000000">

  <p>&nbsp;</p>
  <div align="center"><center>

  <table border="0" width="80%" bgcolor="#000000">
    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><B><font face="verdana" color="#C0C0C0" size="1">$onwan</b></font></B></td>
    </tr>
    <tr>
      <td width="100%" bgcolor="DEE3E7">
       <p>&nbsp;</p>
       <font face="Verdana" size="1"><b>
       $tip</b></b></font>
       <p>&nbsp;<br></p>
</tr></td>
<tr align=center bgcolor=cococo><td>
		<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST" target="_new">
		<input type=hidden name="ID" value="16517">
		<b><font face=verdana size=1><b>Rate this script
</font></b><select name="rate" size="1" style="color: #000000; font-family: Verdana; font-size: 9px">
                <option value="5" selected>Excellent!</option>
                <option value="5">Very Good</option>
                <option value="5">Good</option>
                <option value="5">Fair</option>
                <option value="5">Poor</option>
        </select></font><font color="#CCCCCC">
        <input type="submit" value="Rate It!">
</TD></tr></form>

    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><strong>
       <font face="verdana" color="#C0C0C0" size="1">
      $CGI_NAME v$VERSION - &copy;  Script written by Anas Elhalabi,
      Download it for free from: <a href="http://perlmart.cjb.net">[- PerlMart -]</a> </font></strong></td>
    </tr>
  </table>  </center></div>
  </body>
  </html>

_EOM_

  exit(0);
}
################################################

################################################
############                   #################
############    AUTO-INSTALL   #################
############                   #################
################################################
sub init {
my ($buf,$khatt);


  if ($ENV{'QUERY_STRING'} eq 'paramlic') {
    print "SERVER_NAME\t$ENV{'SERVER_NAME'}\n";
    print "VERSION\t$VERSION\n";
    exit(0);
  }

  ## Configuration de base #
  %CONF=();
  $CGI_DESC='By Anas Elhalabi';				# Won't work if changed
  $CGI_NAME='PerlSpy';				# Won't work if changed
  $PMIMG_URL= $ENV{'SERVER_NAME'} eq 'http://perlmart.cjb.net' ? 'http://perlmart.cjb.net/images' : 'http://perlmart.cjb.net/perlspy/images';



  ##  ##
  if (open (CONFR,"./$DATA_DIR/config.txt")) {
    while ($khatt=<CONFR>) {
      chomp($khatt);
      #$khatt=~ s/\s*\#.*$//;			# #
      if ( ($khatt ne '') && ($khatt!~ /^#/) && ($khatt=~ /^([^\s]+)\s+(.*)/) ) {
        $CONF{"$1"}="$2" unless ($2 eq '');
      }
    }
    close (CONFR);
  }

  ## Is perlspy-data there ??? ##
  if (!(-e "./$DATA_DIR")) {
    &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#ffffff>Installation Wizard</font><br>ERROR !","<p>&nbsp;</p>\n<p><font face=\"Verdana\" size=\"1\">This script requires a data directory for storing your configuration file.<br>
              You have to create a subdirectory called <b><font color=white>$DATA_DIR</font></b> within the directory containing this script (cgi-bin by default) <br>
              Don\'t forget to  CHMOD  it 777 (full write and execute permissions) in Unix servers<br></font></p><p>&nbsp;</p>\n");
  }

  #############################
  ## Install - Step 1 : URL_CGI ##
  #############################
  if ( (!(-e "./$DATA_DIR/config.txt")) || ($CONF{'CGI_URL'} eq '') ) {
    # D�tection URL du CGI
    $buf=($ENV{'REQUEST_URI'} || $ENV{'SCRIPT_NAME'}); # URL de ce CGI
    $buf=~ s/\?.*//gs;
    # Cr�ation du fichier de configuration
    open (CONF,">>./$DATA_DIR/config.txt") ||  (&end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#ffffff>Installation Wizard</font> <br> ERROR !",
                                                         "<p>&nbsp;</p>\n<p><font face=\"Verdana\" size=\"1\">Couldn\'t write to the subdirectory 
                                                          <b><font color=white>$DATA_DIR</font></b> !<br> &nbsp; <br> <u>This subdirectory\'s Chmod permissions are set to <b><font color=white>".sprintf("%o",((stat("./$DATA_DIR")) [2] & 07777))."</font></b></u>. Please change them to 777.
                                                         <br>&nbsp;</font></p><p>&nbsp;</p>"));
    print CONF ("CGI_URL\t$buf\n");
    close (CONF);
    eval{chmod(0777,"./$DATA_DIR/config.txt");};

    &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br>",
             "<div align=\"center\"><center><table border=\"0\" cellpadding=\"4\" width=\"99%\" cellspacing=\"1\">
              <tr>
              <td width=\"80\"><p align=\"center\"><font face=\"Verdana\" color=\"#FFFFFF\" size=\"2\"><B>Step 1/3</B></font></p>
               <p>
             </td><td valign=\"top\">
              <p align=\"center\"><font face=\"Verdana\" size=\"1\"><b>Welcome to $CGI_NAME\'s Installation wizard !</b></p>
              <p>Thank you for downloading $CGI_NAME <br>You are running this script for the first time. For your convenience the scipt will create the files necessary, then you will be asked to enter your preferences such as password, email ,..etc. </p>
              <p align=\"center\"><b>What does PerlSpy do? :</b></p>
              <p>Nothing complicated. In fact, it sends you an email whenever someone visits a page of your choice with the visitor\'s infos. We will show you later how to instert this in your pages and get the spy working for you!</font></td>
            </tr>
            </table> </center></div>
            <p align=\"center\"><font face=\"Verdana\" size=\"1\"><font color=\"#000000\">
             <B>Configuration file successfully created.</B><br><br></b>
             The script detected that it\'s located in : <u>$buf</u><br>
             If this is not true, Get via FTP in ASCII/Text the file $DATA_DIR/config.txt, and hand edit it (NotePad for instance) </font></B><br>&nbsp; <br>
            Please refresh this page to continue.<br>
            <small>Use your browser\'s [Reload] or [Refresh] buttons.</small></font><</p><p>&nbsp;</p> ");
  }

  ####################################
  ## Install - Step 2 : Security ##
  ####################################
  if ($CONF{'Step2'} == 0) {
    eval{chmod(0777,"./$DATA_DIR/config.txt");};
    open (CONF,">>./$DATA_DIR/config.txt") ||  (&end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#ffffff>Installation Wizard</font> <br> ERROR !","<p>&nbsp;</p>\n<p><font face=\"Verdana\" size=\"1\">Couldn\'t write to  <b><font color=white>$DATA_DIR/config.txt</font></b> !
                                                         <br> &nbsp; <br> Please set this file\'s Chomd permissions to 777... <br>&nbsp;<br>
                                                         </font></p><p>&nbsp;</p>"));
    print CONF ("Step2\t1\n");
    close (CONF);

  ## .htaccess creation.
  if (open (HTACCESS,">$DATA_DIR/.htaccess")) {
    print HTACCESS "<Limit GET>\norder deny,allow\ndeny from all\n</Limit>";
    close (HTACCESS);
    $buf="The directory $DATA_DIR is protected : No access allowed for security reasons.<br>&nbsp;<br>";
    eval{chmod(0644,"./$DATA_DIR/.htaccess");};
  } else {
    $buf='';
  }

    &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#ffffff>Installation Wizard</font>",
             "<p align=\"center\"><font face=\"Verdana\" size=\"1\"><font color=\"#000000\">
            $buf
            The last step will let you configure this script. Once you do that, 
            Click on one of the buttons [French] or [English] and you will see how to use this script.<br>
            You can go back to the Administration page any time by visiting : <br>
            http://$ENV{SERVER_NAME}$CONF{CGI_URL}?admin </font></p>

            <p align=\"center\"><font face=\"Verdana\" size=\"1\"><br>&nbsp; <br>
            <b>Please refresh this page to continue.<br>
            <small>Use your browser\'s [Reload] or [Refresh] buttons.</small></font></b></p><p>&nbsp;</p> ");

  }

  ####################################
  ## Install - Step 3 : Configuration ##
  ####################################
  # 
  if ($CONF{'CPASSWD'} eq '') {			# 
    %form=&receivepost; 			# 
    if ($form{'ORD_change_param_do'}) {		# 
      &admin_change_param_do;			# 
    } else {					# 
      &admin_change_param;			# 
    }
  }

}

################################################


################################################
############                   #################
############       ADMIN       #################
############                   #################
################################################

sub admin {
  # 
  $PASSWD=$form{'PASSWD'};
  if (crypt($PASSWD,'aa') ne $CONF{'CPASSWD'}) {
    sleep(3);
    &end_msg ("$CGI_DESC <br> ADMINISTRATION<br></strong>","
              <p>&nbsp;</p>\n<font face=\"Verdana\" size=\"1\"><b>Wrong Password</b><br><br>
              Go back and try again...<br>
              In case you can\'t remember your password, the only thing to do is: Using FTP,
              delete the configuration file \"$DATA_DIR/config.txt\", then revisit this script at 
              (http://$ENV{SERVER_NAME}$CONF{CGI_URL}) and set a new password again, Nothing fancy but it\'s the only way.</font><p>&nbsp;</p>");
  }

  if ($form{'ORD_change_param'}) {&admin_change_param;}		# 
  if ($form{'ORD_change_param_do'}) {&admin_change_param_do;}	# 
  if ($form{'ORD_french'}) {&admin_french;}
  if ($form{'ORD_english'}) {&admin_english;}				# 
  if ($form{'ORD_version'}) {&admin_version;}			# 
  if ($form{'ORD_licence'}) {&admin_licence;}			# 
  if ($form{'ORD_licence_do'}) {&admin_licence_do;}		# 


  ##
  &admin_menu;

}
################################################
sub admin_menu {

  &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br>ADMINISTRATION","
    <p>&nbsp;</p>
    <p align=\"center\"><u><B><font face=\"Verdana\" color=\"#FFCC00\">Menu :</font></B></u></p>
    <form method=\"POST\" action=\"$CONF{CGI_URL}\">
     <input type=\"hidden\" name=\"PASSWD\" VALUE=\"$PASSWD\">
      <div align=\"center\"><center><table border=\"0\" cellspacing=\"1\">
        <tr>
          <td><font face=\"Verdana\" size=\"1\"><b>
          <input type=\"submit\" value=\"&gt;&gt;\" name=\"ORD_change_param\"> Change the Config.<br>
          <input type=\"submit\" value=\"&gt;&gt;\" name=\"ORD_version\"> Check for updates.<br>
          <input type=\"submit\" value=\"&gt;&gt;\" name=\"ORD_french\"> French<br>
          <input type=\"submit\" value=\"&gt;&gt;\" name=\"ORD_english\"> English</font></b></td>
        </tr>
      </table>
      </center></div><p>&nbsp;</p>
    </form>
    <p>&nbsp;</p>");


}
################################################
sub admin_change_param {
my ($msg,$d_guess_sendmail,$d1);

  # Where the heck is Sendmail
  # Let's look for it everywhere usual in Unix
  foreach $buf ('/usr/lib/sendmail','/usr/bin/sendmail','/bin/sendmail','/usr/sbin/sendmail','/usr/local/bin/sendmail','/usr/local/lib/sendmail') {
    if ((-e "$buf") && (-x "$buf")) {		# 
      $d_guess_sendmail.="$buf<br>";		# 
    }
  }
  if ($d_guess_sendmail eq'') { $d_guess_sendmail='Aucun';} #

  # 
  $d1 ='<input type="radio" name="teswira" value="black"'. ($CONF{'teswira'} ne 'white' ? 'CHECKED' : '').'>black<br>';
  $d1.='<input type="radio" name="teswira" value="white"'.($CONF{'teswira'} eq 'white' ? 'CHECKED' : '').'>white<br>';

  $msg=<<_EOM2_;
  <p>&nbsp;</p>
  <p align="center"><font color="#ffcc00" face="Verdana" size="2"><u><strong>Configuration</strong></u></font></p>
  <form method="POST" action="$CONF{CGI_URL}">
  <input type="hidden" name="PASSWD" value="$PASSWD">
  <table border="0" cellpadding="5" cellspacing="1" width="100%">
    <tr>
      <td valign="top">
         <font face="Verdana" size="1"><B>Password</B><br>
          This will be the administrator's password.</font> </td>
         <td valign="top">
         <input name="d_passwd" size="20"><br> <input name="d_passwdbis" size="20">  </td>
    </tr><tr>
       <td valign="top">
       <font face="Verdana" size="1"><B>Webmaster's Email :</B><br>
       This is where the script will send email alerts.</font>
       </td><td valign="top">
       <input name="EMAIL_WEBMASTER" VALUE="$CONF{EMAIL_WEBMASTER}" size="20">  </td>
    </tr><tr>
       <td valign="top"><font face="Verdana" size="1"><B>Path to sendmail :</B><br>
       PerlSpy will try to guess this path by looking in the usual locations, but in some cases you have to enter it yourself. We recommend using our script ServTest, this will tell you exaclty where sendmail is located in your server. Get it from <a href="http://perlmart.cjb.net" target="_new">PerlMart</a></font></p>
       </td><td valign="top">
       <input type="text" name="MAILPROG" size="20" value="$CONF{MAILPROG}"><br>
       <font face="Verdana" size="1"><u>Found Location(s):</u><br>
       $d_guess_sendmail
       </font></td>

    </tr> <tr>

       <td valign="top"><font face="Verdana" size="1"><B>Image Color :</B><br>
        This script uses a little scripting trick. It displays a very small image (a dot) in the page you're tracking (1 pixel) This is the color of that image.<br>
        this can be white or black depending on your site's background</font></td>
        <td valign="top"><font face="Verdana" size="1">$d1</font></td>
    </tr>
      </table>
      <center><p align="center">
       <input name="ORD_change_param_do" type="submit" value="Confirm !">
       <input name="ORD_admin" type="submit" value="Cancel!"></p></center>
    </form>
    <p>&nbsp;</td>
_EOM2_

  &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#FFFFFF>Configuration</font>",$msg);
}
################################################
sub admin_change_param_do {
my ($msg);

  if (($CONF{'CPASSWD'} eq '') && ($form{'d_passwd'} eq '')) {
    &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#FFFFFF>Configuration</font>",
             "<p>&nbsp;</p>\nThis is the first time you\'re running $CGI_NAME ! You have to choose a password !<br>Please choose one !<p>&nbsp;</p>");
  }
  if ($form{'d_passwd'} ne '') {			# 
    if ($form{'d_passwd'} ne $form{'d_passwdbis'}) {	# 
      &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#FFFFFF>Configuration</font>",
               "<p>&nbsp;</p>\nYour passwords don\'t match. Please try again! <p>&nbsp;</p>");
    } elsif (length($form{'d_passwd'}) < 3) {           #
      &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#FFFFFF>Configuration</font>",
               "<p>&nbsp;</p>\nYour password <b>$form{d_passwd}</b> is less than 3 characters long, the script won\'t accept that for security reasons !<br> Please choose a longer one. (3 char. Min).<p>&nbsp;</p>\n");
    } else {						# 
      $PASSWD=$form{'d_passwd'};			# 
      $msg="<br><b>Administration password has changed to <font color=\"#FFCC00\">$PASSWD</font>.</b> Note, it will be stored in a crypted format, and there\'s no way for you to remember it. If you forget it, you will have to reset it and choose an other one. PerlSpy will tell you how to do that if you enter a wrong password.<br>";
    }
  }

  # 
  if ($form{'EMAIL_WEBMASTER'} eq '') {
    &end_msg ("$CGI_DESC <br> ADMINISTRATION<br></strong>",
            "<p>&nbsp;</p>You forgot to write the webmaster\'s email (Yours).<p>&nbsp;</p>");
  }
  if (&verifie_email($form{'EMAIL_WEBMASTER'}) ==0) {
    &end_msg ("$CGI_DESC <br> ADMINISTRATION<br></strong>",
            "<p>&nbsp;</p>The email address (<b>$form{EMAIL_WEBMASTER}</b>) is invalid!<p>&nbsp;</p>");
  }
  if ($form{'MAILPROG'} eq '') {
    &end_msg ("$CGI_DESC <br> ADMINISTRATION<br></strong>",
            "<p>&nbsp;</p>You didn\'t write the path to sendmail. This is mandatory for sending Emails.. <br> &nbsp;<br>
            <u>Our script ServTest will tell you all these info. Download it from <a href=\"http://perlmart.cjb.net\" target=\"_new\">PerlMart</u><p>&nbsp;</p>");
  }
  if (!(-e "$form{MAILPROG}")) {
    &end_msg ("$CGI_DESC <br> ADMINISTRATION<br></strong>",
            "<p>&nbsp;</p>The path $form{MAILPROG} is wrong, please correct it!<br> This is mandatory for sending Emails. <br>
             &nbsp;<br> <u>Our script ServTest will tell you all these info. Download it from <a href=\"http://perlmart.cjb.net\" target=\"_new\">PerlMart</u><p>&nbsp;</p>");
  }

  ####
  $CONF{'CPASSWD'}=crypt($PASSWD,'aa');
  $CONF{'EMAIL_WEBMASTER'}=$form{'EMAIL_WEBMASTER'};
  $CONF{'MAILPROG'}=$form{'MAILPROG'};
  $CONF{'teswira'}=$form{'teswira'};


  # 
  # 
  eval{chmod(0777,"./$DATA_DIR/config.txt");};
  open (CONFW,">./$DATA_DIR/config.txt") ||  (&end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#FFFFFF>Configuration</font> <br> ERROR !","<p>&nbsp;</p>\n<p><font face=\"Verdana\" size=\"1\">Couldn\'t rewrite <b>$DATA_DIR/config.txt</b> !
                                                         <br> &nbsp; <br> Please Chmod this file to 777 <br>&nbsp;</font></p><p>&nbsp;</p>"));
  foreach ('CGI_URL','Step2','CPASSWD','EMAIL_WEBMASTER','MAILPROG','teswira') {
    print CONFW ($_."\t".$CONF{"$_"}."\n");
  }
  close (CONFW);


  &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br><font face=verdana size=2 color=#FFFFFF>Configuration</font>",
          "<p>&nbsp;</p>\n<p><font face=\"Verdana\" size=\"1\"> $CGI_NAME\'s config was successfully modified! <br>
           $msg <br>&nbsp; <br>
           Let\'s test this script! <a href=\"http://$ENV{'SERVER_NAME'}$CONF{'CGI_URL'}\" target=\"_blank\">Click here to test</a>.
           If you chose black as the color of the image sent, you will see a black bar  
           (8 pixels wide, 1 height). Then check your email inbox for the images sent by the script.\n </p>
           <center><p align=\"center\"><form action=\"$CONF{CGI_URL}\" METHOD=\"POST\">\n 
           <input type=\"hidden\" name=\"PASSWD\" value=\"$PASSWD\">\n
           <input type=\"submit\" value=\"Continue !\"><br> &nbsp; <br>
           Manuals in :<br>
           <input type=\"submit\" name=\"ORD_french\" value=\"French\">
           <input type=\"submit\" name=\"ORD_english\" value=\"English\">
           </form></p></center>\n<p>&nbsp;</p>");

}
################################################
sub admin_french {
my ($msg);

$msg=<<_EOM3_;
    <p>&nbsp;</p>
    <p align="center"><font face="Verdana" color="#FFCC00" size="2"><b><u><strong>Informations
    sur l'Utilisation de $CGI_NAME</strong></b></u></font></p>
    <p><font face="Verdana" size="1"><strong><u>Pour acc�der � la partie Administration</u></strong>
    de $CGI_NAME, il vous faut vous rendre � l'URL : <br>
    <a href="http://$ENV{SERVER_NAME}$CONF{CGI_URL}?admin">http://$ENV{SERVER_NAME}$CONF{CGI_URL}?admin</a>.<br>\n Mettez cette URL
    dans vos Favoris pour ne pas l'oublier! Vous devrez alors taper votre mot de passe.</font></p>
    
    <p><font face="Verdana" size="1"><u><B>Pour utiliser ce CGI :</B></u><br>
    Code HTML � ins�rer dans la (ou les) page(s) HTML de votre choix :<br>
    Soit vous ins�rez un appel normal au script en tant qu'image (Solution 1), soit vous ins�rez un
    code Javascript qui fait la m�me chose, mais qui transmet aussi au script l'URL pr�c�dente du visiteur :<br>
    <UL>
    <LI> <b>Solution 1 : </b><br>
     <b>&lt;IMG SRC=&quot;http://$ENV{SERVER_NAME}$CONF{CGI_URL}&quot; WIDTH=&quot;1&quot; HEIGHT=&quot;1&quot&gt;</b><br>
     A chaque fois qu'un visiteur se rendra sur une page contenant ce code HTML, un E-Mail vous sera envoy� pour
     vous signaler le passage, avec diverses informations.<br> </LI>
    <LI> <b>Solution 2 : </b><br>
     <b>&lt;!-- Debut PerlSpy Code - Copyright Anas Elhalabi, Perlmart, http://perlmart.cjb.net --&gt;<br>
        &lt;script language=&quot;JavaScript&quot;&gt;<br>
        &lt;!--<br>
        document.write(&quot;&lt;img
        src=\\&quot;http://$ENV{'SERVER_NAME'}$CONF{'CGI_URL'}?referer=&quot;);<br>
        document.write(escape(document.referrer));<br>
        document.write(&quot;\\&quot; width=1 height=1&gt;&quot;);<br>
        // --&gt;<br>
        &lt;/script&gt;<br>
        &lt;!-- Fin PerlSpy Code - Copyright Anas Elhalabi, Perlmart, http://perlmart.cjb.net --&gt;  </b><br>
        Si vous utilisez cette solution 2, l'E-Mail que vous recevrez sera comme celui de la Solution 1,
        mais il vous indiquera en plus, l'URL de la page que le visiteur a �t� visiter juste avant la v�tre.<br>
        Si vous mettez ce code Javascript sur votre page d'accueil, vous saurez donc dans quel site (URL exacte)
        le visiteur a cliqu� sur un lien vers votre page (moteur de recherche, partenaire, etc).<br>
        A noter pour cette solution 2, que les visiteurs ayant d�sactiv�s Javascript dans leur navigateur, 
        ne pourront pas �tre &quot;vus&quot; par ce script. Vous en raterez donc un faible pourcentage.
    </LI>
    </UL>
     Ce script peut �tre particuli�rement utile pour savoir qui vient voir des pages prot�g�es par mot de passe (si vous en avez...).</font></p>
    
    <p><font face="Verdana" size="1"><u><B>Attention... :</B></u><br>
    Etant donn� que ce script vous envoie un E-Mail � chaque fois que la (ou les) page(s) contenant un des 2 codes HTML
    ci-dessus est visit�e, vous risquez d'�tre submerg� d'E-Mail de PerlSpy si vous avez un tr�s fort traffic :-)</font></p>

    <p><font face="Verdana" size="1"><u><B>LIMITES :</B></u><br>
    Ce script ne pas donner adresse mail des visiteurs.<br>
    Vous ne pourrez jamais conna�tre l'adresse E-Mail de vos visiteurs avec ce script.<br>
    Personne ne peut conna�tre l'adresse E-Mail d'un visiteur � son insu.<br>
    ...<br>
    Bref, vous l'avez compris, aucun script CGI ne pourra jamais vous donner l'E-Mail de vos visiteurs.
    Et c'est tant mieux pour chacun d'entre nous, sinon le spam serait immense.</font></p>

    <p><font face="Verdana" size="1"><u><B>Copyright et Licence d'Utilisation :</B></u><br>
    Merci de ne pas enlever le copyright et les mentions de l'auteur du code
    source de ce CGI Perl...<br>
    La licence d'utilisation gratuite de ce script CGI vous est accord�e � la condition
    expresse que vous ne fassiez pas de modifications dans le script CGI en vue de supprimer
    ou alt�rer ce type de mention. Dans le cas contraire, son utilisation est ill�gale...<br>
    Ceci est un �change correct de services rendus :-)<br>
    &nbsp; <br>
    <br>
    <u>Distribution/revente interdite sans accord de l'auteur.</u></font></p>
    <center><p align=\"center\"><form action=\"$CONF{CGI_URL}\" METHOD=\"POST\">\n 
    <input type=\"hidden\" name=\"PASSWD\" value=\"$PASSWD\">
    <input type=\"submit\" value=\"Retour Menu\"></form></p></center>

   <p>&nbsp;</p>

_EOM3_


  &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br>ADMINISTRATION",$msg);
}
################################################
sub admin_version {
my ($msg);

  $msg=<<_EOM4_;
    <p align="center"><u><font face="Verdana" color="#FFFFFF" size=2><strong>Version :</strong></font></u></p>
    <blockquote>
      <p><font face="Verdana" size="2">This page tells you in <u>real time</u> wether an other version of PerlSpy
      has been released or not.<br>
      If you find out that it's the case, please visit PerlMart for updates and download the newer version<br>
      </font></p>
    </blockquote>
    <div align="center"><center><table border="0" cellpadding="1" cellspacing="1">
      <tr>
        <td><font face="Verdana" size="2"><b>The version of this scipt is :</b></font></td>
        <td><font face="Verdana" size="2" color="#0000FF"><b>$VERSION</b></font></td>
      </tr>
      <tr>
        <td><p align="center"><font face="Verdana" size="2"><b>The latest version available is : </b></font></td>
        <td><img src="$PMIMG_URL/$VERSION.gif" border="0"></td>
      </tr>
    </table>
    </center></div>

<p align="center"><font face="Verdana" size="2"> The latest version is
     available in <a href="http://perlmart.cjb.net">PerlMart</a>.</font></p>
    </p></center>
    <p>&nbsp;</p>

    

_EOM4_

  &end_msg("<font color=ffcc00 size=3>$CGI_NAME</font><img src=\"$PMIMG_URL/$VERSION.gif\" ALT=\"$CGI_NAME\"><br><br>$CGI_DESC",$msg);
}
################################################
################################################
################################################
sub admin_english {
my ($msg);

$msg=<<_EOM5_;
    <p>&nbsp;</p>
    <p align="center"><font face="Verdana" color="#FFCC00" size="2"><u><strong>$CGI_NAME\'s Help Manual</strong></u></font></p>
    <p><font face="Verdana" size="1"><strong><u>for access to the $CGI_NAME\'s administration page</u></strong>
    you have to go to: <br>
    <a href="http://$ENV{SERVER_NAME}$CONF{CGI_URL}?admin">http://$ENV{SERVER_NAME}$CONF{CGI_URL}?admin</a>.<br>\n You may want to bookmark this page! Each time you access this page you have to type in your password.</font></p>
    
    <p><font face="Verdana" size="1"><u><B>How to use this script :</B></u><br>
    You will have to insert an HTML code in the page(s) you want to watch:<br>
    There are two ways (options) to do this:  Either 1- is to insert a 1 pixel image in the page. Or 2- call a javascript that runs the script from your page :<br>
    <UL>
    <LI> <b>Option 1 : </b><br>
     <b>&lt;IMG SRC=&quot;http://$ENV{SERVER_NAME}$CONF{CGI_URL}&quot; WIDTH=&quot;1&quot; HEIGHT=&quot;1&quot&gt;</b><br>
     Each time a visitor lands on the page containing an Html code (marked page), PerlSpy sends you an alert email.<br> </LI>
    <LI> <b>Option 2 : </b><br>
     <b>&lt;!-- Start PerlSpy Code - Copyright Anas Elhalabi, Perlmart, http://perlmart.cjb.net --&gt;<br>
        &lt;script language=&quot;JavaScript&quot;&gt;<br>
        &lt;!--<br>
        document.write(&quot;&lt;img
        src=\\&quot;http://$ENV{'SERVER_NAME'}$CONF{'CGI_URL'}?referer=&quot;);<br>
        document.write(escape(document.referrer));<br>
        document.write(&quot;\\&quot; width=1 height=1&gt;&quot;);<br>
        // --&gt;<br>
        &lt;/script&gt;<br>
        &lt;!-- End PerlSpy Code - Copyright Anas Elhalabi, Perlmart, http://perlmart.cjb.net --&gt;  </b><br>
        If you use option 2, you will receive in addition to the same email sent by option 1, the URL of the referring page tha sent your visitor to your marked one.<br>
        The only side effect of this option is that Javascript disabled browsers will not be detected. So it\'s up to you.
    </LI>
    </UL>
     A good use of this script is to know who visits your password protected pages, and may be trying to break in.</font></p>
    
    <p><font face="Verdana" size="1"><u><B>Warning... :</B></u><br>
    PerlSpy will send you an email each time someone visits your marked pages. If you are expecting millions of visitors, also expect millions of emails. So you have to use PerlSpy with this in mind :)</font></p>

    <p><font face="Verdana" size="1"><u><B>LIMITES :</B></u><br>
    PerlSpy has no way of knowing the email addresses of your visitors. This is a Perl script not a psychic!<br>
   </font></p>

    <p><font face="Verdana" size="1"><u><B>Copyright Notice :</B></u><br>
<br>This is a freeware script written by Anas Elhalabi, MD.                                               
<br>You can change anything you want in it, but let me tell you something                     
<br>It won't really work if you damage the core of it.                                                        
<br>Other awsome scripts are available on  http://perlmart.cjb.net                                   
<br>If you need help installing this script you can always go to                                        
<br>http://perlmart.cjb.net      or email me at       aelhalabi@hotmail.com
<br>REMOVAL OF THE LINKS TO PERLMART AND THE MENTION OF THE AUTHOR IS A CLEAR VIOLATION OF THIS FREE LICENSE
<br>MODIFYING, TRANSLATING, SELLING, REDISTRIBUTING THIS SCRIPT IS ILLEGAL AND WE REALLY MEAN THAT AND ENFORCE IT !!
 
    <center><p align=\"center\"><form action=\"$CONF{CGI_URL}\" METHOD=\"POST\">\n 
    <input type=\"hidden\" name=\"PASSWD\" value=\"$PASSWD\">
    <input type=\"submit\" value=\"Back To Menu\"></form></p></center>

   <p>&nbsp;</p>

_EOM5_


  &end_msg("<font face=Arial size=3 color=#ffcc00>PerlSpy</font><br>ADMINISTRATION",$msg);
}
################################################
