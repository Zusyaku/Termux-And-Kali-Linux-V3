#!/usr/bin/perl 

use Tk;

$Main=MainWindow->new; 
$Main->title("HTML Contact Book");
$Main->geometry("470x470+8+8");

        
$entry=$Main->Label(-anchor => "w", -text => "Name:", -background => "#9990C8", 
-font => "Tahoma 10 bold", -foreground => "#333F7B" );
$entry->place( -width => 93, -height => 24, -x => 40, -y => 32);


$entry2=$Main->Label(-anchor => "w", -text => "Address:", -background => "#9990C8", 
-font => "Tahoma 10 bold",-foreground => "#333F7B");
$entry2->place( -width => 93, -height => 24, -x => 40, -y => 64);

    
$entry3=$Main->Label(-anchor => "w", -text => "Number:", -background => "#9990C8", 
-font => "Tahoma 10 bold",-foreground => "#333F7B");
$entry3->place( -width => 93, -height => 24, -x => 40, -y => 96);


$entry4=$Main->Label(-anchor => "w", -text => "Birthday:", -background => "#9990C8", 
-font => "Tahoma 10 bold",-foreground => "#333F7B");
$entry4->place( -width => 93, -height => 24, -x => 40, -y => 128);


$entry5=$Main->Label(-anchor => "w", -text => "Comments:", -background => "#9990C8", 
-font => "Tahoma 10 bold",-foreground => "#333F7B");
$entry5->place( -width => 93, -height => 24, -x => 40, -y => 160);


   
###STDIN Boxes### 

$p1 = $Main->Entry(-borderwidth => 3,-font => "Arial 10 normal", 
-foreground => "#000000",-relief => "sunken");
$p1->place(-width => 264,-height => 24,-x => 144,-y => 32 );


$p2 = $Main->Entry( -borderwidth => 3, 
-font => "Arial 10 normal", -foreground => "#000000", -relief => "sunken");
$p2->place(-width => 264,-height => 24,-x => 144,-y => 64);


$p3 = $Main->Entry( -borderwidth => 3, 
-font => "Arial 10 normal", -foreground => "#000000", -relief => "sunken");
$p3->place(-width => 264,-height => 24,-x => 144,-y => 96); 


$p4 = $Main->Entry( -borderwidth => 3, 
-font => "Arial 10 normal", -foreground => "#000000", -relief => "sunken");
$p4->place(-width => 264,-height => 24,-x => 144,-y => 128);


$p5 = $Main->Entry( -borderwidth => 3, 
-font => "Arial 10 normal", -foreground => "#000000", -relief => "sunken");
$p5->place(-width => 264,-height => 24,-x => 144,-y => 160);



###Buttons Placements & Design###

    $save=$Main->Button
    (-activebackground => "#FFFCBF", 
    -activeforeground => "#E30229", -background => "#FFFFFF", 
    -borderwidth => 2, -text => "Save",
    -command => sub{save()}, -cursor => "", 
    -font => "Tahoma 11 bold", 
    -foreground => "#000999", -relief => "solid");
    $save->place(-width => 96, -height => 30, -x => 50, -y => 400);


    $open = $Main->Button
    (-activebackground => "#FFFCBF", -activeforeground => "#E30229", 
    -text => "Display", -command=>\&open,-borderwidth => 2,
    -cursor => "", -font => "Tahoma 11 bold",-background => "#FFFFFF", 
    -foreground => "#000999", -relief => "solid" );
    $open->place( -width => 96,-height => 30, -x => 170, -y => 400);


    $cmdExit = $Main->Button( -activebackground => "#FFFCBF", 
    -activeforeground => "#E30229", -background => "#FFFFFF", 
    -borderwidth => 2, -text => "Exit", 
    -cursor => "", -font => "Tahoma 11 bold", 
    -command => [$Main => 'destroy'],-foreground => "#000999", -relief => "solid"); 
    $cmdExit->place(-width => 96, -height => 30, -x => 292, -y => 400);


    MainLoop;
    


sub open(){$aa="start contact.html";system($aa);}
    

sub save()
{       
require:localtime();
$time=localtime;
$widget=@_; $a=$p1-> get();
$widget=@_; $b=$p2-> get();
$widget=@_; $c = $p3 -> get();
$widget=@_; $d = $p4 -> get();
$widget=@_; $e = $p5 -> get();


for(open(HT, ">>contact.html"))
{
print HT ("\<html\>\n");
print HT ("\<body bgcolor=orange\>\n");
print HT ("\<input id=\"abc\" type=\"hidden\" value=\"abc\"\>\n");
print HT ("\<h1 style=\"color:Blue\"\> \<font-size:150%\"\> $a \</h1\>\n");
#print HT ("\<br\>\n");
print HT ("\<p\> $b \</p\>\<p\> $c \</p\>\<p\> $d \</p\>\<p\> $e \</p\>\n");
print HT ("\</body\>\</html\>");
close(HT);
}
}