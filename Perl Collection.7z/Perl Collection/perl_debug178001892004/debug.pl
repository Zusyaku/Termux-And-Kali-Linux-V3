#!/usr/bin/perl

=head
Author: Tomleung (lok_2000_tom@hotmail.com)
 ____           _   ____            _       _   
|  _ \ ___ _ __| | / ___|  ___ _ __(_)_ __ | |_ 
| |_) / _ \ '__| | \___ \ / __| '__| | '_ \| __|
|  __/  __/ |  | |  ___) | (__| |  | | |_) | |_ 
|_|   \___|_|  |_| |____/ \___|_|  |_| .__/ \__|
                                     |_|        
 ____       _                                 
|  _ \  ___| |__  _   _  __ _  __ _  ___ _ __ 
| | | |/ _ \ '_ \| | | |/ _` |/ _` |/ _ \ '__|
| |_| |  __/ |_) | |_| | (_| | (_| |  __/ |   
|____/ \___|_.__/ \__,_|\__, |\__, |\___|_|   
                        |___/ |___/           
                        
                        v1.0
=cut
########################################################################
#Note:This script can only run in web server, but not command prompt.
#Access this script by http://localhost/debug.pl or something like that.
#Do not try to enter "perl.exe debug.pl" in command prompt, because it doesn't work:<
########################################################################
############################################################
#Settings
############################################################
$homedir='/usr/home/uhomeu/windowl/cgi-bin/debug/';
$tempdir='/usr/home/uhomeu/windowl/cgi-bin/debug/';
$perl='/usr/bin/perl';
#e.g $homedir='c:\cgi-bin\'; #for win32
#e.g $homedir='/home/cgi-bin/'; #for unix
if ($^O =~ /win32/i) {
$OS="win32";
}else {
$OS="unix";	
}

############################################################
use CGI;
$data=new CGI;
$action=$data->param("action");
$script=$data->param("path");
############################################################
#check input						   #
############################################################
print "Content-type: text/html\n\n";
if ($script eq "" && $action eq "debug") {
&cgi_error("Please enter script name");
}elsif (!(-e "$homedir$script")) {
&cgi_error("File $homedir$script does not exist");
}elsif (!(-x "$homedir$script") && $OS eq "unix") {
&cgi_error("Please chmod file to 755 or 700");
}

&debug if ($action eq "debug");
&start if ($action eq "");



sub debug {
$ip=$ENV{'REMOTE_ADDR'};

$time=localtime;
$filename=rand($$);

open (FILE,"$homedir$script")|| &cgi_error("$!");
flock (FILE,2) if ($OS eq "unix");
@line=<FILE>;
flock (FILE,8) if ($OS eq "unix");
close (FILE);

`$perl -wc $homedir$script 2>$tempdir$filename`;
open (TEMP,"$tempdir$filename")||die &cgi_error("$!");
while (<TEMP>) {
push (@array,$_);
push (@array,"<br>");
}
&cgi_error("@array");
close (TEMP);

}

sub cgi_error {
local ($msg) = @_;

print qq*

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Perl Debugger v1.0</title>
</head>
<style>
font { cursor:default;}
</style>
<body>
<!-- This script is written by Tomleung(lok_2000_tom\@hotmail.com), and this tag should not be removed-->
<div align="center">
  <center>

<TABLE WIDTH="486" CELLSPACING=0 CELLPADDING=0 BORDER=1>
<td VALIGN=TOP BGCOLOR="#999999">
    <tr>
      <td width="50%" bgcolor="#4A67F0"><font face="Arial" size="2" color="#1ED960">Bugs</font></td>
    </tr>
    <tr>
  </center>
      <td width="50%" valign="middle" align="center">
        <p align="left"><font face="Verdana" size="2">$msg</font></td>
    </tr>
  <center>
    <input type="hidden" name="action" value="debug">
    <tr>
    </tr>
  </table>
  </center>
</div>
<br>
*;
&count;
print qq*
<br>
<div align="center">
  <center>
  <TABLE WIDTH="486" CELLSPACING=0 CELLPADDING=0 BORDER=1>
  <table border="1" width="486" bordercolor="#999999">
    <tr>
      <td bgcolor="#4A67F0"><font
face="Arial" size="2" color="#1ED960">Brackets</font></td>
    </tr>
  </table>
  </center>
<div align="center">
  <center>
  <TABLE WIDTH="486" CELLSPACING=0 CELLPADDING=0 BORDER=1>
<!--  <table border="0" width="486">-->
<td VALIGN=TOP BGCOLOR="#999999">

    <tr>
      <td>&quot;</td>
      <td>{</td>
      <td valign="middle" align="right">}</td>
      <td>(</td>
      <td align="right" valign="middle">)</td>
      <td>[</td>
      <td valign="middle" align="right">]</td>
    </tr>
    <tr>
      <td width="70">$quot</td>
      <td width="74">$lb</td>
      <td valign="middle" align="right" width="74">$rb</td>
      <td width="61">$lr</td>
      <td valign="middle" align="right" width="63">$rr</td>
      <td width="60.5">$ls</td>
      <td valign="middle" align="right" width="60.5">$rs</td>
    </tr>
  </table>


*;
if (($quot % 2) == 0) {
$first="\#1ED960";
$textfirst="OK";
}else {
$first="\#FF0000";
$textfirst="Failed";
}

if ($lb == $rb) {
$sec="\#1ED960";
$textsec="OK";
}else {
$sec="\#FF0000";
$textsec="Failed";
}

if ($lr == $rr) {
$th="\#1ED960";
$textth="OK";
}else {
$th="\#FF0000";  
$textth="Failed";  
}
if ($ls == $rs) {
$fo="\#1ED960";   
$textfo="OK";   
}else {
$fo="\#FF0000";   
$textfo="Failed";   
}
print qq*
 <div align="center">
    <table border="1" width="486">
      <tr>
        <td width="66" bgcolor="$first"><center>$textfirst</center></td>
        <td width="148" bgcolor="$sec"><center>$textsec</center></td>
        <td width="125" bgcolor="$th"><center>$textth</center></td>
        <td width="121" bgcolor="$fo"><center>$textfo</center></td>
      </tr>
    </table>
  </div>

*;

print qq*

    </table>

</div>

</body>

</html>

*;
unlink "$tempdir$filename";

exit;
}


sub start {
print qq*
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>Perl Debugger v1.0</title>
<!--Author: Tomleung(lok_2000_tom\@hotmail.com)-->
</head>
<style>
font { cursor:default;}
</style>
<body>

<div align="center">
  <center>
<TABLE WIDTH="486" CELLSPACING=0 CELLPADDING=0 BORDER=1 bgcolor="#999999">
<!--<td VALIGN=TOP BGCOLOR="#999999" colspan="2" width="478">-->

    <tr>
      <td width="486" bgcolor="#4A67F0"><span style="cursor:'default'" ><font
face="Arial" size="2" color="#1ED960">Perl Script Debugger v1.0</font></td></span>
      
    <tr>
    <form action="debug.pl" method="POST">

      <td width="478" valign="middle" align="center" colspan="2"></center>

	<font face="MS Sans Serif" size="2">Perl script   
        absolute path:<SPAN style="background-color:#00FA9A">$homedir</span><input
type="text" name="path" value="test.pl" size="20" style="font-family:Arial;font-style:italic;color:#8A2BE2"></font>  
        <p><input type="submit" name="b1" value="Debug"></p>
    </td>
    </tr>
    <input type="hidden" name="action" value="debug">
    <tr>
      </form>
    </tr>
  </table>
</div>
<br><br>
<a href="/debug.zip"> Click here to download this script</a>
<br><br>
<!--WEBBOT bot="HTMLMarkup" startspan ALT="Site Meter" -->
<script type="text/javascript" language="JavaScript">var site="s1008082004"</script>
<script type="text/javascript" language="JavaScript1.2" src="http://s10.sitemeter.com/js/counter.js?site=s1008082004">
</script>
<noscript>

<img src="http://s10.sitemeter.com/meter.asp?site=s1008082004" alt="Site Meter" border=0></a>
</noscript>
<!-- Copyright (c)2002 Site Meter -->
<!--WEBBOT bot="HTMLMarkup" Endspan -->
<br><br><br><a href="http://www.scripts.com">Scripts.com - Get the best scripts NOW!</a>
<br><a href="http://www.webmasterzine.com">
Webmaster Zine Online
</a>

</body>

</html>




*;


}




sub count {
print qq*
<div align="center">
  <center> 
<TABLE WIDTH="486" CELLSPACING=0 CELLPADDING=0 BORDER=1>
<td VALIGN=TOP BGCOLOR="#999999">
    <tr>
      <td width="50%" bgcolor="#4A67F0"><font face="Arial" size="2" color="#1ED960">Brackets counting</font></td>
    </tr>   
    <tr>
  </center>
*;

foreach $lines (@line) {
$i++;
next if ($lines =~ /^\#/);
next if ($lines eq "\n");


 (@letter)=split(/ */,$lines);
foreach $letters (@letter) {
chomp $letters;
#quot="
#lb={
#rb=}
#lr=(
#rr=)
#ls=[
#$rs=]
if ($letters eq "\"") {
$quot++ ;
push (@qqqs,$letters);
}elsif ($letters eq "\{") {
$lb++ ;
push (@qqqs,$letters);
}elsif ($letters eq "\}") {
$rb++ ;
push (@qqqs,$letters);
}elsif ($letters eq "\(") {
$lr++ ;
push (@qqqs,$letters);
}elsif ($letters eq "\)") {
$rr++ ;
push (@qqqs,$letters);
}elsif ($letters eq "\[") {
$ls++ ;
push (@qqqs,$letters);
}elsif ($letters eq "\]") {
$rs++ ;
push (@qqqs,$letters);
}
}#eachletters
print qq*
     <td width="50%" valign="middle" align="center">
        <p align="left"><font face="Arial Narrow" size="2">$i:@qqqs</font></td>
    </tr>
*;
undef(@qqqs);
}
print qq*
  <center>
    <tr>  
    </tr>
  </table>
  </center>
</div>

*;

}#sub
