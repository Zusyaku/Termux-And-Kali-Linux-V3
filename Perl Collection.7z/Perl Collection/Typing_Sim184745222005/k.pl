#!/usr/bin/perl

for ($loop = 1; $loop <= 300000; $loop++)
{ 
    if ($loop == 300000)
    {
	print "m";
	exec "perl l.pl";
    }
}
