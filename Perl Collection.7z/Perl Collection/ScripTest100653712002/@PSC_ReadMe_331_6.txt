Title: ScripTest
Description: How many times did you install a Perl script and had trouble configuring it because of a small errors? ScripTest lets you browse your directories and check your scripts for Syntax Errors, Perl Warnings, Chmod permissions, ...etc...
Browse through your directories, perform different tests on your Perl scripts and find out what's wrong with them. Instead of those 500 Internal Error messages get a list of errors and warnings that only the server knows such as wrong path to Perl, Wrong Chmod permissions, Syntax errors, Server/Line endings mismatch, etc. All this is displayed in a nice output and a user friendly web based interface. Help manual available in English and French.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=331&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
