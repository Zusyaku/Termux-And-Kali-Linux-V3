#!/usr/bin/perl

$|=1;
##############################################################################
# This is a freeware script written by Anas Elhalabi, MD.                                               
# You can change anything you want in it, but let me tell you something                     
# It won't really work if you damage the core of it.                                                        
# Other awsome scripts are available on  http://perlmart.cjb.net                                   
# If you need help installing this script you can always go to                                        
# http://perlmart.cjb.net      or email me at       aelhalabi@hotmail.com
#
# This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License included in this package for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA                             
##############################################################################

print "Content-type: text/html\n\n";
$VERSION='2.0';

##############################################################################
# If you're getting error message, you have to change the following variables#
# Usually ther are auto detected, change only in case it doesn't work  :     #
# 																							     #
#$CONF{"PERL_BIN"}='';				# Path to Perl in your server, for more info use our script ServTest
#$REAL_CURDIR='';					# Complete path to your CGI directory
#$CONF{"DOC_ROOT"}='';				# Path to your site's Root
##############################################################################

# Let's get started
# 1.2.3....... Go
&init;

#
#
if ($ENV{'REQUEST_METHOD'} eq 'POST') {
  %form=&receivepost;
} elsif ($ENV{'QUERY_STRING'} ne '') {
  %form=&receiveget;
}


$REAL_CURDIR =( $form{'REAL_CURDIR'} || $REAL_CURDIR);


foreach $key (keys(%form)) {
  if ($key=~ /^rep\.(.*)$/)  { $form{'rep'} =$1;  }
  if ($key=~ /^test\.(.*)$/) { $form{'test'}=$1; }
}


if ($form{'rep'} ne '') {
  $REAL_CURDIR=&change_rep($REAL_CURDIR,$form{'rep'});
}


  if ($CONF{'DOC_ROOT'} ne '') {
    my ($tmp)=$CONF{'DOC_ROOT'};
    $tmp=~ s/\\/\\\\/g;
    if ($REAL_CURDIR=~ /^$tmp(.*)$/) {$VIRT_CURDIR=$1;}else {$VIRT_CURDIR='??';}
    $VIRT_CURDIR=~ s/\\/\//g;
  }

if ( ($CONF{'DOC_ROOT'} ne '') && ($REAL_CURDIR !~ /^$CONF{DOC_ROOT}/) ) {
  &msg_fin("$CGI_NAME <br>\n$CGI_DESC","You can't access the directory <b>$REAL_CURDIR</b>, because it looks like it's out of you site's range");
}

if ($form{'ORDexplorateur'}) {
  &explorateur;
} elsif ($form{'ORD_test_cw'}) {
  &test_script_cw;
} elsif ($form{'ORD_version'}) {
  &admin_version;
} elsif ($form{'ORD_French'}) {
  &admin_French;
} elsif ($form{'ORD_English'}) {
  &admin_English;
} elsif ($form{'test'}) {
  &test_script;
}


&explorateur;






################################################
############                   #################
############  Subroutines      #################
############                   #################
################################################

sub init {
use Config;




################### script will not work if changed !!!!##############################
  $CGI_DESC='By Anas Elhalabi';										# script will not work if changed  !
  $CGI_NAME='ScripTest';													# script will not work if changed  !
  $PERL_TYPES='|pl|cgi|fcgi|wcgi|';									# script will not work if changed  !
  $CONF{BGCOLOR}="#DDDDDD";									# script will not work if changed  !
  $CONF{'CGI_URL'}=($ENV{'REQUEST_URI'} || $ENV{'SCRIPT_NAME'}); # script will not work if changed  !
  $CONF{'CGI_URL'}=~ s/\?.*//gs;								# script will not work if changed  !
  $PMIMG_URL= $ENV{'SERVER_NAME'} eq 'http://perlmart.hypermart.net' ? 'http://perlmart.hypermart.net/images' : 'http://perlmart.hypermart.net/scriptest/images';
  $FONT='<font face="Verdana,Tahoma" size="1"><b>';

  $VIRT_CURDIR='';
  if ($REAL_CURDIR eq '') {
    foreach $buf ($0,$ENV{'SCRIPT_FILENAME'},$ENV{'PATH_TRANSLATED'}) {
      if ($buf eq '') {next;}
      if ($buf=~ /wrap/i) {next;}
      if ($buf=~ /sbox/i) {next;}
      if (($^O!~ /win/i) && ($buf!~ /^\//)) {next;}
      if (!-e "$buf") {next;}
      $REAL_CURDIR=$buf;
      last;
    }
    $REAL_CURDIR=~ s/[^\/|\\]+$//;
    $REAL_CURDIR=~ s/[\/|\\]$//;
    if ($^O=~ /win/i) {$REAL_CURDIR=~ s/\//\\/g;}
    $REAL_CGIDIR=$REAL_CURDIR;
    if ($REAL_CURDIR eq '') {  &msg_fin("$CGI_NAME <br>\n$CGI_DESC","Couldn't find the complete path to your CGI directory,... You'll have to change the script manually and write the complete path to your CGI directory in the line containing <b>\$REAL_CURDIR</b> You can use our script ServTest for finding out this path");  }
  }


  $SEP= $^O=~ /win/i ? '\\' : '/';

  if ($CONF{'PERL_BIN'} eq '') {
    foreach ('/usr/local/bin/perl','/usr/bin/perl',$Config{'perlpath'},"C:\\perl\\bin\\perl.exe") {
      if ( (-e "$_") && (-x "$_") ) {
        $CONF{'PERL_BIN'}=$_;
        last;
      }
    }
  }
  if ($CONF{'PERL_BIN'} eq '') {  &msg_fin("$CGI_NAME <br>\n$CGI_DESC","Couldn't find the complete path to PERL,... You'll have to change the script manually and write the complete path to Perl in the line containing  <b>\$CONF\{&quot;PERL_BIN&quot;\}</b> You can use our script ServTest for finding out this path");  }



  if ($CONF{'DOC_ROOT'} eq '') {
    my ($tmp_real_curdir,$tmp_cgi_dir);
    $tmp_real_curdir=$REAL_CURDIR;
    $tmp_real_curdir=~ s/\\/\//g;
    $tmp_cgi_dir=$CONF{'CGI_URL'};
    $tmp_cgi_dir=~ s/\\/\//g;
    $tmp_cgi_dir=~ s/[^\/]+$//;
    $tmp_cgi_dir=~ s/\/$//;

    if ($tmp_real_curdir=~ /^(.*)$tmp_cgi_dir/) {
      $CONF{'DOC_ROOT'}=$1;
    }
  }

  if ($^O=~ /win/i) {
    $CONF{'DOC_ROOT'}=~ s/\//\\/g;
    $CONF{'DOC_ROOT'}=~ s/\\$//;
  } else {
    $CONF{'DOC_ROOT'}=~ s/\\/\//g;
    $CONF{'DOC_ROOT'}=~ s/\/$//;
  }
}
################################################
sub receivepost {
my (%postdata)=();
my ($len,$d,$data,$nom,$valeur)=();

  if ($ENV{'REQUEST_METHOD'} eq 'POST') {
    $len=$ENV{'CONTENT_LENGTH'};       # Longueur de l envoi
    $data='';                          # Chaine envoy�e
    if (read(STDIN,$data,$len) !=$len) {       # tout n est pas lu
      print ("<H1>error reading post data </H1>");
      die("Error reading 'POST' data\n") ; }
    foreach $d (split('&',$data)) {            # s�paration de la chaine par paires
      ($nom,$valeur)=split('=',$d);      # paires s�par�es
      $nom=&url_decode($nom);
      $valeur=&url_decode($valeur);
     $postdata{$nom}=$valeur;                  # paires rang�es dans data
      }
    } else {
      print ("Content-type: text/html\n\n<H1>webmaster says : Post Error in CGI method <BR>GO BACK and TRY again</H1>");
      exit;
    }
  return %postdata ;
}
################################################
sub url_decode {
  my ($s)=@_;
  $s=~ tr/+/ /;
  $s=~ s/%([0-9A-F][0-9A-F])/pack("C",oct("0x$1"))/ge;
  $s;
}
################################################
sub receiveget {
my (%postdata)=();
my ($data,$d,$nom,$valeur)=();

  if ($ENV{'REQUEST_METHOD'} eq 'GET') {
    $data=$ENV{'QUERY_STRING'};
    foreach $d (split('&',$data)) {            # s�paration de la chaine par paires
      ($nom,$valeur)=split('=',$d);      # paires s�par�es
      $nom=&url_decode($nom);
      $valeur=&url_decode($valeur);
      $postdata{$nom}=$valeur;                  # paires rang�es dans data
    }
  } else {
    print ("Content-type: text/html\n\n<H1>webmaster says : GET Error in CGI method <BR>GO BACK and TRY again</H1>");
    die ("webmaster says : GET Error in CGI method") ;
  }
  return %postdata ;
}

sub msg_fin {
my ($titre,$tip)=@_;

                                                        #

  print <<_EOM_;
  <html>
  <head> <title>$CGI_NAME</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Content-Language" content="en-us">
<meta NAME="TITLE" CONTENT="PerlMart Sript Tester By Anas Elhalabi">
<meta NAME="DESCRIPTION" CONTENT="ScripTest is a simple Perl script that tells you what's wrong with your perl scripts">
<meta NAME="KEYWORDS" CONTENT="Perl,CGI,script,Serveur,servers,Script,Test,ScripTest,Anas,Elhalabi,Perlmart">
<meta HTTP-EQUIV="CHARSET" CONTENT="ISO-8859-1">
<meta HTTP-EQUIV="CONTENT-LANGUAGE" CONTENT="French, EN-US">
<meta HTTP-EQUIV="VW96.OBJECT TYPE" CONTENT="Document">
<meta NAME="REVISIT-AFTER" CONTENT="7 days">
<meta name="robots" content="ALL">
<meta name="rating" content="GENERAL">
<meta http-equiv="expires" content="Mon, 31 Dec 2099 00:00:00 GMT">
<meta http-equiv="pragma" content="no-cache">
<meta name="distribution" content="GLOBAL">
<meta name="copyright" content="This code is Copyright (C) 2000-02 Anas Elhalabi">
<style>
a:link    {color: #CCFF00; text-decoration: none; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
a:visited {color: #CCFF00; text-decoration:none; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
a:hover   {color: BLACK; background-color: #ffcc00; text-decoration: underline overline; font-family: Verdana; font-size: 8 pt; font-weight: bold; }
INPUT {

	color : #000000;
	background : #ffffff;
	border-top : 1px solid;
	border-bottom : 1px solid;
	border-left : 1px solid;
	border-right : 1px solid;
	font-family : Verdana;
	font-size : 9px;
	font-weight: bold;
	}
  </style></head>
  <body bgcolor="#537895" text="#000000" link="#FF0000" vlink="#FF0000" alink="#FF0000">

  <p>&nbsp;</p>
  <div align="center"><center>

  <table border="0" width="80%" bgcolor="#C0C0C0">
    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><B><font face="verdana" color="#C0C0C0" size="1">$titre</b></font></B></td>
    </tr>
    <tr>
      <td width="100%" bgcolor="#A6A6FF">
       <p>&nbsp;</p>
       <font face="Verdana" size="1"><b>
       $tip</b></b></font>
       <p>&nbsp;</p>
      </td></tr>
		<form action="http://www.hotscripts.com/cgi-bin/rate.cgi" method="POST" target="_new">
		<input type=hidden name="ID" value="16313">
		<tr><td align="center" valign="middle"><font face=verdana size=1><b>Rate this script
</font></b><select name="rate" size="1" style="color: #ff0000; font-family: Verdana; font-size: 10px">
                <option value="5" selected>Excellent!</option>
                <option value="5">Very Good</option>
                <option value="5">Good</option>
                <option value="5">Fair</option>
                <option value="5">Poor</option>
        </select></font><font color="#CCCCCC">
        <input type="submit" value="Rate It!">
        </font></TD></tr></form>

    <tr>
      <td width="100%" bgcolor="#537895"><p align="center"><strong>
       <font face="verdana" color="#C0C0C0" size="1">
      $CGI_NAME v$VERSION - &copy;  Script written by Anas Elhalabi,
      Download it for free from: <a href="http://perlmart.cjb.net">[- PerlMart -]</a> </font></strong></td>
    </tr>
  </table>  </center></div>
  </body>
  </html>

_EOM_

  exit(0);
}
################################################
sub list_dir {
my ($repertoire)=@_;
my (@fichiers,$buf);

  opendir (DIR,"$repertoire") || (&msg_fin("$CGI_NAME <br>\n$CGI_DESC","Failure to open the directory:  $repertoire: $!<br> Either you're not authorized to or your permissions are not set correctly."));
  while ($buf=readdir(DIR)) {
    push(@fichiers,$buf) if (($buf ne '.') && ($buf ne '..'));
  }
  closedir(DIR);
  return (@fichiers);
}
################################################
sub change_rep {
my ($repertoire,$selectdir)=@_;
  # Il ne doit pas y avoir de / ou \ dans le r�pertoire o� aller
  $selectdir=~s/^\\//g;
  $selectdir=~s/^\///g;

  if ($selectdir eq '..') {
    if ($repertoire eq $CONF{'DOC_ROOT'}) {
      &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$FONT.'You are already in the Root, you can\'t go any higher</font>');
    }
    if ($^O=~/win/i) {
      $repertoire=~ s/\\[^\\]+$//;
    } else {
      $repertoire=~ s/\/[^\/]+$//;
    }
  } else {
    $repertoire.=$SEP.$selectdir;
  }
  return ($repertoire);
}
################################################
sub explorateur {
my (@curdir_files)=();
my ($msg,$fichier,$extension,$buf);


  ## D�but formulaire :
  $msg.="<form method=\"POST\" action=\"$CONF{CGI_URL}\">\n";
  $msg.="<input type=\"hidden\" name=\"REAL_CURDIR\" value=\"$REAL_CURDIR\">\n";
  $msg.="<div align=\"center\"><center><p>\n";
  $msg.='<input type="submit" name="ORD_version" value="Check for Updates"> &nbsp; ';
  $msg.='<input type="submit" name="ORD_English" value="English"> &nbsp; ';
  $msg.='<input type="submit" name="ORD_French" value="French"><br>&nbsp'."\n";
  $msg.="</p></center></div>\n";

  ## On affiche le r�pertoire en cours (complet, et virtuel)
  $msg.='<div align="center"><center><table border="0">'."\n";
  $msg.=" <tr>\n";
  $msg.="  <td> $FONT <b>Current Real Directory :</b></font></td>\n";
  $msg.="  <td> $FONT <font color=\"#FF0000\"><b>$REAL_CURDIR$SEP</b></font></font></td>\n";
  $msg.=" </tr><tr>\n";
  $msg.="  <td> $FONT <b>Current Virtual Directory :</b></font></td>\n";
  $msg.="  <td> $FONT <font color=\"#FF0000\"><b>$VIRT_CURDIR/<b></font></font></td>\n";
  $msg.="</tr>\n";
  $msg.="</table>\n\n";

  $msg.="<p align=\"center\"><font face=verdana color=\"#FF0000\" size=2><b>Content of the current directory :</b></font><br>";
  $msg.=" <font face=verdana size=1></b>Browse using the &quot;&gt;&gt;&quot; button<br>";
  $msg.=" then click on the  [ Test ] button to test</font></p>\n</center></div>\n";


  @curdir_files=&list_dir($REAL_CURDIR);	# On liste le contenu du r�pertoire courant
  @curdir_files=(sort(@curdir_files));		# On trie la liste de fa�on alphab�tique

  $msg.='<div align="center"><center><table border="0" cellspacing="0" cellpadding="0">'."\n";

  # R�pertoire Sup�rieur
  $msg.="<tr><td align=\"right\"><input type=\"submit\" name=\"rep...\" value=\"Upper Directory\"> </td></tr>\n";

  # On affiche d'abord les r�pertoires :
  foreach $fichier (@curdir_files) {
    if (-d "$REAL_CURDIR/$fichier") {		# Si c'est un r�pertoire
      $msg.=" <tr><td align=\"right\"><input type=\"submit\" name=\"rep.$fichier\" value=\">>\"> </td>";
      $msg.=" <td><font face=\"Verdana,Tahoma\" size=\"1\">&nbsp;<font color=\"#800000\"><b>Directory</b></font>$FONT &nbsp; $fichier</font></td></tr>\n";
    }
  }

  $msg.='<tr><td colspan="2"><hr noshade color="#800000"></td></tr>'."\n";

  # On affiche ensuite les fichiers :
  foreach $fichier (@curdir_files) {
    if (!(-d "$REAL_CURDIR/$fichier")) {	# Si ce n'est pas un r�pertoire
      if ( ($fichier=~ /\.([^\.]+)$/) && ($extension=$1) && ($extension!~ /\W/) && ($PERL_TYPES=~ /\|$extension\|/i) ) {
        # Si c'est un fichier de type script perl
        $msg.=" <tr><td align=\"right\"><input type=\"submit\" name=\"test.$fichier\" value=\"Test\"> </td>";
        $msg.=" <td><font face=\"Verdana,Tahoma\" size=\"1\">&nbsp;<b>$fichier</b></font></td></tr>\n";
      } else {
        # Sinon
        $msg.=" <tr><td align=\"right\">-&nbsp; &nbsp; </td>";
        $msg.=" <td><font face=\"Verdana,Tahoma\" size=\"1\">&nbsp;$fichier</font></td></tr>\n";
      }
    }
  }
  $msg.="</table></center></div>\n\n";

  ## Fin formulaire :
  $msg.="</form>\n";

  &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$msg);
}
################################################
sub test_chmod {
my ($fichier)=@_;
my ($chmod,$reponse);

  if ($^O=~ /win/i) { return "Windows server, you do not need to test";}
  $chmod=(stat($fichier)) [2];

  if (!($chmod & 0001)) {$reponse.="Script not allowed to be executed by web visitors<br>\n";}
  if (!($chmod & 0004)) {$reponse.="Script not allowed to be read by web visitors<br>\n";}
  if (!($chmod & 0010)) {$reponse.="Script not allowed to be executed by your group<br>\n";}
  if (!($chmod & 0040)) {$reponse.="Script not allowed to be read by your group<br>\n";}
  if (!($chmod & 0100)) {$reponse.="Script not allowed to be executed by the owner (You)<br>\n";}
  if (!($chmod & 0400)) {$reponse.="Script not allowed to be read by the owner (You)<br>\n";}

  if ($reponse ne '') {
    $reponse.="Chmod permissions for this script are:  <u>".sprintf("%o",($chmod & 07777));
    $reponse.="</u> instead of 755 or 777.<br>\n";
    $reponse.="This is why the server <u>probably</u> could not run it through the browser...";
  }

  return ($reponse);
}
################################################
sub test_shebang {
my ($fichier)=@_;
my ($shebang);

  if ($^O=~ /win/i) { return "Windows server, you do not need to test";}

  open (TSR,"$fichier") || (return "Failure to read the script. Test cancelled: <i>$!</i>");
  $shebang=<TSR>;
  close (TSR);

  chomp($shebang);
  $shebang=~ s/\s+$//;
  $shebang=~ s/\r.*//;				# Au cas o� ce serait au format MAC, on coupe apr�s le fin de ligne MAC

  # On v�rifie que le shebang commence par:#!
  if ($shebang!~ /^\#\!/) {
    return "The first line of your script should start with :<big><b>\#\!</b></big><br>\n The script can not be run this way by your browser\n";
  }

  # On v�rifie que le shebang correspond au programme �x�cutable
  $shebang=~ s/^\#\!//;
  if (!-e "$shebang") {
    return "The first line of your script points to<br> The wrong Perl :<b>$shebang</b>  is unavailable !<br>Instead, write :<br><b>\#\!$CONF{PERL_BIN}</b>";
  }
}
################################################
sub test_findeligne {
my ($fichier)=@_;
my (@ligne,$i,$reponse);


  ## On ouvre le fichier script CGI et on y lit les 10 premi�res lignes
  open (TFR,"$fichier") || (return "Failure to read the script. Test cancelled: <i>$!</i>");
  # binmode indispensable, sinon Perl arrange les fins de ligne entre DOS et Unix
  binmode (TFR);
  $i=0;
  while (($i<10) && ($ligne[$i]=<TFR>) ) {
    $i++;
  }
  close (TFR);

  # On regarde les $nb_lues premi�res lignes du script ainsi lues,
  # et on v�rifie que les caract�res de fin de ligne sont bien
  # \n sur Unix, ou \r\n sur Windows.
  # Caract�res fin de ligne :
  # Unix      : \010 (\n)
  # Windows   : \013\010 (\r\n)
  # Macintosh : \013 (\r)

  for ($i=0;$i<$#ligne;$i++) {

    if ($^O=~ /win/i) {				# Si serveur Windows...
      if (($ligne[$i]=~ /\r/) && ($ligne[$i]!~ /\n/)) {	# Si la ligne contient \r et pas de \n, caract�ristique de fin de ligne MAC
        $reponse= "The file contains line endings typical of MAC,<br> which makes it misread by your sever:  Windows. ";
        last;
      }
      if ($ligne[$i]!~ /\r/) {
        $reponse= "The file contains line endings typical of UNIX,<br> which makes it misread by your sever:  Windows. ";
        last;
      }

    } else {					# Serveur Unix
      if ($ligne[$i]=~ /\r\n/) {
        $reponse= "The file contains line endings typical of MSDOS/Windows,<br> which makes it misread by your sever:  Unix. ";
        last;
      }
      if ($ligne[$i]=~ /\r/) {
        $reponse= "The file contains line endings typical of MAC,<br> which makes it misread by your sever:  Unix. ";
        last;
      }
    }
  }

  if ($reponse ne '') {
    $reponse.="<br>\n<i>Uplod the script again using the ASCII/text mode in FTP.<br>\n";
  }
  return ($reponse);
}
################################################
sub test_script {
my ($msg);

  if (!-e "$REAL_CURDIR$SEP$form{'test'}") {
    &msg_fin("$CGI_NAME <br>\n$CGI_DESC","$FONT Le fichier $REAL_CURDIR$SEP$form{'test'} is unavailable !</font>");
  }

  ## D�but formulaire :
  $msg.="<form method=\"POST\" action=\"$CONF{CGI_URL}\">\n";
  $msg.="<input type=\"hidden\" name=\"REAL_CURDIR\" value=\"$REAL_CURDIR\">\n";
  $msg.="<input type=\"hidden\" name=\"test\" value=\"$form{'test'}\">\n";
  $msg.="<div align=\"center\"><center><p>\n";
  $msg.='<input type="submit" name="ORD_version" value="Check for Updates"> &nbsp; ';
  $msg.='<input type="submit" name="ORD_English" value="English"> &nbsp; ';
  $msg.='<input type="submit" name="ORD_French" value="French"><br>&nbsp'."\n";
  $msg.="</p></center></div>\n";

  ## On affiche le r�pertoire en cours (complet, et virtuel)
  $msg.='<div align="center"><center><table border="0">'."\n";
  $msg.=" <tr>\n";
  $msg.="  <td> $FONT <b>Current Real Directory :</b></font></td>\n";
  $msg.="  <td> $FONT <font color=\"#FF0000\"><b>$REAL_CURDIR$SEP</b></font></font></td>\n";
  $msg.=" </tr><tr>\n";
  $msg.="  <td> $FONT <b>Current Virtual Directory :</b></font></td>\n";
  $msg.="  <td> $FONT <font color=\"#FF0000\"><b>$VIRT_CURDIR/<b></font></font></td>\n";
  $msg.="</tr>\n";
  $msg.="</table>\n\n";

  $msg.="<p align=\"center\"><font face=\"Verdana\" color=\"#800000\"><b>Test Results For:  $VIRT_CURDIR/$form{'test'} :</b></font></p>\n";

  # Tests
  $msg.='<table border="0">'."\n";
  $msg.="<tr>\n";
  # test CHMOD :
  $msg.=" <td valign=\"top\">$FONT <b>Test 1 (chmod) :</b> </font></td>\n";
  $msg.=" <td>$FONT".(&test_chmod($REAL_CURDIR.$SEP.$form{'test'}) || 'OK')." </font></td>\n";
  # test sheebang
  $msg.="</tr><tr>\n";
  $msg.=" <td valign=\"top\">$FONT <b>Test 2 (sheebang) :<br></b> </font></td>\n";
  $msg.=" <td>$FONT".(&test_shebang($REAL_CURDIR.$SEP.$form{'test'}) || 'OK')." </font></td>\n";
  # test upload FTP ASCII (fin de ligne)
  $msg.="</tr><tr>\n";
  $msg.=" <td valign=\"top\">$FONT <b>Test 3 (envoi FTP ASCII/texte) :<br></b> </font></td>\n";
  $msg.=" <td>$FONT".(&test_findeligne($REAL_CURDIR.$SEP.$form{'test'}) || 'OK')." </font></td>\n";

  $msg.="</table>\n";


  # on tente de faire perl -c sur le script pour v�rifier la syntaxe :
  eval {
    if ($^O=~ /win/i) {
      chdir($REAL_CURDIR);
      open (STDERR,">".$REAL_CGIDIR.$SEP."stderr.txt") || (  &msg_fin("$CGI_NAME <br>\n$CGI_DESC","You are using a  Windows server,
                                                    ScripTest could not create a temporary testing file called:  <b>stderr.txt</b>,
                                                    <br>. Please create it yourself (empty)
                                                    in the same directory as this sciptle and set its permissions to write and read... Then refresh this page."));
      $res=`$CONF{PERL_BIN} -c $form{test}`;
      close (STDERR);
      open (LR,$REAL_CGIDIR.$SEP."stderr.txt") || print "Failure to get the test results :$!";
      while (<LR>) {$res.=$_;}
      close (LR);
    } else {					# Si on est sur Unix
      $res=`cd $REAL_CURDIR; $CONF{PERL_BIN} -c $form{test} 2>&1`; # OK SUR UNIX PAS WINDOWS
    }
    $res=~ s/\n$//;
    $res=~ s/</&lt/gs;
    $res=~ s/>/&gt/gs;
    $res=~ s/\"/&quot;/gs;
    $res=~ s/\n/<br>\n/g;
  };

  $msg.='<table border="0" cellpadding="6" cellspacing="1" bgcolor=#000000>'."\n";
  $msg.="<tr bgcolor=#cococo><td>\n";

  if ($@) {
    $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control : <font color=\"#FF0000\">??</font></b><br>&nbsp;<br>\n";
    $msg.= "Impossible de tester le script avec \"perl -c\" :$@ </font></p>\n";
  } else {
    if ($res=~ /syntax OK/i) {
      $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control : <font color=\"#FF0000\">OK</font></b><br>&nbsp;<br>\n";
      $msg.= " No Syntax Errors :)</font></p>\n";
    } else {
      $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control : <font color=\"#FF0000\">Error !</font></b><br>&nbsp;<br>\n";
      $msg.= "This script has at least one error :</font></p>\n";
    }
    $msg.="<p>$FONT <u>Complete message returned by Perl verification (perl -c): </u><br>&nbsp;<br>\n".$res."\n</font></p>\n";
  }

  $msg.="</td></tr></table>\n\n";

  ## Bouton et fin de formulaire :
  $msg.="<p align=\"center\"> $FONT If your script has no syntax errors, you can run  ";
  $msg.="a complete test (perl -cw, warnings display) ";
  $msg.="by clicking on the button below. Otherwise, go back to the script selection page :</font><br>&nbsp;<br>\n";
  $msg.='<input type="submit" name="ORD_test_cw" value="Complete Test"> ou <input type="submit" name="ORDexplorateur" value="Go Back..."></p>'."\n";

  $msg.="</form></center></div>\n";

  &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$msg);
}
################################################
sub test_script_cw {
my ($msg);

  if (!-e "$REAL_CURDIR$SEP$form{'test'}") {
    &msg_fin("$CGI_NAME <br>\n$CGI_DESC","$FONT The file $REAL_CURDIR$SEP$form{'test'} is unavailable !</font>");
  }

  ## D�but formulaire :
  $msg.="<form method=\"POST\" action=\"$CONF{CGI_URL}\">\n";
  $msg.="<input type=\"hidden\" name=\"REAL_CURDIR\" value=\"$REAL_CURDIR\">\n";
  $msg.="<div align=\"center\"><center><p>\n";
  $msg.='<input type="submit" name="ORD_version" value="Check for Updates"> &nbsp; ';
  $msg.='<input type="submit" name="ORD_French" value="French"><br>&nbsp'."\n";
  $msg.="</p></center></div>\n";

  ## On affiche le r�pertoire en cours (complet, et virtuel)
  $msg.='<div align="center"><center><table border="0">'."\n";
  $msg.=" <tr>\n";
  $msg.="  <td> $FONT <b>Current Real Directory :</b></font></td>\n";
  $msg.="  <td> $FONT <font color=\"#FF0000\"><b>$REAL_CURDIR$SEP</b></font></font></td>\n";
  $msg.=" </tr><tr>\n";
  $msg.="  <td> $FONT <b>Current Virtual Directory :</b></font></td>\n";
  $msg.="  <td> $FONT <font color=\"#FF0000\"><b>$VIRT_CURDIR/<b></font></font></td>\n";
  $msg.="</tr>\n";
  $msg.="</table>\n\n";

  $msg.="<p align=\"center\"><font face=\"Verdana\" color=\"#800000\"><b>Comlete test of:  $VIRT_CURDIR/$form{'test'} :</b></font></p>\n";

  # on tente de faire perl -cw sur le script pour v�rifier la syntaxe :
  eval {
    if ($^O=~ /win/i) {
      chdir($REAL_CURDIR);
      open (STDERR,">".$REAL_CGIDIR.$SEP."stderr.txt") || (  &msg_fin("$CGI_NAME <br>\n$CGI_DESC","Your are using a Windows server,
                                                    ScripTest could not create a temporary testing file called:  <b>stderr.txt</b>,
                                                    <br>. Please create it yourself (empty)
                                                    in the same directory as this sciptle and set its permissions to write and read... Then refresh this page."));
      $res=`$CONF{PERL_BIN} -cw $form{test}`;
      close (STDERR);
      open (LR,$REAL_CGIDIR.$SEP."stderr.txt") || print "Could not get the test results :$!";
      while (<LR>) {$res.=$_;}
      close (LR);
    } else {					# Si on est sur Unix
      $res=`cd $REAL_CURDIR; $CONF{PERL_BIN} -cw $form{test} 2>&1`; # OK SUR UNIX PAS WINDOWS
    }
    $res=~ s/^\n//;
    $res=~ s/\n$//;
    $res=~ s/</&lt/gs;
    $res=~ s/>/&gt/gs;
    $res=~ s/\"/&quot;/gs;
    $res=~ s/\n/<br>\n/g;
  };

  $msg.='<table border="1" cellpadding="6" cellspacing="0">'."\n";
  $msg.="<tr><td>\n";

  if ($@) {
    $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control and warnings: <font color=\"#FF0000\">??</font></b><br>&nbsp;<br>\n";
    $msg.= "Impossible de tester le script avec \"perl -cw\" :$@ </font></p>\n";
  } else {
    if (($res=~ /syntax OK/i) && ($res=~ /\n/) ) {
      $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control and warnings: <font color=\"#FF0000\">Warnings</font></b><br>&nbsp;<br>\n";
      $msg.= " Aucune erreur de syntaxe, mais <u>warning messages</u> :-)</font></p>\n";
    } elsif ($res=~ /syntax OK/i) {
      $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control and warnings: <font color=\"#FF0000\">OK</font></b><br>&nbsp;<br>\n";
      $msg.= " No Syntax Errors.  <u>No warning messages</u> :-)</font></p>\n";
    } else {
      $msg.="<p align=\"center\"><b>$FONT Perl Syntax Control and warnings: <font color=\"#FF0000\">Error !</font></b><br>&nbsp;<br>\n";
      $msg.= "This script has at least one Syntax Error or Warning :</font></p>\n";
    }
    $msg.="<p>$FONT <u>Complete message returned by Perl verification et warning (perl -cw): </u><br>&nbsp;<br>\n".$res."\n</font></p>\n";
  }

  $msg.="</td></tr></table>\n\n";

  ## Bouton et fin de formulaire :
  $msg.='<p align="center"><input type="submit" name="ORDexplorateur" value="Retour..."></p>'."\n";

  $msg.="</form></center></div>\n";

  &msg_fin("$CGI_NAME <br>\n$CGI_DESC",$msg);


}
################################################
################################################
################################################
sub admin_version {
my ($msg);

  $msg=<<_EOM4_;
    <p align="center"><u><font face="Verdana" color="#0000FF"><strong>Version :</strong></font></u></p>
    <blockquote>
      <p><font face="Verdana" size="2">This page tells you in <u>real time</u> wether an other version of ScripTest
      has been released or not.<br>
      If you find out that it's the case, please visit PerlMart for updates and download the newer version<br>
      </font></p>
    </blockquote>
    <div align="center"><center><table border="0" cellpadding="2" cellspacing="1">
      <tr>
        <td><font face="Verdana" size="2"><b>The version of this scipt is :</b></font></td>
        <td><font face="Verdana" size="2" color="#0000FF"><b>$VERSION</b></font></td>
      </tr>
      <tr>
        <td><p align="center"><font face="Verdana" size="2"><b>The latest version available is : </b></font></td>
        <td><img src="$PMIMG_URL/$VERSION.gif" border="0"></td>
      </tr>
    </table>
    </center></div>

<p align="center"><font face="Verdana" size="2"> The latest version is
     available in <a href="http://perlmart.cjb.net">PerlMart</a>.</font></p>
    <center><p align=\"center\">
      <form method="POST" action="$CONF{CGI_URL}">
      <input type="hidden" name="REAL_CURDIR" value="$REAL_CURDIR">
      <input type="submit" value="Go Back..."></form>
    </p></center>
    <p>&nbsp;</p>

_EOM4_

  &msg_fin("$CGI_NAME<br>$CGI_DESC",$msg);
}
################################################
################################################
sub admin_French {
my ($msg);

$msg=<<_EOM3_;
    <p align="center"><font face="Verdana" color="#000000" size="2"><u><strong> Informations
    sur l'Utilisation de $CGI_NAME :</strong></u></font></p>

    <p><font face="Verdana" size="1"><u><B>S�curit�, ATTENTION :</B></u><br>
      Etant donn� que ScripTest permet de voir le contenu des diff�rents r�pertoires du site sur lequel il est install�,
      vous devriez le renommer avec un nom peu commun voire compliqu�, afin d'�viter que des visiteurs
      puissent le trouver, ou, mieux encore, le supprimer de votre site web apr�s l'avoir utilis�.</font></p>

    <p><font face="Verdana" size="1"><u><B>Informations diverses :</B></u><br>
     <UL>
     <LI><b>Configuration/Auto-Configuration :</b> ScripTest tente de d�tecter de nombreux param�tres, afin que
       vous n'ayez pas besoin de modifier ce script.<br>
       El�ments auto-d�tect�s : Emplacement de Perl <small>(si non trouv�, vous devrez l'indiquer
       vous-m�me)</small>, URL de ScripTest, chemin complet au r�pertoire de ScripTest sur le disque dur du serveur,
       type de serveur (Unix/Windows) et caract�re de s�paration de r�pertoire (\\ ou /), chemin complet
       du r�pertoire de base de votre site web.<br>
       Si vous notez que l\'auto-configuration fonctionne mal, merci de m'�crire afin que j'am�liore...<br>&nbsp; <br>
     </LI>
     <LI><b>Compatibilit� Windows :</b> Ce script est con�u pour fonctionner �galement sur serveur Windows.<br>
       Pour ce faire, ScripTest d�tecte si le serveur est du type Windows ou autre (Unix), et les m�thodes de
       navigation dans les r�pertoires, et de test des scripts Perl sont diff�rentes dans les 2 cas.
       ScripTest a �t� test� avec succ�s avec OmniHttpdv2.06 et Apache sur Windows 95/98 (en plus de tests
       sur diff�rents syst�mes Unix), avec une version r�cente de Perl pour Windows.<br>
       A l'heure actuelle, des tests plus complets manquent sur Windows NT, si vous rencontrez des
       probl�mes sur ce type de machine, merci de m'en avertir SVP.<br>&nbsp; <br>
     </LI>
     <LI><b>Pour choisir le fichier Perl � tester :</b> D�placez-vous dans les r�pertoires (par d�faut, celui
       qui contient ScripTest), puis cliquez sur le bouton \"TEST\" devant le script Perl � tester.<br>
       Seuls les fichiers dont l'extension est .pl ou .cgi ou .fcgi ou .wcgi peuvent �tre test�s.<br>&nbsp; <br>
     </LI>
     <LI><b>Current Real Directory :</b> C'est le chemin complet du r�pertoire dont le contenu est
       list� au-dessous.<br>&nbsp; <br>
     </LI>
     <LI><b>Current Virtual Directory :</b> C'est le chemin <i>par rapport au r�pertoire de base de
       votre site</i> au r�pertoire dont le contenu est list� au-dessous.<br>
       S'il commence par <b>??</b>, c'est que ScripTest ne peut pas le d�tecter, ce qui n'est pas g�nant.<br>&nbsp; <br>
     </LI>
     <LI><b>Test1 (chmod) :</b> ScripTest v�rifie que le script � tester a les bonnes permissions.
      Si les permissions sont incorrectes (diff�rent de 755 ou 777), le script test� ne pourra pas s'�x�cuter
      normalement avec le navigateur (sauf pour quelques rares serveurs).<br>
      Ce test est ignor� si votre serveur est Windows, car le syst�me de permission est diff�rent.<br>&nbsp; <br>
     </LI>
     <LI><b>Test2 (shebang) :</b> ScripTest v�rifie que la premi�re ligne (appel�e shebang) du script � tester
      contient bien \"\#!\" suivi de l'emplacement <u>CORRECT</u> de l'interpr�teur Perl.
      Si ce n'est pas le cas, le script test� ne pourra pas s'�x�cuter normalement avec le navigateur.<br>
      Ce test n\'est pas effectu� si votre serveur est Windows, car le shebang y est ignor�.<br>&nbsp; <br>
     </LI>
     <LI><b>Test3 (envoi FTP ASCII/Texte) :</b> ScripTest v�rifie que le fichier a bien �t� t�l�charg� par FTP en mode
      ASCII/Texte et non pas en mode binaire, les caract�res de fin de ligne �tant diff�rents sur Unix, Windows
      et Macintosh. Dans ce test les 10 premi�res lignes du script � tester sont lues et analys�es pour savoir
      si les caract�res de fin de ligne sont conformes au syst�me d'exploitation de votre serveur.
      Si ce n'est pas le cas, le script test� ne pourra pas s'�x�cuter normalement avec le navigateur.<br>&nbsp; <br>
     </LI>
     <LI><b>Test de la syntaxe :</b> ScripTest lance le v�rificateur de syntaxe de Perl (debogueur) pour le
      script � tester (perl -c nom-du-fichier.pl), intercepte le message renvoy�, et vous l'affiche apr�s
      analyse/traitement. La m�thode employ�e est relativement diff�rente selon que votre serveur est de type
      Unix ou Windows.<br>
      Si ce test vous indique des erreurs de syntaxe, il n'y a aucune chance pour que le script test�
      fonctionne normalement avec le navigateur.<br>&nbsp; <br>
     </LI>
     <LI><b>Test de la syntaxe avec avertissements :</b> ScripTest lance le v�rificateur de syntaxe de Perl
     (debogueur) avec affichage de \"Warnings\" (avertissements sur l'utilisation non rigoureuse de variables)
      pour le script � tester (perl -cw nom-du-fichier.pl), intercepte le message renvoy�, et vous l'affiche
      apr�s analyse/traitement. La m�thode employ�e est relativement diff�rente selon que votre serveur est de type
      Unix ou Windows.<br>
      Si ce test vous indique des <i>avertissements</i>, mais pas d'erreurs de syntaxe, il pourra quand m�me
      fonctionner tout � fait normallement, en tant que CGI.<br>&nbsp; <br>
     </LI>


</font></p>
</UL>
    <p><font face="Verdana" size="1"><u><B>Copyright et Licence d'Utilisation :</B></u><br>
    Merci de ne pas enlever le copyright et les mentions de l'auteur du code
    source de ScripTest Perl...<br>
    La licence d'utilisation gratuite de ce script CGI vous est accord�e � la condition
    expresse que vous ne fassiez pas de modifications dans le script CGI en vue de supprimer
    ou alt�rer ce type de mention. Dans le cas contraire, son utilisation est ill�gale...<br>
    Ceci est un �change correct de services rendus :-)<br>
    <u>Distribution/revente interdite sans accord de l'auteur.</u> </p>
    <center><p align=\"center\">
      <form method="POST" action="$CONF{CGI_URL}">
      <input type="hidden" name="REAL_CURDIR" value="$REAL_CURDIR">
      <input type="submit" value="Retour..."></form>
    </p></center>
   <p>&nbsp;</p>

_EOM3_


  &msg_fin("$CGI_NAME<br>$CGI_DESC",$msg);
}
################################################
################################################
################################################
###########################ENGLISH##########
sub admin_English {
my ($msg);

$msg=<<_EOM5_;
<p align="center"><font face="Verdana" color="#000000" size="2"><u><strong> $CGI_NAME Manual:</strong></u></font></p>
<p><font face="Verdana" size="1"><u><B>Security Warning :</B></u><br>
      ScripTest displays the content of the directory it's installed in! You have to rename it to a less common name so that visitors of your site can't find it. A newer version will include a password protection tool</font></p>

    <p><font face="Verdana" size="1"><u><B>Informations :</B></u><br>
     <UL>
     <LI><b>Configuration/Auto-Configuration :</b> ScripTest will attempt to detect several parameters for it's own configuration, you don't need to modify it.<br>

Parameters automatically detected : Location of Perl <small>(if not found, you have to write it yourself)</small>, URL of ScripTest, Path to this sciprt on your server, Server type (Uniix/Windows), Complete path to your site's root.<br><br>&nbsp; <br>
     </LI>
     <LI><b>Windows Compatibilty :</b> ScripTest runs on Windows servers too.<br>
<br>&nbsp; <br>
     </LI>
     <LI><b>How to perform tests:</b> Browse through your directories (the default is the one that contains ScripTest), then click ont the \"TEST\"  button in front of the script you want to test.<br>
       Only files with .pl or .cgi or .fcgi or .wcgi extensions can be tested.<br>&nbsp; <br>
     </LI>
     <LI><b>Current Real Directory :</b> Complete path of the directory listed below.<br>&nbsp; <br>
     </LI>
     <LI><b>Current Virtual Directory :</b> Complete path <i>relatively to the root of your site </i> and the directory listed below.<br>
       If it starts with <b>??</b>, this means that ScripTest could not detect it, this is not a big deal.<br>&nbsp; <br>
     </LI>
     <LI><b>Test1 (chmod) :</b> ScripTest checks for the correct permissions.
      If these are not set correctly (not 755 or 777), the tested script can not run correctly through a browser (except some very rare servers).<br>
      This test is not performed if you're using a Windows sever because the permission system is different.<br>&nbsp; <br>
     </LI>
     <LI><b>Test2 (shebang) :</b> ScripTest checks wether the first line of your script (also called shebang) starts with \"\#!\" followed by the <u>CORRECT</u> Perl Location.
      If this is not the case, your script can not run normally through a browser.<br>
      This test is not performed in Windows servers because they ignore the shebang.<br>&nbsp; <br>
     </LI>
     <LI><b>Test3 (FTP Upload ASCII/Text) :</b> ScirpTest that you have FTP uploaded your script in 
      ASCII/Text not in Binary. The line endings are different in Unix, Windows
      and Macintosh. ScripTest checks the first 10 lines of your script to see wheter your line endings match your server.
      If it is not the case, your script can't run normally through a browser.<br>&nbsp; <br>
     </LI>
     <LI><b>Syntax Test :</b> ScirpTest runs the Perl Syntax Debugger for your script (perl -c script.pl), gets the sent message and displays it for you. This test is different on Unix or Windows.<br>
      If your script sends Syntax Errors, there's no way you can run it normally through a browser.<br>&nbsp; <br>
     </LI>
     <LI><b>Syntax and Warnings Test :</b> ScirpTest runs the same test as above but displays the Warnings also.<br>
      If your script sends  <i>Warnings</i>, and no Syntax Errors, it could eventually run normally.<br>&nbsp; <br>
     </LI>


</font></p>
</UL>
    <p><font face="Verdana" size="1"><u><B>Copyright Notice :</B></u><br>
    Please do not remove the copyright, Author, and PerlMart Links in this script...<br>
    Your free license is granted to you for the only condition that you do not change these copyright mentions.<br>
    <u>Commercial use and Distribution Forbidden without permission of <a href=mailto"aelhalabi@hotmail.com> Anas Elhalabi</a>.</u> </p>
    <center><p align=\"center\">
      <form method="POST" action="$CONF{CGI_URL}">
      <input type="hidden" name="REAL_CURDIR" value="$REAL_CURDIR">
      <input type="submit" value="Go Back..."></form>
    </p></center>
   <p>&nbsp;</p>
_EOM5_


  &msg_fin("$CGI_NAME<br>$CGI_DESC",$msg);
}
