Title: ServerTester
Description: ServerTester is a simple yet very powerful tool that tells you more than what your hosting service has told you about the server's settings. You can view in real time your server's hardware, software, version, Perl, installed perl modules, the real path to your files, the location of Date/Time, sendmail, whois, PGP, tar, gunzip, gzip, sh, etc. The latest version includes a Help manual in French.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=329&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
