#!/usr/bin/perl
#######################################################################
# MOLLENSOFT Freeware Project Notice                                  #
# Modified: Monashee Information Systems - Bill Carlson               #
#######################################################################
# PERL HTTP Server "PYXUS" v 2.1.1                                    #
#                                                                     #
# The PYXUS (Latin For "Fast Stream") Server is an HTTP Server design #
# to be used as a local test server and an experimental platform for  #
# testing new ideas.                                                  #
#                                                                     #
# Last update: Nov 2001                                               #
#                                                                     #
#######################################################################

use strict;
use IO::Socket;

sub process_request;
sub extractVar;
sub printHeader;
sub error;
sub gotNastyChars;
sub isACLscriptOK;
sub isItHTML;
sub SSI;
sub HTTPtime;
sub LOCALtime;

# If you run in 'taint' mode, make sure the path is really pointing to
# your Perl binaries etc. For Win32 systems the present setting should
# do in most cases.

if ($ENV{'OS'} eq "Windows_NT") {
	$ENV{'PATH'} = '\perl\bin;c:\perl\bin';
	system('cls');
	binmode(STDOUT); #win32 platforms must use this!!
	print "Running under Windows NT.\n";
}

#Start PYXUS help page
#system("start http://127.0.0.1:8089/index.htm");

########################################################################
# Set up error messages in hash.
########################################################################

my %errors = (
	403, "Forbidden - access denied!",
	404, "File Not Found.",
	500, "Internal error.",
	501, "This server does not support the given request type.",
	900, "Excessive GET length",
	901, "Excessive POST size.",
	902, "Excessive ENV variable length.",
	903, "Too many variables in client header.",
	904, "Too many variables after Content-length."
	);

########################################################################
# Get server variables from Pyxus.conf
########################################################################

my $cnf;
if (defined(@ARGV)) {
	$cnf = @ARGV[0];
} else {
	$cnf = "pyxus.conf";
}

my %PROC;
open(PROC, $cnf) or die "Where is the PYXUS Configuration FILE?\n";
while(<PROC>) {
	chomp;
	my @allconf = split(/\n/);
	foreach my $line (@allconf) {
			unless($line =~ /^#/) {
				# Remove white space
				$line =~ s/\s+|\t+//g;
				$line =~ /(.*)=(.*)/;
				$PROC{$1} = $2;
			}
		}
	}
close(PROC);

my $port = $PROC{'port'};
my $maxconn = $PROC{'maxconn'};
my $root = $PROC{'docroot'};
my $cgibin = $PROC{'cgibin'};
my $BINSECkey = $PROC{'binseckey'};
my $enablelogs = $PROC{'enablelogs'};
my $maxGETlength = $PROC{'maxGETlength'};
my $maxPOSTlength = $PROC{'maxPOSTlength'};
my $timezone = $PROC{'timezone'};
my @ACLscript = split(',', $PROC{'securedscripts'});
my @ACLfiletypes = split(',', $PROC{'securedfiletypes'});

my %mimetype;
my $index;
for ($index = 0; $index <= $#ACLfiletypes; $index += 2) {
	$mimetype{$ACLfiletypes[$index]} = $ACLfiletypes[$index + 1];
}

my $hackerTrigger = $PROC{'hackerTrigger'};
my $hackerDelta = $PROC{'hackerDelta'};
my $maxHdrVars = $PROC{'maxHdrVars'};
my $timeout = $PROC{'timeout'};

my $hackerSensor = 0;
my $files_served = 0;
my $client;
my $method;
my $url;
my $versionid;
my $qryfile = "Queryfile.txt";
my $msg1;
my $msg2;
my $querystring;
my $querylength;

$ENV{'SERVER_NAME'} = "Pyxus";
$ENV{'SERVER_PORT'} = $port;
$ENV{'SERVER_PROTOCOL'} = "HTTP/1.1";
$ENV{'SERVER_SOFTWARE'} = "Pyxus 2.1";

########################################################################
# Start Server Logfile
########################################################################

my $Date = localtime();
open(LOGS, ">>severlog.txt");
print LOGS "\n*** Server started $Date \n";
print LOGS "*** Server port:$port, maximum connnections: $maxconn \n";
print LOGS "*** Server document root is $root \n\n";
close(LOGS);

########################################################################
# Start Network Server
########################################################################

my $server = IO::Socket::INET->new
	(
	Type=>SOCK_STREAM,
	LocalPort=>$port,
	Listen=>$maxconn,
	Reuse=>1,
	Timeout=>$timeout
	) or die "Error: Cannot open server socket!\n";

my $sss = '#' x 70;
print "$sss\n";
print "Mollensoft Labs & Monashee Information Systems - $ENV{'SERVER_SOFTWARE'}\n\n";
print "PYXUS = \"Fast Stream\"\n\n";
print "$sss\n";
print "Use Control-C to exit Server (until GUI control is complete)\n";
print "$sss\n";
print "Server operating under username: $ENV{'USERNAME'}\n";
print "Starting Server Log....\n";
print "PYXUS Server Started, $Date \n";
print "Listening on Port: $port\n";
print "Maxconnections: $maxconn\n";
print "Server File Root: $root\n";
print "CGI directory is: $cgibin \n";
print "The server is running ...\n\n"; 

######## Main Loop of Web Server ########

# These loops look a little wierd I know. Notice that we force the server to time
# out after 5 seconds so that any malformed requests that leave the server
# waiting for missing newline '\n' characters will now be abandoned. This is
# a real possibility if the HTTP request headers from the client are incomplete
# for some reason. The 'loopcontrol' variable simply ensures that the server
# keeps running after we've timed out. Of course if we set it to anything but
# '0' we terminate the program after the time out.

my $loopcontrol = 0;
while ($loopcontrol == 0) {
while ($client = $server->accept) {
	$client->autoflush(1);
	my $line = <$client>;
	$line =~ /^(.*) (.*) (.*)\Z/;
	$method = $1;
	$url = $2;
	$versionid = $3;

	$Date = localtime();
	$msg1 = join(" ", $files_served, $hackerSensor, $client->peerhost(), $Date, " "); 
	$msg2 = join(" ", $method, $url, $versionid);
	print "$msg1$msg2\n";

	if ($enablelogs eq "Y") {
		open(LOGS, ">>severlog.txt") or
			die "Error: Cannot open SERVERLOG.TXT!\n";
		print LOGS "$msg1$msg2\n";
		close(LOGS);
	}

	if ($method eq "GET" || "POST") {
		if ($versionid eq "HTTP/1.0" || "HTTP/1.1") {
			&process_request;
			$root = $PROC{'docroot'};
		}
	} else {

		# If not GET or POST then what is it? It could be one of
		# the other legitimate HTTP headers that are legal but,
		# not recognized by our server.

		if ($method eq "HEAD" || "PUT" || "DELETE" || "LINK" || "UNLINK") {
			&error(501);
		} else {
			# Unrecognized header, abandon request!	
			$hackerSensor += $hackerDelta;
		}
	}
	close($client);
	if ($hackerSensor > $hackerTrigger) {
		# 'hackerSensor' is a variable whose value increases quickly
		# with each major error and decreases slowly with each
		# successfully served web page or time out. If we receive just
		# a few hack attempts, the threshold value is quickly reached
		# and we take some appropriate action. For example, we could
		#  - Send an mail
		#  - Launch an application
		#  - Sleep for awhile
		#  - Terminate Pyxus
		#  - Shutdown the OS! (if you're really paranoid)
		# If no hack attempts are detected the system gradually
		# settles down and 'forgets' after a period of time. In other
		# words Pyxus will tolerate some mischief but not a lot!

		#print "\nWARNING: Potential hacker attack under way!\n\n";
		$hackerSensor -= $hackerDelta;

		#system('shutdown.exe /L /T:5 /Y /C');
		#sleep 600;
		#exit(0);
	}
}
if ($hackerSensor > 0) {$hackerSensor--}
}
close($server);
exit(0);

########################################################################
# Processing of requests are done here.
########################################################################

sub process_request {
	# Prevent directory go-back and directory tree traversals and
	# known executables. These types of requests are so dangerous,
	# don't even respond.

	if ($url =~ /\.\./) {
		$hackerSensor += $hackerDelta;
		return;
	}
	if ($url =~ /\.exe|\.cmd|\.bat/i) {
		$hackerSensor += $hackerDelta;
		return;
	}

	# This clever contruction looks for the default page in any directory.
	# If the last character in any URL is a '/' then we assume the
	# default page is being requested and append 'index.htm' to it.

	if (rindex($url, "/") == length($url)-length("\n")) {
		$url .= "index.htm";
	}

	# If this is a Perl GET form request, then extract query string.

	$url =~ /(.*?)\.pl\?(.*$)/;
	$querystring = $2;
	$querylength = length($querystring);

	$ENV{'QUERY_STRING'} = $querystring;
	$ENV{'CONTENT_LENGTH'} = $querylength;
	$ENV{'DATE_GMT'} = HTTPtime;
	$ENV{'DATE_LOCAL'} = LOCALtime;
	$ENV{'REQUEST_METHOD'} = $method;
	$ENV{'REMOTE_HOST'} = $client->peerhost();
	$ENV{'REMOTE_ADDR'} = inet_ntoa($client->peeraddr());

	# Now, strip away all query characters after the url filename.

	$url =~ s/\?.*$//;

	# Reject any filenames with escaped characters! Somebody's been
	# hacking if true! Remember we've stripped away the query part
	# and only path/file now remains.

	if (gotNastyChars($url)) {
		$hackerSensor += $hackerDelta;
		return;
	}

	if ($method eq "GET" && isACLscriptOK($url)) {
		if ($querylength >= $maxGETlength) {
			&error(900);
			return;
		}

		# We don't extract header variables here as there is no
		# guarantee there are any with the GET method. 

		my $rs = `perl -T $cgibin$url`;
		if ($?) {
			&error(500, $?);
			return;
		} else {
			&printHeader unless ($rs =~ /^HTTP(.*) OK\Z/);
			print $client $rs;
			$BINSECkey += 100;
			if ($hackerSensor > 0) {$hackerSensor--}
			return;
		}
	}

	if ($method eq "POST") {
		unless(isACLscriptOK($url)) {
			&error(403);
			return;
		}

		# Collect header variables and create environment variables
		# with them. By prefixing all header variables with 'HTTP_'
		# we ensure that no one can overwrite sensitive system
		# variables. We've tried to limit the number of them as well.

		my $line;
		my $flag=0;
		while ($flag <= $maxHdrVars - 1) {
			$line = <$client>;
			if(length($line) >= $maxGETlength) {
				&error(902);
				return;
			}
			$flag++;
			&extractVar($line);
			if ($line =~ /(Content-Length: )(\d+)/) {
				$querylength = $2;
				$flag = $maxHdrVars;
			}
		}
		if ($flag > $maxHdrVars + 1) {
			&error(903);
			return;
		}
		if ($querylength >= $maxPOSTlength) {
			&error(901);
			return;
		}

		# Read in remainder of the request and create an array
		# using the newline '\n' character as the separator.

		read($client, $querystring, $querylength);
		my @array = split("\n", $querystring);
		if ($#array >= $maxHdrVars) {
			&error(904);
			return;
		}

		# There may be additional variables after the Content-length
		# variable so scan the array for them here. We assume the very
		# last element in the array is the POSTed query string itself.

		for (my $index = 0; $index < $#array; $index++) {
			if(length($array[$index]) >= $maxGETlength) {
				&error(902);
				return;
			}
			&extractVar($array[$index]);
		}
		$ENV{'CONTENT_LENGTH'} = length($array[$#array]);

		# $qryfile serves as STDIN for any POST script that runs. I would
		# like to avoid using a file but haven't figured that one out
		# as yet. May not be possible without creating a child process.

		open(QSTR, ">$qryfile");
		print QSTR "$array[$#array]\n";
		close(QSTR);

		my $rs = `perl -T $cgibin$url <$qryfile`;
		if ($?) {
			&error(500, $?);
			return;
		} else {
			&printHeader unless ($rs =~ /^HTTP(.*) OK\Z/);
			print $client $rs;
			$BINSECkey += 101;
			if ($hackerSensor > 0) {$hackerSensor--}
			return;
		}
	}

	# If either the GET or POST above fail, we fall through to here
	# for a presumed HTML file specified in the URL. 

	if ((my $ct = isItHTML($url)) && (my $buffer = gulpFile($root.$url))) {
		$buffer =~ s/<!--#(.*?)-->/&SSI($1)/ge;
		printHeader($ct);
		print $client $buffer;
		$files_served++;
		if ($hackerSensor > 0) {$hackerSensor--}
		return;
	} else {
		&error(404);
		return;
	}
}

########################################################################
# Service & support routines.
########################################################################

sub extractVar {
	# Create environment variables using the request header
	# information coming from the client.
	my ($var, $val) = split(": ", @_[0]);
	$var =~ tr/-/_/;
	$var = join("", "HTTP_", $var);
	$ENV{$var} = $val;
}

sub printHeader {
	# Some CGI scripts print their own header stuff so this routine
	# is excuted only in the event that it's missing. See code above.
	my $ct = @_[0];
	my $xxx = HTTPtime();
	if (!defined($ct)) {$ct = "text/html";}
	print $client "$versionid 200 OK\n";
	print $client "$xxx\n";
	print $client "Content-type: $ct\n\n";
}

sub SSI {
	# Here we process some common server-side include statements.
	# We've removed server side includes that invoked scripts or
	# applications from the command line. Although it could be
	# done, use a Perl script instead. I'm of two minds with SSI
	# in any case (Bill).

	my ($cmd, $arg) = split('=', @_[0]);
	my $root = $PROC{'docroot'};
	$arg =~ s/"|'//g;

	if (gotNastyChars($arg)) {
		return "SSI Error: Escaped characters present! = $arg"
	}

	if ($cmd eq "include file") {
		return gulpFile($root.$arg);
	}

	if ($cmd eq "fsize file") {
		if (-e $root.$arg) {
			return -s $root.$arg;
		} else {
			return "SSI Error: $cmd = $arg";
		}
	}

	if ($cmd eq "flastmod file") {
		if (-e $root.$arg) {
			return -A $root.$arg;
		} else {
			return "SSI Error: $cmd = $arg";
		}
	}

	if ($cmd eq "echo var") {
		return $ENV{"$arg"};
	}

	return "SSI Error: $cmd = $arg - not found!";
}

sub gulpFile {
	my $file = @_[0];
	if (open(FH, $file)) {
		binmode(FH);
		my $size = -s FH;
		my $buff;
		read(FH, $buff, $size);
		close(FH);
		return "$buff";
	}
	return 0;
}

sub error {
	# The second variable passed to this routine, (if present) will
	# indicate the return value coming back from a failed script.
	my ($errno, $rv) = @_;
	my $vmsg = join(' ',"Server error:", $errno, $hackerSensor, $client->peerhost, $Date, $root.$url);
	my $GMT = HTTPtime;
	my $Hi;
	my $Lo;
	my $rm = "System return message";
	if (defined($rv)) {
		$Hi = $rv / 256;
		$Lo = $rv & 127;
		# Here we could detect nasty errors coming back from the script.
		# Some malformed query requests might be viewed as a hack attempt.
		# For this to be useful we would need a standard/convention for
		# the error codes used.
	}

	if ($errno >= 900) {
		# We could create a different hackerDelta for each type of error
		# based on potential damage to the system. At the moment it's
		# the same for all.
		$hackerSensor += $hackerDelta;
	} else {
		### Echo error to Client ###
		print $client "$versionid $errno OK\n";
		print $client "$GMT\n\n";
		print $client "<HTML><HEAD><TITLE>Server Error!</TITLE></HEAD>\n";
		print $client "<BODY><H1>Error: $errno</H1>\n";
		print $client "$errors{$errno}: <PRE> @_[1]</PRE><BR>\n";
		print $client "</BODY></HTML>\n";
	}

	### Echo error to Console ###
	print "$vmsg\n";
	if (defined($rv)) {print "$rm $Hi $Lo \n"}

	### Echo error to Server log(file) ###
	open(LOGS, ">>severlog.txt");
	print LOGS "$vmsg\n";
	if (defined($rv)) {print LOGS "$rm $Hi $Lo \n"}
	close(LOGS);
}


sub gotNastyChars {
	# Filenames with space characters are not a good idea so we've
	# rejected them in Pyxus. Use the underscore '_', instead to 
	# break up words.
	my $arg = $_[0];
	return ($arg =~ /[^A-Za-z0-9\.\-\_\/]+/g);
}

sub isACLscriptOK {
	# This routine is a test to see if the script is on our list
	# of explcitly approved scripts. See 'Pyxus.conf'. Remember,
	# filenames are case sensitive.
	my $u = @_[0];
	foreach my $script (@ACLscript) {
		if ($u =~ /\/${script}\Z/) {
			return 1;
		}
	}
	return 0;
}

sub isItHTML {
	# This routine checks requested file-types for its presence on our
	# secured file list. If it's OK then the 'Content-type' is returned.
	# See 'Pyxus.conf'. Filenames are case sensitive!
	my $u = @_[0];
	foreach my $filetype (%mimetype) {
		if ($u =~ /\.${filetype}\Z/) {
			return $mimetype{$filetype};
		}
	}
	return 0;
}

sub HTTPtime {
	my ($dd, $mm, $DD, $tt, $yy) = split(' ',localtime(time()+3600*$timezone));
	return "Date: $dd, $DD $mm $yy $tt GMT";
}

sub LOCALtime {
	my ($dd, $mm, $DD, $tt, $yy) = split(' ',localtime(time()));
	return "Date: $dd, $DD $mm $yy $tt LST";
}
