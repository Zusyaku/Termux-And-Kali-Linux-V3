Title: Pyxus Pure Perl Web Server
Description: Pure Perl HTTP (Web) Server For Windows Platforms
The Server was Coded Entirely in PERL. This server is not intended to compete with the Likes of Apache and Sambar Servers. It is fast and stable ... but is still in developmental stages (read BETA). It is not constructed nor does it operate like a typical webserver. Rather, it is a new type of webserver which is more "aware" of its environment and if it is being attacked. See our security page.
Pxyus is also simple and small by design. It consists of a two scripts, start and configure pyxus. Assuming a normal distribution of Perl is available on your computer then you probably have everything you need already! See the links page for more resources.
 If you need to adapt it for some reason, you have a good chance of getting it to work without blowing your budget or your mind. If you're really paranoid about security you can edit out (or in) those features you don't (do) want.
Pyxus is a single process server. Unlike other servers which delegate requests to a child process or other threads, Pyxus keeps to itself and tries to get files out as quickly as possible. 
While Pyxus is not intended for high volume sites or sites requiring high performance we feel it still has enough zip to service smaller sites. It is an excellent teaching tool and can be use to help students acquire a feel for the issues associated with server design.
If you're interested in helping to develop this server or if you have problems Please Email Us
.. We are aware that the logfile fills quickly. It can be disabled in the configuration file if desired.
Pyxus is very fast and provides modest CGI support which is customizable.
However, Pyxus is still a work in progress. While Pyxus supports most CGI scripts there may be some circumstances where things don't work as expected. That's why we need more eyeballs to help check things out!

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=286&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
