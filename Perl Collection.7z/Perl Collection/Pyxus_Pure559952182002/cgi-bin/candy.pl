#!h:\axeserver\perl\bin\perl.exe

use CGI;

$Date = localtime();

print "<body bgcolor=\"orange\">";

print "<font face=Arial size=2>
        Candy IS GREAT!";

print "<HR>";

print "<font color=RED face=Arial size=3>
        I LOVE CANDY!";

print "<HR>";

                
print "<font face=Arial color=Green size=4>
        System Date Time is $Date";
print "<HR>";

print "<font color=RED face=Arial size=3>
        I LOVE CANDY!";

print "<HR>";
print "<HR>";

print "<font color=RED face=Arial size=3>
        I LOVE CANDY!";

print "<HR>";

