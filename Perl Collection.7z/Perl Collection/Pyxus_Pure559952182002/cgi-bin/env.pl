#!/usr/bin/perl

use strict;
my $pt = "CGI Environment Variables";
open(STDOUT);

print "<html><head><title>$pt</title></head>
	<body background='images/wall.gif'>
	<div align='center'>
	<img src='images/title1.gif'>
	</div><p>
	<h3 align='center'>$pt</h3></p>
	<table style='font-family: Verdana; font-size: 10pt; valign: top'>
	<tr><td width='20%'></td><td>
	If you are using Pyxus as your server this test script should be removed
	 from the script directory and removed from the list of approved/secured 
	scripts. The information found here is generally considered quite sensitive and not 
	generally made available to the public.</td></tr></table>
	<br>
	<table style='font-family: Verdana; font-size: 8pt; valign: top'>";
my $i=1;
foreach my $key (sort keys %ENV) {
	print  "<tr><td width='20%'>&nbsp;</td><td>$i) $key</td><td>$ENV{$key}</td></tr>";
	$i++;
}
print "</table></body></html>";
close(STDOUT);
