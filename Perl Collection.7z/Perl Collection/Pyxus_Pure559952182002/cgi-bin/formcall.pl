#!H:\axeserver\perl\perl.exe

################################################################################
open(FILE1, "rfi_num.txt");
$rfinum = <FILE1>;
$rfinumber = $rfinum + 1;
close (FILE1);


open (OUTFILE, ">rfi_num.txt");
print OUTFILE "$rfinumber";
close OUTFILE;

$Date = localtime();


print<<end_rfi;
<HTML>
 <HEAD>

  <TITLE>Template</TITLE>
  
  <DIV ALIGN=LEFT>
  <P ALIGN=LEFT>
   <TABLE WIDTH="620" CELLPADDING="8" CELLSPACING="0" BORDER="0">
    <TR>
     <TD ROWSPAN="2" WIDTH="190" VALIGN=TOP>
      
     
     <TD ROWSPAN="2" WIDTH="573" VALIGN=TOP>
      <P ALIGN=CENTER>
       <FONT SIZE="5"><FONT COLOR="BLACK"><FONT FACE="Verdana,Arial,Times New I2"><B>SUBMIT
        FEEDBACK</B></FONT></FONT></FONT></P>
      <P ALIGN=CENTER>
       <FONT SIZE="2"><FONT COLOR="BLACK"><FONT FACE="Verdana,Arial,Times New I2">This
        is the RFI Form, Please Fill out as completely as Possible.</FONT></FONT></FONT></P>
 <FONT SIZE="2"><FONT COLOR="RED"><FONT FACE="Verdana,Arial,Times New I2"> Please input a COMPLETE Email Address If you want an Email Response</FONT></FONT></FONT></P>

      <FORM ACTION="formmail.pl" METHOD=POST>
    
      
      
      
                        <CENTER>
          <P ALIGN=CENTER>
           <TABLE CELLPADDING="2" CELLSPACING="1" BORDER="2">


		<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">RFI Number:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="rfi number" VALUE="$rfinumber" SIZE="15" MAXLENGTH="15"></TD>
            </TR>
	<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submission DTG:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submission DTG" VALUE="$Date" SIZE="50" MAXLENGTH="125"></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submitters Name:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submitters Name" VALUE=" " SIZE="50" MAXLENGTH="125"></TD>
            </TR>
           
		<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submitter EMail Address</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submitter EMail Address" SIZE="50" MAXLENGTH="125"></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submitter Phone</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submitter Phone" SIZE="50" MAXLENGTH="125"></TD>
            </TR>
 	<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT SIZE="2"><FONT FACE="Verdana,Arial,Helvetica,Geneva">Unit:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <TABLE WIDTH="100%" CELLPADDING="2" CELLSPACING="0" BORDER="0">
                <TR>
                 <TD VALIGN=TOP><DIV ALIGN=LEFT>
                  <P ALIGN=LEFT>
                   <INPUT TYPE=TEXT NAME="Unit" SIZE="25" MAXLENGTH="125"></TD>
                </TR>
               </TABLE></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               Priority:</TD>
             <TD VALIGN=TOP>
             
               <SELECT NAME="Priority" SIZE="1"><OPTION VALUE="immediate">Immediate(&lt;2hrs)<OPTION>6hours<OPTION>12hours<OPTION>24hours<OPTION>48hours<OPTION>5days<OPTION>7days</SELECT></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Requested Response Time (if Any):</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="LTIOV" SIZE="25" MAXLENGTH="40"> (any 
               date/time format)</TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Feedback Text:</FONT></FONT></P>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Max650chars-</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <TEXTAREA NAME="ORIGINAL RFI SUBMISSION" COLS="50" ROWS="10"></TEXTAREA></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               &nbsp;</TD>
             <TD VALIGN=TOP><CENTER>
              <P ALIGN=CENTER>
         <INPUT TYPE=SUBMIT NAME=action VALUE="SUBMIT">
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
              </TR>



	<TR>
             <TD VALIGN=TOP>
              
              <P ALIGN=LEFT>
               <INPUT TYPE=hidden NAME="RFI Response POC" VALUE="" SIZE="25" MAXLENGTH="115"></TD>
            </TR>


<TR>
             <TD VALIGN=TOP>
               <INPUT TYPE=Hidden NAME="RFI Response DTG" VALUE="" SIZE="25" MAXLENGTH="60"></TD>
            </TR>


            </TR>
           </TABLE></P>
          </CENTER></FORM>
         <P ALIGN=CENTER>
          <!-- $MVD$:spaceretainer() -->&nbsp;</P>
         <P ALIGN=CENTER>
          <!-- $MVD$:spaceretainer() -->&nbsp;</P>
         <P ALIGN=CENTER>
          <!-- $MVD$:spaceretainer() -->&nbsp;</P>
         <P>
          <!-- $MVD$:spaceretainer() -->&nbsp;</P>
         <P ALIGN=CENTER>
          <!-- $MVD$:spaceretainer() -->&nbsp;</P>
         <P>
          <!-- $MVD$:spaceretainer() -->&nbsp;</TD>
    </TR>
    <TR>
    </TR>
   </TABLE>
 </BODY>


</HTML>
end_rfi
print <<EOF;
EOF


