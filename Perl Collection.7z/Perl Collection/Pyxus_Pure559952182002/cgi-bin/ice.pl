#!h:\axeserver\perl\bin\perl.exe

use CGI;

$Date = localtime();

print "<body bgcolor=\"orange\">";

print "<font face=Arial size=2>
        THis is Arial Text Size Two!";

print "<HR>";

print "<font color=RED face=Arial size=3>
        THis is Arial Text Size Three Color Is RED!";

print "<HR>";

                
print "<font face=Arial color=Green size=4>
        System Date Time is $Date";

