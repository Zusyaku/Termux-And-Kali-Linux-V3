#/usr/bin/perl

use strict;

my $Date = localtime();
my %hash;
my $item;
my $key;
my $val;
my $line;
my @array;

open(STDOUT);
print "<html><head><title>This is a test script.</title></head>";
print "<body bgcolor=\"RFI\">";
print "<font face=Arial size=2>Your Feed Back Was Accepted!<HR>";
print "<font color=RED face=Arial size=3>Thank You Very Much!<HR>";      
print "<font face=Arial color=Green size=4>Your Feed back Was Logged using System Date Time $Date<br>";
print "POST information submitted:<hr>";
print "<font color=YELLOW face=Arial size=3>";

# TYPE 1 - Read in everything from STDIN because the server
#          appends a '\n' newline character at the end.
#open(STDIN);
#$line = <STDIN>;	
#chomp $line;	
#close(STDIN);

# TYPE 2 - Read in everyhing from STDIN using CONTENT_LENGTH variable.
open(STDIN);
read(STDIN, $line, $ENV{'CONTENT_LENGTH'});
close(STDIN);

# Depending on what we're doing with our forms we may need to massage
# the stuff coming in to remove escaped characters and the like.

@array = split("&", $line);
foreach $item (@array) {
	($key, $val) = split("=", $item);
	$key =~ tr/+/_/;
	my $uns = unescape($val);
	# If you use any of the vars in the hash to access files on the server,
	# make sure there's some protection in the way your script processes them.
	if ($uns =~ /\.\./) {
		exit(1);
	}
	$hash{$key} = unescape($uns);
}

print "Here's our form variables, <br><br>";

foreach $key (keys %hash) {
	print "$key = $hash{$key}<br>";
}

# From here on we should be able to do just about whatever we want.
# Virtually all our environment variables will be defined and the
# query string has been broken down into a hash.

print "<br>Here's our environment variables,<br><br>";

foreach $key (sort keys %ENV) {
	print "$key = $ENV{$key} <br>";
}

print "<body></html>";
close(STDOUT);

# If we have an error in our script and don't want to proceed then
# use 'exit(n)' with a non-zero value to terminate the server's response.
# The server will pick up on this and abandon the request. The error 
# should also show up in 'serverlog.txt'. So if care is taken in choosing
# error codes you can figure out what went wrong.

exit(0);

sub unescape {
	my $var = @_[0];
	$var =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;
	$var =~ s/\n/<br>/g;
	$var =~ tr/+/ /;
	return $var;
}
