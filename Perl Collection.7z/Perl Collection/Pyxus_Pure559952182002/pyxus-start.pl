use Tk;
use Tk::NoteBook;
use Tk::Frame;
use Tk::Text;
use Tk::Label;
use Tk::Button;
use Tk::Entry;
use Tk::Scrollbar;
use Tk::Checkbutton;
use IO::Socket;
use Socket;
use English;
use Tk::DialogBox;
use Tk::Listbox;
#use strict;
use IO::Socket;
use Tk::MenuButton;


my $mw = MainWindow->new();
$mw->title("Pyxus Web Server");


my $menubar = $mw->Frame(-relief=>"raised",-borderwidth=>2);
 $menubar->pack(-side=>"top", -fill=>"x");
 my  $filebutton = $menubar->Menubutton(-text=>"Start Web Server",-underline => 0);  
 my  $filemenu = $filebutton->Menu();
     $filebutton->configure(-menu=>$filemenu);
     $filemenu->command(-command => \&start_pyxus,-label => "Start Server",-underline => 0); 
     $filemenu->command(-label => "Exit",-command => \&exit,-underline => 1);  

                            
 my  $configbutton = $menubar->Menubutton(-text=>"Configure Pyxus",-underline => 0);  
 my  $configmenu = $configbutton->Menu();
     $configbutton->configure(-menu=>$configmenu);
                     $configmenu->command(-command => \&edit_config,-label => "Configure Server",-underline => 0); 

 my     $logbutton = $menubar->Menubutton(-text=>"Log",-underline => 0); 
 my     $logmenu = $logbutton->Menu();
        $logbutton->command(-command => \&view_log,-label => "View Logfile", -underline => 0); 
        $logbutton->separator;
        $logbutton->command(-command => \&clear_log,-label => "Clear Logfile", -underline => 0); 


my   $helpbutton = $menubar->Menubutton(-text=>"Help",-underline => 0); 
my   $helpmenu = $helpbutton->Menu();
     $helpmenu->command(-command => \&about_choice,-label => "About Pyxus Web Server", -underline => 0); # A in About
     $helpbutton->configure(-menu=>$helpmenu);
                    $helpmenu->command(-command => \&show_help,-label => "Help", -underline => 0); # A in About






$filebutton->pack(-side=>"left");
$configbutton->pack(-side=>"left");
$helpbutton->pack(-side=>"right");
$logbutton->pack(-side=>"right");
$menubar->pack(-side=>"top", -fill=>"x");
my $status = $mw->Label(-text=>"Ready...",-borderwidth=>2,-anchor=>"w");
$status->pack(-side=>"bottom", -fill=>"x");










my $lookup_frame = $mw->Frame()->pack(-expand => '1', -fill => 'both', -side => 'top');
my $scroll = $mw->Scrollbar();
$scroll->pack(-side => 'right', -fill => 'y');
my $display = $mw->Text(-height => '25', -width => '85', -yscrollcommand => ['set', $scroll]) ->pack(-side => 'top', -expand => '1', -fill => 'both');
$scroll->configure(-command => ['yview', $display]);




 my %PROC;
open(PROC, "pyxus.conf") or die "Where is the PYXUS Configuration FILE?\n";
while(<PROC>) {
	chomp;
	my @allconf = split(/\n/);
	foreach my $line (@allconf) {
			unless($line =~ /^#/) {
				# Remove white space
				$line =~ s/\s+|\t+//g;
				$line =~ /(.*)=(.*)/;
				$PROC{$1} = $2;
			}
		}
	}
close(PROC);

my $port = $PROC{'port'};
my $maxconn = $PROC{'maxconn'};
my $root = $PROC{'docroot'};
my $cgibin = $PROC{'cgibin'};
my $BINSECkey = $PROC{'binseckey'};
my $enablelogs = $PROC{'enablelogs'};
my $maxGETlength = $PROC{'maxGETlength'};
my $maxPOSTlength = $PROC{'maxPOSTlength'};
my $timezone = $PROC{'timezone'};

my @ACLscript = split(',', $PROC{'securedscripts'});

my @ACLfiletypes = split(',', $PROC{'securedfiletypes'});
my %mimetype;
my $index;
for ($index = 0; $index <= $#ACLfiletypes; $index += 2) {
	$mimetype{$ACLfiletypes[$index]} = $ACLfiletypes[$index + 1];
}

	
%newconfig = 

my @promote;
$promote[2]="Mollensoft Software & Monashee Information Systems - Pyxus Http Server ver 2.2\n";
$promote[3]="              PYXUS = \"Fast Stream\"\n\n";
$promote[6]="\nPyxus is pre-configured to operate from the \"C:\\Pyxus\" Directory, if you have installed into a different directory please verify that your configuration (Especially the Root Path) is updated as appropriate.\n"; 
$promote[7]="\nTo Start the Pyxus Web Server, Verify your Server Configuration and Then select \"Start Server\" from the menu bar \"Start\/Stop Server\" Menu Selection.\n\n";
$promote[8]="To make Changes to your server select the \"Server Config\" button on the menubar\n"; 
$promote[9]="\nBelow is your Current Server Configuration....\n";
$promote[11]="Server Port: $port\n";
$promote[12]="Maximum Connections: $maxconn\n";
$promote[13]="Server Root Directory: $root\n";
$promote[14]="Server CGI-BIN Directory: $cgibin\n";
$promote[15]="Server Initial Security Key: $BINSECkey\n";
$promote[16]="Server Enable Logging: $enablelogs\n";
$promote[17]="Server Max Get Length: $maxGETlength\n";
$promote[18]="Server Max Post Length: $maxPOSTlength\n";
$promote[19]="Server Time Zone: $timezone\n";
$promote[20]="Server Available Scripts: @ACLscript\n";
$promote[21]="Server Supported File Types: @ACLfiletypes\n";

 	      $display-> yview('end');
	      $mw->update;
              $display -> insert('end',"@promote");





########################################################################
sub bind_message {
  my ($widget, $msg) = @_;
}

########################################################################
sub start_pyxus {
exec 'pyxus-main.pl';
}


sub edit_config {

  
        my $mp=MainWindow->new;
        $mp->title("Edit Pyxus Configuration Variables");
        my $label4 = $mp->Label(-text => "Enter Values to Suite your Needs. \n If you dont know what to change then dont change anything. \n\n If you installed Pyxus into a directory other than \"c:\\pyxus\" \n then change the root path to reflect where you installed Pyxus.\n\n To Change Values...\n Change Only the Value after the \"=\" For Example to change the Service Port\n from 80 to 90, Change the text \n value on the line \"port=80\" to read \"port=90\"",-font => "Verdana 7",-foreground => "Dark Red");
        $label4->pack(-side=>"top", -expand=>1,-padx=>2, -pady=>2);
        my $xwtext1 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext2 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext3 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext4 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext5 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext6 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext7 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext8 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext9 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext10 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext11 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext12 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext13 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext14 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
        my $xwtext15 = $mp ->Text ('-width'=> 60, '-height'=>1)->pack(-padx=>2, -pady=>2);
    
         open(INPUT, "pyxus.conf");
         my @data = <INPUT>;
         close(INPUT);
     
        $xwtext1->insert('end',"$data[0]");
        $xwtext2->insert('end',"$data[1]");
        $xwtext3->insert('end',"$data[2]");
        $xwtext4->insert('end',"$data[3]");
        $xwtext5->insert('end',"$data[4]");
        $xwtext6->insert('end',"$data[5]");
        $xwtext7->insert('end',"$data[6]");
        $xwtext8->insert('end',"$data[7]");
        $xwtext9->insert('end',"$data[8]");
        $xwtext10->insert('end',"$data[9]");
        $xwtext11->insert('end',"$data[10]");
        $xwtext12->insert('end',"$data[11]");
        $xwtext13->insert('end',"$data[12]");
        $xwtext14->insert('end',"$data[13]");
        $xwtext15->insert('end',"$data[14]");
        
        my $label9 = $mp->Label(-text => "Clicking the \"Save\" button saves new values. \nClicking \"Quit\"with out clicking the \"Save\" \nbutton keeps the current Configuration intact.",-font => "Verdana 7",-foreground => "Dark Red");
        $label9->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
        $mp->Button(-text => 'Quit',-command => [$mp => 'destroy'])->pack(-side=>left,-padx=>10, -pady=>10);
        $mp->Button(-text => 'Save',-command => sub{save_config($xwtext1,$xwtext2, $xwtext3, $xwtext4, $xwtext5, $xwtext6, $xwtext7, $xwtext8, $xwtext9, $xwtext10, $xwtext11, $xwtext12, $xwtext13, $xwtext14, $xwtext15)})->pack(-side=>right,-padx=>25, -pady=>25);
 
                 }

sub save_config {
	          
	    my ($xwtext1, $xwtext2, $xwtext3, $xwtext4, $xwtext5, $xwtext6, $xwtext7, $xwtext8, $xwtext9, $xwtext10, $xwtext11, $xwtext12, $xwtext13, $xwtext14, $xwtext15) = @_;
            my $text1 = $xwtext1 ->Contents(); 
            my $text2 = $xwtext2 ->Contents(); 
            my $text3 = $xwtext3 ->Contents(); 
            my $text4 = $xwtext4 ->Contents(); 
            my $text5 = $xwtext5 ->Contents(); 
            my $text6 = $xwtext6 ->Contents(); 
            my $text7 = $xwtext7 ->Contents(); 
            my $text8 = $xwtext8 ->Contents(); 
            my $text9 = $xwtext9 ->Contents(); 
            my $text10 = $xwtext10 ->Contents(); 
            my $text11 = $xwtext11 ->Contents(); 
            my $text12 = $xwtext12 ->Contents(); 
            my $text13 = $xwtext13 ->Contents(); 
            my $text14 = $xwtext14 ->Contents(); 
            my $text15 = $xwtext15 ->Contents(); 
            chop $text1;  
            chop $text2;       
            chop $text3;       
            chop $text4;       
            chop $text5; 
            chop $text6;                       
            chop $text7;                       
            chop $text8;                       
            chop $text9;                       
            chop $text10;                       
            chop $text11;                       
            chop $text12;                       
            chop $text13;                       
            chop $text14;                       
            chop $text15;                       
                                                       
            open (HOSTS, ">pyxus.conf")|| die ("Cannot Open Hosts/IP Database File");
            print HOSTS "$text1$text2$text3$text4$text5$text6$text7$text8$text9$text10$text11$text12$text13$text14$text15";
            close(HOSTS);
            $status->configure(-text=>"Pyxus config updated...");
                 }



sub about_choice {
      
      my $xw=MainWindow->new;
      $xw->title("About Pyxus Pure Perl Web Server");
      my $label = $xw->Label(-text => "Pyxus HTTP Server For Windows",-font => "Verdana",-foreground => "Dark Red");
      my $label2 = $xw->Label(-text => "Courtesy",-font => "Arial 16",-foreground => "Black");
      my $label3 = $xw->Label(-text => "Monashee Information Systems\n & \n Mollensoft Software",-font => "Arial 10",-foreground => "Dark Green");
       $label->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
       $label2->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
       $label3->pack(-side=>"top", -expand=>1,-padx=>10, -pady=>10);
      $xw->Button(-text => 'Exit',-command => [$xw => 'destroy'])->pack;
      $status->configure(-text=>"about Pyxus Web Server");

}



sub show_help{
	          
      
 my $main = new MainWindow;
        $main->title("Pyuxs Help");
        $main->Button(-text => 'Exit',-command => [$main => 'destroy'])->pack(-side=>"bottom");
 my $text_frame = $main->Frame()->pack(-expand => '1', -fill => 'both', -side => 'top');


 my $scroll = $main->Scrollbar();
 $scroll->pack(-side => 'right', -fill => 'y');
 my $helpdisplay = $main->Text(-height => '25', -width => '85', -yscrollcommand => ['set', $scroll]) ->pack(-side => 'top', -expand => '1', -fill =>'both'); 


  open (HELPF, "help.txt")|| die ("Cannot Open Help File");
            my @helpfilez = <HELPF>;
            close(HELPF);
                    foreach (@helpfilez) {
                       $helpdisplay->insert('end', $_);
       $scroll->configure(-command => ['yview', $helpdisplay]);
                              }

                                         
               }






sub view_log {
my $logmain = new MainWindow;
        $logmain->title("Pyuxs Log");
        $logmain->Button(-text => 'Exit',-command => [$logmain => 'destroy'])->pack(-side=>"bottom");
 my $logtext_frame = $logmain->Frame()->pack(-expand => '1', -fill => 'both', -side => 'top');


 my $scroll = $logmain->Scrollbar();
 $scroll->pack(-side => 'right', -fill => 'y');
 my $loghelpdisplay = $logmain->Text(-height => '25', -width => '85', -yscrollcommand => ['set', $scroll]) ->pack(-side => 'top', -expand => '1', -fill =>'both'); 


  open (LOG1, "serverlog.txt")|| die ("Cannot Open Log File");
            my @logfilez = <LOG1>;
            close(LOG1);
                    foreach (@logfilez) {
                       #chomp $_;
                       $loghelpdisplay->insert('end', $_);
       $scroll->configure(-command => ['yview', $loghelpdisplay]);
                              }

                                         
               }

sub clear_log {
            open (LOG, ">serverlog.txt")|| die ("Cannot Open Logfile File");
            close(LOG);

}
















MainLoop;

