Title: SpiderTest
Description: You have spent a lot of time and effort designing your site, congratulations! Are you sure that all your links are pointing to the right files or do you want your visitors to get those annoying 404 errors? Are your metatags search-engine ready and compatible with the very competitive ranking standards? 
SpiderTest is a simple script that answers all these questions by digging deep into your pages. It looks for broken internal and external links, mailto links, frames, metatags, titles, keywords, descriptions, ...etc and gives a detailed report with an analysis of your errors and proposes solutions according to the most recent HTML standards.
You can generate more traffic to your site by offering this service to your visitors who can read the reports or have them emailed to them.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=333&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
