#!/usr/bin/perl
#change to your server setting
$CGI_NAME ='SpiderTest';
$VERSION='2.0';
#                                                                                       #
##############################################################################
# This is a freeware script written by Anas Elhalabi, MD.                                               
# You can change anything you want in it, but let me tell you something                     
# It won't really work if you damage the core of it.                                                        
# Other awsome scripts are available on  http://perlmart.cjb.net                                   
# If you need help installing this script you can always go to                                        
# http://perlmart.cjb.net      or email me at       aelhalabi@hotmail.com
#
# REMOVAL OF THE LINKS TO PERLMART AND THE MENTION OF THE AUTHOR IS A CLEAR VIOLATION OF THIS FREE LICENSE
#
# This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA                             
##############################################################################
########################################
## CONFIGURATION                      ##
########################################
$top = "top.txt";
$footer = "footer.txt";
$font_color_error = "#FF0000";
$font_color_ok = "#009900";
$size = "30";                       
$style="BACKGROUND-COLOR: #DEE3E7; BORDER-LEFT: #234D76 solid 1; BORDER-RIGHT: #234D76 solid 1; BORDER-TOP: #234D76 solid 1; BORDER-BOTTOM: #234D76 solid 1; COLOR: #234D76; FONT-FAMILY: Verdana, Geneva, Arial, Helvetica, sans-serif; FONT-SIZE: 10px";
# path to sendmail :
$sendmail = "/usr/sbin/sendmail";    #use our script ServTest to find out the path to perl in your server. Available for free at #http://perlmart.cjb.net
# Your email watch out for the @ and write \@ instead:
$myemail = "you\@yoursite.com";   	#change to your email address
# domains authorized to access the script and execute it :
#change to your site
@adresses =                        
	(
	'your-site.com',
	'perlmart.cjb.net',
	'localhost'
	);
# Change your-site.com to   the url of your site.
#########################################################################
## MODIFYING THE FOLLOWING LINES IS ILLEGAL AND WE REALLY MEAN THAT AND ENFORCE IT !! ##
########################################################################
if ($ENV{'HTTP_REFERER'})
{
foreach $adresses(@adresses)
	{
	if ($ENV{'HTTP_REFERER'} =~ /$adresse/i) { $referer =1; last; }
	}
}
else { $referer=1; }
if ($referer != 1)
   {
$aff="Sorry, you can\'t use this script from this address  :<br>$ENV{'HTTP_REFERER'} !\n";
$tikshbila = "<hr width=50% size=1 align=left><font size=1>$CGI_NAME v $VERSION By Anas Elhalabi.<br>\� Copyright <a href=\"http://perlmart.cjb.net\" target=\"_top\" class=\"link\">PerlMart</a></font>";
&display; exit;
            }
read(STDIN,$temp,$ENV{'CONTENT_LENGTH'});
{$temp = "$temp\&$ENV{'QUERY_STRING'}";}
@pairs=split(/&/,$temp);
foreach $item(@pairs)
 {
  ($mots,$content)=split(/=/,$item,2);
  $content=~tr/+/ /;
  $content=~s/%(..)/pack("c",hex($1))/ge;
$content{$mots}="$content";
$champs{$mots} .= "\0" if (defined($champs{$mots}));
      $champs{$mots} .= "$content";
 }
$site_rjel = 'http://'.($ENV{'SERVER_NAME'} || $ENV{'HTTP_HOST'});
$script =($ENV{'REQUEST_URI'} || $ENV{'SCRIPT_NAME'});
$script =~ s/\?.*//gs;
$cgi='http://'.($ENV{'SERVER_NAME'} || $ENV{'HTTP_HOST'}).$script;
$site=$champs{url};
if ($champs{test} eq 'meta') { &debut; &test_meta; &display; exit; }
elsif ($champs{test} eq 'links') { &debut; &test_url; &display; exit }
elsif (defined $champs{email}) { &envoi; &display; exit; }
else { &form_test; &display; exit }
sub debut
{
require LWP::UserAgent;
require HTTP::Request;
if (($site !~ /^http:\/\//i) && ($site !~ /^https:\/\//i)) { $site="http://$site";}
if (($site ne '') && ($site ne 'http://')) { $kifash_site = &verifie_url($site); }
$tikshbila = "<hr width=50% size=1 align=left><font size=1>$CGI_NAME v$VERSION By Anas Elhalabi.<br>\� Copyright <a href=\"http://perlmart.cjb.net\" target=\"_top\" class=\"link\">PerlMart</a></font>";
if (($kifash_site ne 'ok') || ($site eq '') || ($site eq 'http://'))
   {
   $aff.="<b>The Url &quot;$site&quot is incorrect !</b><br>error $kifash_site !\n";
   &form_test;
   &display;
   exit;
   }
use LWP::Simple;
$ligne = get ($site);
}
sub test_url
{
@LOIG2 = split (/\n/, $ligne);
$ligne =~ s/mailto:/MAILTO:/g;
$ligne =~ s/Mailto:/MAILTO:/g;
$ligne =~ s/MAilto:/MAILTO:/g;
$ligne =~ s/href/HREF/g;
$ligne =~ s/Href/HREF/g;
$ligne =~ s/HRef/HREF/g;
$ligne =~ s/HREF=\"([^\"]+)\"/\|\|\|%%%%%%%%%$1\|\|\|/g;
@LOIG = split (/\|\|\|/, $ligne);
$i=0; $m=0; $j=0; $ma=0; $li=0; $liext=0;
$c_li=0; $c_i=0; $c_liext=0; $c_fra=0; $ln=0; $lf=0; $l_s=0;
$site2=$site;
$site2 =~ s/HTTP:\/\//http:\/\//g; $site2 =~ s/Http:\/\//http:\/\//g; $site2 =~ s/http:\/\///g; $http='http://';
@gra  = split (/\//, $site2);
$rjel_site2 = $gra[0];
foreach $gra(@gra) { $m++; $part[$m]=$gra; }
$m2=$m;
if ($m != 0) { foreach $m(1..$m)
                       {
                         $m3++;
                         if ($part[$m] =~ /\.htm|\.html|\.shtml|\.phtml|\.phtm|\.shtm|\.php|\.php3|\.php4|\.pl|\.cgi|\.asp|\.jsp|\.cfm/) {$part[$m]=''; }
                         $reppage.="$part[$m]"; if ($m3 != $m2) { $reppage.="/"; }
                         }
                 }
if ($m == 0) {$reppage=$rjel_site2; }
foreach $LOIG(@LOIG)
        {
          if ($LOIG =~ /%%%%%%%%/)
             {
             $LOIG =~ s/%%%%%%%%%//g;
               if ($LOIG =~ /javascript/i) { $i++; $java[$i]=$LOIG; next; }
             if ($LOIG =~ /MAILTO:/) { $i++; $LOIG =~ s/MAILTO://g; $mail[$i]=$LOIG; next; }
             if ($LOIG !~ /^http:\/\//i) {
             $i++;
                if ($LOIG =~ /^..\//) { $LOIG =~ s/\.\.\///g; $link[$i]="$http$rjel_site2/$LOIG"; next; }
               if ($LOIG =~ /^.\//) { $LOIG =~ s/\.\///g; $link[$i]="$http$rjel_site2/$LOIG"; next; }
               if ($LOIG =~ /^...\//) { $LOIG =~ s/\.\.\.\///g; $link[$i]="$http$rjel_site2/$LOIG"; next; }
               if (($LOIG !~ /^..\//) && ($LOIG !~ /^.\//) && ($LOIG !~ /^...\//))
                  {
                   if ($LOIG =~ /^https:\/\//i)  { $link_sec[$i]=$LOIG; next; }
                   if ($LOIG =~ /^ftp:\/\//i) { $link_ftp[$i]=$LOIG; next; }
                   if ($LOIG =~ /^news:/i) { $link_news[$i]=$LOIG; next; }
                   if ($LOIG !~ /^\//)  { $link[$i]="$reppage/$LOIG"; $link[$i] =~ s/\/\//\//g; $link[$i]="$http$link[$i]"; next; }
                   if ($LOIG =~ /^\//)  { $link[$i]="$http$rjel_site2$LOIG"; next; }
                  }
                }
             if ($LOIG =~ /^http:\/\//i)
                {
                $i++;
                if ($LOIG =~ /$rjel_site2/i) { $link[$i]=$LOIG; }
                if ($LOIG !~ /$rjel_site2/i) { $link_ext[$i]=$LOIG;}
                }
             }
        }
foreach $i(1..$i)
        {
          if ($link[$i])
          {
           $li++; 
          $kifash = &verifie_url($link[$i]);
          if ($kifash eq "ok")
             {
           $affi[$li]="$link[$i] : <font color=\"$font_color_ok\"><b>$kifash</b></font> (<a href=\"$link[$i]\" class=link target=_blank>view</a>) - (<a href=\"$cgi?test=links&url=$link[$i]\" class=link>test</a>)<br>\n";
           $messa[$li]="$link[$i] : $kifash\n";
                     }
            else
            {
              $c_li++; $c_i++;
            $affi[$li]="$link[$i] : <font color=\"$font_color_error\">error </font> (<a href=\"$link[$i]\" class=link target=_blank>view</a>)<br>\n";
            $messa[$li]="$link[$i] : error $kifash\n";
            }
          }
          if ($link_ext[$i])
          {
           $liext++;
          $kifash = &verifie_url($link_ext[$i]);
          if ($kifash eq "ok")
             {
           $affic[$liext]="$link_ext[$i] : <font color=\"$font_color_ok\"><b>$kifash</b></font> (<a href=\"$link_ext[$i]\" class=link target=_blank>view</a>) - (<a href=\"$cgi?test=links&url=$link_ext[$i]\" class=link>test</a>)<br>\n";
           $messas[$liext]="$link_ext[$i] : $kifash\n";
                     }
            else
            {
               $c_liext++; $c_i++;
            $affic[$liext]="$link_ext[$i] : <font color=\"$font_color_error\">error $kifash</font> (<a href=\"$link_ext[$i]\" class=link target=_blank>view</a>)<br>\n";
            $messas[$liext]="$link_ext[$i] : error $kifash\n";
            }
          }
          if ($java[$i]) { $j++; $java[$j] = $java[$i]; }
          if ($mail[$i]) { $ma++; $mail[$ma] = $mail[$i]; }
          if ($link_news[$i]) { $ln++; $link_news[$ln] = $link_news[$i]; }
          if ($link_ftp[$i]) { $lf++; $link_ftp[$lf] = $link_ftp[$i]; } 
          if ($link_sec[$i]) { $l_s++; $link_sec[$l_s] = $link_sec[$i]; }
      }
$aff.="<br><b>$li internal link(s).</b><br>\n";
$mess.="\n$li internal link(s).\n";
foreach $li(1..$li) { $aff.=$affi[$li]; $mess.=$messa[$li]; }
$aff.="<br><b>$liext external link(s).</b><br>\n";
$mess.="\n$liext external link(s).\n";
foreach $liext(1..$liext) { $aff.=$affic[$liext]; $mess.=$messas[$liext]; }
$aff.="<br><b>$j Javascript link(s).</b> -<br>";
$mess.="\n$j link(s) Javascript link(s). -\n";
 foreach $j(1..$j)
         {
        $aff.="$java[$j]<br>\n";
        $mess.="$java[$j]\n";
         }
$aff.="<br><b>$ma Mailto link(s).</b><br>";
$mess.="\n$ma Mailto link(s).\n";
foreach $ma(1..$ma)
         {
         if ( &verifie_email($mail[$ma]) == 0) { $aff.="$mail[$ma] : <font color=\"$font_color_error\">invalid email</font><br>\n";  $mess.="$mail[$ma] : invalid email\n"; }
         if ( &verifie_email($mail[$ma]) == 1) { $aff.="$mail[$ma] : <font color=\"$font_color_ok\">x</font><br>\n";   $mess.="$mail[$ma] : correct syntax\n"; }
           }
$aff.="<br><b>$ln New Link(s).</b> -<br>";
$mess.="\n$ln link(s) news. -\n";
 foreach $ln(1..$ln)
         {
        $aff.="$link_news[$ln]<br>\n";
        $mess.="$link_news[$ln]\n";
         }
$aff.="<br><b>$lf Ftp link(s).</b> -<br>";
$mess.="\n$lf Ftp link(s). -\n";
 foreach $lf(1..$lf)
         {
        $aff.="$link_ftp[$lf]<br>\n";
        $mess.="$link_ftp[$lf]\n";
         }
$aff.="<br><b>$l_s https link(s).</b> -<br>";
$mess.="\n$l_s https link(s). -\n";
 foreach $lf(1..$lf)
         {
        $aff.="$link_sec[$l_s]<br>\n";
        $mess.="$link_sec[$l_s]\n";
         }         
$f=0; $fra=0;
foreach $loig2(@LOIG2)
        {
if ($loig2 =~ /<frame/i)
            {
             if ($loig2 =~ /src=\"([^\"]+)\"/i)
               {
                 $fra++;
                 $frame[$fra] = $1;
                  if ($frame[$fra]!~ /^http:\/\//)
                     {
                     if ($frame[$fra] =~ /^...\//) { $frame[$fra] =~ s/\.\.\.\///g; $frame[$fra]="$http$rjel_site2/$frame[$fra]"; next; }
                     if ($frame[$fra] =~ /^..\//) { $frame[$fra] =~ s/\.\.\///g; $frame[$fra]="$http$rjel_site2/$frame[$fra]"; next; }
                     if ($frame[$fra] =~ /^.\//) { $frame[$fra] =~ s/\.\///g; $frame[$fra]="$http$rjel_site2/$frame[$fra]"; next; }
                     if (($frame[$fra] !~ /^..\//) && ($frame[$fra] !~ /^.\//) && ($frame[$fra] !~ /^...\//))
                        {
                        if ($frame[$fra] =~ /^https:\/\//i)  { next; }
                        if ($frame[$fra] !~ /^\//)  { $frame[$fra]="$reppage/$frame[$fra]";  $frame[$fra] =~ s/\/\//\//g; $frame[$fra]="$http$frame[$fra]"; next; }
                        if ($frame[$fra]=~ /^\//)  { $frame[$fra]="$http$rjel_site2$frame[$fra]"; next; }
                        }
                      }
              }    # fin if src
            }  # fin if <frame

        }  # fin foreach
$aff1.="<b>$fra frame(s).</b><br>";
$mess1.="$fra frame(s).\n";
foreach $fra(1..$fra)
        {
          $kifash = &verifie_url($frame[$fra]);
             if ($kifash eq "ok")
             {
           $aff1.="$frame[$fra] : <font color=\"$font_color_ok\"><b>$kifash</b></font> (<a href=\"$frame[$fra]\" class=link target=_blank>view</a>) - (<a href=\"$cgi?test=links&url=$frame[$fra]\" class=link>test</a>)<br>\n";
           $mess1.="$frame[$fra] : $kifash\n";
                     }
            else
            {
              $c_fra++;
            $aff1.="$frame[$fra] : <font color=\"$font_color_error\">error $kifash</font> (<a href=\"$frame[$fra]\" class=link target=_blank>view</a>)<br>\n";
            $mess1.="$frame[$fra] : error $kifash\n";
            }
        }
$aff0.="<b>Results for the page : $site</b><br><br>\n";
$mess0.="Results of the Link Test for the page :\n$site\n\n";
$aff0.="<table border=0 cellspacing=0 cellpadding=1>\n";
$aff0.="<tr class=text><td class=text>Number of frames :</td><td class=text><b>$fra</b> of which <b>$c_fra</b> are broken.</td></tr>\n";
$aff0.="<tr class=text><td class=text>Number of links :</td><td class=text><b>$i</b> of which <b>$c_i</b> are broken.</td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- internal links :</td><td class=text><b>$li</b> of which <b>$c_li</b> are broken.</td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- external links :</td><td class=text><b>$liext</b> of which <b>$c_liext</b> are broken.</td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- mailto links:</td><td class=text><b>$ma</b></td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- javascript links:</td><td class=text><b>$j</b></td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- news links:</td><td class=text><b>$ln</b></td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- ftp links:</td><td class=text><b>$lf</b></td></tr>\n";
$aff0.="<tr class=text><td class=text>&nbsp;&nbsp;&nbsp;- https links:</td><td class=text><b>$l_s</b></td></tr>\n";
$aff0.="</table><br>";
$mess0.="Number of frames : $fra of which $c_fra are broken\n";
$mess0.="Number of links : $i of which $c_i are broken.\n";
$mess0.="   - internal links : $li of which $c_li are broken.\n";
$mess0.="   - external links : $liext of which $c_liext are broken.\n";
$mess0.="   - mailto links : $ma\n";
$mess0.="   - javascript links : $j\n";
$mess0.="   - news links : $ln\n";
$mess0.="   - ftp links : $lf\n";
$mess0.="   - https links : $l_s\n\n";
$aff="$aff0$aff1$aff";
$mess="$mess0$mess1$mess";
&form_envoi;
&form_test;
}
###########
sub test_meta
{
$i=0;
@LOIG = split (/\n/, $ligne);
$aff.="<b>Results for the page : $site</b><br><br>\n";
$mess.="Results of the Metatag test for the page :\n$site\n\n";
if ($ligne =~ /<TITLE>([^\"]+)<\/TITLE>/i)
            {
            $i++;
            $ounwan=$1; $t_titre = length $ounwan;
            }
foreach $loig(@LOIG)
        {
         if ($loig =~ /keywords/i)
            {
               $i++;
            if ($loig=~ /content=\"([^\"]+)\"/i)
               {
               $keywords=$1; $t_kk = length $keywords;
               $n_mc=0;
               @MC = split (/,/, $keywords);
               foreach $MC(@MC) { $n_mc++; }
               $keywords =~ s/,/ /g;
               }
             }
          if ($loig =~ /description/i)
            {
               $i++;
            if ($loig=~ /content=\"([^\"]+)\"/i)
               {
               $description=$1; $t_desc = length $description;
               }
             }
        }
$aff.="<b>Number of found Tags : $i </b><br><br>";
$mess.="Number of found Tags : $i\n\n";
if (!$ounwan) { $aff.="<b>Titre :</b><br> <font color=\"$font_color_error\">Not found !<br>Your site\'s title must between the &lt;HEAD&gt; and  &lt;/HEAD&gt; tags like this:<br>&lt;TITLE&gt;Your Page Title&lt;/TITLE&gt;.</font><br><br>\n";
            $mess.="Titre :\n Not found !\nYour site\'s title must between the &lt;HEAD&gt; and &lt;/HEAD&gt; tags like this:<br>&lt;TITLE&gt;Your Page Title&lt;/TITLE&gt;.\n\n"; }
if ($ounwan)
   {
   $aff.="<b>Your site\'s title:</b><br>$ounwan<br>\n";
   $mess.="Your site\'s title:\n$ounwan\n";
   if ($t_titre > 100)
      {
      $aff.= "<font color=\"$font_color_error\">Your title is $t_titre characters long.<br>You can use up to 100 characters long.<br>Please shorten it.</font><br>";
      $mess.= "Your title is $t_titre characters long.\nYou can use up to 100 characters.\nPlease shorten it.\n";
      }
   if ($t_titre <= 100)
      {
      $aff.="<font color=\"$font_color_ok\">Your title is $t_titre characters long.<br>You can use up to 100 characters long.<br>You are using $t_titre% of this tag.<br></font>\n";
      $mess.="Your title is $t_titre characters long.\nYou can use up to 100 characters.\nYou are using $t_titre% of this tag.\n";
      }
   $aff.="<br>";
   $mess.="\n";
   }
if (!$description) {
  $aff.="<b>Your site\'s description :</b><br> <font color=\"$font_color_error\">Not found !<br>Your site\'s description must be between the &lt;HEAD&gt; and &lt;/HEAD&gt; tags like this:<br>&lt;META NAME=\"description\" Content=\"Your site\'s description\"&gt;.</font><br><br>\n";
  $mess.="Your site\'s description :\n Not found !\nYour site\'s description must be between the &lt;HEAD&gt; and &lt;/HEAD&gt; tags like this:\n&lt;META NAME=&quot;description&quot; Content=&quot;Your site\'s description&quot;&gt;.\n\n"; }
if ($description)
   {
    $aff.="<b>Your site\'s description :</b><br>$description<br>\n";
    $mess.="Your site\'s description :\n$description\n";
    $d_pourcent = sprintf("%.2f",($t_desc / 200) * 100);
    if ($t_desc > 200)
       {
       $aff.= "<font color=\"$font_color_error\">Your description is  $t_desc characters long.<br>You can use up to 200 characters long.<br>Think about shortening it.</font><br>\n";
       $mess.= "Your description is  $t_desc characters.\nYou can use up to 200 characters.\nThink about shortening it.\n";
       }
   if ($t_desc <= 200)
      {
      $aff.="<font color=\"$font_color_ok\">Your description is  $t_desc characters long.<br>You can use up to 200 characters long.<br>You are using $d_pourcent% of this tag.<br></font>\n";
      $mess.="Your description is  $t_desc characters.\nYou can use up to 200 characters.\nYou are using $d_pourcent% of this tag.\n";
      }
     $aff.="<br>";
     $mess.="\n";
     }
if (!$keywords)
   { 
   $aff.="<b>Your site\'s keywords:</b><br> <font color=\"$font_color_error\">Not found !<br>Your page\'s keywords must be between &lt;HEAD&gt; and &lt;/HEAD&gt; tags like this:<br>&lt;META NAME=\"keywords\" Content=\"keywords separated by comas\"&gt;.</font><br><br>\n";
   $mess.="Your site\'s keywords :\nNot found !\nYour page\'s keywords must be between &lt;HEAD&gt; and &lt;/HEAD&gt; tags like this:\n&lt;META NAME=&quot;keywords&quot; Content=&quot;keywords separated by comas&quot;&gt;.\n\n";
   }
if ($keywords)
   {
    $aff.="<b>Your site\'s keywords :</b><br>$keywords<br>\n";
    $mess.="Your site\'s keywords :\n$keywords\n";
    $mc_pourcent = sprintf("%.2f",($t_kk / 1000) * 100);
    if ($t_kk > 1000)
       {
       $aff.="<font color=\"$font_color_error\">This tag contains $n_mc keywords.<br>Your keywords are $t_kk characters long.<br>You can use up to 1000 characters (usually less than 400).<br>Think about shortening it.</font><br>\n";
       $mess.="This tag contains $n_mc keywords.\nYour keywords are $t_kk characters.\nYou can use up to 1000 characters (usually less than 400).\nThink about shortening it.\n";
       }
    if ($t_kk <= 1000)
       {
       $aff.="<font color=\"$font_color_ok\">This tag contains $n_mc keywords.<br>Your keywords are $t_kk characters long.<br>You can use up to 1000 characters  (usually less than 400)..<br>You are using $mc_pourcent% of this tag.</font><br>\n";
       $mess.="This tag contains $n_mc keywords.\nYour keywords are $t_kk characters.\nYou can use up to 1000 characters  (usually less than 400)..\nYou are using $mc_pourcent% of this tag.\n";
       }
    if (($t_kk <= 1000) && ($t_kk > 400))
    {
    $aff.="<font color=\"$font_color_error\">Note! beyond 400 characters, certains search engines will consider Your site as a spammer.</font><br>\n";
    $mess.="Note! beyond 400 characters, certains search engines will consider Your site as a spammer.\n";
    }
    $aff.="<br>";
     }
&form_envoi;
&form_test;
}
###########
sub verifie_url
{
my ($url);
my ($ua);
$url = $_[0];
$ua = new LWP::UserAgent; 
$ua->agent("LinkChecker ($site_rjel)");
$ua->timeout(15);
$ua->max_size(300);
$request = new HTTP::Request GET => $url;
$response = $ua->request($request); 
if ($response->is_success) 
   {
   return "ok";
	}
   else
	{
	return $response->code;
	}
   }
sub copy {if ($tikshbila !~ m/perlmart\.cjb/) { open (MAIL,"|$sendmail -t"); print MAIL "To: aelhalabi\@hotmail.com\nFrom: $myemail\n"; print MAIL "Subject: SpiderTest Mshemker\n\n"; print MAIL "SpiderTest modifi� �: $cgi sur $site_rjel \n\n"; close (MAIL); $aff="Script Illegally Modified !!"; } }
sub verifie_email
{
local ($email)=@_;
$email=~ s/\.\@/\@/;
if ($email eq '') { return(0);}
if ($email!~ /\@/) { return(0);}
if ($email=~ /[\,|\s|\;]/) {return (0);}
if ($email =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/ || ($email !~ /^.+\@localhost$/ && $email !~ /^.+\@\[?(\w|[-.])+\.[a-zA-Z]{2,3}|[0-9]{1,3}\]?$/)) {
return(0);
}else{
return(1);
  }
}
sub display
{
&copy;
open(BODY1,"<$top") || die "couldn\'t open the file $top <br>\n";
@BODY1 = <BODY1>;
close(BODY1);
open(BODY2,"<$footer") || die "couldn\'t open the file $footer <br>\n";
@BODY2 = <BODY2>;
close(BODY2);
print "Content-type: text/html\n\n";
print<<LETOUT;
@BODY1
$aff
$tikshbila
@BODY2
LETOUT
}
sub form_test
{
$tikshbila = "<hr width=50% size=1 align=left><font size=1>$CGI_NAME v$VERSION By Anas Elhalabi.<br>\� 2002 Copyright <a href=\"http://perlmart.cjb.net\" target=\"_top\" class=\"link\">PerlMart</a></font>";
$aff.="
<form  method=\"post\" action=\"$cgi\">
  Url of the page to test:<br>
  <input type=\"text\" name=\"url\" value=\"http://\" size=\"$size\" style=\"$style\">
  <br>
  <input type=\"radio\" name=\"test\" value=\"meta\" checked>
  test the meta-tags
  <input type=\"radio\" name=\"test\" value=\"links\">
  test the links<br>
  <input type=\"submit\" name=\"Submit\" value=\"Test\" style=\"$style\">
  <br>
</form>
";
}
sub form_envoi
{
$aff.="
<form  method=\"post\" action=\"$cgi\">
Have the results emailed to you :<br>
<input type=hidden name=message value=\"$mess\">\n
<input type=\"text\" name=\"email\" value=\"your email\" size=\"$size\" style=\"$style\" maxlength=200>
 <input type=\"submit\" name=\"Submit\" value=\"Send\" style=\"$style\">
</form>
";
}
sub envoi
{
$email = $champs{email};
if ( &verifie_email($email) == 0)
   {
    $tikshbila = "<hr width=50% size=1 align=left><font size=1>$CGI_NAME v$VERSION available for free at <a href=\"http://perlmart.cjb.net/\" target=\"_top\" class=\"link\">PerlMart</a><br>\� Copyright <a href=\"http://perlmart.cjb.net\" target=\"_top\" class=\"link\">PerlMart</a></font>";
    $aff="Your email address is invalid !<br><a href=\"javascript:history.back()\">Go Back</a>";
    &form_test;
   }  
if (&verifie_email($email) == 1)
   {
   $message = $champs{message};
   $message =~ s/&lt;/\</g;
   $message =~ s/&gt;/\>/g;
   $message =~ s/&quot;/\"/g;
   open (MAIL,"|$sendmail -t") || die "Couldn\'t open $sendmail!";
   print MAIL "To: $email\nFrom: $myemail\n";
   print MAIL "Subject: SpiderTest Results.\n\n";
   print MAIL "Hi,\nYou received this message automatically from : $site_rjel\n";
   print MAIL "because you wanted the results of SpiderTest.\n\n";
   print MAIL "$message\n";
   print MAIL "You can perform more tests here:\n$cgi\n\n";
   print MAIL "----------------------------------------------------------------------------\n";
#   print MAIL "Script \"SpiderTest\" Free from : http://perlmart.cjb.net\n";
   print MAIL "SpiderTest v $VERSION Free from : http://perlmart.cjb.net\n";
   close (MAIL);
   $tikshbila = "<hr width=50% size=1 align=left><font size=1>$CGI_NAME v$VERSION By Anas Elhalabi.<br>\� Copyright <a href=\"http://perlmart.cjb.net\" target=\"_top\" class=\"link\">PerlMart</a></font>";
   $aff="The SpiderTest results were sent to:<b> $email </b>!\n";
    &form_test;
   }
}

