Title: donnervogel "smart" picture counter
Description: the program (counter.pl ) counts all users, except the ones who have visited the homepage very recently, and writes an entry for each one into a statistic file (stats.txt). the program will then increase the number of users in the count.txt file and will finally create a picture showing the number of visitors, using image files form 0 (0.gif) to 9 (9.gif) that you have to provide.
if you want to look at the statistics you can either use the log.pl program to view the latest entry first, or you can have a look at the stats.txt file to view the lastest entry at the bottom of the page.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=300&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
