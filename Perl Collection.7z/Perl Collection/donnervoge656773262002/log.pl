#!/usr/bin/perl

use CGI qw/:standard/;

@kette = ("");
open(datei, "<count.txt");
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$komm = join("",@kette);
@eintrag = split(/�/,$komm);

$input_fields = 6;

$multi = $eintrag[0];
$end = 0;

sub write
{
@kette = ("");
open(datei, "<stats.txt");
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$komm = join("",@kette);
@liste = split(/�/,$komm);

print qq!
$liste[(($multi-1)*$input_fields)+2]&nbsp;-&nbsp;$liste[(($multi-1)*$input_fields)+5]&nbsp;-&nbsp;$liste[(($multi-1)*$input_fields)+3]&nbsp;-&nbsp;$liste[(($multi-1)*$input_fields)+4]&nbsp;-&nbsp;$liste[(($multi-1)*$input_fields)+6]<br>
!;

$multi = $multi - 1;
}

print "Content-type: text/html\n\n";

until($multi == $end)
{
&write;
}