"smart" picture counter:

the program (counter.pl) counts all users, except the ones who have visited the homepage very recently, and writes an entry for each one into a statistic file (stats.txt). the program will then increase the number of users in the count.txt file and will finally create a picture showing the number of visitors, using image files form 0 to 9 that you have to provide.
if you want to look at the statistics you can either use the log.pl program to view the latest entry first, or you can have a look at the stats.txt file to view the lastest entry at the bottom of the page.

requirements:

   server:
   a webserver running perl (e.g.: Apache/1.3.14 and ActivePerl-5.6.1.629-MSWin32-x86-multi-thread.msi)
   counter.pl
   count.txt
   stats.txt
   log.pl

   client:
   an internet browser (e.g.: Opera/5.12)
   
if you want the counter to be a part of a webpage (http://www.geocities.com/michael_salcher) you can either use server side includes or you simply write a perl program that places your html code all around the counter code (e.g.: http://www.pfarrehopfgarten.at/michael_net/startpage.pl).