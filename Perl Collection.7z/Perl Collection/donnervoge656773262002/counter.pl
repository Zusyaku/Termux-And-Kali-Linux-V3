#!/usr/bin/perl

use CGI qw/:standard/;

print "Content-type: text/html\n\n";

$space = 14400; # 4 hours in seconds, the same user will only be counted every 4 hours
$info = 6; # number of input fields per entry
$start_value = 550; # set to the number from which counting should start

$unix_time = time(); # up to date time, in seconds that have passed since the 01.01.1970

sub read_count # reads the number of users ($count[0])
{
@kette = ("");
open(datei, "<count.txt"); # file in which the number of user is saved
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$komm = join("",@kette);

@count = split(/�/,$komm); # � seperates one record from another one
}

sub write_count
{
open(DATEI, ">count.txt");   # opening file to (over)write
print DATEI "$count[0]�\n";  # writing into the file
close(DATEI);
}

sub read_stats # reads the statistics file
{
@kette = ("");
open(datei, "<stats.txt");
 while(<datei>)
  {
  push(@kette,$_);
  }
 close(datei);

$komm = join("",@kette);

@liste = split(/�/,$komm); # every record can now be reached with $liste[x]
}

sub write_stats
{
open(DATEI, ">>stats.txt");   # opening file to begin writing at the end of the file
print DATEI "$unix_time� $ENV{'REMOTE_ADDR'}� $Zeit[2].$Zeit[1].$Zeit[4]� $Zeit[3]� $ENV{'REMOTE_HOST'}� $ENV{'HTTP_USER_AGENT'}�\n";  # writes the statistics
close(DATEI);
}

sub check_ip # finds out if the user has visited the page in the given time intervall (4 hours)
{
&read_count;
&read_stats;
$found = 0;
$stop = 0;
$y = $count[0];
$x = $y * $info - ($info - 1); # time record for the last entry

 while ($stop != 1)
 {
  $x = $y * $info - ($info - 1);
  if ($liste[$x] + $space > $unix_time) # if true, user may have visited the page in the last 4 hours
  {
   if ($liste[$x+1] =~ /$ENV{'REMOTE_ADDR'}/) # check if the ip adress record contains the ip of the user that is executing the program now
   {
   $stop = 1; # process stopped
   $found = 1; # user has been here in the last 4 hours
   }
  }
  else
  {
  $stop = 1; # process stopped, but user hasn't been here in the last 4 hours
  }
 $y = $y - 1; # checks the next entry
 }
}

sub create_pic
{
$actual_value = $count[0] + $start_value;
$digits = length($actual_value);
$z = 0;
 while ($z < $digits) # transforms for example the number 123 into 1.gif and 2.gif and 3.gif writes html img tags for each image 
 {
 print qq!<img src="digits/!;
 print substr($actual_value,$z,1);
 print qq!.gif" alt="" border="0">!;
 $z = $z + 1;
 }
}

$Jetztwert = time();
$Jetztzeit = localtime($Jetztwert); # function to get the date from the time function
&names;
@Zeit = split(/ +/,$Jetztzeit); # $Zeit[3] is the date, $Zeit[2].$Zeit[1].$Zeit[4] is the time in hh:mm:ss

sub names
{
 $Jetztzeit =~ s/Jan/01/; # writes 01 instead of Jan
 $Jetztzeit =~ s/Feb/02/;
 $Jetztzeit =~ s/Mar/03/;
 $Jetztzeit =~ s/Apr/04/;
 $Jetztzeit =~ s/May/05/;
 $Jetztzeit =~ s/Jun/06/;
 $Jetztzeit =~ s/Jul/07/;
 $Jetztzeit =~ s/Aug/08/;
 $Jetztzeit =~ s/Sep/09/;
 $Jetztzeit =~ s/Oct/10/;
 $Jetztzeit =~ s/Nov/11/;
 $Jetztzeit =~ s/Dec/12/;
}

&check_ip;

if ($found == 1) # if the user has visited the page recently, only  print the numbers of users
{
&create_pic;
}
else # if the user has not visited the page recently, increase the numbers of user, write the statistics and print the number of users
{
$count[0] = $count[0] + 1;
&write_count;
&write_stats;
&create_pic;
}