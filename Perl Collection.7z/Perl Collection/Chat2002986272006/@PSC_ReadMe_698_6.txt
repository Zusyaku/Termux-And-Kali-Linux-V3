Title: Chat
Description: Can be used to chat. However, it is not full duplex. It can be used for chatting over a LAN.
------------------------------------------------
Basically u hav to run server script(chat_ser7v2.pl) in one machine &amp; client script(chat_cli7v2.pl) in other. Only thing you should know is your ip &amp; the ip where the server script is running.
There are basically 2 modes:
1. listen: where u listen &amp; the other sends messages
2. send: where u send messages &amp; the other listens
Use the keyword "done" to switch between modes. For example if ur message is "done" (without quotes) then u switch to listening mode &amp; the other switches to sending mode
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=698&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
