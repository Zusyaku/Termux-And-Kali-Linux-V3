use Socket;

our $listen=0; 
our $write=1; 
our $send; 
our $recv;

sub safe_exit{
	#sleep 5;
	print "Exit!!!";
	exit;
}

sub send_msg{
	print "Enter new message: ";
	$send=<STDIN>;
	chop $send;
	send(SOCK,$send,MSGPEEK);
	if($send eq "done"){
		$write=0;
		$listen=1;
		$send=$recv=" ";
	}
	if($recv eq "done"){
		$listen=0;
		$write=1;
		$send=$recv=" ";
	}
	if($send eq "exit"){
		safe_exit();
	}
}

sub recv_msg{
	print "Received: ";
	$length=2000;
	recv(SOCK,$recv,$length,MSGPEEK);
	print "$recv\n";
	if($send eq "done"){
		$write=0;
		$listen=1;
	}
	if($recv eq "done"){
		$listen=0;
		$write=1;
	}
	if($recv eq "exit"){
		safe_exit();
	}
}

##$ssend="It is assumed that Client writes first, please wait till you get a 'done'. Then you can type messages.
##Same rule apply to you, when you send 'done', you switch back to listening mode\n\n";
##print $ssend;
$argc=@ARGV;

if($argc!=2){
	die "Syntax: $0 <your ipaddress> <server ipaddress>\n";
}

$my_addr=inet_aton($ARGV[0]);
$peer_addr=inet_aton($ARGV[1]);
$my_hostname=gethostbyaddr($myaddr,AF_INET);
$peer_hostname=gethostbyaddr($peer_addr,AF_INET);

$proto=getprotobyname('tcp');
socket(SOCK,AF_INET,SOCK_STREAM,$proto) || die "Socket: $!\n";

$port=1234;
$paddr=sockaddr_in($port,$my_addr);
bind(SOCK,$paddr);

$server_paddr=sockaddr_in($port,$peer_addr);

print "Connecting to $peer_hostname<$ARGV[1]> ...\n";
connect(SOCK,$server_paddr) || die "No connections\n";

###listen mode wite mode.
###assuming client is in write mode & server is in listen mode. ie. $listen=0 & $write=1

while(1){
	if($listen==1 && $write==0){
		recv_msg();
	}
	if($listen==0 && $write==1){
		send_msg();
	}
}