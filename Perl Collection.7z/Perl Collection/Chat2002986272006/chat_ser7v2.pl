use Socket;

our $listen=1; 
our $write=0; 
our $send; 
our $recv;

#$argc=@ARGV;
#print $argc;
#if($argc!=1){
#	die "Syntax: $0 <your ipaddress>\n";
#}

$my_hostname=gethostbyaddr($iaddr,AF_INET);
print "Server start on $my_hostname <$ARGV[0]>\n";

$proto=getprotobyname('tcp');
socket(SOCK,AF_INET,SOCK_STREAM,$proto) || die "Socket: $!\n";

$port=1234;
$inaddr=inet_aton($ARGV[0]);
$paddr=sockaddr_in($port,$inaddr);
bind(SOCK,$paddr);

listen(SOCK,10);

$client_paddr=accept(CLIENT_SOCK,SOCK);
#($client_port,$client_inaddr)=sockaddr_in($client_paddr);
#$client_addr=inet_ntoa($client_inaddr);
#$client_name=gethostbyaddr($client_addr,AF_INET);

#print "Connected to: $client_name <$clinet_addr>\n";
print "Connected\n";

###listen mode, write mode
###assuming cserver is in listen mode & client is in write mode. ie. $listen=1 & $write=0

while(1){
	if($listen==1 && $write==0){
		recv_msg();
	}
	if($listen==0 && $write==1){
		send_msg();
	}
}

sub safe_exit{
	#sleep 5;
	print "Exit!!!\n";
	exit;
}

sub send_msg{
	print "Enter new message: ";
	$send=<STDIN>;
	chop $send;
	$temp=$send;
	send(CLIENT_SOCK,$send,MSGPEEK);
	if($send eq "done"){
		$write=0;
		$listen=1;
		$send=$recv=" ";
	}
	if($recv eq "done"){
		$listen=0;
		$write=1;
		$recv=$send=" ";
	}
	if($temp eq "exit"){
		safe_exit();
	}
}

sub recv_msg{
	print "Received: ";
	$length=2000;
	recv(CLIENT_SOCK,$recv,$length,MSGPEEK);
	print "$recv\n";
	if($send eq "done"){
		$write=0;
		$listen=1;
	}
	if($recv eq "done"){
		$listen=0;
		$write=1;
	}
	if($recv eq "exit"){
		safe_exit();
	}
}