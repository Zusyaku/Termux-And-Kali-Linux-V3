#!/usr/bin/perl
# random password generator for perl
# Joel Addams - 27/02/2002
# use '--help' argument for help
use warnings;
use strict;

our $ver = "2.0.2";

# defaults;
our $lf = "/dev/null";
our $length = "8"; our %final; 
our $numcounter = "0"; our $numlimit = "3"; 
our $capscounter = "0"; our $capslimit = "2";
our $log = "0";


print "\n[randpass]: this is randpass $ver\n";

# check for /dev/random
if (! -e '/dev/random2') { warn("Cannot find /dev/random."); }
else { print "[randpass]: OK -- found /dev/random\n"; }

# check arguments
if (@ARGV) {
if ($ARGV[0] eq "--help") { help(); exit 0; }
print "[randpass]: Found arguments...\n";
my @args = @ARGV; my $counter = 0;
foreach (@args) {
	if (($_ eq "-l") && ($args[($counter + 1)] =~ /\d/)) {
		$length = $args[($counter + 1)];
	}
	elsif (($_ eq "-n") && ($args[($counter + 1)] =~ /\d/)) {
		$numlimit = $args[($counter + 1)];
	}
	elsif (($_ eq "-c") && ($args[($counter + 1)] =~ /\d/)) {
		$capslimit = $args[($counter + 1)];
	}
	elsif (($_ eq "-log") && ($args[$counter + 1])) {
		$log = "1";
		$lf = $args[($counter + 1)];
	}
	else { $counter++; next; } 				 
	$counter++;
    }
}
else { print "[randpass]: No args specified -- using defaults\n"; }
print "[randpass]: Args: Len[$length] NumLim[$numlimit] CapsLim[$capslimit]\n";

# logging stuff
if ($log) { 
my $outfile = ">>$lf";
print "[randpass]: Args: LogFile: $lf\n\n"; 
open OUT,"$outfile" or warn("Can't open outfile: These passwords are not being logged.");
}
else { print "\n"; }

# inform about stuff;
print " * Getting random seed....\n"; srand;
print " * Getting random string ($length chars)...\n";

# run randchar subroutine & save returned value into %final hash
{
my $counter = 0;
while ($counter < $length) {
	$counter++;
	$final{$counter} = randchar();
     }
}
# Print out password
{
print "\n[randpass]: Done. Password is:\t";
if ($log) { print OUT `date`, " "; }
foreach (keys %final) {
	print $final{$_};
	if ($log) { print OUT $final{$_}; }
    }
print "\t\n\n\n";
}

if ($log) { print OUT "\n"; close OUT; }

#SUBROUTINES

sub warn {
	print "WARNING: ", @_;
}

sub randchar {
   my $num  = rand 2; $num = int(($num + 1)); $num = ($num - 1);
   if (($num == 0) || ($numcounter == $numlimit)) { 
	my $caps = rand 2; $caps = int(($caps + 1)); $caps = ($caps - 1);
	if (($caps == "1") && ($capscounter < $capslimit)) { 
	$capscounter++; my $chr = (65 + int(rand 26)); return chr($chr);
	}
	else { my $chr = (97 + int(rand 26)); return chr($chr); }
   }
   elsif ($num == 1) {
	$numcounter++; my $chr = rand 10; $chr = int($chr); return $chr;
 	}
   else { die "Something went wrong ?!"; }
}

sub help {
print<<HELP;
[randpass]: Usage: perl randpass.pl [-l n] [-n n] [-c n] [-log <logfile>]

 -l n: Password will be "n" characters long.
 -n n: Password should have no more than "n" numbers in it.
 -c n: Password should have no more than "n" caps in it.
 
 -log <file> : Log the password to <file>.

Note: To change any of the default values, edit the variables within the 
script. By default logging is off. To turn it on always, set $log to 1 and 
ensure $lf is not /dev/null, but <file>.

This is FREE Software and may be distributed and/or modified under the same
licences as Perl itself.

HELP
}

