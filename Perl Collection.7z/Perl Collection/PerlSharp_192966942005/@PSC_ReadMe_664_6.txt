Title: PerlSharp - Shrink Perl Source 95% And Make Perl Faster 100%
Description: PerlSharp is a Perl script that you can use to shrink your perl scripts and programs by may be 95% of the original size. You use also PerlSharp script to reduce your all perl modules installed on your server to make Perl loads and runs faster may be by 100%.
What PerlSharp do is, parses and reformat the Perl source code like MS Visual Basic do, remove all comments, POD text blocks, unncessessary semicolons, extra spaces, tabs, multiple blank lines and more.
This process will reduce some Perl modules and scripts by may be more than 95% of the original size. This makes Perl loads these modules and scripts faster 100%.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=664&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
