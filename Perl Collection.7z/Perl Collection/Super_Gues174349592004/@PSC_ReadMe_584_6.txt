Title: Super Guestbook A Simple guest book with admin,auto installer, Security trouble shooter ,template
Description: Super Guestbook A Simple guest book with admin,auto installer, Security trouble shooter ,template and more !!!
-----------------  
 http://superguestbook.cjb.net/  
Super GuestBook is A Simple guestbook for your website but it has many advanced features that other guestbook's don't have as of easily and fully customizable HTML files you can change the view and look of the guestbook by just simply editing the TEMPLATE.HTML file
 Online Admin Demo Is Now Available !!!
  http://superguestbook.cjb.net/
Admin User Name is    :superman
Password is            :power
Note :Please Don't Delete Other Entries Using Your Administrative rights
Its noticeable features include :-
1. Fully automatic guestbook setup script !!
2. Fully automatic trouble shooter script !!!
3 .Admin area to delete all those unwanted entries !!!!!!!
4. Works on Unix ,Linux and windows 
5 .XML  Encoded Data For Browsers
6. High security (IF you use apache to run this script)
 MORE INSTRUCTIONS INSIDE THE DOWNLOAD 
so pls don't forget to vote for this code as it took me a lot of net surfing and nearly two weeks to figure out the setup script and these admin functions pls feel to use this script as you like Once again Please vote !!!                                                           Thanks
   Stephen Antony
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=584&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
