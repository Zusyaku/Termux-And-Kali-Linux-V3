#!/usr/bin/perl


&get_env;
&get_setup;

$cgidir = "$cgidir/guestbook.pl";

print "Content-type: text/html\n\n";

if ($fields{'fct'} eq "post"){&post_processor;}
if ($fields{'fct'} eq ""){&view_superguestbook;}


exit;

############################################################################################

sub view_superguestbook
{

$fsize1 = (-s "$html_loc/template.html");
open (RVF, "$html_loc/template.html");
	read(RVF,$ml,$fsize1);
close (RVF);


if ($praceImage eq "Y"){$ml = &InsertImages($ml);}
$ml =~ s/!!cgiscript!!/$cgidir/g;


$fsize1 = (-s "$html_loc/Viewentries.html");
open (RVF, "$html_loc/Viewentries.html");
	read(RVF,$listformat,$fsize1);
close (RVF);


open (DT, "data.txt");
 while (defined($line=<DT>))
	{
	if (length($line) > 4)
		{
		($name, $msg, $email, $date) =split(/::-::/,$line);	
	
		$listings = $listformat;
		
		if ($email ne "") {$name = "<a href=\"mailto:$email\">$name</a>";}
		
		$listings =~ s/!!from!!/$name/g;
		$listings =~ s/!!date!!/$date/g;
		$listings =~ s/!!comment!!/$msg/g;
		
		$gentries = $gentries . $listings;
		}
	}
close (DT);

$listformat = &strip_html_body_tags ($listformat);

$ml =~ s/!!guest_book_entries!!/$gentries/g;

print "$ml";

}


sub post_processor
{

if ($fields{'name'} eq "") { &post_prb ("Hallo Guest you have to supply your name !!."); }
if ($fields{'comment'} eq "") { &post_prb ("DEAR guest you have to Supply Your valuable comments also."); }

$fields{'comment'} =~ s/\n/<br>/g;

$fsize1 = (-s "data.txt");
open (RVF, "data.txt");
	read(RVF,$tdata,$fsize1);
close (RVF);


($sec,$min,$hour,$mday,$mon,$year,$wday,$ydat,$isdst) = localtime();
$year = "20" . substr($year, 1, 2);
$mon = &decode_month($mon);
$wday = &decode_weekday($wday);
$today = "$wday $mday $mon $year";

$fields{'comment'} =~ s/\n//g;
$crit = chr(10);
$fields{'comment'} =~ s/$crit//g;
$crit = chr(13);
$fields{'comment'} =~ s/$crit//g;

open (DT, "> data.txt");
	print DT $fields{'name'} . "::-::" . $fields{'comment'} . "::-::" . $fields{'email'} . "::-::" . $today . "\n" . $tdata;
close (DT);


$fsize1 = (-s "$html_loc/thanks.html");
open (RVF, "$html_loc/thanks.html");
	read(RVF,$ml,$fsize1);
close (RVF);

if ($praceImage eq "Y"){$ml = &InsertImages($ml);}
$ml =~ s/!!cgiscript!!/$cgidir/g;

print $ml;

exit;

}




sub post_prb
{

my ($problem) = @_;

$fsize1 = (-s "$html_loc/problem.html");
open (RVF, "$html_loc/problem.html");
	read(RVF,$ml,$fsize1);
close (RVF);

if ($praceImage eq "Y"){$ml = &InsertImages($ml);}
$ml =~ s/!!problem!!/$problem/g;

print "$ml";
exit;

}




sub get_env
{

if ($ENV{'QUERY_STRING'} ne "") {
								$temp = $ENV{'QUERY_STRING'};
								}
								else
								{
								read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
								}

@pairs=split(/&/,$temp);

foreach $item(@pairs) 
	{
	($key,$content)=split (/=/,$item,2);
	$content=~tr/+/ /;
	$content=~ s/%(..)/pack("c",hex($1))/ge;
	$fields{$key}=$content;
	}

}






sub get_setup
{

$setupcfg = "configration.ste";

$exists = (-e "$setupcfg");
if ($exists > 0)
	{

	open (STP, "$setupcfg");
		while (defined($line=<STP>))
			{
			if ($line =~ m/#/g)
				{
				$r = pos($line);
				$line = substr($line, 0, $r - 1);
				}
				
				$line =~ s/\n//g;
			
if ($line =~ /CGIURL/){$line =~ s/CGIURL//g; $line =~ s/ //g; $cgidir = $line;}
if ($line =~ /PASSWORD/){$line =~ s/PASSWORD//g; $line =~ s/ //g; $password = $line;}
if ($line =~ /USERNAME/){$line =~ s/USERNAME//g; $line =~ s/ //g; $username = $line;}
if ($line =~ /HTML_LOC/){$line =~ s/HTML_LOC//g; $line =~ s/ //g; $html_loc = $line;}
if ($line =~ /HTML_URL/){$line =~ s/HTML_URL//g; $line =~ s/ //g; $html_url = $line;}
if ($line =~ /praceImage/){$line =~ s/praceImage//g; $line =~ s/ //g; $praceImage = $line;}

#chdir("$scripts_loc");
			
			}
	close (STP);
	
	}
	else
	{
	print "Content-type: text/html\n\n";
	print " <p><big> <b>Error<b> ::::</big></p> <p><b>problem with configration.ste please upload it agian</p> </b>";
	exit;
	}

#### ##########Below to insert images ########################################################
}





sub InsertImages
{

my ($html) = @_;

if ($html =~ /<img/i)
{

$html =~ s/<img/:-:image::_::-:tag:-:/gi;

@lines = split(/::-:tag:-:/,$html);

foreach $item (@lines)
  {
  
  if (($item =~ m/\.gif/gi) or ($item =~ m/\.jpg/gi))
     {
		$item = &ProcessLine ($item);
		$newline = $newline . $item;
	 }
	 else
	 {
	 	$newline = $newline . $item;
	 }

  }

$newline =~ s/:-:image::_/<img/g;
}

else
{
$newline = $html;
}

return ($newline);

} ### END SUB



sub ProcessLine
{

my ($aline) = @_;

my ($iname, $r, $acn, $orgp, $ichar, $geturl, $sb);

	if (($aline =~ m/\.gif/gi) or ($aline =~ m/\.jpg/gi))
	 {
	 $r = pos($aline);
	 $orgp = $r;
	 $r = $r -1;
	 }

	while ($r >= 0)
	{
	$ichar = substr($aline, $r, 1);
	$r = $r - 1;
	

	if (($ichar eq "\\") or ($ichar eq "/"))
		{
		$sb = "true";
		}


	if (($ichar eq "=") or ($ichar eq "\""))
		{
		if ($geturl ne "true")
			{
			$sb = "";
			$iname = "$html_url/" . $iname;
			$geturl = "true";
			}
		}


	if ($sb ne "true")
		{
		$iname = $ichar . $iname;
		}
	}

$iname = $iname . substr($aline, $orgp, length($aline) - $orgp);

#print "==> $iname <br>";
return ($iname);

}





sub strip_html_body_tags
{

my ($thehtml) = @_;

$thestripped = "";

@html_lines=split(/\n/,$thehtml);

foreach $item (@html_lines)
	{

	if (($item !~ /<html>/) and ($item !~ /<head>/) and ($item !~ /<meta name/) and ($item !~ /<body>/) and ($item !~ /<title>/) and 
	   ($item !~ /<\/html>/) and ($item !~ /<\/head>/) and ($item !~ /<\/body>/))
	   {
		$thestripped = $thestripped . "$item" . "\n";
	   }

	}

return ($thestripped);

}




sub decode_month
{

my ($themonth) = @_;

if ($themonth == 0) {$themonth = " January   (1)";}
if ($themonth == 1) {$themonth = " February  (2)";}
if ($themonth == 2) {$themonth = " March     (3)   ";}
if ($themonth == 3) {$themonth = " April     (4)";}
if ($themonth == 4) {$themonth = " May       (5)   ";}
if ($themonth == 5) {$themonth = " June      (6)   ";}
if ($themonth == 6) {$themonth = " July      (7)  ";}
if ($themonth == 7) {$themonth = " August    (8) ";}
if ($themonth == 8) {$themonth = "September  (9) ";}
if ($themonth == 9) {$themonth = "October    (10) ";}
if ($themonth == 10) {$themonth = "November  (11)";}
if ($themonth == 11) {$themonth = "December  (12)  ";}

return ($themonth);

}

############# START PRINTING  DATA ##############


#$now_string = localtime;
#@thetime = split(/ +/,$now_string);


#$form{'message'} =~ s/\n/ /g;


#open (OLDDATA, "$DATA_DIR/messages.dat");
#@input = <OLDDATA>;
#close (OLDDATA);

#open (NEWDATA, ">$DATA_DIR/messages.dat");
#flock(DATA,2);
#print NEWDATA "$count#!#$form{'name'}#!#$form{'email'}#!#$thetime[2]-$thetime[1]-$thetime[4]#!#$form{'subject'}#!#$form{'message'}#!#\n";
#print NEWDATA @input;
#flock(DATA,8);
#close (NEWDATA);


sub decode_weekday
{

my ($theweekday) = @_;

if ($theweekday == 0) {$theweekday = "Sunday";}
if ($theweekday == 1) {$theweekday = "Monday";}
if ($theweekday == 2) {$theweekday = "Tuesday";}
if ($theweekday == 3) {$theweekday = "Wednesday";}
if ($theweekday == 4) {$theweekday = "Thursday";}
if ($theweekday == 5) {$theweekday = "Friday";}
if ($theweekday == 6) {$theweekday = "Saturday";}

return ($theweekday);

}
