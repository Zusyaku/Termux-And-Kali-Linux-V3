#!/usr/bin/perl


&get_setup;
&get_env;

print "Content-type: text/html\n\n";

if ($fields{'fct'} eq "") {&start;}
if ($fields{'fct'} eq "step2") {&complete;}





sub complete
{
################	#$string = join('  ',@LINES);
   #### # $string =~ s/\n//g;
#### #   $include{$line} = 'no';
              ####  #  last;
             ####  #}
              #### #else {
              ####    #$include{$line} = 'yes';

$exists1 = (-e "$fields{'serv_html'}");
if ($exists1 < 1)
	{

$problem = <<END_OF_PRN4;
<body bgcolor="#000000">

<p><font face="Verdana" size="2" color="#FF0000"><strong>The server path to Viewentries.html, template.html, problem.html and thanks.html does not exist. 
:</strong></font></p>
<p><strong><font face="Verdana" size="2" color="#FF0000">pls see this</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#FF0000">1. Did you chmod 755 
admin.pl, guestbook.pl and setup.pl this is very important <br>
<br>
2. Did you chmod 766 configration.ste and data.txt/data.dat to your webserver <br>
<br>
3. Did you enter the correct paths when you ran setup.pl otherwise if you doubt ask the web host company</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">or else</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">THE POSSIBLE REASONS MAY BE :-</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">1. The files are not uploaded 
correctley</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
if so pls upload again</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">2. the path set may be wrong</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">3. some other problems</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">4. you might have renamed those files</font></strong></p>
<p><strong><font face="Verdana" size="2" color="#C0C0C0">&nbsp;pls do contact your webserver 
admin for furthor help and if he fails then cach me up on</font></strong></p>
<p><strong><font face="Verdana" size="2"><font color="#C0C0C0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</font>
<a href="http://www.stephenonline.tk"><font color="#C0C0C0">www.stephenonline.tk</font></a></font></strong></p>
<p>&nbsp;</p>

END_OF_PRN4

	&setup_problem ($problem);
	
	}


&write_var ("CGIURL", $fields{'cgi_url'});
&write_var ("HTML_URL", $fields{'html_dir'});
&write_var ("HTML_LOC", $fields{'serv_html'});
&write_var ("praceImage", $fields{'praceImage'});
&write_var ("USERNAME", $fields{'username'});
&write_var ("PASSWORD", $fields{'password'});


print <<END_OF_COMPLETE;

<html>
<head>
<title>Setup Compelte</title>
</head>
<body>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
              WELL-DONE MY DEAR FRIEND NOW WITH A FEW MOMENTS YOUR WEBSITE 
              VISTORS WILL&nbsp; SIGN UP !!!!!!!<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#C0C0C0">
  <tr>
    <td width="100%" bgcolor="#000000"><div align="center"><center>
      <table border="4"
    cellpadding="3" cellspacing="0" width="100%" bgcolor="#C0C0C0" bordercolor="#008000" style="border-collapse: collapse">
      <tr>
        <td bgcolor="#FFDA09"><font color="#000000" face="Arial" size="4"><strong>Setup Completeted&nbsp; 
        !!</strong></font></td>
      </tr>
      <tr>
        <small><td bgcolor="#000000"></small><blockquote>
          <p><strong><font face="Verdana" size="2" color="#0000FF">&nbsp;&nbsp;&nbsp;&nbsp; <br>
          </font><font face="Verdana" size="4" color="#C0C0C0">Setup has been completed. </font> </strong>
          <font color="#C0C0C0"><font face="Verdana" size="4">Please delete
          setup.pl - OTHER WISE THEIR WILL BE A SECURITY PROBLEMS</font><font size="4"><br>
          </font>
          <font face="Verdana" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font>
          </font><font face="Verdana"
          size="4" color="#C0C0C0"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></font></p>
        </blockquote>
        </td>
      </tr>
    </table>
    </center></div></td>
  </tr>
</table>
              <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
              CODER&nbsp; :</p>
              <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
              STEPHEN ANTONY</p>
</body>
</html>
END_OF_COMPLETE

}



sub start
{

print <<END_OF_ST;

<html>
<head>
<title>Super Guestbook Setup</title>
</head>
<body bgcolor="#33CC33">

<form method="POST" action="setup.pl">
  <input type="hidden" name="fct" value="step2"><table border="0" cellpadding="0"
  cellspacing="0" width="100%" bgcolor="#C0C0C0">
    <tr>
      <td width="100%" bgcolor="#000000"><div align="center"><center><table border="0"
      cellpadding="3" cellspacing="1" width="100%">
        <tr>
          <td bgcolor="#FF0000"><strong>
          <font color="#000000" face="Arial" size="7">Super Guestbook
          Setup</font><font color="#000000" face="Arial" size="4"><br>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
          SETUP YOUR GUESTBOOK IN MINUTES</font></strong></td>
        </tr>
        <tr>
          <small><td bgcolor="#000000"></small><blockquote>
            <p><strong><font face="Verdana" size="2" color="#C0C0C0">&nbsp;&nbsp;&nbsp;&nbsp; <br>
            The URL location of the CGI scripts</font></strong><font face="Verdana" size="2" color="#C0C0C0">:<br>
            </font><font color="#C0C0C0" face="Verdana" size="1">This is the url location of guestbook.pl and
            admin.pl<br>
            <strong>Fictional Example:
            http://www.yourdomain.com/cgi-bin/Super Guestbook</strong><br>
            </font><font color="#C0C0C0"><input type="text" name="cgi_url" size="49" value="$cgi_url"></font></p>
            <p><font face="Verdana" size="2" color="#C0C0C0"><strong>URL location where Viewentries.html,
            template.html, problem.html and thanks.html are located<br>
            </strong></font><font face="Verdana" size="1"><font color="#C0C0C0">These HTML files should be somewhere in your
            web document directory.<br>
            </font>
            <strong><font color="#C0C0C0">Fictional Example: http://www.yourdomain.com/Super Guestbook</font></strong></font><strong><font
            face="Verdana" size="2" color="#C0C0C0"><br>
            </font></strong><font color="#C0C0C0"><input type="text" name="html_dir" size="49" value="$html_dir"></font></p>
            <p><strong><font face="Verdana" size="2" color="#C0C0C0">Server location of Viewentries.html,
            template.html, problem.html and thanks.html<br>
            </font><font color="#C0C0C0" face="Verdana" size="1">Fictional Example:
            /home/yourdomain/www/Super Guestbook</font></strong><font face="Verdana" size="1" color="#C0C0C0"><br>
            </font><font color="#C0C0C0"><input type="text" name="serv_html" size="49" value="$serv_html"></font></p>
            <p><font color="#C0C0C0"><font face="Verdana" size="2"><strong>User Name<br>
            </strong></font><font face="Verdana" size="1">This is the user name you will use to access
            the control panel.</font><font face="Verdana" size="2"><strong><br>
            </strong></font><input type="text" name="username" size="21" value="$username"></font></p>
            <p><font color="#C0C0C0"><font face="Verdana" size="2"><strong>Password<br>
            </strong></font><font face="Verdana" size="1">This is the password you will use to access
            the control panel.<br>
            </font><input type="text" name="password" size="21" value="$password"></font></p>
            <p>&nbsp;</p>
          </blockquote>
          <p><font face="Verdana" size="2" color="#C0C0C0"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></font></td>
        </tr>
        <tr>
          <td width="745" bgcolor="#FF0000"><font face="Verdana" size="2" color="#000000"><strong>
          <input
          type="submit" value="Complete it as i think above every thing is correct" name="B1">&nbsp;&nbsp;
          <input type="reset" value="Reset" name="B2"></strong></font></td>
        </tr>
      </table>
      </center></div></td>
    </tr>
  </table>
</form>

</body>
</html>
END_OF_ST

}







sub get_env
{
if ($ENV{'QUERY_STRING'} ne "") {
								$temp = $ENV{'QUERY_STRING'};
								}
								else
								{
								read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
								}

@pairs=split(/&/,$temp);

foreach $item(@pairs) 
	{
	($key,$content)=split (/=/,$item,2);
	$content=~tr/+/ /;
	$content=~ s/%(..)/pack("c",hex($1))/ge;
	$fields{$key}=$content;
	}

}





sub get_setup
{
#### GET CONFIGURATION ########################################################

$setupcfg = "configration.ste";

$exists = (-e "$setupcfg");
if ($exists > 0)
	{

	open (STP, "$setupcfg");
		while (defined($line=<STP>))
			{
			if ($line =~ m/#/g)
				{
				$r = pos($line);
				$line = substr($line, 0, $r - 1);
				}
				
				$line =~ s/\n//g;
			
if ($line =~ /CGIURL/){$line =~ s/CGIURL//g; $line =~ s/ //g; $cgi_url = $line;}
if ($line =~ /HTML_URL/){$line =~ s/HTML_URL//g; $line =~ s/ //g; $html_dir = $line;}
if ($line =~ /HTML_LOC/){$line =~ s/HTML_LOC//g; $line =~ s/ //g; $serv_html = $line;}
if ($line =~ /PASSWORD/){$line =~ s/PASSWORD//g; $line =~ s/ //g; $password = $line;}
if ($line =~ /USERNAME/){$line =~ s/USERNAME//g; $line =~ s/ //g; $username = $line;}
if ($line =~ /praceImage/){$line =~ s/praceImage//g; $line =~ s/ //g; $praceImage = $line;}

			}
	close (STP);
	
	}
	else
	{
	print "Content-type: text/html\n\n";
	print "Could not find configration.ste";
	exit;
	}

#### END CONFIGURATION ########################################################
}




sub write_var
{

my ($identifier, $write_crit) = @_;

my ($line, $tocheck, $towrite);

$towrite = "";

open (STP, "configration.ste");

	while (defined($line=<STP>))
		{

		if ($line =~ m/#/g)
			{
			$r = pos($line);
			$tocheck = substr($line, 0, $r - 1);
			}
			else
			{
			$tocheck = $line;
			}
			
		if ($tocheck =~ /$identifier/)
			{
			$line = "$identifier $write_crit\n";
			}

		$towrite = $towrite . $line;

		}
close (STP);


open (STP, "> configration.ste");
	print STP $towrite;
close (STP);

}





sub setup_problem
{

my ($sproblem) = @_;

print <<END_OF_PRB;
<body text="#FAFAFA" bgcolor="#111111">

<table border="0" width="100%" bgcolor="#000000" cellspacing="1" cellpadding="4">
  <tr>
    <td bgcolor="#FFCC00"><p align="center">
    <font face="Verdana" style="font-size: smaller"><u>&nbsp; </u>&nbsp;sorry 
    their is some error with the inputs !!!!!!</font></td>
  </tr>
</table>
<table border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#C0C0C0">
  <tr>
    <td width="100%"><div align="center"><center>
      <table border="5" cellpadding="3"
    cellspacing="0" width="100%" bordercolorlight="#808000" bordercolordark="#FF00FF" bgcolor="#000000" style="border-collapse: collapse" bordercolor="#111111">
      <tr>
        <small><td width="745" bgcolor="#FAFAFA"></small><blockquote>
          <p><font color="#C0C0C0">&nbsp;&nbsp;&nbsp;&nbsp; <br>
          $sproblem</font><font face="Verdana" color="#C0C0C0" size="2"><strong><br>
          &nbsp;&nbsp;&nbsp;&nbsp; </strong></font></p>
        </blockquote>
        </td>
      </tr>
      <tr>
        <td width="745" bgcolor="#FFFFFF"><p align="center"><font face="Verdana" color="#000000"
        size="2"><strong>Use the back button of your browser to go back and correct the problem.</strong></font><p align="center">
        <strong><font face="Verdana" color="#000000">if you find more problems 
        then pls contact your webserver admin or if he cant help me then pls 
        contact me you can cach me from my website</font></strong><p align="center">
        <strong><font face="Verdana" color="#000000">
        <a href="http://www.stephenonline.tk">www.stephenonline.tk</a> </font>
        </strong></td>
      </tr>
    </table>
    </center></div></td>
  </tr>
</table>
END_OF_PRB

&print_bottom;
exit;
}



