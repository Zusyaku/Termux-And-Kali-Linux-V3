#!/usr/bin/perl


&get_env;
&get_setup;

#$cgidir
#$password


if (substr($fields{'pass'}, 0, 2) eq "_-"){$password = "_-" . crypt ($password, "Superencpass");}

if ($fields{'usern'} eq "") {&passwordsite;}
if ($fields{'pass'} eq "") {&passwordsite;}

if ($fields{'usern'} ne $username) {&passwordwrong;}
if ($fields{'pass'} ne $password) {&passwordwrong;}


if ($fields{'usern'} eq $username) {
	if ($fields{'pass'} eq $password) {
			
		if (($fields{'faction'} eq "") and ($fields{'fct'} eq "")) {&start;}
		if ($fields{'delete_entries'} eq "") {&delete_entries;}

	}
}


exit;

########################################################################################################################
########################################################################################################################
# function to delete entries by usind admin rights
########################################################################################################################

sub delete_entries
{

$mcount = 0;

for ($ms = 0; $ms < $fields{'cntr'}; $ms++)
	{
	$fc = C . "$ms";
	if ($fields{$fc} eq "Y")
		{
		$itemnr[$mcount] = $ms;
		$mcount++;
		}
	}


if ($mcount == 0){&start; exit;}

print "Content-type: text/html\n\n";
&print_top;


$oapi = 0;

open (STP, "data.txt");
	while (defined($line=<STP>))
		{
		
		$fndmatch = "false";
		
		foreach $item (@itemnr)
			{
			if ($item == $oapi) {$fndmatch = "true";}
			}

		if ($fndmatch eq "false")
			{
			$towrite = $towrite . $line;
			}

		$oapi++;
		}
close (STP);


open (STP, ">data.txt");
	print STP $towrite;
close (STP);


print <<END_OF_E;
<body text="#C0C0C0" bgcolor="#000000">

<p align="center"><strong><font face="Verdana" size="7">T</font><font face="Verdana" size="5">he 
items that was checked has been deleted.</font></strong></p>
<p align="center"><a href="$admin_cgi?usern=$username&amp;pass=$password">
<font
face="Verdana" size="6">Click here to continue</font></a></p>
<p align="center"><font face="Verdana" size="6">Super Guestbook !!!!</font></p>
<p align="center"><font face="Verdana"><font size="6">c</font>oder :<font color="#FF6600" size="6">Stephen 
Antony</font></font></p>
</body>
</html>
END_OF_E

}





sub start
{

print "Content-type: text/html\n\n";

if ($fields{'login'} eq "login") { $password = "_-" . crypt ($password, "Superencpass"); }


$lnc = 0;

open (STP, "data.txt");
	while (defined($line=<STP>))
		{

($name, $msg, $email, $date) =split(/::-::/,$line);

$cname = "C" . $lnc;

$edit_entries = $edit_entries . <<END_OF_ENT;
<table border="7" cellpadding="4" cellspacing="0" width="100%" bordercolorlight="#800000" bordercolordark="#FF0000" bgcolor="#FF9999" style="border-collapse: collapse" bordercolor="#111111">
  <tr>
    <td width="6" bgcolor="#F3F3F3"><font face="Verdana" size="1"><input type="checkbox"
    name="$cname" value="Y"></font></td>
    <td width="613"><font face="Verdana" size="4"><strong>Name:</strong> $name <br>
    <strong>Email:</strong> $email<br>
    <strong>Date:</strong> $date<br>
    <strong>Message: </strong>$msg</font></td>
  </tr>
</table>
<hr noshade size="1" color="#C0C0C0">
END_OF_ENT

$lnc++;

		}
close (STP);


if ($lnc != 0)
	{
	$dbut = "<input type=\"submit\" value=\"Delete Checked Items\" name=\"B1\">";
	}
	else
	{
	$dbut = "<p align=\"center\"><font face=\"Verdana\" size=\"2\">There are currently no entries present in the guestbook.</font></p><br><br>";
	}


&print_top;

print <<End_of_start;

<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">

<link rel="File-List" href="filelist.xml">
<!--[if !mso]>
<style>
v\:*         { behavior: url(#default#VML) }
o\:*         { behavior: url(#default#VML) }
.shape       { behavior: url(#default#VML) }
</style>
<![endif]--><!--[if gte mso 9]>
<xml><o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]-->

<body>

<form method="POST" action="$cgidir/admin.pl">
  <input type="hidden" name="fct" value="delete_entries">
  <input type="hidden" name="cntr" value="$lnc">
  <input type="hidden" name="usern" value="$username">
  <input type="hidden" name="pass" value="$password">

<table border="0" cellspacing="1" width="630" cellpadding="4" bgcolor="#D8D8D8">
  <tr>
    <td width="250%" bgcolor="#FF9966" bordercolorlight="#808000" bordercolordark="#0000FF" bordercolor="#008080">
    <img border="0" src="icon_users_32px.gif" width="32" height="32">&nbsp; <!--[if gte vml 1]><v:shapetype id="_x0000_t136"
 coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
 <v:formulas>
  <v:f eqn="sum #0 0 10800"/>
  <v:f eqn="prod #0 2 1"/>
  <v:f eqn="sum 21600 0 @1"/>
  <v:f eqn="sum 0 0 @2"/>
  <v:f eqn="sum 21600 0 @3"/>
  <v:f eqn="if @0 @3 0"/>
  <v:f eqn="if @0 21600 @1"/>
  <v:f eqn="if @0 0 @2"/>
  <v:f eqn="if @0 @4 21600"/>
  <v:f eqn="mid @5 @6"/>
  <v:f eqn="mid @8 @5"/>
  <v:f eqn="mid @7 @8"/>
  <v:f eqn="mid @6 @7"/>
  <v:f eqn="sum @6 0 @5"/>
 </v:formulas>
 <v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800"
  o:connectangles="270,180,90,0"/>
 <v:textpath on="t" fitshape="t"/>
 <v:handles>
  <v:h position="#0,bottomRight" xrange="6629,14971"/>
 </v:handles>
 <o:lock v:ext="edit" text="t" shapetype="t"/>
</v:shapetype><v:shape id="_x0000_s1025" type="#_x0000_t136" alt="Super Guestbook !!!!!"
 style='width:308.25pt;height:41.25pt' fillcolor="#fc0" stroked="f">
 <v:fill opacity="47841f" color2="lime" rotate="t" focus="100%" type="gradient"/>
 <v:shadow on="t" color="#b2b2b2" opacity="52429f" offset="3pt"/>
 <v:textpath style='font-family:"Times New Roman";v-text-kern:t' trim="t"
  fitpath="t" string="Super Guestbook !!!!!"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=415 height=58
src="image001.gif" alt="Super Guestbook !!!!!" v:shapes="_x0000_s1025"><![endif]>Coder 
    :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="http://www.stephenonline.tk">Stephen antony</a></td>
  </tr>
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><strong><p
    align="left"><font face="Verdana"
    size="2">
    <img border="0" src="tguest.GIF" width="616" height="60"><br>
    &nbsp;</font></strong></td>
  </tr>
</table>
  <div align="center"><center>
  <table border="0" cellspacing="0" width="630" bgcolor="#E2E2E2" cellpadding="0">
    <tr>
      <td width="100%">&nbsp;<div align="center"><center>
        <table border="5" cellspacing="0"
      width="100%" cellpadding="4" bordercolorlight="#FF0000" bordercolordark="#FF00FF" bgcolor="#FF99CC" style="border-collapse: collapse" bordercolor="#111111">
        <tr>
          <td width="100%" bgcolor="#FFCE00"><font size="6">Okay my dear admin 
          what you want to&nbsp; !!!!!!!!</font></td>
        </tr>
        <tr>
          <td width="100%" bgcolor="#FF5050"><font face="Verdana" size="6"><strong>$edit_entries<br>
          </strong></font><font size="6">$dbut</font></td>
        </tr>
      </table>
      </center></div></td>
    </tr>
  </table>
  </center></div>
</form>

</body>

</body>
</html>

End_of_start
	
exit;
}


###########################################################################


sub passwordsite

{
	
print "Content-type: text/html\n\n";
print <<End_of_pp;


<html>

<head>
<title>Super Guestbook - ADMIN AREA</title>
</head>

<body bgcolor="#800000" text="#000000">
<div align="center"><center>

<table border="0" cellspacing="0" cellpadding="0" width="630">
  <tr>
    <td bgcolor="#000000">
    <table border="4" cellspacing="0" width="100%" cellpadding="2" bordercolorlight="#000080" bordercolordark="#008080" bgcolor="#FF0000" style="border-collapse: collapse" bordercolor="#111111">
      <tr>
        <td width="100%" bgcolor="#CCFF66" valign="top"><p align="center"><b>
        <font face="Verdana"
        size="7" color="#FFFFFF">S</font><font face="Verdana"
        size="5" color="#FFFFFF">uper Guestbook</font><font face="Verdana"
        size="4" color="#FFFFFF"> </font><font face="Verdana"
        size="2" color="#FFFFFF">- </font>
        <font face="Verdana"
        size="2" color="#FF00FF">ADMINISTRATOR AREA</font></b><p align="center">
        <b><font face="Verdana" color="#FFFFFF" size="5">C</font><font face="Verdana" size="2" color="#FFFFFF">oder 
        :Stephen Antony ( <a href="http://www.stephenonline.tk">
        www.stephenonline.tk</a> )</font></b></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>

<hr width="630" size="1">
<div align="center"><center>

<table border="0" cellpadding="0" cellspacing="0" width="630" bgcolor="#000000">
  <tr>
    <td width="100%" bgcolor="#000000"><table border="0" cellspacing="1" width="100%"
    bgcolor="#000000">
      <tr>
        <td width="100%" bgcolor="#009933" bordercolorlight="#FFFFFF" bordercolordark="#C0C0C0" bordercolor="#808000"><p align="center"><font color="#000000"><br>
        <font face="Arial" size="4">Please Insert Your User Name and Password as you gave in the setup</font></font></p>
        <form method="POST" action="admin.pl" $adminpath; vadmin.pl>
          <input type="hidden" name="login" value="login"><div align="center"><center><p><font
          face="Arial"><font color="#000000"><strong><small>User Name :For admin</small></strong><br>
          </font><input type="text" name="usern" size="26"><br>
          <font color="#000000"><strong><small>Password :</small></strong><br>
          </font><input type="password" name="pass" size="26"><br>
          <br>
          <strong><small>
            <input type="submit" value="Log In To ADMIN AREA" name="B1"></small></strong></font></p>
          </center></div>
        </form>
        <p align="center"><font size="6">Developer</font> :<font size="7">Stephen 
        Antony </font></p>
        
        <small>&nbsp;&nbsp; </small></font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>

<p>&nbsp;</p>
</body>
</html>
	
End_of_pp
	
	exit;
	
}

###########################################################################


sub passwordwrong {
	
print "Content-type: text/html\n\n";

print <<End_of_wrong;

<html>


<head>
<title> Warning !!!Super Guestbook - PASSWORD IS WRONG /ERROR lOG in</title>
</head>

<body bgcolor="#CC3300" text="#000000">
    <table border="4" cellspacing="0" width="100%" cellpadding="2" bordercolorlight="#000080" bordercolordark="#008080" bgcolor="#FF0000" style="border-collapse: collapse" bordercolor="#111111">
      <tr>
        <td width="100%" bgcolor="#CCFF66" valign="top"><p align="center"><b>
        <font face="Verdana"
        size="7" color="#FFFFFF">S</font><font face="Verdana"
        size="5" color="#FFFFFF">uper Guestbook</font><font face="Verdana"
        size="4" color="#FFFFFF"> </font><font face="Verdana"
        size="2" color="#FFFFFF">- </font>
        <font face="Verdana"
        size="2" color="#FF00FF">ADMINISTRATOR AREA</font></b><p align="center">
        <b><font face="Verdana" color="#FFFFFF" size="5">C</font><font face="Verdana" size="2" color="#FFFFFF">oder 
        :Stephen Antony ( <a href="http://www.stephenonline.tk">
        www.stephenonline.tk</a> )</font></b></td>
      </tr>
    </table>

<hr width="630" size="1">
<div align="center"><center>

<table border="0" cellpadding="0" cellspacing="0" width="630" bgcolor="#000000">
  <tr>
    <td width="100%" bgcolor="#000000"><table border="0" cellspacing="1" width="100%"
    bgcolor="#000000">
      <tr>
        <td width="100%" bgcolor="green"><p align="center">&nbsp;</p>
        <p align="center"><strong><font face="Arial" color="#000000"><small>
        Sorry, the password /user name went wrong</small></font></strong></p>
        <form method="POST" action="admin.pl" $adminpath; vadmin.pl>
          <input type="hidden" name="login" value="login"><div align="center"><center><p><font
          face="Arial"><font color="#000000"><strong><small>User Name :</small></strong><br>
          </font><input type="text" name="usern" size="32"><br>
          <font color="#000000"><strong><small>Password :</small></strong><br>
          </font><input type="password" name="pass" size="27"><br>
          <br>
          <strong><small>
            <input type="submit" value="Log In To ADMIN AREA" name="B1"></small></strong></font></p>
          </center></div>
        </form>
        <p align="center"><font size="6">Developer</font> :<font size="7">Stephen 
        Antony </font></p>
        <p align="center"><font face="Arial"><br>
        <small>&nbsp;&nbsp; </small></font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</center></div>

<p>&nbsp;</p>
</body>
</html>
End_of_wrong

exit;
	
}






################################################################################################



sub print_top
{

print <<End_of_top;

<html>

<head>
<title>Super Guestbook - EDIT  </title>
</head>

<body>
<div align="center"><center>
<table border="0" cellspacing="0" width="630" bgcolor="#000000" cellpadding="0">
  <tr>
    <td width="100%"><div align="center"><center><table border="0" cellspacing="1"
    width="100%" cellpadding="4">
      <tr>
        <td width="100%" bgcolor="#990000" bordercolorlight="#800000" bordercolordark="#FF0000" bordercolor="#0000FF"><strong>
        <font face="Arial" color="#808000" size="7">Super Guestbook</font><font face="Arial" color="#FFFFFF" size="6"> 
        ADMINISTRATOR::::::::::::::::::::::::::::::::::</font></strong></td>
      </tr>
    </table>
    </center></div></td>
  </tr>
</table>
</center></div>
<hr width="630" size="1">
<p><strong><font face="Arial">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font size="5">DEVELOPER</font> :<a href="http://www.stephenonline.tk">Stephen 
Antony</a> (Thanks to perl)</font></strong></p>

End_of_top


}



sub get_env
{

if ($ENV{'QUERY_STRING'} ne "") {
								$temp = $ENV{'QUERY_STRING'};
								}
								else
								{
								read(STDIN, $temp, $ENV{'CONTENT_LENGTH'});
								}

@pairs=split(/&/,$temp);

foreach $item(@pairs) 
	{
	($key,$content)=split (/=/,$item,2);
	$content=~tr/+/ /;
	$content=~ s/%(..)/pack("c",hex($1))/ge;
	$fields{$key}=$content;
	}

}





sub get_setup
{
#
################	#$string = join('  ',@LINES);
   #### # $string =~ s/\n//g;


    #### # if ($form{'boolean'} eq 'AND') {
       #### # foreach $term (@terms) {
         #### #  if ($form{'case'} eq 'Insensitive') {
          ####  #   if (!($string =~ /$term/i)) {
              #### #   $include{$line} = 'no';
              ####  #  last;
             ####  #}
              #### #else {
              ####    #$include{$line} = 'yes';
            ####  # }
          #### # }
          ####  #elsif ($form{'case'} eq 'Sensitive') {
            ######## #  if (!($string =~ /$term/)) {
             ####  #   $include{$line} = 'no';
             ####  #   last;
             #### # }
             ####  #else {
              ####   # $include{$line} = 'yes';
             ####  #}
           ##### }
       ####  #}
     #### #}
	
	
	#############################################################
$setupcfg = "configration.ste";

$exists = (-e "$setupcfg");
if ($exists > 0)
	{

	open (STP, "$setupcfg");
		while (defined($line=<STP>))
			{
			if ($line =~ m/#/g)
				{
				$r = pos($line);
				$line = substr($line, 0, $r - 1);
				}
				
				$line =~ s/\n//g;
			
if ($line =~ /CGIURL/){$line =~ s/CGIURL//g; $line =~ s/ //g; $cgidir = $line;}
if ($line =~ /PASSWORD/){$line =~ s/PASSWORD//g; $line =~ s/ //g; $password = $line;}
if ($line =~ /USERNAME/){$line =~ s/USERNAME//g; $line =~ s/ //g; $username = $line;}

#chdir("$scripts_loc");
			
			}
	close (STP);
	
	}
	else
	{
	print "Content-type: text/html\n\n";
	print "<big> <p><font color=0000FF><b> <font size="6">Error</font></b><font size="6"></font></font> </p> <p><font color=FF0066><font size="6">Misconfigration with the file configration.ste</font></font><font size="6"></p><P></font><font size="6" color="FF0066">Please upload the file again </font>  </big></p>";	
	exit;
	}

#### END CONFIGURATION ########################################################
}