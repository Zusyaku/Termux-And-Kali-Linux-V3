#Random Code Generator v1.01
#Copyright � 2001 Leow Kah Man
#Email: kmleow@bigfoot.com

#COPYRIGHT INFO
#You may modify and/or insert this code into your perl scripts as long as you
#keep all the comments in this code inside it and as long as it is not used for
#commercial purpose.
#If you would like to use this code for commercial purpose, please get prior
#permission from me.
#You may redistribute this code provided it is not modified and all comments in
#this code is present.

#CREDITS
#Please let me know that you are using my code and your website address.
#At least, I know that this code is wanted.
#Optionally, send the entire cgi script than uses this code.
#I just want to see how you make use of my code. :-)
#Many thanks to all who find this code useful.

#DISCLAIMER
#I will not be responsible for whatever damages that may occur because of using
#this code. I thoroughly checked this code to ensure it is error free.

#FUNCTION OF THIS CODE
#This code will generate a random code consisting of alphanumeric characters.
#The length of the random code is adjustable. This code was highly optimized to
#ensure high speed execution time and error free.
#I have seen other random code generators, but their codes are very long and
#mostly run slower than this code.

#USAGE INSTRUCTIONS
#Place this CGI script in the same directory as your other CGI.
#
#Insert "require 'randcode.pl';" without the double quotes(") into your CGI.
#If randcode.pl is placed in a different directory as your CGI script,
#you have to specify the full path. Example: '/full_path/randcode.pl'
#
#Then get the random code by calling "randcode(10)" without the double quotes.
#Example: print randcode(10);
#
#Replace the number 10 with any number even 1000!
#The higher this number, the longer the code, but slower.

#IMPORTANT NOTE
#The generated code's length will not be the same as this!
#The length of the code will be slightly longer than the value specified.
#The whole idea is to create a random code with dynamic length so that the
#difficulty of guessing the code will be higher and thus increases the security.
#Recommended values: 8 to 20.

#HISTORY
#1.0-Initial public release
#1.01-Fixed a bug where the same random code is produced when this code is
#	  called within the same loop (Thanks to Charles for the solution)

#CONFIGURATION
#No configuration is necessary.

#CODE SECTION
#Editing anything below this is not necessary.
#It is best that you leave anything below unchanged.
srand;
sub main'randcode
{
	for(my $i=0,$randcode="";$i<$_[0];$i++){
		if(int(rand(2))){$randcode.=chr(65+(int(rand(26))));}
		else{$randcode.=chr(97+(int(rand(26))));}
		if(int(rand(2))){$randcode.=int(rand(10));}
	}
	return $randcode; #Output the random code
}
1;
