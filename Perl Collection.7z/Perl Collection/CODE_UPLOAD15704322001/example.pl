#!/usr/local/bin/perl
#Place both the perl scripts into the same directory and execute example.pl
require 'randcode.pl';
print randcode(10);
