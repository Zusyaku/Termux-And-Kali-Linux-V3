Title: Random Code Generator v1.01 (AlphaNumeric Characters)
Description: This code will generate a random code consisting
of alphanumeric characters.
The length of the random code is adjustable.
The length of the random code generated is not the
same as the length you specified. It is slightly
longer. The length is dynamic so that hackers will
find it more difficult to find out the code.
This code was highly optimized to ensure high
speed execution time and error free.
I have seen other random code generators, but
their codes are very long and mostly run slower
than this code. More info inside the CGI script.
Insert "require 'randcode.pl';" without the
double quotes(") into your CGI script.
If randcode.pl is placed in a different directory
as your CGI script, you have to specify the full
path. Example: '/full_path/randcode.pl'
Example on calling the code: print randcode(10);
Replace the number 10 with any number, even 1000
is possible!
The higher this number, the longer the code, but
slower.
IMPORTANT NOTE
The generated code's length will not be the same as the this!
The length of the code will be slightly longer than the value specified.
The whole idea is to create a random code with dynamic length so that the difficulty of guessing the code will be higher and thus increases the security.
Recommended values: 8 to 20.
If you know how to use the 'require' command in
Perl. It shouldn't be a problem for you to get this script working in no time.
Using this script is simple.
I have mentioned the steps above.
For those of you who are having problems getting it running, make sure you are using Perl 5 and if you do not know how to include modules as mentioned above, copy and paste the code into your perl script. Feel free to send me feedback.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=159&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
