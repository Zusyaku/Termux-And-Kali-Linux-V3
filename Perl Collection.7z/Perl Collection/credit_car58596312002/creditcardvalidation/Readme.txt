Please Read The Entire Document 
The credit card Validator ... don't let another random number slip into your 
credit card batch again! The Validator verifies all 13 and 16 digit Visa Cards, 
16 digit MasterCards,
16 digit Novus (Discover) cards, and 15 digit American Express cards.Packing List
cardvali.html 
cc_ver.pl   
readme.txt