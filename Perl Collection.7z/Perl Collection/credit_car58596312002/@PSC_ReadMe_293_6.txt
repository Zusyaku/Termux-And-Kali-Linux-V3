Title: credit card Validation
Description: Please Read The Entire Document 
The credit card Validator ... don't let another random number slip into your 
credit card batch again! The Validator verifies all 13 and 16 digit Visa Cards, 
16 digit MasterCards,
16 digit Novus (Discover) cards, and 15 digit American Express cards.Packing List
cardvali.html 
cc_ver.pl  
readme.txt
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=293&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
