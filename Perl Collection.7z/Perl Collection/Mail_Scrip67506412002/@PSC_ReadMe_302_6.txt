Title: Mail Script V2
Description: This is my first attempt at a mailing script with advanced features. It includes all files need to make the logging system work and also has built in anti-hacking features as well as a bug reporting system. There are still some problems that I am working on but the majority of features in this script work. 
I have re-uploaded the file as I have made some changes to the Carbon Copy Feature. So if you have downloaded the older version then please remeber to check the Carbon Copy Email Address.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=302&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
