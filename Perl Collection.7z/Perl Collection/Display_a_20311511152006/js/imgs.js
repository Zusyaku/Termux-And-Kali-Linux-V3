function navigate(f, pg)
{
	var d = eval('document.' + f);
	d.p.value = pg;
	d.submit();
}

function changeImgsPerScr()
{
	var imgsPer = prompt("How many images would you like per screen?", document.formtop.n.value);

	if (imgsPer != null)
	{
		var imgsPerInt = parseInt(imgsPer, 10);

		if (imgsPerInt > 0)
		{
			document.formtop.n.value = imgsPerInt;
			navigate('formtop', 1);
		}
		else
		{
			alert("Sorry. '" + imgsPer + "' is not a valid number. I need an integer.");
		}
	}
}

function goToPage()
{
	var pg = prompt("What page would you like to go to?");

	if (pg != null)
	{
		var pgInt = parseInt(pg, 10);

		if (pgInt > 0)
		{
			navigate('formtop', pgInt);
		}
		else
		{
			alert("Sorry. '" + pg + "' is not a valid number. I need an integer.");
		}
	}
}

function toggleFileList(idxStart, idxEnd)
{
	if (document.getElementById)
	{
		var ele = document.getElementById('file-list');

		if (ele.style.display == 'block')
		{
			ele.style.display = 'none';

			for (var i = idxStart; i <= idxEnd; i++)
			{
				document.getElementById('i' + i).style.display = 'block';
			}
		}
		else
		{
			ele.style.display = 'block';

			for (var i = idxStart; i <= idxEnd; i++)
			{
				document.getElementById('i' + i).style.display = 'none';
			}
		}
	}
}
