#!/usr/bin/perl
use Tk;
require Tk::Dialog;
$Main=MainWindow->new;
$Main->title("FTp to LAn Card");
$Main->geometry("440x190+8+8");
$bk=$Main->Label(-anchor => "w", -background => "#FFFF11");
$bk->place( -width => 430, -height => 170, -x => 5, -y => 5);




$entry=$Main->Label(-anchor => "w", -text => "LAN Card IP:", -background => "#BBB0C8",
-font => "Tahoma 10 bold", -foreground => "#FFFFFF" );
$entry->place( -width => 100, -height => 24, -x => 40, -y => 32);
$p1 = $Main->Entry(-borderwidth => 3,-font => "Arial 12 normal",
    -foreground => "#000000",-relief => "sunken");
$p1->place(-width => 264,-height => 26,-x => 144,-y => 32 );


$save=$Main->Button(-activebackground => "#FFFCBF",
-activeforeground => "#E30229", -background => "#FFFFFF",
-borderwidth => 1, -text => " Sent Over",
-command => \&save, -cursor => "", -font => "Verdana 10 bold",
-foreground => "#000999", -relief => "solid");
$save->place(-width => 250, -height => 25, -x => 100, -y => 130);


sub save() {
$widget=@_; $a = $p1-> get();
for(open(IN, ">ptlink.pl"))
{
print IN ("use Net::FTP;\n");
print IN ("\$ftp = Net::FTP->new(\"$a\", Timeout => 10);\n");
print IN ("\$username = \"root\";\n");
print IN ("\$password = \"root\";\n");
print IN ("\$ftp->login(\$username, \$password);\n");
print IN ("\$localfile = \"sbpl.txt\";\n");
print IN ("\$ftp->put(\$localfile);\n");
close(IN);
}


for(open(NX, ">dellink.bat"))
{
print NX ("echo off\n");
print NX ("del sbpl.txt rnlink.bat ptlink.pl\n");
print NX ("exit");
close(NX);
}


$a="start ptlink.pl"; system($a);
$b="start dellink.bat"; system($b);
};



$rnfile=$Main->Button(-activebackground => "#FFFCBF",
-activeforeground => "#E30229", -background => "#FFFFFF",
-borderwidth => 1, -text => "Initialize SBPL file",
-command => \&rnfile, -cursor => "", -font => "Verdana 10 bold",
-foreground => "#000999", -relief => "solid");
$rnfile->place(-width => 250, -height => 25, -x => 100, -y => 80);


sub rnfile() {
for(open(IN, ">rnlink.bat"))
{
print IN ("echo off\n");
print IN ("ren *.txt sbpl.txt\n");
print IN ("exit");
close(IN);
}
$b="start rnlink.bat"; system($b);
};




sub del() {
for(open(IN, ">dellink.bat"))
{
print IN ("echo off\n");
print IN ("del *.txt *.bat\n");
print IN ("exit");
close(IN);
}
$c="start dellink.bat"; system($c);
};

MainLoop;








