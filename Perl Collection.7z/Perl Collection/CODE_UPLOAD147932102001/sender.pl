#!/usr/bin/perl


if ($ENV{'QUERY_STRING'}) {
	$namevalues = $ENV{'QUERY_STRING'};
} else {
	read(STDIN, $namevalues, $ENV{'CONTENT_LENGTH'});
}

@pairs = split(/&/, $namevalues);
foreach $pair (@pairs) {
($name, $value) = split(/=/, $pair);
$value =~ tr/+/ /;
$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
$value =~ s/<!--(.|\n)*-->//g;
$value =~ s/<([^>]|\n)*>//g;
$form_data{$name} = $value;
}


$mailit = "news.txt";
$mail_file = "/var/www/html/freebieforum.net/cgi/board/" . $mailit;
$mailprog = '/usr/sbin/sendmail';
$sender = 'freebies@michelle.as';
$subject = $form_data{'subject'};
$message = $form_data{'message'};
$scripurl = "http://yourhost.com/cgi-bin/";
$efile = "emailr.list";
$emar = "/var/www/html/freebieforum.net/cgi/board/" . $efile;







#############################################
# display mailer form
if ($form_data{'action'} eq ""){
print "Content-type: text/html\n\n";
print qq~
<html>
<form action="saw.pl" method="post">
<input type="hidden" name="action" value="go">
Subject<br>
<input type="text" name="subject"size="45"><br>
Message<br>
<textarea name="message" cols=60 rows=29></textarea><br>
<input type="submit"value="submit"><input type="reset"value="reset">
</form>

~;
exit;
}
#############################################
# send newsletter
if ($form_data{'action'} eq "go"){
open (BANDFIT, "$emar") || die "Can't Open $emar";
while(<BANDFIT>)	{
($ID,$uid,
 $options) = split(/\|/,$_);
 chop($options);
 foreach ($ID) {
$recipient = $ID;
$user = $uid;
if ($user eq ""){
$recipient =~ s/\s//g; 
$recipient =~ s/\n//g; 
}
    open(MAIL,"|$mailprog -t");
    print MAIL "To: $recipient\n";
    print MAIL "From: $sender\n";
    print MAIL "Subject: $subject\n\n\n" ;
    print MAIL "\n";
    print MAIL "$message\n";
    print MAIL "\n";
    print MAIL "To unsubscribe from this newsletter please click here $scripurl/unnewsl.pl?email=$recipient\n";
    print MAIL "Freenews V1.0 http://www.freebieforum.net\n";
	    close (MAIL);

}
}
close(BANDFIT);
print qq~
<html>
<center><font size=5 face=verdana>News Letter Sent</font></center>


~;
exit;
}
1;