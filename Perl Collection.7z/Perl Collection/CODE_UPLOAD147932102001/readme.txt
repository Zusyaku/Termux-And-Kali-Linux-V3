Complete Newsletter Program will send to an infinate list of emails please
please see emailr.list for correct email address formats
call sender.pl to type in your message and send
 E.G. http://yourhost.com/cgi-bin/sender.pl
if you use this code please rate it
or visit my old ladies web site
http://www.freebieforum.net