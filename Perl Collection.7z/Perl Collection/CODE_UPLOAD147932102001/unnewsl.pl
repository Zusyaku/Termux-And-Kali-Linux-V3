#!/usr/bin/perl


if ($ENV{'QUERY_STRING'}) {
	$namevalues = $ENV{'QUERY_STRING'};
} else {
	read(STDIN, $namevalues, $ENV{'CONTENT_LENGTH'});
}

@pairs = split(/&/, $namevalues);
foreach $pair (@pairs) {
($name, $value) = split(/=/, $pair);
$value =~ tr/+/ /;
$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
$value =~ s/<!--(.|\n)*-->//g;
$value =~ s/<([^>]|\n)*>//g;
$form_data{$name} = $value;
}


####
$fullthing = "/var/www/html/freebieforum.net/cgi/board/emailr.list";
$User = $form_data{'email'};



#########
if ($User eq ""){
print qq!
<html>
<center><font size=5 face=verdana>No Email address was specified </center></font>
!;
exit;
}
else
{
@users_to_delete = $User; 

open(FILE,"$fullthing")||die"Cannot open file\n$!\n"; 
while (<FILE>){ 
  unless(/^\s*$/){ 
    push (@passlist, $_); 
  } 
} 
close(FILE); 


open(OUT,"> $fullthing")||die"Cannot open file\n$!\n"; 
foreach $line (@passlist){ 
  $to_delete = 0; 
  foreach $user (@users_to_delete){ 
    if($line =~ /^$user/){ 
      $to_delete = 1; 
        $cat = $to_delete;
      last; 
    } 
  } 
  if($to_delete == 0){ 
    print OUT $line; 


  } 
} 
close(OUT); 
if ($cat eq 1){
print qq!
<html>
<center><font size=5 face=verdana>$User You have successfully been removed from the freebieforum.net newsletter</center></font>
!;
exit;
}
else{
print qq!
<html>
<center><font size=5 face=verdana>$User your email address has already been removed from the freebieforum.net newsletter</center></font>
!;
exit;
}
}
