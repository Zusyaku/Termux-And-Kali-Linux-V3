Title: Complete Web Based Newsletter App
Description: Complete newsletter App will collect emails and mass mail all subscribers include auto remove for subscribers who wish to be removed from the list call sender.pl to type in your message and send the intire list an email... if you use this code PLEASE RATE IT.... This code sends each subscriber a personal email E.G from you@yourhost.com to Subscriber@hishost.com not your@yourhost.com to subsciber@hishost.com,subsciber2@hishost.com,ETC.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=166&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
