#!/usr/bin/perl



if ($ENV{'QUERY_STRING'}) {
	$namevalues = $ENV{'QUERY_STRING'};
} else {
	read(STDIN, $namevalues, $ENV{'CONTENT_LENGTH'});
}

@pairs = split(/&/, $namevalues);
foreach $pair (@pairs) {
($name, $value) = split(/=/, $pair);
$value =~ tr/+/ /;
$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
$value =~ s/<!--(.|\n)*-->//g;
$value =~ s/<([^>]|\n)*>//g;
$form_data{$name} = $value;
}
###
#location of file
$samsfil = "/var/www/html/freebieforum.net/cgi/board/emailr.list";
##############

$emailaddress = $form_data{'email'};
if ($form_data{'email'} eq ""){
print "Content-type: text/html\n\n";
print qq!
<html>
<center>
<font size=5 face=verdana>You must supply an email address to subscribe to this list</font>
!;
exit; 
}
if ($form_data{'email'} eq 'you@yourhost.com'){
print "Content-type: text/html\n\n";
print qq!
<html>
<center>
<font size=5 face=verdana>You must supply an email address to subscribe to this list</font>
!;
exit; 
}
else{

$this_user = $emailaddress; 

$this_user =~ s/\you\@yourhost.com//gs; 

$this_user =~ s/\s//g; 

$userexists = 0; 

open (USERS, "< $samsfil"); 

while(my $line=<USERS>) { 
  if ($line =~ /^$this_user/) { 
    $userexists=1; 
  } 

} 
if ($userexists eq 0){

        open(SAMS, "+>>$samsfil");
        flock(SAMS, 2);
        print (SAMS "$this_user\n");
        close(SAMS);

print "Content-type: text/html\n\n";
print qq!
<html>
<center>
<font size=5 face=verdana>Thanks $this_user you have successfully subscribed to the Freebieforum Newsletter...</font>
!;
exit; 
}
else{

print qq!
<html>
<center>
<font size=5 face=verdana>$this_user your email address already exists in the database...</font>
!;
exit;
}

}
1;

