Title: Network Commander (Perl/Tk)
Description: This Program is another working example of the Graphic utiltiy found using Perl and Tk, coupled with four commonly used networking functions... PING, Network Scan, Traceroute and Hostname Lookups. This program Displays Good Examples of menus, Dialog Box, Scrolling, List Box, opening files, reading data from files, acting on that data, etc. This program is a learning tool, so pass to your friends that are trying to learn Perl/Tk.
I wrote this program because I recieved a large amount of positive feedback regarding the Ping Commander.
Notice: This example is based on win32 platforms using Perl/Tk. Any Perl later 5.22 and later should be fine to run this program. You also need to have the Tk Module installed. Or, if you dont have perl installed, you can download the program as netcmdr.exe from www.mollensoft.com and run it just like any other exe program.To Run 
 1. Extract the Contents of zipfile into a directory
 2. If you Have Perl installed, Double click the "netcmdr.pl" file in the directory you unzipped it into.
 3. If you do not have perl installed Double click the "netcmdr.exe" file in the directory you unzipped it into.
  
As Always, Provide feedback!
Enjoy!! BigAl Sends....
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=194&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
