#!/usr/bin/perl
use Tk;
require Tk::Dialog;

#####MENU BOX#######

$Main2=MainWindow->new;
$Main2->geometry("220x65");


$dev=$Main2->Button(-activebackground => "#FFFCBF",
-activeforeground => "#E30229", -background => "#FFFFFF",
-borderwidth => 2, -text => "Rename BHT8000 file",
-command => \&dev, -cursor => "", -font => "Verdana 9 bold",
-foreground => "#000999", -relief => "solid");
$dev->place(-width => 200, -height => 25, -x => 10, -y => 20);
sub dev() {
for(open(IN, ">link.bat"))
{ print IN ("echo off\n");
print IN ("ren pack* pack1.txt\n");
print IN ("exit\n");
close(IN); }
sleep 0.5;
$a="start link.bat";system($a) };

MainLoop;


#######END OF MAIN2###########







