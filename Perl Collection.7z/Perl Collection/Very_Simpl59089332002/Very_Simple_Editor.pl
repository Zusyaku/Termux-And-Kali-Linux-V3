#!/usr/bin/perl -w
#
#############################################################################
# FILE:
#			VSEditor-By:C.G.
#			Very Simple Editor
#
# DATE:
#			Fri Mar 01 15:56:16 CST 2002 @955 /Internet Time/
#
# AUTHOR:
#			Casey Gilmer (iChpr = Incipient Cipher)
#
# DESCRIP:
#			A very simple editor that opens files by using multiple tabs
#			instead of using multiple windows. Its written in Perl/Tk.
#
# WOULD LIKE TO DO:
#			Add PRINT to file menu.
#			Be able to save and reload settings.
#			Add syntax highlighing.
#			Have line numbers visible in a gutter.
#
# KNOWN BUGS:
# 			Problem with 'Close All' => If you close all tabs and save some
#			tabs[yes], and dont save others[no]; then open up new tabs and
#			close all again you will keep getting a confirmation dialog
#			after all tabs have been closed but it will eventually go away,
#			try clicking [cancel].
#			When typing with word wrap 'off' the scroll bar moves in the
#			wrong direction. So you can't see what your typing past the
#			visible part os the textarea. If you know how to fix this please
#			email me, I would appreciate it. Thanks.
#
###############################################################################
#

use Tk;
use Tk::Dialog;
use Tk::Font;
use Tk::NoteBook;
use Tk::Menubutton;
use Tk::Scrollbar;
use Tk::TextUndo;
use strict;

##########################################
# Global Variables
##########################################
#
my $i = 0;						# start num for notebook page
my $p;							# future page index variable
my $nbPage;						# temporary value used to create textarea
my @pageName;					# notebook page name
my @ta;							# textarea of notebook page
my @fileName;					# file name of open buffer
my @filePath;					# directory to file
my @font;						# individual font settings
my $textAreaAndYScrollFrame;	# contains textarea and yscrollbar
my $textAreaFrame;				# contains textarea
my $yscrollFrame;				# contains yscrollbar
my $xscrollFrame;				# contains xscrollbar
my $yscroll;					# yscrollbar
my $xscroll;					# xscrollbar

######################
# create MainWindow();
######################
#
my	$main = MainWindow->new();
		$main->title("VSEditor - by C.G.");
		$main->geometry('400x350');

my	$mainFrame = $main->Frame();


####################################################
# This frame will contain the notebook and textarea
####################################################
#
my 	$notebookFrame = $mainFrame->Frame();

###############################################
# Status Bar
###############################################
#
my $status = $mainFrame->Frame(-height=>1, -relief=>'raised');
my $lblModified = $status->Label(-relief=>'sunken', -text=>"            ");
my $lblPath = $status->Label(-relief=>'sunken');

	# From now on if we want to access any methods in the Tk::NoteBook class
	#  we use:    $notebook->methodName(...);
	#########################################
my	$notebook = $notebookFrame->NoteBook();

&newFile();				# create page, text area, and scrollbars

##################
# create menubar
##################
#
my	$menubarFrame = $mainFrame->Frame(-relief=>'raised', -borderwidth=>2);

		# File menu
		############
my	$fileDrop = $menubarFrame->Menubutton(-text=>'File', -underline=>0);
my	$fileMenu = $fileDrop->Menu();
				$fileDrop->configure(-menu=>$fileMenu);
		$fileMenu->command(-label=>'New', -command=>\&newFile, -underline=>0);
		$fileMenu->command(-label=>'Open', -command=>\&openFile, -underline=>0);
		$fileMenu->separator();
		$fileMenu->command(-label=>'Save', -command=>\&saveFile, -underline=>0);
		$fileMenu->command(-label=>'Save As', -command=>\&saveAs, -underline=>5);
		$fileMenu->command(-label=>'Save All', -command=>\&saveAll, -underline=>2);
		$fileMenu->separator();
		$fileMenu->command(-label=>'Include File', -command=>\&includeFile, -underline=>0);
		$fileMenu->command(-label=>'Clear File', -command=>\&clearFile, -underline=>2);
		$fileMenu->separator();
		$fileMenu->command(-label=>'Close', -command=>\&closeFile, -underline=>0);
		$fileMenu->command(-label=>'Close All', -command=>\&closeAll, -underline=>2);
		$fileMenu->separator();
		$fileMenu->command(-label=>'Exit', -command=>\&exitEditor, -underline=>1);

		# Edit menu
		############
my	$editDrop = $menubarFrame->Menubutton(-text=>'Edit', -underline=>0);
my	$editMenu = $editDrop->Menu();
				$editDrop->configure(-menu=>$editMenu);
		$editMenu->command(-label=>'Undo', -command=>\&undoMenu, -underline=>0);
		$editMenu->command(-label=>'Redo', -command=>\&redoMenu, -underline=>0);
		$editMenu->separator();
		$editMenu->command(-label=>'Copy', -command=>\&copyMenu, -underline=>0);
		$editMenu->command(-label=>'Cut', -command=>\&cutMenu, -underline=>1);
		$editMenu->command(-label=>'Paste', -command=>\&pasteMenu, -underline=>0);
		$editMenu->separator();
		$editMenu->command(-label=>'Select All', -command=>\&selectAllMenu, -underline=>0);
		$editMenu->command(-label=>'Unselect All', -command=>\&unselectAllMenu, -underline=>1);

		# View menu
		############
my	$viewDrop = $menubarFrame->Menubutton(-text=>'View', -underline=>0);
my 	$viewMenu = $viewDrop->Menu();
				$viewDrop->configure(-menu=>$viewMenu);
		$viewMenu->command(-label=>'Goto Line Number', -command=>\&gotoLineMenu, -underline=>0);
		$viewMenu->command(-label=>'What Line Number', -command=>\&whatLineMenu, -underline=>1);
		$viewMenu->separator;
		my $wrap;		# Word Wrap #
		my $viewWrap = $viewMenu->cascade(-label=>'Word Wrap');
			 	$viewWrap->radiobutton(-label=>'Off', -value=>'none', -variable=>\$wrap, -command=>\&wordWrap);
				$viewWrap->radiobutton(-label=>'By Character', -value=>'char', -variable=>\$wrap, -command=>\&wordWrap);
				$viewWrap->radiobutton(-invoke=>1, -label=>'By Word', -value=>'word', -variable=>\$wrap, -command=>\&wordWrap);
		my $viewFont = $viewMenu->cascade(-label=>'Font');
			my $fstyle;		# Font Style #
				$viewFont->radiobutton(-invoke=>1, -label=>'Courier', -value=>'courier', -variable=>\$fstyle, -command=>\&fontStyle);
				$viewFont->radiobutton(-label=>'Helvetica', -value=>'helvetica', -variable=>\$fstyle, -command=>\&fontStyle);
				$viewFont->radiobutton(-label=>'Times', -value=>'times', -variable=>\$fstyle, -command=>\&fontStyle);
			my $fsize;		# Font Size #
			$viewFont->separator;
				$viewFont->radiobutton(-label=>'8', -value=>8, -variable=>\$fsize, -command=>\&fontSize);
				$viewFont->radiobutton(-invoke=>1, -label=>'12', -value=>12, -variable=>\$fsize, -command=>\&fontSize);
				$viewFont->radiobutton(-label=>'16', -value=>16, -variable=>\$fsize, -command=>\&fontSize);
				$viewFont->radiobutton(-label=>'20', -value=>20, -variable=>\$fsize, -command=>\&fontSize);
				$viewFont->radiobutton(-label=>'24', -value=>24, -variable=>\$fsize, -command=>\&fontSize);


my 	$searchDrop = $menubarFrame->Menubutton(-text=>'Search', -underline=>0);
my	$searchMenu = $searchDrop->Menu();
					$searchDrop->configure(-menu=>$searchMenu);
		$searchMenu->command(-label=>'Find', -command=>\&searchFind, -underline=>0);
		$searchMenu->command(-label=>'Find Next', -command=>\&searchNext, -underline=>5);
		$searchMenu->command(-label=>'Find Previous', -command=>\&searchPrev, -underline=>5);
		$searchMenu->command(-label=>'Find and Replace', -command=>\&searchReplace, -underline=>9);

		# Help menu
		############
my	$helpDrop = $menubarFrame->Menubutton(-text=>'Help', -underline=>0);
my	$helpMenu = $helpDrop->Menu();
				$helpDrop->configure(-menu=>$helpMenu);
		$helpMenu->command(-label=>'About', -command=>\&helpAbout, -underline=>0);




######################################
# pack everything
######################################
#
$mainFrame->pack(-side=>'top', -fill=>'both', -expand=>1);

	# pack menubar stuff
	#####################
	$menubarFrame->pack(-side=>'top', -fill=>'x');
	$fileDrop->pack(-side=>'left');
	$editDrop->pack(-side=>'left');
	$viewDrop->pack(-side=>'left');
	$searchDrop->pack(-side=>'left');
	$helpDrop->pack(-side=>'right');

	# pack textarea stuff
	######################
	$notebookFrame->pack(-side=>'top', -fill=>'both', -expand=>1);
	$notebook->place(-in=>$notebookFrame, -x=>1, -y=>1,
						-relwidth=>'1.0', -relheight=>'1.0');

	# pack status bar stuff
	########################
	$status->pack(-side=>'top', -anchor=>'s', -fill=>'x');
	$lblModified->pack(-side=>'left', -anchor=>'w');
	$lblPath->pack(-side=>'left', -fill=>'x', -expand=>1);

########################################################################
# Start Subroutines
########################################################################
#

	# Set Status Bar for first page
	###############################
	&pageRaised;			# init settings for first page


MainLoop();


#######################################################################
# Status Bar
#######################################################################
#
sub pageRaised{
	$p = $notebook->raised();						# which page is raised

	# Set Status bar info
	######################
	if($ta[$p]->numberChanges()){					# text has been modified
		$lblModified->configure(-text=>" Modified ");
	}elsif($filePath[$p] eq ""){					# new buffer not saved yet
		$lblModified->configure(-text=>" Untitled Buffer ");
	}else{											# buffer has been saved
		$lblModified->configure(-text=>"  Saved   ");
		&resetPageLabel();
	}
	$lblPath->configure(-text=>$filePath[$p]);		# show path of buffer

	# Set Word Wrap button
	#########################
	$wrap = $ta[$p]->cget(-wrap);

	# Set Font Style & Size button
	################################
	my $temp = $ta[$p]->cget(-font);
	$fstyle = $ta[$p]->fontActual($temp, -family);
	$fsize = $ta[$p]->fontActual($temp, -size);

}

###############################################################################
sub textModified{
	$p = $notebook->raised();
	my $pageLabel = $notebook->pagecget($pageName[$p], -label);
	my $modLabel = "* $pageLabel";
	if ($pageLabel !~ /^\*/i){		# page doesnt show file is modified
		$notebook->pageconfigure($pageName[$p], -label=>$modLabel);
	}
	$lblModified->configure(-text=>" Modified ");	# buffer modified
													# since last save
}

sub resetPageLabel{				# resets page label to show file has been saved
	$p = $notebook->raised();
	$notebook->pageconfigure($pageName[$p], -label=>$fileName[$p]);
}

###################################################################
# Question Dialog
####################################################################
#
sub userWantsToSaveBuffer{
	my $n = $notebook->raised();
	my $file = $notebook->pagecget($pageName[$n], -label);

	my $dialog = $main->Dialog(-title=>"Save File ?",
		-text=>"File has been modified.\n$file \nDo you want to save file? ",
		-bitmap=>'question',
		-default_button=>'Yes',
		-buttons=>[qw/Yes No Cancel/]);
	return $dialog->Show();

}

#######################################################################
# REGEX File: Path/Name
#######################################################################
#
sub regexPath{							# extract path to file
	my ($path2file) = @_;
	if ($path2file =~ /(.*\/)/ig){			# for unix machines '/'
		return $1;
	}elsif($path2file =~ /(.*\\)/ig){		# for windows '\'
		return $1;
	}
}

sub regexFile{							# extract file name only
	my ($fileFromPath) = @_;
	if($fileFromPath =~ /.*\/(.*)/ig){			# for unix machines '/'
		return $1;
	}elsif($fileFromPath =~ /.*\\(.*)/ig){		# for windows '\'
		return $1;
	}
}

##########################################################################
# FILE Menu
###########################################################################
#
sub newFile{

	# Are there any open pages
	#############################
	if(($notebook->raised()) eq ""){
		$i = 0;
	}else{
		# Increment for next new page.
		################################
		$i += 1;
	}
	$p = $i + 1;
	$fileName[$i] = "Untitled $p";
	$filePath[$i] = "";
	# Create a name for the page.
	##############################
	$pageName[$i] = $i;

	# Create a new page.
	#####################
	$nbPage = $notebook->add($pageName[$i], -label=>$fileName[$i],
	                                        -raisecmd=>\&pageRaised);

	$textAreaAndYScrollFrame = $nbPage->Frame();
	$textAreaFrame = $textAreaAndYScrollFrame->Frame();
	$yscrollFrame = $textAreaAndYScrollFrame->Frame();

	# Create a TextUndo widget and place inside the notebook page.
	###############################################################
	$wrap = 'word';
	$ta[$i] = $nbPage->TextUndo(-background=>'white', -wrap=>$wrap);


	$ta[$i]->bind('<KeyPress>', \&textModified);
	$font[$i] = $ta[$i]->Font();
	$ta[$i]->pack(-side=>'top', -fill=>'both', -expand=>1);

	##################################################
	# Scrollbars
	##################################################
	#
	$yscroll = $yscrollFrame->Scrollbar(-command=>['yview', $ta[$i]]);
	$xscrollFrame = $nbPage->Frame();
	$xscroll = $xscrollFrame->Scrollbar(-orient=>'horizontal',
										 -command=>['xview', $ta[$i] ]);

	$ta[$i]->configure(-yscrollcommand=>['set', $yscroll],
						   -xscrollcommand=>['set', $xscroll]);

	$textAreaAndYScrollFrame->pack(-side=>'top', -fill=>'both', -expand=>1);
	$textAreaFrame->pack(-side=>'left', -fill=>'both', -expand=>1);
	$ta[$i]->place(-in=>$textAreaFrame, -x=>1, -y=>1, -relwidth=>'1.0', -relheight=>'1.0');

	$yscrollFrame->pack(-side=>'right', -fill=>'y');
	$yscroll->pack(-side=>'right', -fill=>'y');

	$xscrollFrame->pack(-side=>'top', -fill=>'x');
	$xscroll->pack(-side=>'top', -anchor=>'s', -fill=>'x');

	# Raise the new notebook page.
	###############################
	$notebook->raise($pageName[$i]);

	&pageRaised;					# set status bar
}

sub openFile{

	# Open the file in a new page
	##############################
	&newFile;

	# Retrieve name of raised page.
	################################
	$p = $notebook->raised();

	# Display 'Open' file dialog (From Tk::TextUndo Class).
	########################################################
	$ta[$p]->FileLoadPopup();

	# Retrieve filename.
	####################
	my $openedFile = $ta[$p]->FileName();
	if($openedFile eq ""){				# No file was selected
		$notebook->delete($pageName[$p]);
	}else{
		# Get file name to show for page label (not the path).
		#######################################################
		$filePath[$p] = &regexPath($openedFile);
		$fileName[$p] = &regexFile($openedFile);

		# Findout which page is raised.
		################################
		$notebook->pageconfigure($pageName[$p], -label=>$fileName[$p]);

		&pageRaised;				# set status bar
	}
}

sub saveFile{

	# Findout which page is raised.
	################################
	$p = $notebook->raised();

	# Display 'Save' file dialog
	#  if its the first time to save or
	#  if changes have been made since last save.
	###############################################
	if($ta[$p]->numberChanges){
		$ta[$p]->Save();

		# Retrieve filename
		####################
		my $saveName = $ta[$p]->FileName();

		if($saveName eq ""){		# user canceled save
			return 'CanceledSave';
		}else{
			# Get file name to show for page label
			#######################################
			$filePath[$p] = &regexPath($saveName);
			$fileName[$p] = &regexFile($saveName);

			# Set label of page to filename.
			#################################
			$notebook->pageconfigure($pageName[$p], -label=>$fileName[$p]);

		}
		&pageRaised;				# set status bar
	}
}

sub saveAs{

	# Which page is currently raised
	#################################
	$p = $notebook->raised();

	# Display 'Files Save As' dialog.
	###################################
	$ta[$p]->FileSaveAsPopup();

	# Retrieve Filname of saved file
	##################################
	my $saveAsName = $ta[$p]->FileName();

	if($saveAsName eq ""){			# user canceled save
		return 'CanceledSave';
	}else{
		# Cut path from filename
		#########################
		$filePath[$p] = &regexPath($saveAsName);
		$fileName[$p] = &regexFile($saveAsName);

		# Show the file name in the page tab
		#####################################
		$notebook->pageconfigure($pageName[$p], -label=>$fileName[$p]);
		&pageRaised;
	}
}

sub saveAll{
	# Take note of the current page thats raised.
	###############################################
	my $currentPage = $notebook->raised();

	# Loop thru each page to save them
	###################################
	foreach $p (@pageName){
		$notebook->raise($pageName[$p])
		&saveFile();
	}

	# Be sure the page that was last raised before the call
	# to saveAll is raised again for the user.
	###########################################################
	$notebook->raise($pageName[$currentPage]);

}
sub printFile{
	# add code to print the file
	# need to learn how to do this
	###############################
}

sub includeFile{
	$p = $notebook->raised();
	$ta[$p]->IncludeFilePopup();
	&textModified();
}

sub clearFile{
	$p = $notebook->raised();
	$ta[$p]->ConfirmEmptyDocument();
	&textModified();
}

sub closeFile{

	# Which page is raised.
	########################
	$p = $notebook->raised();

	# Has file been modified.
	##########################
	if($ta[$p]->numberChanges()){
		my $saveBuffer = &userWantsToSaveBuffer();
		if($saveBuffer eq 'Yes'){
			if(&saveFile() eq 'CanceledSave'){
				return ;
			}
		}elsif($saveBuffer eq 'Cancel'){
			return ;
		}
	}
	$notebook->delete($pageName[$p]);
	$lblModified->configure(-text=>" No Files ");
	$lblPath->configure(-text=>"Very Simple Editor-By::Casey Gilmer(icphr)");
	if($notebook->raised() ne ""){
		&pageRaised;
	}
}

sub closeAll{
	# Go thru each page and see if it has been modified
	####################################################
	foreach $p (@pageName){
		$notebook->raise($pageName[$p]);
		if($notebook->raised() eq ""){
			next;
		}
		&closeFile();
	}
	if($notebook->raised() ne ""){
		&pageRaised();
	}else{
		$lblModified->configure(-text=>" No Files ");
		$lblPath->configure(-text=>"pTk-Very Simple Editor-By::Casey Gilmer(icphr)");
	}
}

sub exitEditor{
		# Check if all files have been saved.
		######################################
	&closeAll;

		# Bye.
		#######
	exit(0);
}

#############################################################################
# EDIT Menu : Calls methods in the Tk::TextUndo class
#############################################################################
#
sub undoMenu{
	$p = $notebook->raised();
	$ta[$p]->undo();
}

sub redoMenu{
	$p = $notebook->raised();
	$ta[$p]->redo();
}

sub copyMenu{
	$p = $notebook->raised();
	$ta[$p]->clipboardColumnCopy();
}

sub cutMenu{
	$p = $notebook->raised();
	$ta[$p]->clipboardCut();
}

sub pasteMenu{
	$p = $notebook->raised();
	$ta[$p]->clipboardPaste();
}

sub selectAllMenu{
	$p = $notebook->raised();
	$ta[$p]->selectAll();
}

sub unselectAllMenu{
	$p = $notebook->raised();
	$ta[$p]->unselectAll();
}

############################################################################
# View Menu
############################################################################
#
sub gotoLineMenu{
	$ta[$p]->GotoLineNumberPopup;
}

sub whatLineMenu{
	$ta[$p]->WhatLineNumberPopup;
}

sub searchFind{
	$p = $notebook->raised();
	$ta[$p]->FindPopUp();
}

sub searchNext{
	$p = $notebook->raised();
	$ta[$p]->FindSelectionNext();
}

sub searchPrev{
	$p = $notebook->raised();
	$ta[$p]->FindSelectionPrevious();
}

sub searchReplace{
	$p = $notebook->raised();
	$ta[$p]->findandreplacepopup();
	if($ta[$p]->numberChanges()){
		&textModified();
	}
}

sub wordWrap{
	$p = $notebook->raised();
	$ta[$p]->configure(-wrap=>$wrap);
}

sub fontStyle{
	$p = $notebook->raised();
	my $f = $ta[$p]->cget(-font);
	my $size = $ta[$p]->fontActual($f, -size);
	$font[$p]->configure(-size=>$size, -family=>$fstyle);
	$ta[$p]->configure(-font=>$font[$p]);
}


sub fontSize{
	$p = $notebook->raised();
	my $f = $ta[$p]->cget(-font);
	my $family = $ta[$p]->fontActual($f, -family);
	$font[$p]->configure(-size=>$fsize, -family=>$family);
	$ta[$p]->configure(-font=>$font[$p]);
}

############################################################################
# Help Menu
############################################################################
#
sub helpAbout{
	my $about = $main->Toplevel(-relief=>'raised', -borderwidth=>10);
			$about->title("About Me");
			$about->geometry('+300+300');
	my $label = $about->Label(-text=>'
Very Simple Editor
By: Casey Gilmer (ichpr=IncipientCipher)
gilmercs@iland.net
http://caseygilmer.freehosting.net


~Shows how to use~

Tk::Font
Tk::Dialog
Tk::Notebook
Tk::TextUndo
Tk::Scrollbar
Tk::Menubutton


Right click on the text area and see what happens.
This is a default behavior due to using Tk::TextUndo
which is a subclass of Tk::Text
(which also does the same but not as many options).


 Most of the items in the menubar just call the methods
in the Tk::TextUndo/Tk::Text classes.

----------------------------------------------
You can redistribute this program but only
under the same conditions as Perl/Tk itself.
');
	$label->pack();
}
