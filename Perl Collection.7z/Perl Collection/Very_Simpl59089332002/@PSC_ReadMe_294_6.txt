Title: Very Simple Editor
Description: VSE (Very Simple Editor) is written in Perl/Tk. Each file is opened in a new tab instead of a new window. Shows file name in the tab and the path to the file in the status bar. An '*' in the tab means the file has been modified since its last save, it also says "Modified" in the status bar. This code is basically to show usage of Tk::Menubutton, Tk::NoteBook and Tk::TextUndo.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=294&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
