#!/usr/bin/perl -w

############################################################################
#    Copyright (C) 2007 by Andrea Ghersi                                   #
#    hawk@uno.it                                                           #
#                                                                          #
#    This program is free software; you can redistribute it and/or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

use warnings;
use strict;
use Cwd;

if ( exists $ENV{'SMFBC_HOMEDIR'} )
{ push @INC, $ENV{'SMFBC_HOMEDIR'}; }

require 'printhtml.pl';
require 'parseopts.pl';
require 'bmkscan.pl';
   
my $oOME = "Error opening '%s' in output mode ( CWD: %s ): %s\n";   
my $oIME = "Error opening '%s' in input mode ( CWD: %s ): %s\n";   
   
my $msgbrk = "Broken or unreachable link(s)";
my $msgdup = "Valid but duplicated link(s)";  
     
sub mcdie { printf STDERR @_, $!; exit 1; }   
        
        
##
## MAIN: program start
##   
   
my $opt = processCommandLine();
my $cwd = getcwd();

open INFILE, '<', $opt->{'infile'}  or mcdie( $oIME, $opt->{'infile'}, $cwd );
open OUTFILE,'>', $opt->{'outfile'} or mcdie( $oOME, $opt->{'outfile'},$cwd );

my $linkinfo = bookmarksScancheck ( \*INFILE, $opt );

&printHtmlHeader ( \*OUTFILE, $linkinfo, 'Scan Result' );
&printHtmlContent( \*OUTFILE, $linkinfo, $msgbrk, 'brklink' );
&printHtmlContent( \*OUTFILE, $linkinfo, $msgdup, 'duplink' );
&printHtmlFooter ( \*OUTFILE );
  
close OUTFILE;  
close INFILE;

__END__
