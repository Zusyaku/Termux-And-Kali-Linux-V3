#!/usr/bin/perl -w

############################################################################
#    Copyright (C) 2007 by Andrea Ghersi                                   #
#    hawk@uno.it                                                           #
#                                                                          #
#    This program is free software; you can redistribute it and/or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

use warnings;
use strict;

# for the statusCode hash
require 'netcheck.pl';

my $cssfile='style.css';
my $maxUrlRowSize = 35;

# for images and stylesheet
my $prefix = '';



# #################################################################
#
# Auxliary private functions
#
# #################################################################

sub _readCssFileAndSetPrefix
{
     my $envvar = $ENV{'SMFBC_HOMEDIR'};
     my $csscontent = '';

     ## try to open file <$cssfile> looking
     ## into the cwd

     if ( open ( INFILE, '<', $cssfile ) ) 
        { $prefix= cwd(); }  
     elsif (
       
        ## cwd does not contain <$cssfile>
        ## we use the env-var if set  

        $envvar && open ( INFILE, '<', 
         "$envvar/$cssfile" ) 
     ) 
        { $prefix = $envvar; }      
     else 
        { return ''; }

     while ( my $line = <INFILE> )
     { $csscontent .= "\t  $line"; }

     close INFILE;
     return $csscontent;
}

##
##

sub _formatUrl
{
     my $url = shift;
     my $bak = $url;
     
     #$url =~ s/(.{$maxUlen}).*/$1\.\.\./;
     
     $url =~ s/(.{$maxUrlRowSize})/$1<br\/>\n\t\t/g;
     $url =~ s/^/<br\/>\n\t\t/ if ( $bak ne $url ); 
     
     return $url;
}
    
   


# #################################################################
#
# Main functions
#
# #################################################################

##
##

sub printHtmlHeader 
{
   my $flstream = shift;
   my $linkinfo = shift;
   my $htmtitle = shift;

   my $csscontent = _readCssFileAndSetPrefix();
   print $flstream "
    <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 
    'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
    <html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>
      <head>
        <meta http-equiv='Content-Type' content='text/html; 
        charset=ISO-8859-1'/>
        <title>$htmtitle</title>
        <!--link rel='stylesheet' type='text/css' 
          href=\"$cssfile\" title='stylesheet'/-->
        <style type='text/css'> 
          $csscontent
        </style>
      </head>   
      <body>
        <h1>&lt;$htmtitle:
          <span style='font-size:16px;'>
          $linkinfo->{linkstat}{globlink} 
          bookmarks scanned 
          </span>&gt;
        </h1>
        <br/>";  
}

##
##

sub printHtmlFooter 
{
   my $flstream = shift;
   
   print $flstream "
        <a href='http://validator.w3.org/check?uri=referer'>
          <img style='border:0' src='$prefix/images/vxhtml.png'
            alt='Valid XHTML 1.0 Transitional' height='25' 
            width='68'/>
        </a>
        <br/>
        <a href='http://jigsaw.w3.org/css-validator'>
          <img style='border:0' src='$prefix/images/vcss.png'
            alt='Valid CSS!' height='25' width='68'/>
        </a>              
      </body>      
    </html>\n";
}

##
##
  
sub printHtmlContent 
{
   my $flstream  = shift;
   my $linkinfo  = shift;   
   my $blockname = shift;
   my $info      = shift;
      
   my ( $bkmname, $url, $fmturl );   
   my ( $dupcnt, $stcode, $statcode );
         
   if ( ! defined ( $linkinfo->{$info} ) )
   {  return; }
           
   print $flstream "
        <div class='linkinfo_wrapper'>
        <h3><span class='block_name'>$blockname: 
          $linkinfo->{linkstat}{$info}</span>
        </h3>
        </div>
        <br/>";
          
   $statcode = getStatusCode();       
   foreach $url ( keys %{$linkinfo->{$info}} )
   {                 
       $bkmname = $linkinfo->{$info}{$url}[2];
       $dupcnt  = $linkinfo->{$info}{$url}[0];
       
       $stcode  = $linkinfo->{$info}{$url}[1];
       $fmturl  = _formatUrl ( $url );
                                        
       print $flstream "                       
        <table><tr><td>                             
          <ul>
            <li>Bookmark name:
                <span class='ultext'>$bkmname
                </span> 
            </li>
            <li>URL:<br/>
                <a href='$url'>$fmturl</a>
                <br/><br/>  
            </li>
            ";  
                              
       if ( $info eq 'brklink' )
       { 
          print $flstream "
            <li>Status code value:
              <span class='ultext'>$statcode->{$stcode}
              </span>
            </li>"; 
       }                
       
       print $flstream "
            <li>Duplication count:
                <span class='ultext'> $dupcnt
                </span>
            </li>";
                                           
       print $flstream "
            <li>Duplicate's list:
              <blockquote>
                <span class='ultext'>";
                        
       if ( $dupcnt > 0 )
       {
          # remove first three field before printing
          splice( @{ $linkinfo->{$info}{$url} }, 0, 3 );

          foreach $bkmname( @{$linkinfo->{$info}{$url}} )
          {
             print $flstream "
               $bkmname <br/>"; 
          }
       }
       else { print $flstream "empty"; } 
       
       print $flstream "
                </span>
              </blockquote>      
            </li>        
          </ul>
        </td></tr></table> 
        <br/>";
   }     
         
   print $flstream "
   \t<br/><br/>";            
}    


return 1;
__END__
