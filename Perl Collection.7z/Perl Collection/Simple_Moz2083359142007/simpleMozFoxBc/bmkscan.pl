#!/usr/bin/perl -w

############################################################################
#    Copyright (C) 2007 by Andrea Ghersi                                   #
#    hawk@uno.it                                                           #
#                                                                          #
#    This program is free software; you can redistribute it and/or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

use warnings;
use strict;

require 'netcheck.pl';

my %linkstat = ( 'brklink' => 0, 'duplink' => 0, 'globlink' => 0 );
my %linkinfo = ( 'linkstat' => \%linkstat );  



# #################################################################
#
# Auxliary private functions
#
# #################################################################

sub _initBookmarkArrayInfo
{
   my $bmktype = shift; my $bmkurl  = shift;
   my $bmkname = shift; my $bmkcode = shift;
  
   # bookmark duplicates counter
  
   $linkinfo{$bmktype}{$bmkurl}[0] = 0;
  
   # bookmark error code and name 
  
   $linkinfo{$bmktype}{$bmkurl}[1] = $bmkcode;  
   $linkinfo{$bmktype}{$bmkurl}[2] = $bmkname;
}


sub _updateBookmarkArrayInfo
{
   my $bmktype = shift; 
   my $bmkurl  = shift;
   my $bmkname = shift;

   push @{$linkinfo{$bmktype}{$bmkurl}}, $bmkname; 
   $linkinfo{$bmktype}{$bmkurl}[0]++;
}



# #################################################################
#
# Main function
#
# #################################################################

sub bookmarksScancheck ($$) 
{         
   my $bmkregex = '.*<A HREF="(.*?)".*>(.+)</A>';
   my ( $bmkname, $bmkurl );
      
   my $flstream = shift; 
   my $opts = shift;     
   
   # start reading and parsing file
   
   while ( my $line = <$flstream> )
   {        
      if ( $line =~ m/$bmkregex/i )
      {
          $linkinfo  {linkstat}{globlink}++;
          $bmkname = $2; 
          $bmkurl  = $1;

          # not first time addition: dup broken link
                                           
          if ( exists ( $linkinfo{brklink}{$bmkurl} ) )
          {                        
              _updateBookmarkArrayInfo ( 'brklink', 
                 $bmkurl, $bmkname ); 
                 
              # read next line
              next;   
          }
                                          
          # not first time addition: dup link found (1) 
        
          if ( exists ( $linkinfo{othlink}{$bmkurl} ) && 
              !exists ( $linkinfo{duplink}{$bmkurl} ) 
          )      
          {                            
              _initBookmarkArrayInfo( 'duplink', $bmkurl, 
                 $linkinfo{othlink}{$bmkurl}[0], '' );
          }
                                     
          # not first time addition: dup link found (2)
           
          if ( exists ( $linkinfo{othlink}{$bmkurl} ) )
          {
              _updateBookmarkArrayInfo ( 'duplink', 
                 $bmkurl, $bmkname ); 
                 
              $linkinfo{linkstat}{duplink}++;   
              next;  
          }
                                
          # first time addition: broken or valid link

          if ( my $bmkcode = netcheck ( $bmkurl, $opts ) )
          {                      
              _initBookmarkArrayInfo( 'brklink', 
                 $bmkurl, $bmkname, $bmkcode ); 
                 
              $linkinfo{linkstat}{brklink}++;                 
              next;                    
          }
         
          # valid link
          $linkinfo{othlink}{$bmkurl}[0] = $bmkname;    
       }     
   }
   
   # contains all info about links
   return \%linkinfo;
}

__END__
