#!/usr/bin/perl -w

############################################################################
#    Copyright (C) 2007 by Andrea Ghersi                                   #
#    hawk@uno.it                                                           #
#                                                                          #
#    This program is free software; you can redistribute it and/or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

use Getopt::Long;
use warnings;
use strict;

my $defaultMaxTimeout = 10;
my $defaultTimeout = 2;  
  
my $outfile='./scanres.html';
my $infile='';

# hash that keeps cmdline options 
my %opt = ();

# version number
my $version = "0.2";

   
# #################################################################
#
# Auxliary private functions
#
# #################################################################  
  
##
## 
  
sub _usage()
{
    print STDERR << "EOF";

    Usage: $0 [-h] [-timeout value[:maxvalue]] [-i infile] [-o outfile] 
    Version: $version
    
    Options:
    ========

    -timeout value[:maxvalue] : network timeout value 
    -o outfile \t\t      : use outfile as output file
    -i infile  \t\t      : use infile as input file
    -h         \t\t      : this help message

    Notices:
    ========

    If this script runs without any options,
    the variables <\$infile> and <\$outfile> 
    inside the script itself must be set to
    a valid filename.
    
    If input and output files are the same,
    the script will exit without performing
    any kind of operations.
    
EOF
    exit 0;
}  
  
##
##  
  
sub _dealWithTimeoutOpt
{    
    my $maxTimeout = $defaultMaxTimeout;   
    my $timeoutVal = $defaultTimeout;    

    if ( $opt{timeoutOpt} ) 
    {
       if ( $opt{timeoutOpt} =~ /^(\d+):(\d+)$/ ) 
       {
          $maxTimeout = $2;
          $timeoutVal = $1;   
       } 
       elsif ( $opt{timeoutOpt} =~ /^(\d+)$/ ) 
       {
          $maxTimeout = $defaultMaxTimeout;          
          $timeoutVal = $1;
       } 
       else 
       {
          die 
            "$0: Error: wrong timeout value given: ". 
            "($opt{timeoutOpt})\n";
       }
       
       if ( $maxTimeout <= $timeoutVal )
       {
          die 
            "$0: Error: timeout value ($1) must be ".
            "less than max value ($maxTimeout)\n";
       }
    }
     
    $opt{maxTimeout} = $maxTimeout; 
    $opt{timeoutVal} = $timeoutVal; 
}  
  
##
##  
  
sub _dealWithInOutFiles
{
    $opt{o} and $outfile = $opt{o};
    $opt{i} and $infile  = $opt{i};
  
    if ( $infile eq "" ) 
    { 
       die 
         "$0: Error: no input file provided!\nUse " . 
         "option <-i infile>, or set the value of " .
         "variable <\$infile> in 'parseopts.pl'.\n"; 
    }  

    if ( $outfile eq "" ) 
    { 
       die 
         "$0: Error: no output file provided!\nUse " . 
         "option <-i outfile>, or set the value of " .
         "variable <\$outfile> in 'parseopts.pl'.\n"; 
    } 
      
    if ( $infile eq $outfile )  
    { 
       die 
         "$0: Error: input and output file are the ". 
         "same!\nCannot proceed with this script, " . 
         "exiting...\n";
    }
        
    $opt{outfile} = $outfile; 
    $opt{infile}  = $infile;     
}
  
  
  
# #################################################################
#
# Main functions
#
# #################################################################

##
##
  
sub processCommandLine()
{                    
    GetOptions (            
      'timeout=s' => \$opt{timeoutOpt},
      'o=s'       => \$opt{o}, 
      'i=s'       => \$opt{i}, 
      'h'         => \$opt{h} 
    ) or _usage();    
    
    $opt{h} and _usage();
    _usage() if ( $#ARGV > -1 );    
                         
    _dealWithTimeoutOpt();
    _dealWithInOutFiles();
    
    return \%opt;
}


return 1;
__END__
