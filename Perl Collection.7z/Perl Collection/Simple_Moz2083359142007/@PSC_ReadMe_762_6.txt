Title: Simple Mozilla-Firefox Bookmarks Checker v0.2
Description: This small and simple Perl program permits you to get some informations about mozilla-firefox bookmarks. It scans a given bookmark file and tries to output all broken and duplicated links in the file itself. It saves the result to an html file whose style is pretty changeable.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=762&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
