Title: Universal Archive Bruteforcer
Description: the purpose of this code is to propose a quick a bruteforce algorithm and an all in one tool for these applications (such 7-zip) that does not have a complete support on bruteforce/password probing market or simply any application that you can call via command line passing generated values using a batch process , the program support resume and ranges (useful for splitting the bruteforcing on multiple machines passing different ranges..) the program can be used for sequential password generation (ansi unicode support) ... see the help or simple readme for more infos

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=788&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
