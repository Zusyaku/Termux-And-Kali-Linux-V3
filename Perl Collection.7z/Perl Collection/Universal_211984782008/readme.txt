Universal Archive Bruteforcer 1.0

(C) 2008 Berardi Michele
mfxaub@tin.it
http://berardimichele.interfree.it


Run the program with no parameters for a printed help


notes about "bruteforcer.ini":

in the command_line tag you can build the command line for the external un-archiver and also use these "search&replace" tags:

!UNZIPPER_PATH (will be replaced with the unzipper path you specify in the .ini or via command line)
!PROTECTED_FILENAME (will be replaced with the protected archive path you specify in the .ini or via command line)
!BRUTEFORCE_PASSWORD ((will be dinamically replaced with the current generated password)


see the bruteforcer.ini for a clear example (7-zip 7z.exe commandline version..)


If you apreciate the effor donate here:

http://berardimichele.interfree.it/src/perl/donate.htm
