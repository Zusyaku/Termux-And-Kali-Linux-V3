#!/usr/bin/perl

#
# Universal Archive Bruteforcer 1.0
#
# (C) 2008 Berardi Michele
#                    mfxaub@tin.it
# http://berardimichele.interfree.it
#


# UABruteforcer.pl -f="archive.7z" -a="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@ "
# UABruteforcer.pl -u="%ProgramFiles%\\7-Zip\\7z.exe" -f="archive.7z" -a="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@ "


use Getopt::Long qw(:config no_ignore_case no_auto_abbrev pass_through);


if ($#ARGV < 0) {
usage();
}



GetOptions ("a=s" => \$global_alphabet);
#$global_alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 `~!@#\$%^&*()-_=+[{]}\\|;:'\",<.>/?" unless defined $global_alphabet;
$global_alphabet = readini("UABruteforcer.ini",'settings','alphabet') unless defined $global_alphabet;

GetOptions ("p=s" => \$global_startPWD);

GetOptions ("u=s" => \$global_unzipper_path);
$global_unzipper_path = readini('UABruteforcer.ini','settings','unzipper_path') unless defined  $global_unzipper_path;

GetOptions ("f=s" => \$global_protected_file);
$global_protected_file = readini('UABruteforcer.ini','settings','protected_file')  unless defined $global_protected_file;

GetOptions ("r=s" => \$resume_file);
$resume_file = $global_protected_file . readini('UABruteforcer.ini','settings','resume_file_ext') unless defined $resume_file;

GetOptions ("d=s" => \$decryptedpwd_file);
$decryptedpwd_file = $global_protected_file . readini('UABruteforcer.ini','settings','decryptedpwd_file_ext') unless defined $decryptedpwd_file;

GetOptions ("c" => \$clearstate);

if ((not defined $clearstate) && (not defined $global_startPWD)) {
open(REDOFILE, "<$resume_file");
$global_startPWD = <REDOFILE>;
chomp($global_startPWD);
close (REDOFILE);
}


GetOptions ("l=s" => \$global_minimal_currentPWD_len);
$global_minimal_currentPWD_len = 1 unless defined $global_minimal_currentPWD_len;

GetOptions ("m=s" => \$global_maximal_currentPWD_len);
$global_maximal_currentPWD_len = 10000000 unless defined $global_maximal_currentPWD_len;


GetOptions ("s" => \$global_print_currentPWD);
GetOptions ("b" => \$global_block_save_currentPWD);
GetOptions ("g" => \$global_generate_only_currentPWD);


$command_line = readini('UABruteforcer.ini','settings','command_line');
$command_line =~ s/!UNZIPPER_PATH/$global_unzipper_path/g;
$command_line =~ s/!PROTECTED_FILENAME/$global_protected_file/g;






@global_alphabet_vector = split('', $global_alphabet);
$global_alphabet_vector_len = $#global_alphabet_vector;


  if ($global_startPWD ne "") {
  # start with an assigned password from the command line
    $global_currentPWD = $global_startPWD;
  }
else
{
# no password so start with the first character in our alphabet
# duplicated x times (where x is equal to the value we passed
# via "l" minimal password len parameters
$global_currentPWD = @global_alphabet_vector[0] x $global_minimal_currentPWD_len;
}


@global_tmpPWD = split('', $global_currentPWD);

$global_currentPWD_len = length($global_currentPWD);
$global_old_currentPWD_len=$global_currentPWD_len - 1;


$global_first_alphabet_element = @global_alphabet_vector[0];
$global_last_alphabet_element = @global_alphabet_vector[$#global_alphabet_vector];


if (defined $global_print_currentPWD)
{
# first password of the range!
print "$global_currentPWD\n";
}

$global_endrangePWD = @global_alphabet_vector[$#global_alphabet_vector] x $global_currentPWD_len;



#
# performance test
#$global_currentPWD_counter = 1;
#$timea = time;
#



while (1) {

if ($global_currentPWD eq $global_endrangePWD) {

if ($global_currentPWD_len eq $global_maximal_currentPWD_len) {
exit 0;
}

$global_endrangePWD = $global_currentPWD . $global_last_alphabet_element;

$global_old_currentPWD_len=$global_currentPWD_len;

$global_currentPWD_len++;
$global_currentPWD = $global_first_alphabet_element x $global_currentPWD_len;

@global_tmpPWD = split('', $global_currentPWD);

 }
else
{

$x = $global_old_currentPWD_len;

while (1) {
   if ($global_tmpPWD[$x] eq $global_last_alphabet_element) {
      $global_tmpPWD[$x] = $global_first_alphabet_element;
      $x--;
    } else {
      $iTemp = index($global_alphabet, $global_tmpPWD[$x]);
      $iTemp++;
      $global_tmpPWD[$x] = $global_alphabet_vector[$iTemp];
      last;
    }
 }

$global_currentPWD = join("", @global_tmpPWD);

}


if (defined $global_print_currentPWD)
{
print "$global_currentPWD\n";
}


#  SAVE SESSION
if (not defined $global_block_save_currentPWD)
{
 open(REDOFILE, ">$resume_file");
 print REDOFILE $global_currentPWD;
 close (REDOFILE);
}
#


# RUN EXTERNAL APPLICATION
if (not defined $global_generate_only_currentPWD)
{
# dynamic version
 $tmp_command_line = $command_line;
 $tmp_command_line =~ s/!BRUTEFORCE_PASSWORD/$global_currentPWD/;
 $response = system($tmp_command_line);
# static (fast version / no customization)
#$response = system('"' . $global_unzipper_path  . '"' . " " . "t -y -p" . '"' . $global_currentPWD . '"' . " " . '"' . $global_protected_file . '"');
}
#


# password found ? store in a file and exit!
if ($response eq 0)
{
open(LOGFILE, ">$decryptedpwd_file");
print LOGFILE $global_currentPWD;
close (LOGFILE);
exit 0;
}



#
# performance test
#$global_currentPWD_counter++;
#if ($global_currentPWD_counter eq 10000000) {
#      last;
#}
#



}


#
# performance test
#print time - $timea . "\n";
#






#
#
# EXTRA SUBROUTINES
#
#



sub usage {
 print <<EOF;

$0 1.0

Usage: $0 [PARAMETERS] [SWITCHES]

  PARAMETERS:

  -u Unzipper/external program path
  -f protected File to recover
  -r file to load/store the Resume point (optional) the default name will be
     [protected_filename.lst] . If defined does not take in consideration the passed "-p" value
  -a custom Alphabet
  -l minimal password Len (unless you specify the p value this is the minimal lenght)
  -m Maximal password len
  -p last used Password (manual resume point) (crack passwords using multiple machines)
  -c Clear last saved password (see "-r" option)
  -d file (generated in case of decryption) containing the Decrypted password

  SWITCHES:

  -s print password on Screen
  -b Block save last used password on restore file (see "-r" option)
  -g Generate only (don't run the external program)
 

Examples:

  $0 -a="aeiou" -p="ab" -z="%ProgramFiles%\\7-Zip\\7z.exe" -f="archive.7z" -l=1 -m=10
  $0 -a="aeiou" -c -z="%ProgramFiles%\\7-Zip\\7z.exe" -f="archive.7z" -l=1 -m=10
  $0 -f="archive.7z" -r="archive.7z.thread0.lst" -a="aeiou" -l="2" -m="2" -b -g -s

EOF
  exit;
}





sub readini {
  my($inipath, $section, $key) = @_; 
	open(INIFILE, $inipath) || die " [OTP FUNCTIONS LOG] Can't open for reading - $inipath\n\n";
while (<INIFILE>) {
if ($_ =~ m/^\[$section\]\s*\n/im) {
while (<INIFILE>) {
if ($_ != m/^\[+\S*\]\s*\n/im) {
close (INIFILE);
return '';
}
if ( $_ =~ m/^$key\s*=\s*"?([^\n]+)"?\s*\n/im ) {
  close (INIFILE);
  return $1;
	}
}
}
}
  close (INIFILE);
  return '';
}
