Title: install a debian based system!
Description: This you will have a exact copy of your system.
Target systems are all debian based systems!
Run this script as root
sudo perl install.pl
Make a backup on the target computer
sudo cp /etc/apt/sources.list /etc/apt/sources.list_old
Copy the sources.list to the target computer
sudo rcp ~/sources.list 10.0.0.1:/etc/apt/sources.list
Copy the install script install.sh
sudo rcp ~/install.sh 10.0.0.1:/home/marc/
And run the script
sudo install.sh
After this you will have a exact copy of your system
I know there are outer ways to do this
But with me they never work!
Target systems are all debian based systems!
like Debian(theuuuu) ubuntu gnoppix nubuntu edubuntu

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=724&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
