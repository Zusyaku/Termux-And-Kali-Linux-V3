#!/usr/bin/perl
use Shell;
# 
# copy your system to an outer system.
# 
my $temp = dpkg (" --get-selections > debian.package.list"); 
$temp = cp ("/etc/apt/sources.list ~/");
sleep(3);
my $filename = "install.sh";
open(MBOX, ">$filename") or die "Can't write to `$filename': $!\n";
@lines = cat ("debian.package.list");
foreach $line (@lines) {
     $line =~ s/\install//g;
     print "sudo apt-get -y install $line";
     print MBOX "sudo apt-get -y install $line\n";

}
close(MBOX);
sleep(3);

print "\n\n\nRun this script as root\n";
print "sudo perl install.pl\n\n";
print "Make a backup on the target computer\n";
print "sudo cp /etc/apt/sources.list /etc/apt/sources.list_old\n";
print "Copy the sources.list to the target computer\n";
print "sudo rcp ~/sources.list 10.0.0.1:/etc/apt/sources.list\n";
print "Copy the install script install.sh\n";
print "sudo rcp ~/install.sh 10.0.0.1:/home/marc/\n";
print "And run the script\n";
print "sudo install.sh\n";
print "After this you will have a exact copy of your system\n";
print "I know there are outer ways to do this\n";
print "But with me they never work!\n\n";
print "Target systems are all debian based systems!\n";
print "like Debian(theuuuu) ubuntu gnoppix nubuntu edubuntu\n";
 
