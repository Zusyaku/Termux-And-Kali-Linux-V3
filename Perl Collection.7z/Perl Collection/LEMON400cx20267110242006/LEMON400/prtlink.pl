#usr/bin/perl;

use Net::FTP;
$ftp = Net::FTP->new("192.168.1.101", Timeout => 10)
        or die "Could not connect.\n";


$username = "root";
$password = "root";



$ftp->login($username, $password)
        or die "Could not log in.\n";


#$ftp->cwd('/pub/test');


#$remotefile = "main.html";
$localfile = "sbpl.txt";


$ftp->put($localfile)
or die "Can not put file.\n";

