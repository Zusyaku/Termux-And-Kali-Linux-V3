#!/usr/bin/perl
# Scripted by SAM from SSS = SATO ASIA PACIFIC
# DATED: 09 OCT 2006


use Tk;
require Tk::Dialog;
$Main=MainWindow->new;
$Main->title("LEMON400");
$Main->geometry("440x180+8+8");



$bk=$Main->Label(-anchor => "w", -background => "#FFFF11");
$bk->place( -width => 430, -height => 170, -x => 5, -y => 5);


$entry=$Main->Label(-anchor => "w", -text => "Barcode Info:", -background => "#BBB0C8",
-font => "Tahoma 10 bold", -foreground => "#FFFFFF" );
$entry->place( -width => 100, -height => 24, -x => 40, -y => 32);
$p1 = $Main->Entry(-borderwidth => 3,-font => "Arial 10 normal",
    -foreground => "#000000",-relief => "sunken");
$p1->place(-width => 264,-height => 24,-x => 144,-y => 32 );



$entry2=$Main->Label(-anchor => "w", -text => "EDB REF No:", -background => "#BBB0C8",
-font => "Tahoma 10 bold",-foreground => "#FFFFFF");
$entry2->place( -width => 100, -height => 24, -x => 40, -y => 74);
$p2 = $Main->Entry( -borderwidth => 3,
    -font => "Arial 10 normal", -foreground => "#000000", -relief => "sunken");
$p2->place(-width => 264,-height => 24,-x => 144,-y => 74);



$save=$Main->Button(-activebackground => "#FFFCBF",
-activeforeground => "#E30229", -background => "#FFFFFF",
-borderwidth => 1, -text => ">>> Print >>>",
-command => \&save, -cursor => "", -font => "Tahoma 9 bold",
-foreground => "#000999", -relief => "solid");
$save->place(-width => 250, -height => 25, -x => 100, -y => 130);


sub save() {
$widget=@_; $a = $p1-> get();
$widget=@_; $b = $p2-> get();

for(open(IN, ">sbpl.txt"))
{ print IN ("                                                                                                                                                                                                                                                                                                                         ACB+19ZACD200,3300Z                                                                                                                                                                                                        AEX0ARA3H001V001CE1A105190799CS3#E4Z                                                                                                                                                                                                        APS%2H0615V0265B102052*$a*%2H0512V0209L0101P04M*$a*%2H0615V0336L0102P02S$b%2H0614V0412L0202P02S$a&Z                                                                                                                                                                                                        A/CK0Q1CL0Z                                                                                                                                                                                                                                                                                                                                                                                                                    ");
close(IN); }

sleep 0.3;
$send="start prtlink.pl"; system($send);};



#$dev=$Main->Button(-activebackground => "#FFFCBF",
#-activeforeground => "#E30229", -background => "#FFFFFF",
#-borderwidth => 2, -text => "Set Port",
#-command => \&dev, -cursor => "", -font => "Verdana 9 bold",
#-foreground => "#000999", -relief => "solid");
#$dev->place(-width => 150, -height => 25, -x => 440, -y => 40);
#sub dev() { $a="start devmgmt.msc";system($a) };




#$file=$Main->Button(-activebackground => "#FFFCBF",
#-activeforeground => "#E30229", -background => "#FFFFFF",
#-borderwidth => 2, -text => "Restart Spooler",
#-command => \&file, -cursor => "", -font => "Verdana 9 bold",
#-foreground => "#000999", -relief => "solid");
#$file->place(-width => 150, -height => 25, -x => 440, -y => 80);
#sub file() { $b="start link.bat"; system($b) };




#$abt=$Main->Button(-activebackground => "#FFFCBF",
#-activeforeground => "#E30229", -background => "#FFFFFF",
#-borderwidth => 2, -text => "ABOUT",
#-command => \&abt, -cursor => "", -font => "Verdana 9 bold",
#-foreground => "#000999", -relief => "solid");
#$abt->place(-width => 150, -height => 25, -x => 440, -y => 120);
#sub abt()
#{
#$dialog1 = $Main->Dialog(-title => "ABOUT",
#-text=>"CL408E FORM INTERFACE ver 2.0 by SAM TAN EH", -default_button => 'OK', #-buttons => ['OK']);
#$click = $dialog1->Show;}


MainLoop;








