#!/usr/bin/perl

use CGI qw/:standard/;

# for further comments please refer to gb_read2.pl

@kette = ("");
open(datei, "<gb_count.txt");
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$input_fields = 9;

$komm = join("",@kette);

@eintrag = split(/�/,$komm);

$entries = 0; # doesn't matter since all entries will be placed onto a single page

$start = one_page; # puts all entries onto a single page

unless($start eq one_page)
{
$x = $eintrag[0] - $start;
$y = $eintrag[0] - $start;
$multi = $eintrag[0] - ($eintrag[0] - $x);
$end = $x - $entries;
$page_now = $start / $adder + 1;
}
else
{
$multi = $eintrag[0];
$end = 0;
$y = $eintrag[0];
}

sub write
{
@kette = ("");
open(datei, "<gb_data.txt");
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$komm = join("",@kette);

@liste = split(/�/,$komm);

$liste[(($multi-1)*$input_fields)+4]=~ s/[\n]/<br>/g;

$liste[(($multi-1)*$input_fields)+2]=~ s/[\s]//;
$liste[(($multi-1)*$input_fields)+3]=~ s/[\s]//;
$liste[(($multi-1)*$input_fields)+4]=~ s/[\s]//;
$liste[(($multi-1)*$input_fields)+8]=~ s/[\s]//;

print qq!

<br>
<hr noshade size="1"><br>
message $y:<br>
from: !;

if ($liste[(($multi-1)*$input_fields)+2] =~ /@/) # checks for if the email adress is valid
{
print qq!

<a href="mailto:$liste[(($multi-1)*$input_fields)+2]">$liste[(($multi-1)*$input_fields)+1]</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;!;
}
else
{
print qq!

<font color="#FF0000">$liste[(($multi-1)*$input_fields)+1]</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;!;
}

if ($liste[(($multi-1)*$input_fields)+3] =~ /\./) # checks if the website is valid
{
 if ($liste[(($multi-1)*$input_fields)+3] =~ /\bhttp/) # checks if url contains http, if not http will be added
 {
$liste[(($multi-1)*$input_fields)+3] =~ s/http:\/\///;
print qq!<a href="http://$liste[(($multi-1)*$input_fields)+3]" target="_parent">$liste[(($multi-1)*$input_fields)+3]</a><br>!;
 }
 else
 {
print qq!<a href="http://$liste[(($multi-1)*$input_fields)+3]" target="_parent">$liste[(($multi-1)*$input_fields)+3]</a><br>!;
 }
}
else
{
print "<br>";
}

print qq!
date: $liste[(($multi-1)*$input_fields)+5]<br>
<br>
$liste[(($multi-1)*$input_fields)+4]

!;

$multi = $multi - 1;
$y = $y - 1;
}

print "Content-type: text/html\n\n";

print qq!

<html>
<head>
<title>view guestbook</title>
<meta name="author" content="Michael Salcher - donnervogel productions 2001">
<meta name="generator" content="Ulli Meybohms HTML EDITOR">
<meta name="MSSmartTagsPreventParsing" content="TRUE">
<link rel="stylesheet" href="http://www.geocities.com/michael_salcher/css/eigenschaften.css" type="text/css">
</head>
<body text="#FFFFFF" bgcolor="#000000" link="#FF0000" alink="#FF0000" vlink="#FF0000">
<font face="Lucida Blackletter">
<br>
<div align="center"><h1>guestbook</h1></div><br>
<br>
<div align="center">$eintrag[0] people (some twice) have signed my guestbook until yet</div>
</font>

!;

until($multi == $end)
{
&write;
}

print qq!

</html>
<noscript><plaintext><table>
</body>

!;
