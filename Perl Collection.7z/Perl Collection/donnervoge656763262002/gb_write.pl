#!/usr/bin/perl

use CGI qw/:standard/;

$name=param('name'); # input fields
$mail=param('mail');
$website=param('website');
$message=param('message');

$Jetztwert = time(); # uses the perl time funtion to get the date and time
$Jetztzeit = localtime($Jetztwert);
&names;
@Zeit = split(/ +/,$Jetztzeit);

sub names
{
 $Jetztzeit =~ s/Jan/01/;
 $Jetztzeit =~ s/Feb/02/;
 $Jetztzeit =~ s/Mar/03/;
 $Jetztzeit =~ s/Apr/04/;
 $Jetztzeit =~ s/May/05/;
 $Jetztzeit =~ s/Jun/06/;
 $Jetztzeit =~ s/Jul/07/;
 $Jetztzeit =~ s/Aug/08/;
 $Jetztzeit =~ s/Sep/09/;
 $Jetztzeit =~ s/Oct/10/;
 $Jetztzeit =~ s/Nov/11/;
 $Jetztzeit =~ s/Dec/12/;
}

$name =~ s/�/*/gi; # replaces � with *, cause � seperates one record from another
$mail =~ s/�/*/gi;
$website =~ s/�/*/gi;
$message =~ s/�/*/gi;

open(DATEI, ">>gb_data.txt");  # opening file to begin writing at the end of the file
print DATEI "$name� $mail� $website� $message� $Zeit[2].$Zeit[1].$Zeit[4]� $Zeit[3]� $ENV{'REMOTE_ADDR'}� $ENV{'REMOTE_HOST'}� $ENV{'HTTP_USER_AGENT'}�\n";
close(DATEI);

@kette = ("");
open(datei, "<gb_count.txt"); # reads the number of entries
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$komm = join("",@kette);

@liste = split(/�/,$komm);

$count = $liste[0] + 1; # increases the number of entries

open(DATEI, ">gb_count.txt"); # saves the number of entries
print DATEI "$count�\n";
close(DATEI);

print "Content-type: text/html\n\n";

print qq!

<html>
<head>
<title>did it</title>
<meta name="author" content="michael salcher - donnervogel productions, 2001">
<meta name="generator" content="Ulli Meybohms HTML EDITOR">
</head>
<body text="#FFFFFF" bgcolor="#000000" link="#FF0000" alink="#FF0000" vlink="#FF0000">

<script language="JavaScript">
<\!--

   location.replace("signed.html");

//-->
</script>

</body>
</html>
<noscript><plaintext><table>

!;