#!/usr/bin/perl

use CGI qw/:standard/;

@kette = (""); # gets the number of entries
open(datei, "<gb_count.txt");
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$input_fields = 9;

$invisible = FFFFFF; # the font color that is used to make the "forward" and "back" links invisible

$komm = join("",@kette);

@eintrag = split(/�/,$komm);

$entries = param('entries');

$adder = $entries;

$start = param('start'); # entry from which listing will beginn

$back = $start - $adder; # calculates $start for the last and next page

$fro = $start + $adder;

sub intrechnerpositiv # calculates the number pages that will be need to view all entries
{
 if(int($_[0] / $_[1]) == $_[0] / $_[1]) # checks if there is a rest (e.g. 100/10 = 10, no rest)
 {
 $seiten = int($_[0] / $_[1]);
 }
 else
 {
 $seiten = int($_[0] / $_[1]) + 1; # cause there is a rest, 1 will be added (e.g. 70/25 = 2 [with a rest] but the number of pages has to be 3 = 2 + 1
 }
}

&intrechnerpositiv($eintrag[0],$entries);

if($eintrag[0] - $start < $entries) # for the case that there are to less entries to fill a page
{
$entries = $eintrag[0] - $start;
}

unless($start eq one_page) # finds the relevant records
{
$x = $eintrag[0] - $start;
$y = $eintrag[0] - $start;
$multi = $eintrag[0] - ($eintrag[0] - $x);
$end = $x - $entries;
$page_now = $start / $adder + 1;
}
else
{
$multi = $eintrag[0];
$end = 0;
$y = $eintrag[0];
}

sub write
{
@kette = ("");
open(datei, "<gb_data.txt");
while(<datei>)
 {
  push(@kette,$_);
 }
close(datei);

$komm = join("",@kette);

@liste = split(/�/,$komm);

$liste[(($multi-1)*$input_fields)+4]=~ s/[\n]/<br>/g; # truns unix breaks into html breaks

$liste[(($multi-1)*$input_fields)+2]=~ s/[\s]//; # deletes leading blanks
$liste[(($multi-1)*$input_fields)+3]=~ s/[\s]//;
$liste[(($multi-1)*$input_fields)+4]=~ s/[\s]//;
$liste[(($multi-1)*$input_fields)+8]=~ s/[\s]//;

print qq!

message: $y<br>
von: $liste[(($multi-1)*$input_fields)+1]<br>
email: <a href="mailto:$liste[(($multi-1)*$input_fields)+2]">$liste[(($multi-1)*$input_fields)+2]</a><br>
url: !;

if ($liste[(($multi-1)*$input_fields)+3] =~ /./)
{
 if ($liste[(($multi-1)*$input_fields)+3] =~ /\bhttp/)
 {
$liste[(($multi-1)*$input_fields)+3] =~ s/http:\/\///;
print qq!<a href="http://$liste[(($multi-1)*$input_fields)+3]" style="text-decoration:none">$liste[(($multi-1)*$input_fields)+3]</a><br>!;
 }
 else
 {
print qq!<a href="http://$liste[(($multi-1)*$input_fields)+3]" style="text-decoration:none">$liste[(($multi-1)*$input_fields)+3]</a><br>!;
 }
}
else
{
print "<br>";
}

print qq!

date: $liste[(($multi-1)*$input_fields)+5]<br>
at: $liste[(($multi-1)*$input_fields)+6]<br>
ip: $liste[(($multi-1)*$input_fields)+7]<br>
domain: $liste[(($multi-1)*$input_fields)+8]<br>
browser: $liste[(($multi-1)*$input_fields)+9]<br>
<br>
$liste[(($multi-1)*$input_fields)+4]
<br>
<hr noshade size="1"><br>
!;

$multi = $multi - 1;
$y = $y - 1;
}

print "Content-type: text/html\n\n";

$z = 1;

print qq!<div align="center">!;

$link = 0;
$back_fro = $start;

unless($start eq one_page) # creates links to the remaining pages
{
 unless($page_now == 1)
 {
 print qq!<a href="gb_read2.pl?start=$back&entries=$adder">back</a>&nbsp;&nbsp;!;
 }
 else
 {
 print qq!<font color="#$invisible">back</font>&nbsp;&nbsp;!;
 }
 while($z <= $seiten)
 {
  if($z == $page_now)
  {
print qq!<a href="gb_read2.pl?start=$link&entries=$adder"><b>$z</b></a>&nbsp;&nbsp;!;
$z = $z + 1;
$link = $link + $adder;
  }
  else
  {
print qq!<a href="gb_read2.pl?start=$link&entries=$adder">$z</a>&nbsp;&nbsp;!;
$z = $z + 1;
$link = $link + $adder;
  }
 }
 unless($page_now == $seiten)
 {
 print qq!<a href="gb_read2.pl?start=$fro&entries=$adder">forward</a>!;
 }
 else
 {
 print qq!<font color="#$invisible">forward</font>!;
 }
}

print "</div><br><br>";

until($multi == $end)
{
&write;
}
