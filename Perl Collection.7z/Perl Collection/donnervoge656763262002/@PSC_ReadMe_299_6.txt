Title: donnervogel guestbook
Description: i guess you know what a guestbook is. therefor i don't want to write much here. the names are quite self explanatory too. you can either use gb_read.pl or gb_read2.pl. The first program is the one i'm using for my homepage (http://www.geocities.com/michael_salcher ), it will place all entries on a single page, it will only show valid email adresses and valid website adresses. The second program is rather a demonstration program. it shows you all data that is available for a user (e.g. browser, os, ip adress...) and via the paramter "entries" (e.g. gb_read2.pl?entries=10) you can specifiy the number of entries that should be shown on a page. if you want to view all entries on a single page use gb_read2.pl?start=one_page&entries=1
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=299&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
