#!/usr/local/bin/perl


$referer_log = "/usr/httpd/logs/referer_log";
# This is the location of the referer_log
# you can check whether this is correct or not
$websitepages = "/WWW";
# YOUR WEBpage FOLDER on your webserver to the world wide web

@skip_websitepagess = ("banner.html","contact.html","picturs.html");
# WANT SOME websitepagesS TO BE OMIITED THIS WILL DO

$website_domain = "YOURWEBSITE";
# pls change this to your domain

$result_file = "log.html";
# This is the name of the html file the script produces listing the final


$varible_referal = 1;


$|=1;
$time = time();

open(LOG,"$referer_log") || die "Could not open Referer Log error occured $errorcode";
while(<LOG>){
   if($_ =~ /$websitepages/ && $_ !~ /$website_domain/i) {
      $ref = $_;
      foreach$skip(@skip_websitepagess) {
         if($ref =~ /$skip/) {
             $bad =1;
         }
      }
      if(!$bad) {   
         ($steve,$stevebogus) = split(/ /,$ref);
         study($steve);
         $steve =~ s/:80//g;
         $steve =~ s/%7E/~/g;
         if($steve =~ /^file/) {
            $steve = "Bookmark";
         }
         if($steve =~ /^news/) {
            $steve = "Newsgroups on the web";
         }
         if($steve =~ /search.yahoo.com/){
            $steve = "search engine of yahoo";
         }
         if($steve =~ /www.google.com/\search){
            $steve = " most popular search engine google UNITED STATE (GLOBAL)";
         }
         if($steve =~ /www.google.co.in/\search){
            $steve = "google search india";
         }
         }
         if($steve =~ /www.google.co.au/\search){
            $steve = "google search austraila";
         }
         }
         if($steve =~ /www.google.co.jp/\search){
            $steve = "google search japan";
         }
         }
         if($steve =~ /www.google.co.uk/\search){
            $steve = "google search united kingdom";
         }
         }
         if($steve =~ /www.google.co.ca/\search){
            $steve = "google search canada";
         }
         if($steve =~ /www.excite.com\/search/){
            $steve = "Excite Search engine";
         }
         if($steve =~ /www.altavista.digital.com/){
            $steve = "Altavista web search engine";
         }
         if($steve =~ /lycos.com\/cgi-bin/){
            $steve = "Lycos Search engine";
         }
      
         $HASH{"$steve"}++;
         $grandtotal++;
      }
      undef($bad);
   }
}
close(LOG);

sub bynumber { $b <=> $a; }

foreach$key(keys %HASH) {
   $line = "$HASH{$key}\::$key";
   push(@array,$line);
}
undef(%HASH);
@array = sort bynumber @array;

$time = time() - $time;
open(OUTPUT,">$result_file");

print OUTPUT "<html><head><title>websitepages Referals by Search engines</title></head>\n";
print OUTPUT "<body bgcolor=666666>\n";
print OUTPUT "<CENTER><H1>websitepages Referals from search engines</h1><h3>THE websitepagesS: $websitepages<br>\n";
print OUTPUT "Skip Criteria: @skip_websitepagess </h3>\n";
print OUTPUT "It took $time seconds to BRING THIS INFORMATION.</center>\n";
print OUTPUT "<table bordercolorlight=800000 bordercolordark=#0000FF bgcolor=996600 border=5 style=border-collapse: collapse bordercolor=111111 cellpadding=0 cellspacing=0><tr><td><b>#</b></td><td><b>%</b></td><td><b>websitepages</b></td></tr>\n";
foreach$part(@array){
   ($total,$referer) = split(/::/,$part);
   if($total >= $varible_referal) {
      $percentage = (int(($total * 1000) / $grandtotal)) / 10;
      if($referer !~ /^http:\/\//){
         print OUTPUT "<tr><td>$total</td><td>$percentage</td><td>$referer</td></tr>\n";
      }
      else {
         print OUTPUT "<tr><td>$total</td><td>$percentage</td><td><a href=\"$referer\">$referer</a></td></tr>\n";
      }
   }
}
print OUTPUT "</table>";
print OUTPUT " <p> <font size=6 color=#FFCC00>Coded By Stephen Antony</font></p>";
print OUTPUT "<p> <font size=4 color=#FFCC00> Kollam </p><p>Kerala</p><p> India</font></p>";
print OUTPUT "</body></html>\n"; 
close(OUTPUT);
exit;
