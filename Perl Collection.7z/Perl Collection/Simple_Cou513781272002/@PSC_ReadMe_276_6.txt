Title: Simple Counter
Description: Simple Counter is a basic CGI hit counter for websites. It records all hits, the last five ips, browsers,and referers to access the page and displays them all onto a statistics page. In the future, I'm going to add some more features and a unique hit counter to it as well.
NOTE: This code was developed on a linux machine and tested on a linux server. I don't know yet whether it works on a Windows server.
If you need a .tar version of Simple Counter, email me at stormgard5@yahoo.com and I will send it to you.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=276&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
