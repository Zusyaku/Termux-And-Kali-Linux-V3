#!/usr/bin/perl -w

########################################
#                                      #
# Simple Counter                       #
# Created by: stormgard                #
# Email: stormgard5@yahoo.com          #
# http://stormgard.cjb.net             #
#                                      #
# Started: January 23rd, 2002          #
#                                      #
########################################

########################################
# Start of Global variables            #
########################################

# This is the info that will be
# displayed on the stats page under the
# name of your website
$servername = "Type in your servername here";

# $countdat stores the location of the
# file that holds the current number
# of hits
$countdat = "count.dat";

# $ipdat stores the location of the
# file that holds the five most
# recent ips
$ipdat = "ip.dat";

# $clientbrowserdat stores the location
# of the file that holds the five most
# recent browsers
$clientbrowserdat = "clientbrowser.dat";

# $refererdat stores the location of
# the file that holds the five most
# recent referers
$refererdat = "referer.dat";

# $stathtml stores the location of the
# file that holds the Simple Counter
# stats page
$stathtml = "stats.html";

########################################
# End of Global Variables              #
########################################

print "Content-type:text/html\n\n";

########################################
# Hits                                 #
########################################
if ( (-e "$countdat") && (-r "$countdat") && (-w "$countdat") )
{
   open(DAT, "$countdat") || die("Could not open $countdat!");
    $count = <DAT>;
   close(DAT);

   $count++;

   open(COUNT, ">$countdat") || die("Could not open $countdat!");
    print COUNT $count;
   close(COUNT);
}
else
{
   print "Error opening/writing to $countdat\n";
}

########################################
# IP                                   #
########################################
if ( (-e "$ipdat") && (-r "$ipdat") && (-w "$ipdat") )
{
   open(IP, "$ipdat") || die("Could not open $ipdat!");
    chomp($ip = <IP>);
    ($ipone,$iptwo,$ipthree,$ipfour,$ipfive) = split(/\|/,$ip);
   close(IP);

   open(IP, ">$ipdat") || die("Could not open $ipdat!");
    $ipfive = $ipfour;
    $ipfour = $ipthree;
    $ipthree = $iptwo;
    $iptwo = $ipone;
    $ipone = $ENV{'REMOTE_ADDR'};
    print IP "$ipone\|$iptwo\|$ipthree\|$ipfour\|$ipfive";
   close(IP);
}
else
{
   print "Error opening/wrtiting to $ipdat\n";
}

########################################
# Browser                              #
########################################
if ( (-e "$clientbrowserdat") && (-r "$clientbrowserdat") && (-w "$clientbrowserdat") )
{
   open(CLIENTBROWSER, "$clientbrowserdat") || die("Could not open $clientbrowserdat!");
    chomp($clientbrowser = <CLIENTBROWSER>);
    ($clientbrowserone,$clientbrowsertwo,$clientbrowserthree,$clientbrowserfour,$clientbrowserfive) = split(/\|/, $clientbrowser);
   close(CLIENTBROWSER);

   open(CLIENTBROWSER, ">$clientbrowserdat") || die("Could not open $clientbrowserdat!");
    $clientbrowserfive = $clientbrowserfour;
    $clientbrowserfour = $clientbrowserthree;
    $clientbrowserthree = $clientbrowsertwo;
    $clientbrowsertwo = $clientbrowserone;
    $clientbrowserone = $ENV{'HTTP_USER_AGENT'};
    print CLIENTBROWSER "$clientbrowserone\|$clientbrowsertwo\|$clientbrowserthree\|$clientbrowserfour\|$clientbrowserfive";
   close(CLIENTBROWSER);
}
else
{
   print "Error opening/writing to $clientbrowserdat\n";
}

########################################
# Referer                              #
########################################
if ( (-e "$refererdat") && (-r "$refererdat") && (-w "$refererdat") )
{
   open(REFERER, "$refererdat") || die("Could not open $refererdat!");
    chomp($referer = <REFERER>);
    ($refererone,$referertwo,$refererthree,$refererfour,$refererfive) = split(/\|/, $referer);
   close(REFERER);

   open(REFERER, ">$refererdat") || die("Could not open $refererdat!");
    $refererfive = $refererfour;
    $refererfour = $refererthree;
    $refererthree = $referertwo;
    $referertwo = $refererone;
    $refererone = $ENV{'HTTP_REFERER'};
    print REFERER "$refererone\|$referertwo\|$refererthree\|$refererfour\|$refererfive";
   close(REFERER);
}
else
{
   print "Error opening/writing to $refererdat\n";
}

########################################
# Create stats page                    #
########################################
if ( (-e "$stathtml") && (-r "$stathtml") && (-w "$stathtml") )
{
   open(HTML, ">$stathtml") || die("Could not open $stathtml!");
    print HTML "<html>\n";
    print HTML " <head>\n";
    print HTML "  <title>$servername: Simple Counter Stats</title>\n";
    print HTML " </head>\n\n";
    print HTML " <body bgcolor=\"#ffffff\" text=\"#000000\">\n\n";
    print HTML " Number of hits: $count<br><br>\n\n";
    print HTML " Last 5 hits from:<br><br>\n\n";

    print HTML "<br>IP: $ipone<br>\n";
    print HTML "Browser: $clientbrowserone<br>\n";
    print HTML "Referer: $refererone<br>\n";

    print HTML "<br>IP: $iptwo<br>\n";
    print HTML "Browser: $clientbrowsertwo<br>\n";
    print HTML "Referer: $referertwo<br>\n";

    print HTML "<br>IP: $ipthree<br>\n";
    print HTML "Browser: $clientbrowserthree<br>\n";
    print HTML "Referer: $refererthree<br>\n";

    print HTML "<br>IP: $ipfour<br>\n";
    print HTML "Browser: $clientbrowserfour<br>\n";
    print HTML "Referer: $refererfour<br>\n";

    print HTML "<br>IP: $ipfive<br>\n";
    print HTML "Browser: $clientbrowserfive<br>\n";
    print HTML "Referer: $refererfive<br>\n";

    print HTML " </body>\n";
    print HTML "</html>\n";
   close(HTML);
}
else
{
   print "Error opening/writing to $stathtml\n";
}

########################################
# Display the current amount of hits   #
# on the website                       #
########################################
print "$count\n";

