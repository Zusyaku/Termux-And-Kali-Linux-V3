################################################################################
package Armor;


my %arms = ('none'    => [10, 0, 'reset', 'n'],
	 'leather'    => [9, 0, 'brown',  'l'],
	 'ring mail'  => [7, 0, 'grey',   'R'],	
	 'chain mail' => [6, 0, 'grey',   'C'],
	 'plate'      => [3, 0, 'gold',   'P'],
	    );

sub new{

my $obj = shift;
my $arm = bless{
              name => $_[0],
	        ac => $_[1],
	     bonus => $_[2],
   	     color => $_[3],
	       chr => $_[4],
               tpe => 2
   },$obj;
return $arm;

}

sub generate{

my $obj = shift;
my $arm = $_[0];

$arm = Armor->new($arm,$arms{$arm}[0],
                        $arms{$arm}[1],
                        $arms{$arm}[2],
                        $arms{$arm}[3]);
return $arm;
}