########################################################################3

package Map;

sub gbon { #check to see if item has a bonus.
my ($item) = @_; 
my $num = 0;
my $bon = 0;

  do {
    $num = rand(4);
    if ($num == 1){
    	$bon++;
        $item->{name} = $item->{name} . "+";
    	}
    } until ($num != 1);
    $item->{bon} = $bon;
return $item;
}

sub farm { #Armor chooser

my $mon = @_;

my $har;
my $chs = 0;

  $chs = int(rand(100)) + $mon->{xpb};
   if ($chs > 100) {
     $har = 'plate';
     return $har;
     }

  if ( $chs > 75) {
    $har = 'chain mail';
    return $har;
    }

 if ($chs > 40) {
   $har = 'ring mail';
   return $har;
   }

 $har = 'leather'; 
return $har;
}

sub fwep { #Weapon Chooser
$mon = @_;
my $hwp;
my $chs = 0;

  $chs = int(rand(100)) + $mon->{xpb};
  if ($chs > 100) {
    $hwp = 'Ax'; 
    return $hwp;
    }

  if ($chs > 80) {
    $hwp = 'gladius';
    return $hwp;
    }

  if ($chs > 60) {
    $hwp = 'spear';
    return $hwp;
    }

  if ($chs > 30) {
    $hwp = 'club';
    return $hwp;
    }
  
$hwp = 'knife';
 
return $hwp;
}

sub mktreas{ #Generates Treasure

my ($map, $tx, $ty) = @_;
my $monst = $map->{map}->[$ty][$tx]->{monst};
my $roll;
my $item;

  $roll = int(rand(100))+$monst->{xpv};




  if ($roll > 70){
    $roll = int(rand(2));
    if($roll == 0){
       $item = fwep($monst);
       $item = Weapon->generate($item);
       $item = gbon($item);
   }
   if ($roll == 1){
       $item = farm($monst);
       $item = Armor->generate($item);
       $item = gbon($item);
   }
  $map = ptitem($map, $tx, $ty, $item);
}

return $map;

}

sub ptitem{ #puts items on the map
my ($map, $x, $y, $item) = @_;


  $map->{map}->[$y][$x]->{item} = $item;

return $map;
}

sub helpme {
    	print "Help function:\n";
    	print "n - north\n";
    	print "s - south\n";
    	print "e - east\n";
    	print "w - west\n";
    	print "i - inventory\n";
    	print "d - drop\n";
    	print "p - pick-up\n";
    	print "h - help\n";
    	}

sub death {
    	print "$_[0]->{name} You are dead.  GAME OVER";
    	exit;
    	}

sub win {
        print"You Win \a";       
        exit;
        }

sub thaco {
    	my $gen = @_;
    	my $tmp;
    	if ($gen == 1) {$tmp=19};
    	if ($gen == 2) {$tmp=18};
    	if ($gen == 3) {$tmp=17};
    	if ($gen > 4) {$tmp=16};
    	return $tmp;
    	}
#######################################################

my @grd;

my $px = 1;
my $py = 1;

   my $monst;
   my $item;
   my %mov = ( n => [ 0, -1],
    	       s => [ 0, 1], 
    	       e => [ 1, 0], 
    	       w => [ -1, 0],
    	       q => [ 0, 0],
    	       i => [ 0, 0],
    	       p => [ 0, 0],
    	       d => [ 0, 0],	
    	       h => [ 0, 0],
               m => [ 0, 0]
		);
    
sub drmapped{

my ($map) = @_;

my $l1 = 0;
my $l2 = 0;
for $l1(0 .. $map->{y}){
   for $l2(0 .. $map->{x}){
      if (($l1 == $py) && ($l2 == $px)){print"x";}else{ 
           if ($map->{map}->[$l1][$l2]->{pssd} != 0){print "$map->{map}->[$l1][$l2]->{loc}";}
        else{print" ";}
      }} print "\n";
   } 
print "\n";
}

sub gen{ #Creates the map

  print"Generating Map";

my @gd = (
    	[ qw (# # # # # # # # # # # # # # # # # # # # # # # # # #)],
    	[ qw (# . . . . # . . # . . . # # . . . . . . # . . . . #)],
    	[ qw (# # . # . # . # # . # . # . . . # . # . . . . # . #)],
    	[ qw (# . . # . . . . . . # . # . # . # # # . # # # # . #)],
    	[ qw (# . . # # . # # # . . . # . # . . . # . . . . # . #)],
    	[ qw (# . . . . . . # # . # . # . # # . # # # # # . # . #)],
    	[ qw (# # . # # . . # . . # . . . . . . . . . # # . # # #)],
    	[ qw (# # . . # . . . . . # # # # # . # # # . # # . . . #)],
    	[ qw (# . . # # # # # # . . . . . . . . # . . . . . # . #)],
    	[ qw (# . # # # . # # . . # # . # # # . # # . # . # # . #)],
    	[ qw (# . . . . . # . . # # . . . # . . . # # # . . # . #)],
    	[ qw (# # # # # . # # . # . . # # # . # . . . # . # # . #)],
    	[ qw (# . # . # . . # . # # . # . . . # # . # # . . . . #)],
    	[ qw (# . # . # . # # . . . . # # . # # . . . . . # # # #)],
    	[ qw (# . . . # . . # # # # . # . . # # # # # # . . . . #)],
    	[ qw (# # . # # . # # # . . . # # . . . . . . # # # . # #)],
    	[ qw (# . . . . . # # # # . # # # # # . # # . . . . . . #)],
    	[ qw (# # . # # . . . . . . . . . . # . # . . # . # . # #)],
    	[ qw (# # # # # # # # # # # # # # # # # # # # # # # X # #)] 
    	);

$y = $#gd;
$x = $#{$gd[0]};

for $l1(0 .. $y){
   for $l2(0 .. $x){
      $grd[$l1][$l2] = Space->new($gd[$l1][$l2]);
      }
      print".";
   }
print"\n";

my $pmap = bless{
   		map => \@grd,
	          x  => $x,
		  y  => $y
		},'Map';
return $pmap;


}

sub gtplay{
my ($map) = @_;
return $map->{map}->[$py][$px]->{plr};
}

sub ptplay{
my ($map, $play) = @_;
$map->{map}->[$py][$px]->{plr} = $play;
return $map;
}

sub showmp{ # displays player location map

my $obj = shift;
my ($ma) = @_;
my $mp;
my $l1 = 0;
my $l2 = 0;
my $rndmon;

for $l1(($py-1) .. ($py+1)){
   for $l2(($px-1) .. ($px+1)){
      $mp = $ma->{map}->[$l1][$l2]->show($ma);  
      print "$mp"
      }
   print"\n";
   } 
}

sub setplr{ #sets the player on the map

my $obj = shift;
my ($mp, $plr) = @_;

  $mp->{map}->[$py][$px]->{plr} = $plr;

return $mp;
}

sub movplr{ #changes the position of the player on the map

my ($map, $tx, $ty) = @_;

my $plr = gtplay($map);

  $map->{map}->[$py][$px]->{plr} = 0;
  $map->{map}->[$ty][$tx]->{plr} = $plr;

return $map;
}

#***************************************************************

sub move{ #changes the position of the character on the map
my $obj = shift;
my ($kv, $map) = @_;
my $rndmon = int(rand(6))+1;

my $tx = 0;
my $ty = 0;

 $tx = $px + $mov{$kv}[0];
 $ty = $py + $mov{$kv}[1];

if ($kv eq 'i'){
  $map = Player->inv($map, $px, $py);
  return $map;
}

if($kv eq 'm'){
   drmapped($map);

   return $map;
   }

if($kv eq 'h'){
  helpme;
  return $map;
}

if($kv eq 'p'){
  $map = pickup($map);
  return $map;
  }

if($kv eq 'd'){
  $map = drop($map);
  return $map;
  }

if($map->{map}->[$ty][$tx]->{loc} eq "#"){
  print"Can't go that way.\n";
  return $map;
  }

if($map->{map}->[$ty][$tx]->{loc} eq "X"){
  win;
  }
if($map->{map}->[$ty][$tx]->{monst} != 0){
  $map = fight($map, $tx, $ty);
  return $map;
  }


if ($rndmon == 1){
   my $plv = $map->{map}->[$py][$px]->{plr}->{lv};
   $map = Monster->generate($map, $tx, $ty, $plv);
   return $map; 
   }

$map = movplr($map, $tx, $ty);

$px = $tx;
$py = $ty;

return $map;

}

sub pickup{ #Allows player to pick up items

my $lp;
my $lp2;
my $inp;
my $tpe;
my ($map) = @_;
my $play  = gtplay($map);
#my $num   = $map->{map}->[$py][$px]->{item};

if ($map->{map}->[$py][$px]->{item} == 0){
   print "Nothing to pick up! \n";
   return $map;
   }

print "Pick up the $map->{map}->[$py][$px]->{item}->{name} y or n:";
  $inp = <STDIN>; chomp $inp;
  if($inp eq 'y'){
    $item = $map->{map}->[$py][$px]->{item};



    $tpe = $item->{tpe};
    if($tpe == 1){
       push @{$play->{bag}->[0]}, $item;	
       }
   
    if($tpe == 2){
       push @{$play->{bag}->[1]}, $item; 
       }

    
 $map->{map}->[$py][$px]->{item} = 0;
 }


$map->{map}->[$py][$px]->{plr} = $play;

return $map;

}

sub drop{ #Allows player to drop items
my ($map) = @_;
my $play = gtplay($map);

my $drp=-1;
my $drp1=-1;
my $inpt = 0;
my $item;
my $loop = 0;
    		
  print "0 Weapons \n";
  print "1 Armor\n";
  print "-------------\n";
  print "Which to drop:";
  $drp=<STDIN>; chomp $drp;
  if ($drp == 0) {
    $play->Player::pwep();
    print "Which to drop:";
    $inpt=<STDIN>;chomp;
    }
   if ($drp == 1) {
     $play->Player::parm();
     print "Which to drop:";
     $inpt=<STDIN>;chomp;
     }
   if ($play->{bag}->[$drp][$inpt]->{name} eq 'none') {
     print "Cant drop nothing!\n";
     return $play, $map;
     }
   if (($inpt > $#{$play->{bag}->[$drp]}) || ($inpt < 0)) {
     return $play, $map;
     }
   $item = $play->{bag}->[$drp][$inpt];
print"Dropping $item->{name}\n";
    $map = ptitem($map, $px, $py, $item);	
    
    	for $loop ($drp .. $#{$play->{bag}->[$drp]}) {
    		$play->{bag}->[$drp][$loop] = 
    		$play->{bag}->[$drp][$loop+1];
    		}
    	$item = pop @{$play->{bag}->[$drp]};
   


return $map;
}

sub fight{ #Comat Routine.
my ($map, $tx, $ty) = @_;
my $monst = $map->{map}->[$ty][$tx]->{monst};
my $play  = $map->{map}->[$py][$px]->{plr};

  ($monst, $play) = platk($play, $monst);
print"$monst->{name} HP: $monst->{hp} \n";
  if ($monst->{hp} < 1){
     $map = monkill($map, $tx, $ty);	
     return $map;
     }
   
  ($play, $monst) = moatk($play, $monst);

if ($play->{hp} < 0){death($play);}
$map->{map}->[$ty][$tx]->{monst} = $monst;
$map->{map}->[$py][$px]->{plr}   = $play;

return $map;
}

sub thaco {
my $gen = @_;
my $tmp;

  if ($gen == 1) {$tmp=19};
  if ($gen == 2) {$tmp=18};
  if ($gen == 3) {$tmp=17};
  if ($gen == 4) {$tmp=16};
return $tmp;
}

sub atk {
my ($ac, $lv, $bon) = @_;
my $flag;
my $thaco;
my $thn;
my $d20;
my $d20m;
   $thaco = thaco ($lv);
   $thn = ($thaco - $ac);
   $d20 = int rand(20) +1;
   $d20m = $d20 + $bon;

if ($d20m >= $thn) {$flag=1;}
if ($d20m < $hn)   {$flag=0;}
if ($d20 < 2)      {$flag=-1;}
if ($d20m > 19)    {$flag=2;}
  	
return $flag;
}

sub platk{ #player's attack

my ($play, $mon) = @_;
my $dam=0;
my $flag;
$flag = atk($mon->{ac}, $play->{lv}, $play->{wpn}->{bonus} );
if ($flag > 0) {
   print "$play->{name} hit ";
   $dam = int rand($play->{wpn}->{dam})+
                  ($play->{wpn}->{bonus} + 1);

   if ($flag > 1){$dam = $dam *2}	
   if ($dam < 0) {$dam=0;}

   print "and did $dam points \n";
   $mon->{hp} -= $dam;
   } 

   if ($flag == 0) { 
        print "$play->{name} Missed!\n"; 
    	}

   if ($flag > 1){     
         if (($play->{wpn}->{name} !~ 'none')or 
             ($play->{wpn}->{name} !~ /broken/)){

              $play->{wpn}->{bon} = -3;
              $play->{wpn}->{name} =~ /broken/; 
              print"Broke the $play->{wpn}->{name}!\n";
            } 
    }
return $mon, $play;
}

sub moatk{ #Monster's attack

my ($play, $mon) = @_;
my $dam=0;
my $flag;
  $flag = atk ( $play->{arm}->{ac}, $mon->{hd}, 0);

  if ($flag > 0) {
     print "The $mon->{name} hit ";
     $dam = int rand($mon->{dam})+1;
     if ($flag == 2 ){$dam = $dam * 2;
        if (($play->{arm}->{name} !~ 'none') or 
            ($play->{arm}->{name} !~ /dammaged/)){

             print"Armor Dammaged!\n";
             $play->{arm}->{bon} = -3;
             $play->{arm}->{name} =~ " dammaged"; 
             }
	}
    
     print "and did $dam points \n";
     $play->{hp} -= $dam;
     } 
    if ($flag < 1) { 
       print "The $mon->{name} Missed!\n"; 
       }
  
return $play, $mon;
}



sub monkill{
my ($map, $tx, $ty) = @_;
my $play  = gtplay($map);
my $monst = $map->{map}->[$ty][$tx]->{monst};
 

 print "You killed the $monst->{name}  and";
  $play = Player->xpad($play, $monst); 
  $map = mktreas($map, $tx, $ty);
  
  $map->{map}->[$ty][$tx]->{monst} = 0;
  $map->{map}->[$py][$px]->{plr} = $play;
return $map;
}

sub showhp{
my $obj = shift;
my ($map) = @_; 
  print"$map->{map}->[$py][$px]->{plr}->{name} Hp:$map->{map}->[$py][$px]->{plr}->{hp} \n";
}