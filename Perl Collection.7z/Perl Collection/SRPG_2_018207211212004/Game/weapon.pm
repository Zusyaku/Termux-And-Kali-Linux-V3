package Weapon;

my %weps = (none => [1, 0, 'reset', 'x'],
	   knife => [2, 0, 'white', '`'],
	    club => [4, 0, 'brown', 'c'],	
	   spear => [6, 0, 'white', 'i'],
	 gladius => [8, 0, 'yellow','1'],
	      ax => [10, 0, 'green', 'a']
		);

sub new{

my $obj = shift;
my $wep = bless{
              name => $_[0],
	       dam => $_[1],
	     bonus => $_[2],
   	     color => $_[3],
	       chr => $_[4],
               tpe => 1
   },$obj;

return $wep;
}

sub generate{


my $obj = shift;
my $wep = $_[0];

$wep = Weapon->new($wep,$weps{$wep}[0],
                        $weps{$wep}[1],
                        $weps{$wep}[2],
                        $weps{$wep}[3]);
return $wep;
}