package Monster; 
1;

sub new{ #Monster Constructor

my $obj = shift;

my $monster = bless{
          name => $_[0],
    	    hd => $_[1],
    	    hp => $_[2],
    	   dam => $_[3],
    	    ac => $_[4],
    	   xpv => $_[5],
           chr => $_[6],
    	 color => $_[7]
	},$obj;
return $monster;
}

sub generate{

my $obj = shift;

my ($map, $tx, $ty, $plv) = @_;

my $v;
my $hp=0;
my $mons;
my @mona;
my $lp = 0;
my $rm = 0;
my $x = 0;
my @ml = ( 
    [ "Rat",1,0,2,9,10,'r',"BROWN"],
    [ "Kobold",1,0,4,9,10,'k',"GREEN" ],
    [ "Orc",1,0,6,8,15,'o',"BROWN" ],
    [ "Skelliton",1,0,4,9,10,'k',"WHITE" ],
    [ "Gobblin",1,0,7,4,10,'g',"BROWN" ],
    [ "Hobgobblin",2,0,6,6,15,'h',"BROWN" ],
    [ "Wolf",2,0,6,5,20,'w',"GREY" ],
    [ "Ogre",3,0,7,5,25,'O',"GREEN" ],
    [ "Troll",3,0,8,4,25,'T',"GREEN" ],
    [ "Giant",3,0,3,4,8,30,'G',"BROWN" ],
    [ "Dragon!",4,0,10,1,100,'D',"RED" ],
    	 );
# 0 name,1 Hit dice (Level),2 Hit Points,3 Max dammage,4 Armor Class,
# 5 Exprience value, 6 Symbol, 7 color

    	$rm = int rand(4) + ($plv-1) ;
    	if ($rm > 10 ){$rm = 10; } 

    	for $x (0 .. $#{$ml[$rm]}) {
    		$mona[$x] = $ml[$rm][$x];
    }
    	for $x (1 .. $mona[1]) { #Choose monster.
    	  $mona[2] += int rand(6) + 1;
    	  }
$mons = Monster->new(@mona);
$map->{map}->[$ty][$tx]->{monst} = $mons;
print"$mons->{name} $mons->{hp} Generated \n";

return $map;

}