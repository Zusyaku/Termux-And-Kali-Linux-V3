# Simple Role-Playing game
# By Joe Creaney













    
###########################################################################
package Main;

#!/usr/bin/perl -w
use strict;
use integer;
use Term::ANSIColor qw(:constants);

require monster;
use Armor;
use space;
use weapon;
use player;
use map;
  
my $author = 'Joe Creaney';
my $version = '2.0';
my $map;
my $count = 0;
my $healcnt = 0;
my $player;
my $kv;

#******************************************#

print "Welcome to the game. \n";
print "Simple Role Playing Game \n";
print "Written by $author version $version. \n";
print "h for help *hint check inventory* \n \n";

my $map = Map->gen();
my $player = Player->generate();


$map = Map->setplr($map, $player);
$map->showmp($map);

while ( $kv ne "q" ) {
    print "Which way:";
    $kv=<STDIN>; chomp $kv;
if ($healcnt == 1) {
      $player->heal();
    }

    $map = $map->move($kv, $map);
    $count++;
    $healcnt = $count % 3; 
    $map->showmp($map);
    $map->showhp($map);
        
}
print"You quit! \n";
