#########################################################################

package Player;
1;

 sub new{

 my $obj = shift;
 my $play = bless{
             name => $_[0],
    	      chr => $_[1],
            color => $_[2],	
    	       lv => $_[3],
    	       xp => $_[4],
    	       hp => $_[5],
    	      mhp => $_[6],
    	      wpn => $_[7],
    	      arm => $_[8],
    	      bag => $_[9]
		},$obj;

return $play;
}
	
sub generate { #player generator
    	my $player;
    	my $name;
	my $chr = '@';
 	my $clr = 'red';
    	my $lv=1;
    	my $xp=0;
    	my $hp=12;
    	my $mhp = $hp;
    	my $wpn = 'none';
    	my $armor = 'none';
    	my @stuff = (['club','knife'],
    		 ['leather']);
    	my $bag = \@stuff;
    	
    	print "What is your name:";
    	$name=<STDIN>; chomp $name;

    $player = Player->new($name, $chr, $clr, $lv, $xp, $hp, $mhp, $wpn, $armor, $bag);
    $player->{wpn}=Weapon->generate($player->{wpn});
    $player->{arm}=Armor->generate($player->{arm});
    $player->{bag}->[0][0]=Weapon->generate($player->{bag}[0][0]);
    $player->{bag}->[0][1]=Weapon->generate($player->{bag}[0][1]);
    $player->{bag}->[1][0]= Armor->generate($player->{bag}[1][0]);
    		
return $player;
}

sub heal { #heal function
my ($play) = @_;
   if ($play->{hp} < $play->{mhp}) {
   	$play->{hp}++;
    	}
return $play;
}

sub pwep { #prints weapons in bag
my ($play) = @_;
my $lp;
  for $lp (0 .. $#{$play->{bag}->[0]}) {
     print "$lp $play->{bag}->[0][$lp]->{name} $play->{bag}->[0][$lp]->{dam} \n";
     }
  }
    	
sub parm { #prints Armor in bag
my ($play) = @_;
my $lp;
for $lp (0 .. $#{$play->{bag}->[1]}) { 
   print "$lp $play->{bag}->[1][$lp]->{name} $play->{bag}->[1][$lp]->{ac} \n";
   }
}

sub inv { #inventory function
my $obj = shift;

my ($map, $px, $py) = @_;
my $play = $map->{map}->[$py][$px]->{plr};

my $in;
my $in1;
    	
  print "$play->{name} is using:\n";
  print "0 using:$play->{wpn}->{name} $play->{wpn}->{dam} \n";
  print "1 wearing: $play->{arm}->{name} $play->{arm}->{ac} \n";
  print "------------------------ \n";
  print "Level:$play->{lv} \n";  
  print "Xp:$play->{xp} \n";
  print "i Inventory all\n \n";
  print "Enter:";
  $in=<STDIN>;chomp $in;
  if ($in eq "i") { 
  	pwep($play);
  	print "\n";
  	parm($play);
  	}
  if ($in eq "0") {
  	pwep($play);
  	print "Wich to use:";
  	$in1=<STDIN>; chomp $in1;
  	($play->{wpn}, $play->{bag}[$in][$in1]) = 
   	($play->{bag}->[$in][$in1], $play->{wpn});
  	}
  if ($in eq "1") {
  	parm($play);
  	print "Wich to use:";
  	$in1=<STDIN>; chomp $in1;
  	($play->{arm}, $play->{bag}[$in][$in1]) = 
   	($play->{bag}->[$in][$in1], $play->{arm});
  	}
    	
$map->{map}->[$py][$px]->{plr} = $play;
return $map;
}

sub newlev { #New level function
my ($player) = @_;
  $player->{lv} = $player->{lv} + 1;
  $player->{hp} = $player->{hp} + int rand (10)+1;
  $player->{mhp} =$player->{mhp} + $player->{hp}; 
  print "$player->{name} went up the level $player->{lv}\n";
return $player;
}

sub xpad { #adds Experience after a fight

my %xpl = (1 => 50, 
           2 => 125,
           3 => 225,
           4 => 350,
           5 => 500
         );

my $obj = shift;
my ($player, $mon) = @_;

$player->{xp} = $player->{xp} + $mon->{xpv};

print "You got $mon->{xpv} for a total of $player->{xp}\n";
print "$xpl{$player->{lv}} \n";

  if ($player->{xp} > $xpl{$player->{lv}}){
     $player->newlev; 
     }

return $player;
}