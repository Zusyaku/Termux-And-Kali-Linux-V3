#####################################################################
package Space;
1;

#The space object represents each space of the map
#and this object solves my problem of storing things
#on the map.  Now each space can now store multiple 
#items and return their symbol.

sub new{ 

my $obj = shift;
my @item;

my $spc = bless{
	loc   => $_[0],
	plr   => 0,
	pssd  => 0,
	monst => 0,
	item  => 0
		}, $obj; 
return $spc;
}

sub show{
#Show the item in the space or the location. 

my ($spc) = @_;

$spc->{pssd} = 1;

if ($spc->{monst} != 0){
   return $spc->{monst}->{chr}
   }

if ($spc->{plr} != 0){
   return $spc->{plr}->{chr};
   }

if ($spc->{item} != 0){
   return $spc->{item}->{chr};
   }

return $spc->{loc}; 

}