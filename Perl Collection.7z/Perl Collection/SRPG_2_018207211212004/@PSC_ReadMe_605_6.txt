Title: SRPG 2.0
Description: This is the long awaited and much ancicipated update to the SRPGs I have posted here. The game is not much different than I have posted but this game runs better. There are a few new features and improvment in my logic. There is a small bug fix and I brok the files up into several module files.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=605&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
