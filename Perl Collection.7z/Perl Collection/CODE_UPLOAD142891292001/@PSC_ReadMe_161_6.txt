Title: Poll
Description: This is a really simple poll which can be incorperated into a website/webpage. Users can select their answers and a graphical response as well as numeric is given. Input/output tables can be formatted easily, and the question and responses can be easily changed. It stops users from voting multiple times by tagging the first 2 subnets of their ip (for example 149.99)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=161&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
