Title: update image script - mysql
Description: This Perl CGI script displays one entire database record in an HTML table.
All JPEG/GIF images stored within the record are displayed in-line with the rest of the data from the record.
Each MySQL column containing an image includes a menu which enables the user to Keep, Replace or Remove the image data. 
Non-image binary data types are also supported.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=544&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
