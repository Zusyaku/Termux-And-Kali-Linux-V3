Title: Guess My Number
Description: This is just a small number guessing game.. Pretty fun to play when bored :) Don't send me s-t-u-p-i-d as flames becasue this script was made for your enyoyment. Don&#8217;t like it? Then delete it! This was my first script so be nice :) I have something special cooking for next month *smile*
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=218&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
