#!/usr/bin/perl
use warnings;
use strict;

my $nummer = int(rand(100));
print "Guess my number\n Your Guess : "; 
my $gissa = <STDIN>;

until ($gissa == $nummer) { 

if ($gissa > $nummer) { print "Your number is greater then mine\n Guess again : "; }
if ($gissa < $nummer) { print "My number is greater then yours\n Guess again : "; }
$gissa = <STDIN>;

}

print "Correct guess!\n";
sleep 2;
print "Good job!\n";

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # 
#                                                                           #
# Well.. This was my first perl program and I just felt like uploading it.. #
# Its pretty lame but it works and gets the job done! *jeah!*               #
#                                                                           #
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #