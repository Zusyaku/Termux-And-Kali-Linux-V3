Title: ThreeSquare
Description: each player has three colours, you are given your colours randomly, and you
can place them anywhere on the board where the is a free space or on top
 of one of your existing squares. The objective is to have the most adjacent
squares of the same colour. The game is over when all free spaces are used
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=311&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
