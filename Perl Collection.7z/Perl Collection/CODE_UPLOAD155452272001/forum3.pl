#!/usr/bin/perl

## path to your list file this file is | delimited
# E.G. test|test1|test2|Test3
$bandstats = "/home/www/freebieforum/cgi-bin/board/forum3/list.list";

$count="80";
print qq~
<html>
<MARQUEE onmouseover=this.stop() onmouseout=this.start() 
            scrollAmount=1 scrollDelay=1 direction=up width=120 height=360 bgcolor="#ffffff">

~;
open (BANDFIT, "$bandstats") || die "Can't Open $bandstats";


while(<BANDFIT>)
	{
($ID, $Desc, $Blank, $BandMin, $BandAvg, 
 $BandW, $BandL, $BandOtl, $BandGA, 
 $BandSaves,
 @options) = split(/\|/,$_);

chop(@options);
  foreach ($ID) {
if ($count < '100'){
$count ++;
print qq~

           
                  <CENTER><FONT face=veradana,arial size=1><FONT 
                  face=verdana,arial><FONT size=1><B><A target=_top 
                  href="cgi-bin/board/topic.cgi?forum=3&topic=$ID">$Desc 
                  </A></B></FONT> <FONT size=1><BR>By $BandL 
                  </B> </FONT><BR>


~;
}
if ($count > '100'){
close(BANDFIT);


@options=();
exit;
}
elsif($count eq '100'){
close(BANDFIT);

@options=();
exit;
}
}
}
close(BANDFIT);
@options=();
print qq!
</MARQUEE>
!;
exit;
1;