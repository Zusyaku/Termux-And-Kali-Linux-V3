call as a server side include E.G. <exec cgi=blahblah>
