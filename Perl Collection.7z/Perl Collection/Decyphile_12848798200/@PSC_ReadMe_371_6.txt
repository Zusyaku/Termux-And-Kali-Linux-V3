Title: Decyphile AIM Bot v3.3 :HardCore:
Description: Advanced AIM Chat Bot. Features various commands to interact with the bot, conversation capabilities, ability to 'learn' on the fly. Setup to be ran on a *nix/linux server or locally. Try it out to see for yourself. It's an open source project so feel free to modify it, but you'll have to give me credit (jasper@wintermarket.org). For more informationn please visit my site: http://jasper.wintermarket.org).

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=371&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
