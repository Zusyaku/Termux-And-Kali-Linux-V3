#!/usr/bin/perl
###########################
#    name: decyphile	  #
#     author: jasper 	  #
# 	 aim_bot 	  #
# 	  v3.3b 	  #
# jasper@wintermarket.org #
###########################
#  These are special characters 
#  that you you can use in
#  allmost every aspect of
#  decyphile.
#
#%n - replaced with remote screenname
#%t - replaced with local time
#%d - replaced with local date
#%r - replaced with random number (1-9999)
#%s - replaced with random text (a-zA-Z0-9[]_-^{})
############################
use strict;
use Net::AIM;
require 'evnts.lib';

##################
#bot configuration
my $screenname = shift || "SCREENNAME"; #replace with your screenname
my $pass = shift || "PASSWORD"; #replace with screennames password
my $redirect = shift || 1; #redirect all messages bot receives to master (1=true,0=false)
my $chat = 1; #enable or disable automatic chat messages (1=true,0=false)
my $smart_resp = shift || 1; #enable smart responses (1=true,0=false)
my $away = 0; #set bot as allways away (1=true,0=false)
my $away_msg = "Decyphile Bot is currently away!"; #bots away message (if away)



if ($screenname eq '?') { &help(); } #display help
my $DEBUG = 0;
my $aim = new Net::AIM;
$aim->debug(1) if ($DEBUG);

print "Decyphile AIM Bot v3.3b :HardCore: Written By: Jasper <jasper\@wintermarket.org>\n\nInitializing NET::AIM...\n";

$aim->newconn(  Screenname => $screenname,
	 	Password => $pass,
	 	AutoReconnect => 1
	 	) or die "Can't Connect! Please Check your Internet Connection!\n";
my $conn = $aim->getconn();
print "NET::AIM Initialized!\n";

####################
#handler subroutines
print "Setting Up Handler Routines...\n";
$conn->set_handler('error',    \&on_error);
$conn->set_handler('im_in',    \&on_im);
$conn->set_handler('nick',    \&on_nick);
$conn->set_handler('eviled',    \&on_eviled);
$conn->set_handler('config',    \&on_config);
$conn->set_handler('chat_join',    \&on_chat_join);
$conn->set_handler('chat_left',    \&on_chat_left);
$conn->set_handler('chat_in',    \&on_chat);
$conn->set_handler('chat_invite',    \&on_chat_invite);
print "Handler Routine Setup Complete!\nStarting Bot!\n";
if ($redirect == 1) { $aim->set('redirect', &get_master()); }
if ($away == 1) { $aim->set('away_always',1); $aim->set('away_msg',$away_msg); }
$aim->set('smart_resp',$smart_resp);
$aim->set('my_name',$screenname);
$aim->set('chat_onoff',$chat);
$aim->start;


