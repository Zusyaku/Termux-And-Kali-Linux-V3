Title: Updated!  Perl Tk Ping Commander
Description: The Purpose of this Program is to provide a working example of the Graphic capability found using Perl and Tk, coupled with a commonly used networking function PING. Displays Good Examples of menus, Dialog Box, Scrolling, List Box, opening files, reading data from files, acting on that data, etc. This program is a learning tool, so pass to your friends that are trying to learn Perl/Tk. 
To run, unzip the zipfile into any directory and run the perl file in a dos box like "C:>perl pingcdr.pl". The rest of the files are there for support and future development.
I wrote this program because I could not find any programming examples that actually do something, which makes it easier to learn and understand Perl/Tk Integration.
Notice: This example is based on win32 platforms using Perl/Tk. Any Perl later than version 5.22 should be fine to run this program. Or, if you dont have perl installed, you can download the exe file from my site (http://www.mollensoft.com/perl/pcmdrexec.zip) and run it just like any other .exe program. 
Enjoy!! BigAl Sends....
UPDATED! Changed the Host/IP database so that there is no read only parts only entry fields (at the Request of many emails this morning!). Keep providing feedback/requests (mmollenkopf@hot.rr.com)!! 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=192&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
