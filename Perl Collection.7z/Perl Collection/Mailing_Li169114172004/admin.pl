#!/usr/bin/perl


########################################
# You may need to configure the following
########################################
my $pw        = "test";
##  Change the above to the administrator password

my $sendmail  = "/usr/lib/sendmail";
## Change the above to the location of sendmail on your server

my $unsub     = "list-add.pl";  # unsub link
## Change the above to the location of list-rem.pl on your server

my $personal_info = '"Site Name Here" <test@test.com>';
## Change the first section above to a site or an admin name
## Change everything between <> to an email address

########################################
# Please do not alter anything below this line
########################################


use strict;
use warnings;
use POSIX;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);
require SDBM_File;

my $cookiename = "login";
my $favorite   = param('flavor');
my $tasty      = cookie($cookiename);
my $pass       = url_param('pass');
my $edituser   = url_param('lookup');

my (%sig, %emails);
my $sigsave   = "sig.dbm";
my $list      = "mylist.dbm";


# First check if we saved a cookie last time
if($tasty)
{
  print header(-expires=>'now'),
  start_html("Email Control Panel");


my %snailmail;


my $lookup   = url_param('lookup');
my $edituser = url_param('edit');
my %snailmail;

tie %emails, 'SDBM_File', $list, O_CREAT | O_RDWR, 0644;
if ( !tied %emails ) {
    print "database unsuccessful $!.\n";
}

tie %sig, 'SDBM_File', $sigsave, O_CREAT | O_RDWR, 0644;
if ( !tied %sig ) {
    print "database unsuccessful $!.\n";
}


####################################################
# Save signature if requested
####################################################
if (param('save')) {
$sig{'default'} = param('signature');
}

###################################################
# Form checking
###################################################
if ( param('submit') ) {

# rid ourselves from those nasty params
my $message   = param('message');
my $password  = param('password');
my $subject   = param('subject');
my $signature = param('signature');
my $save      = param('save');
my $use       = param('use');
my $time      = localtime;

    if ( $message eq "" || $subject eq "" ) {
        print "<center><font color=red>Your subject or email content was missing.</font></center>\n";
        #exit;
    }
    else {
    
        if ( $save eq "yes" ) {
        print "<br>";
        print "Saving to database...<br>\n";
                $sig{'default'} = $signature;
                $sig{'stored'} = $sig{'default'};
        print "<center><font color=blue>Your Signature has been saved.</font><br><br>\n";
    }
        print "<br>\n";

        foreach(keys %emails) {
        my ($name, $add1, $add2, $city, $zip, $country) = split(/::/, $emails{$_});
                    # Email Subs, special commands
            my $editmes = $message;             # let's not edit $message
            $editmes =~ s/\[name\]/$name/g;    #[name] = user name
            $editmes =~ s/\[time\]/$time/g;     #[time] = time sent 
            $editmes =~ s/\[unsub\]/$unsub/g;   #[unsub] = unsubscribe email  

			my $editsig = $signature;           # let's not edit $signature
            $editsig =~ s/\[name\]/$name/g;    #[name] = user name
            $editsig =~ s/\[time\]/$time/g;     #[time] = time sent 
            $editsig =~ s/\[unsub\]/$unsub/g;   #[unsub] = unsubscribe email   
            
            my $editsub = $subject;             # let's not edit $subject
			$editsub =~ s/\[name\]/$name/g;    # [name] = user name       
       
            open( MAIL, "| $sendmail -t" );
            print MAIL "To: $_\n";
            print MAIL "From: $personal_info\n";
            print MAIL "Subject: $editsub\n\n";
            print MAIL "$editmes\n";
             if ($use ne "" && $signature ne "" ) {          
                print MAIL "$editsig\n";
            }
            print MAIL ".\n";
            close(MAIL);         
        }
my $time      = localtime;
print "<center><font color=blue>Email successfully sent on $time</font></center>";
    }

}




###################################################
# Begin printing everything
###################################################

print <<"ALL";
<center>
<IFRAME NAME="iframe1" SRC="secure.pl" ALIGN="top" HEIGHT="200" WIDTH="200" HSPACE="5" VSPACE="5"></IFRAME>

<table width="470" border="0">
<form name="form" method="post" action="test.pl">
  <tr bgcolor="#666666">
    <td colspan="2"><div align="center">Email Management - Emailer </div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">Subject:</td>
  </tr>
  <tr>
    <td colspan="2">

ALL

if (param('subject')) {
my $subject = param('subject');
   print "<input name=\"subject\" type=\"text\" value=\"$subject\" size=\"45\"> </td>";
} else {
 print "<input name=\"subject\" type=\"text\" size=\"45\"> </td>";
}

print <<"ALL";
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">Message:</td>
  </tr>
  <tr>

ALL

if (param('message')) {
my $message = param('message');
   print "<td colspan=\"2\"><textarea name=\"message\" cols=\"40\" rows=\"5\" id=\"message\">$message</textarea></td>";
   } else {
   print "<td colspan=\"2\"><textarea name=\"message\" cols=\"40\" rows=\"5\" id=\"message\"></textarea></td>";
   }

print <<"ALL";
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">Signature:</td>
  </tr>
  <tr>
    <td width="270"><p>

ALL

if (exists $sig{'default'}) {
   print "<textarea name=\"signature\" cols=\"40\" rows=\"5\" id=\"signature\">$sig{'default'}</textarea>";
   } else {
   print "<textarea name=\"signature\" cols=\"40\" rows=\"5\" id=\"signature\"></textarea>";
   }

print <<"ALL";

      </p>    </td>
    <td width="163"><p>
      <input name="use" type="checkbox" id="use" value="use">
  Use signature<br>
  <input name="save" type="checkbox" id="save" value="save">
Save signature    </p>    </td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">
      <div align="center">
        <input type="submit" name="submit" value="submit">
      </div></td>
  </tr>
</form>
</table>
</center>
ALL


print "</td> </tr> </table>";



my $specifics = param('specifics');
print <<"ALL";

<center>
<table width="470" border="0">
<form name="extract" method="post" action="extract.pl" target="form_results">
<tr bgcolor="#666666"><td colspan="2"><center>Email Management- Data Extractor</center></td></tr>
<tr><td colspan="2"><textarea name="specifics" cols="40" rows="5" id="specifics">$specifics</textarea></td></tr>
<tr bgcolor="#CCCCCC"><td><input type="submit" name="submit1" value="submit"></td></tr>
</form>
</table>
</center>

ALL




  print end_html();
  exit;
}

# No cookie, so let's print a new form
unless ($favorite eq "$pw")
{
       print header(-expires=>'now'), start_html("Email Management- Administrator Login"),
       hr(), start_form(),
       p("Please enter your password: ", textfield("flavor",$tasty)),
       end_form(), hr();

  if (param())
  {
     if ($favorite ne "$pw") 
     {
         
         print "<b>Wrong password!</b>";
         exit;
     }

  exit;
  }
exit;
}



# Favourite value was '$pass', save cookie to browser
my $cookie = cookie(
 -NAME    => $cookiename,
 -VALUE   => $favorite,
 #-PATH    => "/",
 -EXPIRES => "+2y",
);

print header(-COOKIE => $cookie, -expires=>'now');
print start_html("Email Control Panel");


tie %emails, 'SDBM_File', $list, O_CREAT | O_RDWR, 0644;
if ( !tied %emails ) {
    print "database unsuccessful $!.\n";
}

tie %sig, 'SDBM_File', $sigsave, O_CREAT | O_RDWR, 0644;
if ( !tied %sig ) {
    print "database unsuccessful $!.\n";
}


###################################################
# Begin printing everything
###################################################

print <<"ALL";
<center>
<IFRAME NAME="iframe1" SRC="secure.pl" ALIGN="top" HEIGHT="200" WIDTH="200" HSPACE="5" VSPACE="5"></IFRAME>

<table width="470" border="0">
<form name="form" method="post" action="test.pl">
  <tr bgcolor="#666666">
    <td colspan="2"><div align="center">Email Management - Emailer </div></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">Subject:</td>
  </tr>
  <tr>
    <td colspan="2">

ALL

if (param('subject')) {
my $subject = param('subject');
   print "<input name=\"subject\" type=\"text\" value=\"$subject\" size=\"45\"> </td>";
} else {
 print "<input name=\"subject\" type=\"text\" size=\"45\"> </td>";
}

print <<"ALL";
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">Message:</td>
  </tr>
  <tr>

ALL

if (param('message')) {
my $message = param('message');
   print "<td colspan=\"2\"><textarea name=\"message\" cols=\"40\" rows=\"5\" id=\"message\">$message</textarea></td>";
   } else {
   print "<td colspan=\"2\"><textarea name=\"message\" cols=\"40\" rows=\"5\" id=\"message\"></textarea></td>";
   }

print <<"ALL";
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">Signature:</td>
  </tr>
  <tr>
    <td width="270"><p>

ALL

if (exists $sig{'default'}) {
   print "<textarea name=\"signature\" cols=\"40\" rows=\"5\" id=\"signature\">$sig{'default'}</textarea>";
   } else {
   print "<textarea name=\"signature\" cols=\"40\" rows=\"5\" id=\"signature\"></textarea>";
   }

print <<"ALL";

      </p>    </td>
    <td width="163"><p>
      <input name="use" type="checkbox" id="use" value="use">
  Use signature<br>
  <input name="save" type="checkbox" id="save" value="save">
Save signature    </p>    </td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="2">
      <div align="center">
        <input type="submit" name="submit" value="submit">
      </div></td>
  </tr>
</form>
</table>
</center>
ALL


my $specifics = param('specifics');
print <<"ALL";

<center>
<table width="470" border="0">
<form name="extract" method="post" action="extract.pl" target="new">
<tr bgcolor="#666666"><td colspan="2"><center>Email Management- Data Extractor</center></td></tr>
<tr><td colspan="2"><textarea name="specifics" cols="40" rows="5" id="specifics">$specifics</textarea></td></tr>
<tr bgcolor="#CCCCCC"><td><input type="submit" name="submit1" value="submit"></td></tr>
</form>
</table>
</center>

ALL


  print end_html();
  exit;


