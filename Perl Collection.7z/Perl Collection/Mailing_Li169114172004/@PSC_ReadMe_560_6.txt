Title: Mailing List v2.0
Description: Very advanced version of my original Mailing List.
Users add/remove themselves from a database using my premade forms. The administrator now has a password protected secure panel for email sending and data editing/removal.
All user information is viewable and editable by the admin in this version. Another extra feature is data-extraction. There's now a way to extract all data any way you want to print out address lables or for safe keeping.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=560&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
