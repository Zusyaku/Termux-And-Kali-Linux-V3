You have five files:
-------------------------
extract.pl
test.pl
list-add.pl
list-rem.pl
secure.pl


extract.pl
-------------------------
* Backbone for extract form on test.pl
* Extract specific data in any order from the list ([name] [add1] [add2] [city] [zip] [state] [email])
* Data is secured, the correct password and cookie are required for this file to be readable


    Possible changes:
    If you want to change the password from the default 'test', you need to make the change on this file
test.pl
-------------------------
* The main portion of the script.  This is the page the administator has access to all data and functions from
* Connects to secure.pl and extract.pl
* Contains the mailing script
* Password-protected, a password is required to access this file


    Possible changes:
    If you want to change the password from the default 'test', you need to make the change on this file
    Sendmail location may need to be edited
    Admin/Site name and email address needs to be edited
    Unsubscribe link changed to location of your list-rem.pl

list-add.pl
-------------------------
* Web form for users to add themselves to your list

list-rem.pl
-------------------------
* Web form for users to remove themselves from all your lists

secure.pl
-------------------------
* Backbone for browse function on test.pl
* Edit/Remove users in your database
* Data is secured, the correct password and cookie are required for this file to be readable

    Possible changes:
    If you want to change the password from the default 'test', you need to make the change on this file


General installation:
--------------------------------------------------------
1) Make a new directory specifically for the mailing list system
2) Chmod this file directory to 777 (full rights)
3) Upload all five files into the this directory
4) Chmod each file to 755 (RWX-R-RWX)
5) Make possible changes (noted above) to the scripts
6) Upload blank index.html file into this directory to prevent others from viewing your files





FEATURES:
----------------------------------
These commands can be used in your signature or message on admin.pl (you are urged to play with them):
  [name] [time] [unsub]

For the extraction script, it will print ANY order you want.  At the end of your query, you may want to add &nbsp; or || or some delimiter to seperate the data for easy viewing.  This, too, will take a few times to get the hang of.  Again, this is fully customizable.  Only print the records you want, the data will print in the order you put them.  The possible commands are:
  [name] [add1] [add2] [city] [zip] [country] [email]