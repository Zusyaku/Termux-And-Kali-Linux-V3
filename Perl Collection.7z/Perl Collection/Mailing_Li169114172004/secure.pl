#!/usr/bin/perl

use strict;
use warnings;
use POSIX;
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser);
use SDBM_File;

######################################
# You may need to configure the following
######################################
my $password   = "test";
## Set the above to whatever you want the admin password to be

my $url        = "http://www.yoursite.com/secure.pl?lookup=";
## The above is a link to your secure.pl file.  Change the url but it must be secure.pl?lookup= at the end


######################################
# Please do not configure anything blow this line
######################################

my $cookiename = "login";
my $favorite   = param('flavor');
my $tasty      = cookie($cookiename);
my $pass       = url_param('pass');
my $edituser   = url_param('lookup');


my %emails;

my $emails     = "mylist.dbm";  #change to location of snail mail database

my $lookup    = url_param('lookup');

tie %emails, 'SDBM_File', $emails, O_CREAT | O_RDWR, 0644;
if ( !tied %emails ) {
    print "database unsuccessful $!.\n";
    }


# No cookie, so if no favourite value, print new form
unless ($tasty eq $password)
{
 print header(-expires=>'now'), start_html("Denied");
print "DENIED";
 exit;
}


print header();
print start_html('Email Management- Address lookup');

#################################################
# User update checking
#################################################
if (param('update'))
{
my $name    = param('name');
my $email   = param('email');
my $add1    = param('add1');
my $add2    = param('add2');
my $city    = param('city');
my $zip     = param('zip');
my $country = param('country');

 if($email && $name)
 {
   if ( exists $emails{$email} && $lookup ne $email) 

   {
     print "<font color=red>This email address is already being used, please select another.</font>";
   }
   else
   {
   my $info = join("::", $name, $add1, $add2, $city, $zip, $country);

   delete $emails{$edituser};
   $emails{$email} = "$info";
   print "<font color=blue>Updated!</font>";
   print "<SCRIPT LANGUAGE=\"JAVASCRIPT\">";
   print "document.location.href=\"$url$email\";";
   print "</SCRIPT>";

   #exit;
   } 
}
 else
 {
  print "<font color=red>A name and email address are required.</font>";
 }
}

#################################################
# Edit/Delete button checking
#################################################
if (param('delete'))
{
  delete $emails{$edituser};
  print "<b>User information was deleted!</b>";
  exit;
}

if (param('edit'))
{
  my ($name, $add1, $add2, $city, $zip, $country) = split(/::/, $emails{$edituser});

print start_form(), table(
    Tr(
        td("Name: "),
        td(
            textfield(
                -name => 'name',
                -default =>"$name",
                -size => 40
            )
        )
    ),
        Tr(
        td("Email: "),
        td(
            textfield(
                -name => 'email',
                -default =>"$edituser",
                -size => 40
            )
        )
    ),
    Tr(
        td("Address 1: "),
        td(
            textfield(
                -name => 'add1',
                -default =>"$add1",
                -size => 40
            )
        )
    ),
    Tr(
        td("Address 2: "),
        td(
            textfield(
                -name => 'add2',
                -default =>"$add2",
                -size => 40
            )
        )
    ),
    Tr(
        td("City/State: "),
        td(
            textfield(
                -name => 'city',
                -default =>"$city",
                -size => 40
            )
        )
    ),
    Tr(
        td("Zip: "),
        td(
            textfield(
                -name => 'zip',
                -default =>"$zip",
                -size => 40
            )
        )
    ),
    Tr(
        td("Country: "),
        td(
            textfield(
                -name => 'country',
                -default =>"$country",
                -size => 40
            )
        )
    ),
    Tr( td(), td(submit('update')) ),
  ),
  end_form();

exit;
}

#################################################
# Determine if user is found in database, if so print user data and form buttons
#################################################
if ($edituser)
{
  if (exists $emails{$edituser})
  {
    
     my ($name, $add1, $add2, $city, $zip, $country) = split(/::/, $emails{$edituser});
     my $email = $emails{$_};
     print "<b><center>Address information for $name</center></b>";

     print "<table width=100%><tr><td>";
     print "$name<br>";
if ($add1)
{     
print "$add1<br>";
}
     if ($add2 ne "") {
     print "$add2<br>";
     }
if ($city) 
{
     print "$city<br>";
}
if ($zip)
{
     print "$zip<br>";
}
if ($country)
{
     print "$country<br>";
}
if ($edituser)
{
     print "<br>$edituser<br>";
}
     print "</td><td>";
     print start_form(), 
     submit('edit'),
     end_form();

     print start_form(), 
     submit('delete'),
     end_form();

     print "</td></tr></table>";


    exit;
  }
    else
    {
       print "User does not exist";
       exit;
    }
}

#########################################################
# EDIT user information settings
#########################################################
if (param('edit')) 
{
print "Edit";
exit;
}

#########################################################
# Main page prints below -- User List
#########################################################
my $count = "0";

foreach (keys %emails)
 {
   ++$count;
  }

print "<b>User List:</b> ($count)<br>";

foreach (reverse sort keys %emails) {
my ($name, $add1, $add2, $city, $zip, $country) = split(/::/, $emails{$_});

print <<"END";
<A HREF="javascript:window.open('secure.pl?lookup=$_', 
'','scrollbars,width=500,height=250'); void('');">$name</a><br>
END

}

exit;




