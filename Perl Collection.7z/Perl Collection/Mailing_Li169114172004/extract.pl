#!/usr/bin/perl

use strict;
use warnings;
use POSIX;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);
require SDBM_File;


########################################
# You may need to configure the following
########################################
my $password = "test";

########################################




########################################
# Please do not edit anything below this line
########################################

my $results = param('results');

my %data;
my $data     = "mylist.dbm";  

my $lookup    = url_param('lookup');

tie %data, 'SDBM_File', $data, O_CREAT | O_RDWR, 0644;
if ( !tied %data ) {
    print "error $!.\n";
    }



my $cookiename = "login";
my $tasty      = cookie($cookiename);




# No cookie, so if no favourite value, print new form
unless ($tasty eq $password)
{
 print header(-expires=>'now'), start_html("Denied");
print "DENIED";
 exit;
}







print header();
print start_html('Email Management - Results');

if (param('submit1'))
{

 foreach (sort keys %data)
 {
   my ($ab, $bb, $cb, $db, $eb, $fb) = split(/::/, $data{$_});
   my $specs= param('specifics');

my $specifics = $specs; 
$specifics =~ s/\[name\]/$ab/g;
$specifics =~ s/\[add1\]/$bb/g;
$specifics =~ s/\[email\]/$_/g;
$specifics =~ s/\[add2\]/$cb/g;
$specifics =~ s/\[city\]/$db/g;
$specifics =~ s/\[zip\]/$eb/g;
$specifics =~ s/\[country\]/$fb/g;



   print "$specifics";

  }

}


if ($results) 
{
 foreach (sort keys %data)
 {
   my ($ab, $bb, $cb, $db, $eb, $fb) = split(/::/, $data{$_});
   my $specifics = $results; 
$specifics =~ s/\[name\]/$ab  /;
$specifics =~ s/\[add1\]/$bb  /;
$specifics =~ s/\[email\]/$_  /;
$specifics =~ s/\[add2\]/$cb  /;
$specifics =~ s/\[city\]/$db  /;
$specifics =~ s/\[zip\]/$eb  /;
$specifics =~ s/\[country\]/$fb  /;



   print "$specifics ";
 }
}

