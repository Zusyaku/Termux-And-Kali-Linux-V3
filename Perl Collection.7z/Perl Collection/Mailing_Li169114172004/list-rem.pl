#!/usr/bin/perl -w

use strict;
use warnings;
use POSIX;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);


# You are requested not to change any configurations in this file.
# Everything is setup to function as-is, any tamporing may damage
# the script.

require SDBM_File;

my %emails;
my %snailmail;

my $snail     = "snail.dbm";  #change to location of snail mail database
my $list      = "mylist.dbm"; #change to location of email database
my $adminmail = 'admin@test.com';
my $sendmail  = "/usr/lib/sendmail";

tie %emails, 'SDBM_File', $list, O_CREAT | O_RDWR, 0644;
if ( !tied %emails ) {
    print "database unsuccessful $!.\n";
    }


tie %snailmail, 'SDBM_File', $snail, O_CREAT | O_RDWR, 0644;
if ( !tied %snailmail ) {
    print "database unsuccessful $!.\n";
    }

print header, start_html('Email Management');


print <<"END";

<form method="post" action="list-rem.pl">
  <table width="465" border="0" align="center">
    <tr bgcolor="#666666">
      <td colspan="3"><div align="center" class="style1"><font color="white"> Unsubscribe from our Mailing List </div></font></td>
    </tr>
    <tr bgcolor="#CCCCCC">
      <td colspan="3">Email:</td>
    </tr>
    <tr>
      <td colspan="3"><input name="email" type="text" id="email" size="40" /></td>
    </tr>
    <tr>
      <td width="170"><input type="submit" name="submit" /></td>
    </tr>
    </table>
</form>

END

if(param())
{
    my $email   = param('email');
    if(exists $emails{$email})
    {
     delete $emails{$email};
     print "<center><b>You were removed from our list.</b></center>";
     exit;
    }
      else
      {
        print "<center><b>Your email address was not found.  Please check the spelling.<b></center>";
        exit;
      }
}



            print end_html();








