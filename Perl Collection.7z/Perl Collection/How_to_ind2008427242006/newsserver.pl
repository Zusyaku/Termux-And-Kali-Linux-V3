#!/usr/local/bin/perl

require News::NNTPClient;

use DBI;
my $driver   = "mysql";
my $server   = "localhost";
my $database = "news";
my $url      = "DBI:$driver:$database:$server";
my $user     = "root";
my $password = "";
$dbh = DBI->connect( $url, $user, $password ) or die "Failure!\n";
print "Success!\n";
$dbh->{PrintError} = 1;


#CREATE TABLE `newsgroups` (
#  `Id` int(6) unsigned NOT NULL auto_increment,
#  `Server` varchar(100) default NULL,
#  `Group` varchar(255) default NULL,
#  `Number` varchar(50) default NULL,
#  `Subject` varchar(255) default NULL,
#  `Lines` varchar(50) default NULL,
#  PRIMARY KEY  (`Id`)
#) ENGINE=InnoDB DEFAULT CHARSET=latin1;


my $newsserver = 'news.microsoft.com';
my $filename = "$newsserver-nntp.log";

open(MBOX, ">$filename") or die "Can't write to `$filename': $!\n";

$c = new News::NNTPClient($newsserver);

@lists = qw(refs first lst ident);

@fields = qw(numb subj from date mesg refr char line xref);       

foreach $list ($c->list('active')) {
	print MBOX "$list \n";
	
	%lists = ();
	@lists{@lists} = split /\ /, $list;
	my $group = $lists{refs};
	print MBOX "server : $newsserver -> group: $group\n";
	print "server : $newsserver -> group: $group\n";
	
	#print map { "$lists{$_}\n" } @lists[0];
	#print map { "$_: $lists{$_}\n" } @lists;
	#print "\n";
	
	($first, $last) = ($c->group($group));
	my $messages = $last-$first;
	print MBOX "messages : $messages \n";
	print "messages : $messages \n";
	
	my $seenewsgroup = "SELECT max(Number) as Number FROM `newsgroups` WHERE `server`=\'$newsserver\' and `group` = \'$group\'";
	print MBOX $seenewsgroup;

	my $sql = qq{ $seenewsgroup };
	my $sth = $dbh->prepare( $sql );        
	$sth->execute() or print MBOX "Error execute: $DBI::errstr\n";                        
	
	
	my( $Number );
	$sth->bind_columns( undef, \$Number );
	
	$Number = 0;
	                                                            
	while( $sth->fetch() ) {                                    
	  print "$Number\n";                          
	}      
	
	print MBOX "last in database: $Number \n";
	print "last in database: $Number \n";

	if($Number eq 0){
		print MBOX "Reading $first-$last \n";
		print "Reading $first-$last \n";
		foreach $xover ($c->xover($c->group($lists{refs}))) {
			%fields = ();
			@fields{@fields} = split /\t/, $xover;
			#print MBOX "group: ".$lists{refs}." subject:".$fields{subj}." lines:".$fields{line}."\n";
			my $Subject = $fields{subj};
			$Subject =~ s/\'/\�/g;
			my $insertstatment = "INSERT INTO `newsgroups` (`server`,`group`,`number`,`subject`,`lines`) VALUES (\'$newsserver\',\'".$lists{refs}."\',\'".$fields{numb}."\',\'$Subject\',\'".$fields{line}."\');\n";
			#print MBOX $insertstatment."\n";
			$dbh->do($insertstatment) or print MBOX "Error insertstatment: $DBI::errstr   \n$insertstatment\n";
		}
	} else {
		print MBOX "Reading number $Number-$last \n";
		print "Reading number $Number-$last \n";
		foreach $xover ($c->xover(($Number, $last))) {
			%fields = ();
			@fields{@fields} = split /\t/, $xover;
			#print MBOX "group: ".$lists{refs}." subject:".$fields{subj}." lines:".$fields{line}."\n";
			my $Subject = $fields{subj};
			$Subject =~ s/\'/\�/g;
			my $insertstatment = "INSERT INTO `newsgroups` (`server`,`group`,`number`,`subject`,`lines`) VALUES (\'$newsserver\',\'".$lists{refs}."\',\'".$fields{numb}."\',\'$Subject\',\'".$fields{line}."\');\n";
			#print MBOX $insertstatment."\n";
			$dbh->do($insertstatment) or print MBOX "Error insertstatment: $DBI::errstr   \n$insertstatment\n";
		}
	}
	
}

print MBOX "END";
print "END";

$dbh->disconnect();
close(MBOX);
sleep(3);





