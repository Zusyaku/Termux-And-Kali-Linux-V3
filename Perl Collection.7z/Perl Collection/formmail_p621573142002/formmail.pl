#!/usr/bin/perl

# Plagiarised from formmail.pl and elsewhere, this script lays in wait for
# spammers looking for vulnerable formmail.pl scripts and logs their attempt
# so they can be brought to the attention of their ISP's.
#
# Call this script without arguments to view the log page (reasonable format
# I hope), e.g. http://www.drldev.co.uk/cgi-bin/formmail.pl
#
# The log display should really be in another script but it's handy having it here.
#
# This script is supplied as-is by someone who knows only the most rudimentary stuff
# about Perl. Someone once said, "If at first you don't succeed, call it version 1".
# Well... this is version 1. 8-) Enjoy. Dave L

my $spammerlogpath = '/cgi-bin/formmail.log'; # <-- edit this to suit your server
&parse_form;

# The following was taken and modified from the original excellent but vulnerable formmail.pl script

sub parse_form {
    # Define the configuration associative array.                            #
    %Config = ('email','Unknown',
               'subject','Not Specified',
               'recipient','Not Specified'
               );

    # Either GET or POST method
    if ($ENV{'REQUEST_METHOD'} eq 'GET') {
        # Split the name-value pairs
        @pairs = split(/&/, $ENV{'QUERY_STRING'});
    }
    elsif ($ENV{'REQUEST_METHOD'} eq 'POST') {
        # Get the input
        read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
 
        # Split the name-value pairs
        @pairs = split(/&/, $buffer);
    }

    # For each name-value pair:                                              #
    foreach $pair (@pairs) {

        # Split the pair up into individual variables.                       #
        local($name, $value) = split(/=/, $pair);
 
        # Decode the form encoding on the name and value variables.          #
        $name =~ tr/+/ /;
        $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        # If somebody tries to include server side includes, erase them
        $value =~ s/<!--(.|\n)*-->//g;

        # We are only really interested in their email address
        if (defined($Config{$name})) {
            $Config{$name} = $value;
        }
    }

    my $cs = "<td align=center><font face=verdana size=1>";
    my $ce = "</font></td>";


    my $page_head = <<EOT;
Content-type: text/html

    <HTML>
    <HEAD>
    <TITLE>formmail.pl Script Exploitation Log</TITLE>
    </HEAD>
    <BODY bgcolor=#a0a0e0>
    <CENTER>
    <TABLE width=96% border=1 bgcolor=white cellspacing=0 bordercolor=#a0a0e0 cellpadding=8>
    <TR bgcolor=e0e0ff><TD colspan=5 ALIGN=CENTER>
    <font face=verdana size=4><B>FORMMAIL SCRIPT EXPLOITATION LOG</B></font><hr><font size=1 face=verdana>
    The following log entries are of attempts made to exploit the formmail.pl Perl script on our server.<br>
    <font color=red>IMPORTANT: The recipient address may not be that of the hacker/spammer<br>
    (But if the Subject field contains the URL for the formmail.pl script then it speaks for itself!)</font>
    </font></TD></TR>
    <TR bgcolor=e0e0ff>$cs <b>Time</b> $ce$cs <b>Recipient</b> $ce$cs <b>Subject</b> $ce$cs <b>Pretends To Be From</b> $ce</TR>

EOT
    my $page_tail = <<EOT;
    </TABLE>
    </CENTER>
    </BODY>
    </HTML>
EOT

    if($Config{'recipient'} eq "Not Specified"){ # do we want to display the content of the log?
      # Check there is a log file
      unless (-r "$spammerlogpath") {
        # print a page that says the log is empty
        print $page_head;
        print qq~
        <tr><td colspan=5><center><font face=verdana size=2 color=red>
        There are no log entries at present</center></font></td></tr>
        ~;
        print $page_tail;
        exit;
      }

      print $page_head;

      # Read and output the log file
      # Contains: time|recipient|subject|email|messagebody
      unless (open FILE, "$spammerlogpath") {
        print qq~
        <tr><td colspan=5><center><font face=verdana size=2 color=red>
        Could not open the log file!</font></center></td></tr>
        ~;
        print $page_tail;
        exit;
      }

    		seek (FILE, 0, 0);		# make sure we're positioned at top of file
		    while (<FILE>) {				# loop on file contents
    		  chomp $_;							  # get rid of terminating newline
		      my ($d,$r,$s,$t,$m) = split (/\|/, $_);	# split row into fields
        # output the ones we're interested in into our html table
        print qq~
        <tr>$cs$d$ce
            $cs$r$ce
            $cs$s$ce
            $cs$t$ce
        </tr>
        ~;
    		}
      close FILE;

      print $page_tail;  # complete the page output

    } else {
      # hackers arrive here...
      # split their real email address so we can do something with the url
      my($name,$url) = split(/\@/, $Config{'recipient'});

      # Add the spammer to the log file
      unless (open LOG, ">>$spammerlogpath") {
	       # Can't log
        exit;
      } else {
	       print LOG localtime() . "\|$Config{'recipient'}\|$Config{'subject'}\|$Config{'email'}\n";  #\|$Config{'msg'}\n";
	       close LOG;

        # Things we could do here include;
        #     Automatically emailing abuse@theirdomain
        #     Mailing them with a gotcha message
        #     Updating a central shared database of spammers (providing one didn't
        #     create a circular reference, one could simply invoke the same script
        #     on a different server with the same parameters as parsed to this one)
        #     Send their software the content of their own ISP's home page...
        #     which is what I do here 8-)

        print "Location: http:\/\/www.$url\n\n";
    }
  }
}





