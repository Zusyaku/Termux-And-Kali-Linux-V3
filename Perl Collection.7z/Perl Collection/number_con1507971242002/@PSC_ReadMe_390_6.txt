Title: number converter
Description: converts numbers to words, this can accept numbers up to 999 trillion, automatically puts centavos, this is good for check writing applications, modular you can easily modify it if you want to accept more digits if trillion is not enough. fixed bug in case you input more than trillion digits. added hyphenation of compound numbers greater than 20 and less than 100 (not ending in zero) are hyphenated, such as "Twenty-Seven" for "Twenty Seven". 12/6/2002
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=390&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
