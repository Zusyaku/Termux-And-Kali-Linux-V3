#!/usr/bin/perl -w
#
# numword.pl
# function to convert numbers to words
# the code can acccept up to trillion but since its modular
# can easily be modified to accept more digits
# two decimal places are accepted if you put more decimal numbers it will be rounded to
# two decimal places, usual rounding of numbers applies
# this code is good for creating check writing applications
#
# written by : carno c. mercado 
# nov 25, 2002
# onrac@webgate.net.ph
# 
#
# three functions are involve here, checknum, numtoword and trio
#


# this is the sample application code that access the functions
#
my $number = "" ;
my $fnum = "" ;
my $ans = "" ;

while (not uc($ans) eq("N")) {

	print "\nEnter a number   : ";
	chomp($number=<STDIN>);
	
	$number = &checknum ( $number ) ;

	$fnum = sprintf( "%01.2f" , $number ) ;

	print "figures2: " . sprintf( "%019.2f" , $number ) . " \n" ;
	print "\n figures: $fnum \n words: " . &numtoword( $number ) . " \n\n " ;
	
	print  "Enter again (Y/N) " ;
	
	chomp($ans=<STDIN>) ;


}

exit 0 ;


# end of sample app
# 

# these are the subs
#
#

# this sub checks the length of the input number
#
sub checknum {

	my $newnum = $_[0] ;

	my $nlnt = length($newnum)  ;
	my $npos = "" ;
	
	if ( $newnum =~ /\./g ) {
	
		$npos = pos( $newnum ) -1 ;
		$newnum = substr( $newnum, 0, $npos + 3 ) ;
		
		if ( length( $newnum ) > 18 ) {
		
			$newnum = substr( $newnum, length($newnum) - 18, 18 ) ;
		}
	}
	else {
	
		if ( length( $newnum ) > 15 ) {
		
			$newnum = substr( $newnum, length($newnum) - 15, 15 ) ;
		}
	}
	


	return $newnum ;

}


# numtoword sub
# 
sub numtoword {

	my $newnum = $_[0]  ;
	my $tword = "" ;
	my $t_hun = "" ;
	
	
	$newnum = sprintf( "%018.2f", $newnum  ) ;   # increase the padding here to accept more digits

	# these are the segments of the number 
	my $thr = substr($newnum, 0, 3) ;
	
	my $bil = substr($newnum, 3, 3) ;
	
	my $mil = substr($newnum, 6, 3) ;
	
	my $tho = substr($newnum, 9, 3) ;
	
	my $hun = substr($newnum, 12, 3) ;

	my $cen = substr($newnum, 16, 2) ;


	$tword = "" ;
	if ( &trio ( $thr ) ne "" ) {
		$tword = &trio( $thr ) . "Trillion " ;
	}


	if ( &trio ( $bil ) ne "" ) {
		$tword .= &trio( $bil ) . "Billion " ;
	}

	if ( &trio ( $mil ) ne "" ) {
		$tword .= &trio( $mil ) . "Million " ;
	}

	
	# remove dashes here 
	if ( &trio ( $tho ) ne "" ) {
		($tword .= &trio ( $tho ) . "Thousand " ) =~ s/-/ /g ;
	}


	if ( &trio($hun)  ne "" ) {
		$tword .= &trio ( $hun ) ; 
	}
	
	
	if ( $tword eq "" ) {
		$tword .= "Zero and $cen" . '/100' ;
	}
	else {
		$tword .= "and $cen" . '/100' ;
	}


	return $tword ;

}




# sub trio
# this does the conversion of words by segment
#
sub  trio   { 

	my $rtval = "" ;
	my $huns = "" ;
	my $tens = "" ;
	my $ones = "" ;
	
		
	# hundreds
	if ( substr( $_[0], 0,1) == "1" ) {
		$huns = "One Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "2" ) {
		$huns = "Two Hundred " ;
	}
		
	elsif ( substr($_[0], 0,1) == "3" ) {
		$huns = "Three Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "4" ) {
		$huns = "Four Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "5" ) {
		$huns = "Five Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "6" ) {
		$huns = "Six Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "7" ) {
		$huns = "Seven Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "8" ) {
		$huns = "Eight Hundred " ;
	}
	elsif ( substr($_[0], 0,1) == "9" ) {
		$huns = "Nine Hundred " ;
	}
	else {
		$huns .= "" ;
	}
		

	# tens
	if ( substr($_[0], 1,1) == "2" ) {
		$tens .= "Twenty " ;
	}
		
	elsif ( substr($_[0], 1,1) == "3" ) {
		$tens .= "Thirty " ;
	}
	elsif ( substr($_[0], 1,1) == "4" ) {
		$tens .= "Forty " ;
	}
	elsif ( substr($_[0], 1,1) == "5" ) {
		$tens .= "Fifty " ;
	}
	elsif ( substr($_[0], 1,1) == "6" ) {
		$tens .= "Sixty " ;
	}
	elsif ( substr($_[0], 1,1) == "7" ) {
		$tens .= "Seventy " ;
	}
	elsif ( substr($_[0], 1,1) == "8" ) {
		$tens .= "Eighty " ;
	}
	elsif ( substr($_[0], 1,1) == "9" ) {
		$tens .= "Ninety " ;
	}
	else {
		$tens .= "" ;
	}
		

	# ones
	if ( substr($_[0], 1, 1) == "1"  && substr( $_[0], 2, 1 ) == "0" ) {
		$ones .= "Ten " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "1" ) {
		$ones .= "Eleven " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "2" ) {
		$ones .= "Twelve " ;
	}	
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "3" ) {
			$ones .= "Thirteen " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "4" ) {
			$ones .= "Fourteen " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "5" ) {
			$ones .= "Fifteen " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "6" ) {
			$ones .= "Sixteen " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "7" ) {
			$ones .= "Seventeen " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "8" ) {
			$ones .= "Eighteen " ;
	}
	elsif ( substr( $_[0], 1, 1 ) == "1" && substr( $_[0], 2, 1 ) == "9" ) {
			$ones .= "Nineteen " ;
	}
	
	
	elsif ( substr($_[0], 2,1) == "1" ) {
			$ones .= "One " ;
	}
	
	elsif ( substr($_[0], 2,1) == "2" ) {
		$ones .= "Two " ;
	}
		
	elsif ( substr($_[0], 2,1) == "3" ) {
		$ones .= "Three " ;
	}
	elsif ( substr($_[0], 2,1) == "4" ) {
		$ones .= "Four " ;
	}
	elsif ( substr($_[0], 2,1) == "5" ) {
		$ones .= "Five " ;
	}
	elsif ( substr($_[0], 2,1) == "6" ) {
		$ones .= "Six " ;
	}
	elsif ( substr($_[0], 2,1) == "7" ) {
		$ones .= "Seven " ;
	}
	elsif ( substr($_[0], 2,1) == "8" ) {
		$ones .= "Eight " ;
	}
	elsif ( substr($_[0], 2,1) == "9" ) {
		$ones .= "Nine " ;
	}
	else {
		$ones .= "" ;
	}
	
	
	#
	# add hyphenation if applicable
	if ( (substr($_[0], 1,1 ) > "1" )  &&  ( substr($_[0], 2,1 ) > "0" ) ) {
		( $tens .= $ones ) =~ s/\s/-/o ;
		
	}
	else {
		$tens .= $ones ;
	
	}
	# end hyphenation
	#
	
	$rtval .= $huns . $tens ;
	
	
	return $rtval ;
	

}