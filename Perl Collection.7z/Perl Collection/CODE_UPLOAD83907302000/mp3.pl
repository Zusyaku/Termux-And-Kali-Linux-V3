#!/usr/bin/perl

#		Mp3 Lister
# This simply makes a list of your mp3's, nothing special
# It's mostly for bragging rights, make up your list then throw
# it up on your site

# Setup: Change $Mp3Folder to the folder you want to use.
# You might also need to get File::Recurse. You'll find
# that at search.cpan.org

# Courtesy of www.lolindrath.com
# Bugs or possible improvments sent to lolindrath@hotmail.com


use strict;

use File::Recurse;

#This is the only variable you actually should change
my $Mp3Folder = "c:\\toolbar\\toolbar\\Mp3\'s";
# my $Mp3Folder = "c:\\";
#my $Mp3Folder = "/";
#my $Mp3Folder = ".";

#Variables for Counting the Totals
my $BandCount = 0;
my $SongCount = 0;

#The Extra HTML, using variables makes it easier to change and
#easier to read
#Change this too if you want to change the look of the table
my $BandOpen = "<tr><td bgcolor=seagreen><font color=white size=-3 face=veranda><strong>";
my $BandClose = "</strong></font></td></tr>";
my $SongOpen = "<tr><td bgcolor=seagreen><font color=white size=-3 face=arial>";
my $SongClose = "</font></td></tr>";
my $TotalOpen = "<tr><td bgcolor=seagreen><font color=white size=-3 face=veranda><strong>";
my $TotalClose = "</strong></font></td></tr>";

#Open the file to add all the mp3's to
open FILE, ">mp3.html" || die "couldn't create file";
 
#Print header for file
print FILE "<html><head><title>Mp3 List</title></head><body bgcolor=white >\n";
print FILE "<table bgcolor=white cellspacing=1 cellpadding=1 border=0>\n";

#Have Recurse do all the dirty work for us and put it in a hash
my %Files = &Recurse([$Mp3Folder], {match => '\.mp3$', nomatch => '\.html$'});

my ($File, @Name, $Band, $Song, $Songtemp, $Junk, %List);
foreach (sort keys %Files) 
{   
     foreach $File(@{ $Files{$_} }) 
     {
     		#This little hack is so you don't get track numbers as the name
     		#of you mp3
       		( @Name ) = split( /-/, $File );
       		$Band = @Name[0];
       		$Songtemp = @Name[$#Name];
       		
       		#Get rid of the file extension
       		( $Song, $Junk ) = split( /\.mp/, $Songtemp );
     		
     		#Add it to the band
       		push( @{ $List{$Band} }, $Song );
     }
}
 
foreach (sort keys %List)
{
	$BandCount++;
	#Print band then print all the songs by that band
	print FILE "$BandOpen $_ $BandClose \n";
	
	foreach $Song( @{ $List{$_} } )
	{
		$SongCount++;
		print FILE "$SongOpen $Song $SongClose \n";
	}
}
print FILE "$TotalOpen $SongCount Songs by $BandCount Bands $TotalClose \n";
print FILE "</table></body></html>\n";
close FILE;

