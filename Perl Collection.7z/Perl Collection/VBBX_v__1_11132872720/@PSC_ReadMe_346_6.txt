Title: VBBX v. 1.1 Forum
Description: VBBX started out as a simple message board, but eventually ended up less so. I made VBBX because I had tried many other forums on my website, and I didn't like any of them.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=346&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
