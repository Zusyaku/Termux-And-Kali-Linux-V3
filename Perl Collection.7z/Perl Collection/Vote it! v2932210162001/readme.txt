VOTE IT! v1.0
--------------

Created by De KoFfie� (dekoffie@planetkoffie.com)
Last modified on 15/10/2001
An example of this script can be viewed at http://www.planetkoffie.com

This script was written mainly as a CGI example. I should have add comments in the code, but i didn't. I will add comment in later versions. Any question regarding the use, the code or any other details can be sent to dekoffie@planetkoffie.com

[1] Preparation:

First you need to edit some of the cgi files, to make sure they will work.
Open up webpolladmin.cgi, webpollssi.cgi and webpollh.cgi with a text editor and change the first line to the path where perl is located on your webserver.
( In most cases, you don't need to change this and you can leave it to; #!/usr/bin/perl ) 
Then, open up vars.cgi and change the following settings;
$username = "username";
$password = "password";
Change everything between the brackets (" ") to whatever suits your needs. DO NOT LEAVE THESE OPTIONS AS THEY ARE NOW!
After that, take a look at those next three settings. I think they are pretty self-explanitory. The $poll_dir variable needs to be set to the URL to the directory where you will place the scripts files. The $poll_url is the page where you are putting the poll in.
There is a POLLBAR image included in this zip file, so you can simply point out to where you will be uploading the image.

[2] Uploading:

Connect to your webserver, and create a new directory called:
voteit
inside your cgi-bin directory. CHMOD this directory to 777 !

Then you need to upload these files in ASCII MODE:
 - iplog
 - poll_results
 - q_a
 - and the four .CGI files
Now, you need to CHMOD these files. Heres how:
iplog, poll results and q_a ; CHMOD 666
webpolladmin.cgi, webpollssi.cgi, webpollh.cgi and vars.cgi ; CHMOD 755

Now, if you will use the included pollbar image, you will only need to upload the pollbar.gif image, but mind you, this MUST be in BINARY MODE! Otherwise the image won't work.

[3] Configuring the script:

Now that the script has been installed, point your webbrowser to webpolladmin.cgi .
Log in the script by using the username and password you had set in the first step of this readme file.
You'll arrive in your control panel! From here you can set a question, and answers (one answer per line!!) or you can start all over again by resetting the ip log, the results or everything.

[4] Preparing the webpage:

Ok, now that the poll script is working, you still need to incorperate the poll into another web-page. For this, you need to use a server-side-include (SSI), which might look like this:
<!--#exec cgi="cgi-bin/voteit/webpollssi.cgi" -->
This varies from server to server, if you are not sure or cant get it working, ask your system administrators! Don't doubt to ask them!
The include always needs to point out to webpollssi.cgi !

[5] Congratulations:

Great, you got it all working!
I would like to thank you for using this webpoll.
If you have any comments, suggestions, bug reports, whatever, do not hesitate to contact me!
My e-mail is dekoffie@planetkoffie.com , or go to http://www.planetkoffie.com and contact me by posting a word on the forums!

Thank you!

De KoFfie�