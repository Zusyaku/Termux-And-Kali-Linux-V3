Title: Vote it! v1.0
Description: Vote It! is a simple but efficient web poll for your site's pages! Its a SSI poll; this means you can put the code into your webpage, and the poll will be displayed.
You can set the questions and answers, reset the ip log or the results by an easy-to-use control panel! 
The results are shown graphical, the number of total votes can be viewed to.
Please give me comments, report bugs or whatever, so i can make this script better! 
PLEASE READ THE README FILE BEFORE INSTALLING THE SCRIPT!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=242&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
