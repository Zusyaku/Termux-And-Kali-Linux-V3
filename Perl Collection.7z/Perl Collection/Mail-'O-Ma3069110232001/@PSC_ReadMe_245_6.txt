Title: Mail-'O-Matic
Description: Mail-'O-Matic is a mailing list with some extra features for the administrator of this list. Trough the control panel you can send a news mail, invite people to join your mailing list and manage your registered users! This time, i have put in much more comments in the code than i did in my previous code (vote it!). 
PLEASE READ THE README.TXT FILE BEFORE INSTALLING!
*UPDATE: i noticed the code with all the comments didn't work anymore. I am very sorry about that. I have now added the WORKING cgi files in the zip (but without comments in the code), but i also added a zip file inside the zip which contains the code WITH comments! Sorry about this little problem! *
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=245&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
