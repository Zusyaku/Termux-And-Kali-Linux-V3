MAIL-'O-MATIC! v1.0
--------------

Created by De KoFfie� (dekoffie@planetkoffie.com)
Last modified on 20/10/2001

This script was written mainly as a CGI example. I tried to add as much as comment as i could. I hope it can be usefull to some of you beginning coders out there. Any questions, comments or suggestions related to this script can be send to me!

[1] Preparation:

First you need to edit some of the cgi files, to make sure they will work.
Open up these two files with a simple text editor:
- mailinglist.cgi
- mailinglist_admin.cgi
and change the first line (#!/usr/bin/perl) to the correct path to perl on your server.
If you are not sure where this is, contact your system administrator! On most servers, the path is the same so you might leave this like it is now.
Close and save these files.
Then, open up vars.cgi and change the following settings;
 $user_name = "username";
 $password = "password";
to whatever suits your needs.

After that, take a look at the other settings wich need to be edited. I think they are pretty self-explanitory. 
About the headers & footers:
If you set these to "yes", the script will open up the following files:
- mheader.txt & mfooter.txt for e-mails
- pheader.txt & pfooter.txt for html pages
Edit those to suit your needs, and in case you do not want to use them, set the options in the vars.cgi file to "no".
NOTE: the mfooter.txt file has a link wich lets users to be able to unsubscribe by simply clicking on it.
You'll notice that this links ends with the word !email! . This word gets replaced by their e-mail address when a mail is sent out trough the script. You can place this word !email! more than once in the mfooter.txt file, in case you need to use this somewhere else in your footer.

Save the file vars.cgi !

Now, there is only one file left to edit: minvite.txt . This file holds the content wich will be sent out to a user you've invited (trough the admin script). You can edit this to suit your needs. And again, note the !email! word in the url to subscribe. Leave this in that url, otherwise the user will get an error message when clicking on that link.

[2] Uploading:
Connect to your webserver, and create a new directory called:
- mailomatic
inside your cgi-bin directory. CHMOD this directory to 777 !

Now you need to upload and chmod the following files in ASCII MODE(!). Here is how:
  FILE NAME:				CHMOD:
- mailinglist.cgi			  755
- mailinglist_admin.cgi			  755
- vars.cgi				  755
- rusers.usr 				  666
- mheader.txt,mfooter.txt & minvite.txt	  444
- pheader.txt & pfooter.txt 		  444

[3] Running the script:
You, as the admin, need to login in the control panel to be able to use the control features.
Point your browser to the mailinglist_admin.cgi file. A login page will show up. Simply log in using the user name and password you've set in the vars.cgi file.

You will arrive in your control panel. From here you can send out a news mail to all your registred users, invite a new user to join the list or you can look at all the registered users and/or delete them. 

Now, if you want users to be able to subscribe to your mailing list, simply add the following piece of html code in an html page:

<form action="<!url to the mailomatic directory!>/mailinglist.cgi" method="POST">
Email Address: <input type="text" name="email"><br>
<input type="radio" value="subscribe" name="action" checked>Subscribe <img src="http://www.planetkoffie.com/forums/images/smileys/smile.gif"><input type="radio" value="unsub" name="action">Unsubscribe <img src="http://www.planetkoffie.com/forums/images/smileys/cry.gif"><br>
<input type="submit" value="Subscribe!">
</form>

NOTE: change the <!url to the mailomatic directory!> part in the first line of this code to the correct directory (not the PATH, but the URL (for example: http://www.yourdomain.com/cgi-bin/mailomatic )

[4] Congratulations:
Great, you got it all working!
I would like to thank you for using this mailing list.
If you have any comments, suggestions, bug reports, whatever, do not hesitate to contact me!
My e-mail is dekoffie@planetkoffie.com , or go to http://www.planetkoffie.com and contact me by posting a word on the forums!

Thank you!

De KoFfie�