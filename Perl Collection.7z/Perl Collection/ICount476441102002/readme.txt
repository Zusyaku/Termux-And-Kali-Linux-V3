 icount.pl

 Version 1.0, Friday, January 11, 2002

 By Glen Yeager | scripts@distantrealm.com | http://www.distantrealm.com

 Copyright 2002, Glen Yeager  All Rights Reserved.

Image counter is a background web counter that can be used to track page hits
without displaying a count of them on your page. It also keep a log of the Date/Time, IP
Address, and Host Name for each count. Just update the 3 config variables and replace the 
call to the image on you page with a call to this script and the result will be transparent
to your visitors, but you will begin to track hits. It works by hiding behhind one of the images 
 that you would normaly load on your web page. To us this counter just put the three files
 in your cgi-bin directory, edit the three configuration items, and replace the image url in the 
 image tag on you webpage. When the page is loaded and the call is made to this script it
 will make the call to your image, and update your countlog file as well.

 EXAMPLE: 
 <img src="http://www.distantrealm.com/cgi-bin/amacount.cgi" alt="Distantrealm Web Designs" 
 border=0 width="400" height="75" >