Title: ICount
Description: Image counter is a background web counter that can be used to track page hits
without displaying a count of them on your page. It also keep a log of the Date/Time, IP
Address, and Host Name for each count. It works by hiding behhind one of the images 
that you would normaly load on your web page. Edit the three configuration items, and 
replace the image url in the image tag on you webpage. When the page is loaded and 
the call is made to this script it will make the call to your image, and update 
your countlog file as well.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=274&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
