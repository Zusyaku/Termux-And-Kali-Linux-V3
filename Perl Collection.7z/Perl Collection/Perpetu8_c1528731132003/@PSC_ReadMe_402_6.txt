Title: Perpetu8.cgi
Description: PerpetU8 is a calendar script (work in progress). It will display a multi-week calendar with colored days showing seperate months, and past and present day.
Currently the calendar date (ie. number of the month) is clickable and will call the script with 'action=editdate' <- this part is not finished.
I submit this code in hopes that someone will think it is workable and continue if I don't.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=402&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
