Title: Image Gallery v1.8
Description: Image uploader/gallery. For upload images via your browser and have them automatically set into a gallery (with thumbnails and descriptions).
----------------------------
Major Revisions:
-Upload upto 4 images at once, instead of just one.
-Removed ascii exploit
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=533&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
