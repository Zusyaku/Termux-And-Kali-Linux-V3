#!/usr/bin/perl -w

use warnings;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);

use POSIX;

use DB_File;

my %upload;
my $upload = "imagegallery.db";

# full file path to image directory
my $imagedir = "http://sulfericacid.perlmonk.org/playground/upload/files/";

tie %upload, "DB_File", "$upload", O_CREAT | O_RDWR, 0644, $DB_BTREE
  or die "Cannot open file 'upload': $!\n";

print header, start_html('My Image Gallery');

my $page = url_param('page');
$page ||= 1; # if no url_param exists, make it 1

my $first = ($page - 1) * 20;
my $last  = $first + 19;

print "<table>\n";

my $counter = 0;

for (grep defined($_), (reverse keys %upload)[$first .. $last]) {

    my ( $filename, $title, $desc, $width, $height ) = split ( /::/, $upload{$_} );
    print " <tr>" unless ( $counter % 5 );

$title    =~ s/(\S{11})/$1 /g;
$desc     =~ s/(\S{11})/$1 /g;





    print qq(<td valign="top" width="120" height="120">),
    	  qq[<A HREF="javascript:window.open('$imagedir/$filename', 
'','toolbar=no width=$width height=$height scrolling=yes'); void('');">],
		  qq[<img src="$imagedir/$filename" height="100" width="100"></a><br>];
$filename =~ s/(\S{11})/$1 /g;		  
    print qq(<b><font size=2>Filename:</b>$filename<br></font>),
          qq(<b><font size=2>Title:</b>$title<br></font>),
          qq(<b><font size=2>Desc:</b>$desc<br></font>),
          qq(<b><font size=2>Dimens:</b> $width x $height<br></font>),
          qq(</td>);
    unless ( ++$counter % 5 ) {
        print "</tr>\n";
    }
}
print "</table>";






my @keys  = sort keys %upload;
my $group = 0;

while (my @group = splice(@keys, 0, 20)) {

  $group++;


my $url = "http://sulfericacid.perlmonk.org/playground/upload/newupload.pl";
  print qq(<a href="$url?page=$group">Page: $group</a>|\n);

}
