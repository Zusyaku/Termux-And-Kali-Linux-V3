
  Thanks you for d/l this script.

  there are a few things you'll need to do to configure the G.B. before it wil be operational.

  keep in mind that wherever www.yoursite.com is presented you will need to enter your website address.  my example: www.yoursite.com --> www.berard.cc

  1) In the guestbook.cgi file you will need to setup the following.  


  webbaddress              $homepage = "http://www.yoursite.com";
  title of site            $pagename = "My Site";
  location of this file    $cgifile = "http://www.yoursite.com/cgi-bin/guestbook.cgi";
  image to be shown at top $bgimg = "/img/cgi_img.gif"; 


  These are the colors of the tables that will hold the users input information.
  bordercolor      $bdrcolor =  "#5885C8";
  background color $entrybgcolor = "#cfdfff";
  link color       $linkcolor = "#0000ff";

  This is the width of the entries (the box around each entry)
  table width      $tableWidth = "600";

  to access the editor you will need the following
  username    $username = "admin";
  password    $password = "password";



  2)  In the index file provided you will need to change the website from www.yoursite.com

  3)  Upload the images to your site.  The default location in the cgi script is the 'img' folder on the root of your site.
      Wherever you put the images be sure the $bgimg value in the cgi script matches that location.

  4)  Upload the guestbook files to the cgi-bin on your site and change the CHMOD = 777

  5)  Upload the index file and try out the guestbook



  If you find any bugs please report them to me so I can learn from my mistakes.  I've only been programming in PERL for like a year or so on and off.  So I have MUCH to learn.  Plus i'd like to see where my codes being used.

  Thanks JR Berard @ www.berard.cc
  jamesberard@hotmail.com
