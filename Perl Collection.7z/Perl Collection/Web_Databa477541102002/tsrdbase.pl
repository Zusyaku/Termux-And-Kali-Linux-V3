#!c:\faws\perl\bin\perl.exe
#
# Terminal Service Request Database Constructor and Manipulation Example 
# 
# Used to allow subordinate elements to send Terminal Service Requests to Syscon Seciton
#
# Courtesy Mollensoft Software 2000
#
#
# You Should have CGI MODULE installed for some TSR Functions To work!!!!!!!!!!!!!<<<<<<!!!!!!!!!!  
#
############################################################################################################
use File::Copy; 
use CGI qw (:standard);
use CGI::Carp qw(fatalsToBrowser);

# Step 1 Define Database fields and location of flat file
# It is important to use the EXACT form field names in the line below! 
# Dont worry about the text that shows up on the the HTML FORM just the field Name 
@fields = ("TSR number","Submission DTG","Submitters Name","Submitter EMail Address","Submitter Phone","Office","ORIGINAL TSR SUBMISSION");
$database = "tsr/database.txt";
$Date = localtime();
$q = new CGI;
print $q->header;
$numbex = 5;
$field_count = @fields;
$colspan = $numbex + $field_count;
$EXCLUSIVE = 2;
$UNLOCK    = 8;
$search_for   = $q->param(search_for);
$search_field = $q->param(search_field);
$action       = $q->param(action);
@keys         = $q->param(key);
$key_matches  = @keys;
$search_field = "all" if($search_field eq "");
$search_for   = '.'   if ($search_for eq "");

if($action =~ /add record/i){
 # Add the TSR passed from the add TSR page###############################
  &add_record;
  $message="Record Added";
  &print_message($message);
}

elsif($action =~ /SUBMIT/i){
 # Display the add TSR page
  &web_get;
  $message2="TSR Submitted";
  &print_message($message2);
}

elsif($action =~ /PrintBackEnd/i){
 # Display the add TSR page
  &PrintBackEnd;
}

elsif($action =~ /add/i){
 # Display the add TSR page
  &print_add_screen;
}
elsif($action =~ /modify record/i){
 # Display the results of the search
  &search_database($q->param(key));
  $count = @results;
  &no_match if($count < 1);  	
  &print_modify_page;
}
elsif($action =~ /modify this record/i){
 # Modify the TSR that was passed
  &delete_records;
  $key=$keys[0];
  &add_record;
  
  print<<end_TSR;
Content-type: text/html 



<HTML>
 <HEAD>
  <TITLE>CONFIRMATION</TITLE>
        <FONT SIZE="4"><FONT COLOR="RED">TSR MODIFITED... Returining to Main Page.......
      </FONT></FONT></BODY>
</HTML>
end_TSR
print <<EOF;
EOF
&PrintBackEnd;
}

elsif($action =~ /modify/i){
 # look for and show results for TSR modification request
  &search_database($search_for);
  $count = @results;
  if($count < 1){
    &no_match;
  }
  elsif($count == 1){
    &print_modify_page;
  }
  else {
    $caption="Modify Which Record?";
    $button_text="Modify Record";
    &multiple_match("RADIO","modify");
  }
}
elsif($action =~ /delete record/i){
 # Delete the TSRs that were specified on the form
  &delete_records;
  $message="Record(s) Deleted";
   print<<end_TSR;
<HTML>
 <HEAD>
  <TITLE>CONFIRMATION</TITLE>
        <FONT SIZE="4"><FONT COLOR="RED">TSR DELETED... Returining to Main Page.......
      </FONT></FONT></BODY>
</HTML>
end_TSR
print <<EOF;
EOF
&PrintBackEnd;
}

elsif($action =~ /RETURN/){
 &PrintBackEnd;
}

elsif($action =~ /delete/i){
 # Search and show results of TSR modification
  &search_database($search_for);
  $count = @results;
  &no_match if($count < 1);
  $caption="Delete Which Record(s)?";
  $button_text="Delete Record(s)";
  &multiple_match("CHECKBOX","delete");
}
elsif($action =~ /search/i){
 # Search TSR database and display the results
  &search_database($search_for);
  $count = @results;
  if($count > 0){
   # $button_text = "Back to TSR Database";
    #$button_text = "tsrdbase.pl\?action=PrintBackEnd"; 
    $button_text = "RETURN"; 
   
   $caption = "Search Results";
    &multiple_match;
  } else {
    &no_match;
  }
}
else { &print_default; }
exit;

### ALL Action Subroutines Beneath This Line.

sub add_record {
  $key   = time();
  $record=$key;
  foreach $field (@fields){
        ${$field}  = $q->param($field);
    ${$field}  = filter(${$field});
    $record   .= "\|${$field}";
    $record =~ s/\r\n/<br>/g;
}
    unless (-e $database){
    open (DB, ">$database") || die "Error creating database.  $!\n";
  } else {
    open (DB, ">>$database") || die "Error opening database.  $!\n";
  }
   #flock DB, $EXCLUSIVE; For Future Dev (I.E. LINUX and Future WIN32)Please Leave Me Alone
   seek DB, 0, 2;
   print DB "$record\n";
   close(DB);
} 
# End of add_record subroutine.


###########Start the get of TSR from WEB Page Using CGI#########
sub web_get {
  $key   = time();
  $record=$key;
  foreach $field (@fields){
        ${$field}  = $q->param($field);
    ${$field}  = filter(${$field});
    $record   .= "\|${$field}";
    $record =~ s/\r\n/<br>/g;
}
    unless (-e $database){
    open (DB, ">$database") || die "Error creating database.  $!\n";
  } else {
    open (DB, ">>$database") || die "Error opening database.  $!\n";
  }
   #flock DB, $EXCLUSIVE;
   open (ZXRT, ">TSR.tmp.txt");
   seek DB, 0, 2;
   print DB "$record\n";
   print ZXRT "$record";
  close(ZXRT);   
  close(DB);
	  } 

#############End Of Get Record From Web Page Process ######


############# Print the Manual Add Requirement Screen #####
#Warning, This assumes you have administrator Access therfore there is no need for a TSR Number!
sub print_add_screen{
  print<<HTML;
Content-type: text/html



   <HTML><HEAD><TITLE>Add a TSR</TITLE></HEAD>
  <BGCOLOR ="BLACK">
     <CENTER><FONT COLOR=WHITE SIZE=5 FACE="ARIAL">
      Add a Record
     </FONT></CENTER>
     <P>
     <FORM ACTION="tsrdbase.pl" METHOD=POST>
      <CENTER><TABLE BORDER=10 CELLSPACING=0>
HTML
  foreach $field (@fields){
       print<<HTML;
        <TR>
         <TD BGCOLOR ="BLACK"><FONT COLOR="WHITE">
<B>\u$field:</B></TD>
         <TD><INPUT TYPE=TEXT NAME="$field"></TD>
        </TR>
HTML
  } 
  print<<HTML;
       <TR>
        <TD COLSPAN=5 BGCOLOR="BLACK">
         <CENTER>
          <INPUT TYPE=SUBMIT NAME=action VALUE="Add Record">
         </CENTER>
        </TD>
       </TR>
      </TABLE></CENTER>
     <P>
    </FONT>
   </BODY></HTML>
HTML
} # End of Dreaded PRINT_ADD_SCREEN CRAP.

sub delete_records{
  copy("tsr/database.txt","tsr/Backupdatabase.txt");
    $tempfile="tsr/tsrdatabase.txt";
    open (DB,   $database)    or die "Error opening file: $!\n";
  open (TEMP, ">$tempfile") or die "Error opening file: $!\n";
  while(<DB>){
    $match="";
    ($key,$rest)=split(/\|/);
    foreach $current (@keys){
      if($current == $key){$match=1;}
    } # End of foreach loop.
   print TEMP $_ unless ($match == 1);
  } 
          # Please dont touch this... for future dev
          #FLOCK Routine Here for Linux copy($database, $tempfile);
		#FLOCK Routine Here form Linux copy($tempfile, $database);  
close(TEMP);
  close(DB);
   unlink($database);
copy("tsr/tsrdatabase.txt","tsr/database.txt");
} 
# End of subroutine.
sub print_modify_page{
  ($key,@field_vals) = split(/\|/, $results[0]); 
  $fs="<FONT SIZE=2 FACE=ARIAL>";
  $fc="</FONT>";
  print $q->start_html(-TITLE=>'Modify Record',-BGCOLOR=>'white'),
        $q->start_form;
  print<<HTML;
   <CENTER><FONT SIZE=5 FACE=Verdana>
     <FONT SIZE =+2>Modify TSR </FONT><br>     System Time: $Date<br>   
   </FONT></CENTER>
   <HR WIDTH=75%>
   <INPUT TYPE=HIDDEN NAME=key value="$key">
   <CENTER>
    <TABLE BORDER=5 CELLSPACING=0>
HTML
  $x=0;
  foreach $field (@fields){
    print<<HTML;
     <TR BGCOLOR="e0e0e0">
      <TD>$fs<B>\u$field:</B>$fc</TD>
      <TD><INPUT TYPE=TEXT NAME="$field" VALUE="$field_vals[$x]" SIZE=40></TD>
     </TR>
HTML
    $x++;
  } # End of foreach.
print<<HTML;
Content-type: text/html 



     <TR BGCOLOR="efefef">
      <TD COLSPAN=10>
       <CENTER>
        <INPUT TYPE=SUBMIT NAME=action VALUE="Modify This Record">
       </CENTER>
      </TD>
     </TR>
    </TABLE>
   </CENTER>
   <P><HR WIDTH=75%>
  </BODY></HTML>
HTML
}
sub multiple_match{
  print $q->start_html(-TITLE=>'Match Results',-BGCOLOR=>'BLACK');
  print<<HTML;
   <FONT SIZE=6 COLOR="GREEN" FACE=ARIAL>
    <CENTER>$caption</CENTER>
   </FONT>
   <FONT FACE=ARIAL COLOR=WHITE>
    <CENTER>There were $count matches</CENTER>
   </FONT>
   <FORM METHOD=POST>
   <HR WIDTH=75%>
   <P>
   <CENTER><TABLE BORDER=1 CELLSPACING=0>
    <TR>
HTML
  if($_[1] =~ /(modify|delete)/){
    print "<TD ALIGN=center>";
    print "<FONT SIZE=2 FACE=ARIAL BODY BGCOLOR=BLACK><B>Select</B></FONT></TD>";
  }
  foreach $field (@fields){
    print "<TD ALIGN=CENTER>";
    print "<FONT SIZE=3 FACE=ARIAL COLOR=YELLOW><B>\u$field</B></FONT></TD>";
  } # End of foreach

  print "</TR>";
  foreach $record (@results){
    ($key,@field_vals) = split(/\|/, $record); 
    print "<TR BGCOLOR=\"#efefef\">";
    if($_[1] =~ /(modify|delete)/){
       print "<TD ALIGN=left><FONT SIZE=2 FACE=ARIAL>";
       print "<INPUT TYPE=$_[0] NAME=key VALUE=$key>";
       print "</FONT></TD>";
    } 
      for($x=0;$x<$field_count;$x++){
      $item = &check_empty($field_vals[$x]);
      print "<TD><FONT SIZE=2 FACE=ARIAL>$item</FONT></TD>";
    }
     print "</TR>";
  } 
 print<<HTML;
  <TR BGCOLOR="#e0e0e0">
   <TD COLSPAN=10 ALIGN=Center>
<INPUT TYPE=SUBMIT NAME=action VALUE="$button_text">
  </TD>
  </TR>
 </TABLE>
</FORM></BODY></HTML>
HTML
} # End Of Multiple Match Process

sub no_match{
  print $q->start_html(-TITLE=>'No Match',-BGCOLOR=>'white');
  print "<H2><CENTER>There was no match for <I>$search_for</I>, ";
  print "please hit <B>back</B> and try again.</CENTER></H2>";
  print $q->end_html;
  exit;
} # End of Unmatched process.

sub search_database{
  my $search_for = $_[0];
  open(DB, $database) or die "Error opening file: $!\n";
    while(<DB>){
      if($search_field =~ /all/i){
        if(/$search_for/oi){push @results, $_};
      } else {
        ($key,@field_vals) = split(/\|/, $_);
        if($field_vals[$search_field] =~ /$search_for/oi){push @results, $_};
      } # End of else.
    } # End of while.
  close (DB);
} # End of Search Process.

# The Following Prints the Default Login Screen (calls Proc.pl) For Access to DB manipulation
sub print_default {
#PrintHeader("You must Login to Edit System Environment");
print<<"END"
Content-type: text/html 



<HTML>
 <HEAD>
   <TITLE>MOLLENSOFT Freeware</TITLE>
 </HEAD>
<BODY BGCOLOR="BLACK" LINK="#0000BB">
  <P ALIGN=CENTER>
  <CENTER>
  < ALIGN=CENTER>
    <TABLE WIDTH="550" CELLPADDING="2" CELLSPACING="3" BORDER="2">
    <TR>
     <TD WIDTH="330" BGCOLOR="BLACK" VALIGN=CENTER>
      <P ALIGN=CENTER>
       <FONT FACE="arial"><ALIGN=CENTER><FONT SIZE="6"><FONT COLOR="RED">      PLEASE LOGIN</FONT></TD>
    </TR>
    <TR>
     <TD VALIGN=CENTER><CENTER>
      <P ALIGN=CENTER>
       <TABLE WIDTH="320" CELLPADDING="1" CELLSPACING="2" BORDER="0">
        <TR>
         <TD VALIGN=CENTER>
          <FORM ACTION="proc.pl" METHOD="post">
           <INPUT TYPE=HIDDEN NAME="action" VALUE="authenticate">
            <CENTER>
            <P ALIGN=CENTER>
             <TABLE WIDTH="250" CELLPADDING="1" CELLSPACING="2" BORDER="0">
              <TR>
               <TD COLSPAN="2" VALIGN=CENTER>
                <P ALIGN=LEFT>
                 <FONT FACE="Verdana" SIZE = "4"><FONT COLOR="YELLOW"><I>Terminal
    Service Request Database Manager Login</I></B></FONT></FONT>
                 <P ALIGN=CENTER>
                 <FONT FACE="Arial"><FONT SIZE="2">&nbsp;</FONT></FONT><FONT FACE="Arial"><FONT SIZE="4"><FONT COLOR="RED"><B>Enter
                  </B></FONT></FONT></FONT><B><FONT FACE="Arial"><FONT SIZE="4"><FONT COLOR="RED">U</FONT></FONT></FONT></B><FONT FACE="Arial"><FONT SIZE="4"><FONT COLOR="RED"><B>sername
                  and Password</B></FONT></FONT></FONT></TD>
              </TR>
              <TR>
               <TD VALIGN=CENTER>
                <P ALIGN=RIGHT>
                 <FONT FACE="Arial"><B><FONT SIZE="4">Username:</FONT></B></FONT></TD>
               <TD VALIGN=CENTER>
                <P>
                 <INPUT TYPE=TEXT NAME="usr" SIZE="15" MAXLENGTH="15"></TD>
              </TR>
              <TR>
               <TD VALIGN=CENTER>
                <P ALIGN=RIGHT>
                 <FONT FACE="Arial"><B><FONT SIZE="4">Password:</FONT></B></FONT></TD>
               <TD VALIGN=CENTER>
                <P>
                 <INPUT TYPE=PASSWORD NAME="pwd" SIZE="15" MAXLENGTH="15"></TD>
              </TR>
              <TR>
               <TD COLSPAN="2" VALIGN=CENTER><CENTER>
                <P ALIGN=CENTER>
                 <INPUT TYPE=SUBMIT VALUE="Login"></P>
                </CENTER>
                <P ALIGN=CENTER>
                <FONT FACE="Verdana,Arial,Times New I2"><B><FONT COLOR="YELLOW">Courtesy</FONT></B></FONT></P>
  <P>
   <FONT COLOR="YELLOW"><B><FONT FACE="Verdana,Arial,Times New I2">Mollensoft
    Software 2000 www.mollensoft.com</FONT></B></FONT>                 
                                             </TR>
             </TABLE>
            </FORM></TD>
        </TR>
       </TABLE></TD>
    </TR>
   </TABLE>
 </BODY>
</HTML>
END
}

sub PrintBackEnd {
 print<<HTML;
Content-type: text/html




	<HTML><HEAD>
   <TITLE>Terminal Service Request DATABASE Default Screen</TITLE>
  </HEAD>
  <BODY BGCOLOR="BLACK" LINK="#0000BB">
  <FORM METHOD="post" ACTION="tsrdbase.pl">
  <CENTER><FONT SIZE=4 COLOR=RED FACE="verdana"><B>
   The Terminal Service Request Database Managers Console
  </B></FONT></CENTER>
  <CENTER><FONT SIZE=2 FACE="verdana" COLOR="LIGHTGREEN"><B>
   Courtesy Mollensoft Freeware 2000 www.mollensoft.com </B></FONT></CENTER><p>
   <CENTER>
   <TABLE BORDER=1 WIDTH="60%" CELLSPACING="0">
   <TR> 
    <TD COLSPAN=$colspan>
       <CENTER><FONT COLOR="YELLOW"  FACE="ARIAL" SIZE=2>
      To <I>Manually add</I> a TSR, click on the Add button. 
      To <I>search/modify/delete</I> TSR's, enter the text in 
      the box below and choose the field to search on. Then 
      click to appropriate button.
     </FONT></CENTER>
    </TD>
   </TR><TR> 
    <TD><FONT COLOR="WHITE" FACE="ARIAL" SIZE=2><B>Search For:</B></FONT></TD>
    <TD><INPUT TYPE="text" NAME="search_for" SIZE="40"></TD>
   </TR><TR> 
    <TD><FONT COLOR="WHITE" FACE="ARIAL" SIZE=2><B>Search On Any TSR Field:</B></FONT></TD>
    <TD><FONT COLOR="WHITE" FACE="ARIAL" SIZE=2> 
     <INPUT TYPE="radio" NAME="search_field" VALUE="all" CHECKED>All 
HTML
  $x=0;
  foreach $field (@fields){
    print "<br><INPUT TYPE=radio NAME=search_field VALUE=$x>\u$field";
    $x++;
  }
  print<<HTML;
    </FONT></TD>
   </TR><TR> 
    <TD COLSPAN=$colspan> 
     <CENTER> 
      <INPUT TYPE="submit" NAME="action" VALUE="   Add   ">
      <INPUT TYPE="submit" NAME="action" VALUE="Search">
      <INPUT TYPE="submit" NAME="action" VALUE="Modify">
      <INPUT TYPE="submit" NAME="action" VALUE="Delete">
     </CENTER>
    </TD>
  </TR>
 </TABLE></FORM></BODY></HTML>
HTML
}
# End of Print Default Process.



# Get Rid of ASCII PIPE symbols in ASCII DBASE.
sub filter{
  $temp = $_[0];
  $temp =~ s/\|//; 
      return ($temp);
}

sub print_message{
  print<<HTML;
    <HTML><BODY BGCOLOR="#FFFFFF" TEXT=ARIAL>
     <FONT SIZE=6><CENTER>Terminal Service Request ADDED!</CENTER></FONT><HR WIDTH=75%>
     <P>
     <FONT SIZE=5><CENTER>
      Thank You For Your TSR Submission! We Will Handle it as Quickly as Possible!
      <p>
      Back To <A HREF="/index.htm">Intranet Homepage</A>
     </CENTER></FONT>
    </BODY></HTML>
HTML
}

sub check_empty{
  $r_val = $_[0];
  if($r_val =~ /^\s*$/){$r_val="&nbsp;"}

  return($r_val);
}


