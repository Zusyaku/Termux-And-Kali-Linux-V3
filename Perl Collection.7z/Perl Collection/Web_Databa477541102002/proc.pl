#!c:\faws\perl\bin\perl.exe
#
# This File is the Mollensoft Terminal Service Request Access Security Processor(PROC)
# It allows access to the TSR Dbase Management Functions (behind a password and IP <if configured>)
#
#  This is of Course Freeware Just Like Perl Itself!! 
#
# This Perl Script Mitigates access to your Database Management
#
# Courtesy Mollensoft Software
#
# Should have CGI MODULE installed for some TSR Functions To work!!!!!!!!!!!!!<<<<<<!!!!!!!!!!  
#
# Needs: ... still needs more effiecient control interface (var enviroment initialization..etc
############################################################################################################
# Function Declarations
LoadVar();
GetData();
Translate();
WebSVRBAN();
FunctionList();
$Date = localtime();
sub LoadVar {
# configuration variables Loaded here
open(PROC, "proc.conf.txt") || Error("Where is the MOLLENSOFT Configuration FILE");

	while(<PROC>) {
	chomp;
	@allconf = split(/\n/);
	foreach $confline (@allconf) {
	my($var, $set) = split(/=/, $confline);
		$PROC{$var} = $set;
			}
		}
	close(PROC);
}
sub GetData { 
# Standard OLD School HTTP/Get Data
$request = $ENV{'REQUEST_METHOD'};
if($request eq "POST") {
read(STDIN, $input, $ENV{'CONTENT_LENGTH'});
@pairs = split(/&/, $input); }
		elsif ($request eq "GET") {
			@pairs = split(/&/, $ENV{'QUERY_STRING'}); }
				else { Error("Sorry, bad request method!"); }
foreach $pair (@pairs) {
	($name, $value) = split(/=/, $pair);
	$name =~ tr/+/ /;
	$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$value =~ s/<([^>]|\n)*>//g;
  $FORM{$name} = $value;
	    }
foreach( @_ ) {
		 tr/+/ /;
		 s/%(..)/pack("c",hex($1))/ge;
    	}

    	@_;
	}

sub Translate {
$action = $FORM{'action'};
$template = $FORM{'template'};
$usr = $FORM{'usr'};
$pwd = $FORM{'pwd'};
$rid = $FORM{'rid'};
$newpwd = $FORM{'password'};
$newwebserv = $FORM{'webserver'};
$newusr = $FORM{'username'};
$newcgi = $FORM{'cgipath'};
$usrname = $PROC{'username'};
$pword = $PROC{'password'};
$WEB_SERVER = $PROC{'webserver'};
	}

sub WebSVRBAN {
# This ensures Web Server IP Security I hope (based on Sambar Server 4.1 LOCAL Host SYS CALL)
   if($ENV{'HTTP_REFERER'}) {
	if ($ENV{'HTTP_REFERER'} !~ m|https?://([^/]*)$WEB_SERVER|i) {
			$denied = 1;
				 }
			}
	if ($denied) { Error("Sorry, permission denied to Mollensoft RFI Processor"); }
	}
sub FunctionList {
# Determine Which Proc (PROCESS) was requested
if(! $action) { PrintLogIn(); }
	elsif ($action eq "authenticate") {
		Auth(); }
	elsif($action eq "setprefs") {
		SetPrefs(); }
	elsif($action eq "updateprefs") {
		Update(); }
else { Error("Sorry, an unexpected error has occured"); }
	}

sub Update {
#PrintHeader("Update SYS Administrator Preferences for Mollensoft Form Processor");
print"Content-type: text/html \n\n";
print   "<P ALIGN=CENTER>";
print"<BODY BGCOLOR=\"BLACK\" LINK=\"#0000BB\">";
print "<font face=times size=4>\n
	<form action=proc.pl method=post> <input type=hidden name=action value=setprefs>\n
	<table width=700 cellpadding=3 cellspacing=0 border=1>\n
	<tr><td colspan=2 bgcolor=Red><font face=Arial size=5 color=YELLOW>\n
	<strong><center>Mollensoft TSR DBASE Variable Config</center></strong></font></td></tr>\n
	<tr><td><font color=white face=verdana size=4>Root User name:</td><td> <input type=text size=40 name=username value=\"$usrname\"></td></tr>\n
	<tr><td><font color=white face=verdana size=4>Password:</td><td> <input type=text size=40 name=password value=\"$pword\"></td></tr>\n
	<tr><td><font color=white face=verdana size=4>Local Web Server:</td><td><input type=text size=40 name=webserver value=\"$WEB_SERVER\"></td></tr>\n
	<tr><td colspan=2><P ALIGN=CENTER><input type=submit value=\" save changes \"></td></tr></table></form>\n";
print" <FONT SIZE=\"5\"><FONT COLOR=\"RED\">Dont Specify A Webserver IP unless you want to only allow access from that IP Address! ";
print" <br><FONT SIZE=\"5\"><FONT COLOR=\"GREEN\">Courtesy Mollensoft Software 2000 www.mollensoft.com";
	}
sub SetPrefs {
open(Y, ">proc.conf.txt") || Error("Can't find your Mollensoft config. file");
print Y "username=$newusr\n";
print Y "password=$newpwd\n";
print Y "webserver=$newwebserv\n";
	close(Y);
PrintBackEnd();
	}

sub Auth {
	if (! $usrname || ! $pword) {

		PrintHeader("The Keys");
		foreach $key (keys %PROC) {
		print "<font size=2 face=Arial><b>$key</b> : $PROC{$key}<br>\n";
				}
		print "mail server:$SMTP_SERVER, CGI path: $cgipath, 
		admin email: $adminemail, web server: $WEB_SERVER\n";
			exit;
			}
	if($usr eq $usrname && $pwd eq $pword) {
		PrintBackEnd();
			} else { $Date = localtime();
                            Error("Sorry, invalid login <br> <Br> NOTICE: If your ip is detected again you will be locked out of the ACE Intelligence Web SERVER! <br> <br> <font color=red> Logging Hack Attempt at $Date <br> <br></font> BigAL Sends... "); }
	}

sub PrintBackEnd {
$Date = localtime();
# Example of How to Print Your Form very pretty Since CGI.PM is not always pretty!
print "Content-type: text/html\n\n";
print<<"GUT"
<HTML>
 <HEAD>
  <TITLE>MOLLENSOFT</TITLE>
 </HEAD>
 <BODY BGCOLOR="WHITE">
    <P ALIGN=CENTER>
   <FONT SIZE="6"><FONT COLOR="BLACK">Logging Administrator ACCESS <br> To TSR Control PANEL<br>$Date</P>
  <P ALIGN=CENTER>
 <FONT SIZE="6"><FONT COLOR="yellow">
   <A HREF="http:/cgi-bin/tsr.pl">Click Here to View TSR Form</A> <br> <P ALIGN=CENTER><A HREF=proc.pl?action=updateprefs>Click Here to Update Server Variables</A> <br><p ALIGN=CENTER> <A HREF="tsrdbase.pl?action=PrintBackEnd">Click Here to Manage The TSR Database</A></P>
  <P ALIGN=CENTER>
   <CENTER>
  <P ALIGN=CENTER>
   <FONT SIZE="4"><FONT COLOR="ORANGe">Courtesy Mollensoft Freeware 2000 
   <!-- \$MVD\$:spaceretainer() -->&nbsp;</FONT></FONT></P>
  </CENTER><CENTER>
  <H3 ALIGN=CENTER>
   <FONT COLOR="GREEN"><FONT FACE="\&quot;Verdana,Arial,Times"><!-- \$MVD\$:spaceretainer() -->&nbsp;</FONT></FONT>
 </BODY>
</HTML>
GUT
	
}
sub PrintHeader {
print "Content-type: text/html\n\n";
print "<html><head><title>MOLLENSOFT COMPUTER CONSULTING</title></head>\n";
print "<body bgcolor=white>\n";
print "<font face=Arial size=+2>@_</font><p>\n";
		}
sub Error {
PrintHeader("@_");
exit;
	}



