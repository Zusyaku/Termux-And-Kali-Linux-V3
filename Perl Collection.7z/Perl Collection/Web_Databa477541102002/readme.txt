Official Stuff...

Mollensoft Notice.. Script Updated 10 Jan 2002 using Apache Version 1.3.22 and Sambar Server Version 5.2b

This Script is freeware.. you may use it as you wish, we are not responsible for any damage or problems you may experience while using this script...

If you have a need for a custom web database please contact support@mollensoft.com and we will help you for pay in some cases and for free in others (we have not forgotten where we come from)





#########################################



Readme Stuff....


This is an example of a Web Database Using Perl, Complete with secure access and web form input. It was written to enable customers to send computer problems to the Systems Administration Section via Web Posting (in case email fails.. as it usually does). 

This is easy stuff... three simple steps.

1. Copy the following HTML file into your html docs directory...

"perldb.htm"

2. Copy everything else into your http servers "CGI-BIN"
(Make Sure you copy the "tsr" directory into your "CGI-BIN" like
"\cgi-bin\tsr"

In the event of a catastrophic loss there is a backup file in your /tsr directory.

3. Call the "index.htm" file from your web browser and from there you can:
	a. Add Terminal Service Requests (TSR)
	b. Manage The TSR Database 
	c. Setup Access Authentification by IP and/or userid, password

Questions/Suggestions to bigal@mollensoft.com

BigAl Sends....




#########################################