#!c:\faws\perl\bin\perl.exe
#
# This File is the Mollensoft Terminal Service Request Form Generator
#  It uses Perl To Generate HTML in the Old School Format (not using CGI.PM)
#
#  This is of Course Freeware Just Like Perl Itself!! 
#
#  Courtesy Mollensoft Software 2000
#
# FOR MOLLENSOFT... 
# Needs: ... still needs more effiecient control interface (var enviroment initialization..etc
############################################################################################################
open(FILE1, "tsr_num.txt");
$rfinum = <FILE1>;
$rfinumber = $rfinum + 1;
close (FILE1);
open (OUTFILE, ">tsr_num.txt");
print OUTFILE "$rfinumber";
close OUTFILE;
#this is the time/datestamp (mandatory)
$Date = localtime();
print<<end_rfi;
Content-type: text/html 


<HTML>
 <HEAD>
  <TITLE>Template</TITLE>
  
  <DIV ALIGN=LEFT>
  <P ALIGN=LEFT>
   <TABLE WIDTH="620" CELLPADDING="8" CELLSPACING="0" BORDER="0">
    <TR>
     <TD ROWSPAN="2" WIDTH="190" VALIGN=TOP>
     <TD ROWSPAN="2" WIDTH="573" VALIGN=TOP>
      <P ALIGN=CENTER>
       <FONT SIZE="5"><FONT COLOR="BLACK"><FONT FACE="Verdana,Arial,Times New I2"><B>SUBMIT
        TSR</B></FONT></FONT></FONT></P>
      <P ALIGN=CENTER>
       <FONT SIZE="2"><FONT COLOR="BLACK"><FONT FACE="Verdana,Arial,Times New I2">This
        is the Terminal Service Request Form, Please Fill out as completely as Possible.</FONT></FONT></FONT></P>
 <FONT SIZE="2"><FONT COLOR="RED"><FONT FACE="Verdana,Arial,Times New I2"> Please input a COMPLETE Email Address If you want an Email Response</FONT></FONT></FONT></P>
      <FORM ACTION="tsrdbase.pl" METHOD=POST>
                        <CENTER>
          <P ALIGN=CENTER>
           <TABLE CELLPADDING="2" CELLSPACING="1" BORDER="2">
		<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">TSO Number:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="TSR number" VALUE="$rfinumber" SIZE="15" MAXLENGTH="15"></TD>
            </TR>
            	<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submission DTG:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submission DTG" VALUE="$Date" SIZE="50" MAXLENGTH="125"></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submitters Name:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submitters Name" VALUE=" " SIZE="50" MAXLENGTH="125"></TD>
            </TR>
    	<TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submitter EMail Address</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submitter EMail Address" SIZE="50" MAXLENGTH="125"></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Submitter Phone</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <INPUT TYPE=TEXT NAME="Submitter Phone" SIZE="50" MAXLENGTH="125"></TD>
            </TR>
 	        <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT SIZE="2"><FONT FACE="Verdana,Arial,Helvetica,Geneva">Submitters Office:</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <TABLE WIDTH="100%" CELLPADDING="2" CELLSPACING="0" BORDER="0">
                <TR>
                 <TD VALIGN=TOP><DIV ALIGN=LEFT>
                  <P ALIGN=LEFT>
                   <INPUT TYPE=TEXT NAME="Office" SIZE="25" MAXLENGTH="125"></TD>
                </TR>
               </TABLE></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">TSR Request Text:</FONT></FONT></P>
              <P ALIGN=RIGHT>
               <FONT FACE="Verdana,Arial,Helvetica,Geneva"><FONT SIZE="2">Max650chars-</FONT></FONT></TD>
             <TD VALIGN=TOP><DIV ALIGN=LEFT>
              <P ALIGN=LEFT>
               <TEXTAREA NAME="ORIGINAL TSR SUBMISSION" COLS="50" ROWS="10"></TEXTAREA></TD>
            </TR>
            <TR>
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
               &nbsp;</TD>
             <TD VALIGN=TOP><CENTER>
              <P ALIGN=CENTER>
         <INPUT TYPE=SUBMIT NAME=action VALUE="SUBMIT">
             <TD VALIGN=TOP>
              <P ALIGN=RIGHT>
              </TR>
           </TABLE></P>
          </CENTER></FORM>
         <P ALIGN=CENTER>
     </TD>
    </TR>
    <TR>
    </TR>
   </TABLE>
 </BODY>
</HTML>
end_rfi
print <<EOF;
EOF


