#!H:\axeserver\perl\perl.exe
# Mollensoft Network Status ENGINE
#
# This is used to on win32 platforms to display Network Status via Web Server.
#
# Dependencies : CGI.pm 
# Creation: 23 FEB 2000
# Last Edit: 21 APR 2001
#
# 
#
############################################################################################################
use CGI qw(:all);

print header, start_html(" "), h6(" "); print h2(" ");
if (param()) {

	open(NETSTAT, ">netstat.proc");
	my $switch = param("switch");
	if ($switch eq "all connections") {
	$switchoutput = `netstat -a`;
	print NETSTAT "$switchoutput";	
	close(NETSTAT);	
unless (open(MYFILE, "netstat.proc")) {
	die ("cannot open input file file1\n");
	}
$line = <MYFILE>;
while ($line ne "") {
	$line =~ s/Active Routes/\<font color=blue face=Arial \>Active Routes \<\/font\>/g;
	$line =~ s/Network/\<font color=red face=Arial size+1\>Network\<\/font\>/g;
	$line =~ s/Gateway/\<font color=blue face=Arial \>Gateway\<\/font\>/g;
	print "<tr><td><p><font face=Verdana,Arial,Times New I2>$line</td></tr>";
	$line = <MYFILE>;
}

}

elsif ($switch eq "routing tables only") {
	$switchoutput = `netstat -r`;
	print NETSTAT "$switchoutput";	
	close(NETSTAT);
unless (open(MYFILE, "netstat.proc")) {
	die ("cannot open input file file1\n");
	}
$line = <MYFILE>;
while ($line ne "") {
	$line =~ s/Active Routes/\<font color=blue face=Arial \>Active Routes \<\/font\>/g;
	$line =~ s/Network/\<font color=red face=Arial size+1\>Network\<\/font\>/g;
	$line =~ s/Gateway/\<font color=blue face=Arial \>Gateway\<\/font\>/g;
	print "<tr><td><p><font face=Verdana,Arial,Times New I2>$line</td></tr>";
	$line = <MYFILE>;
}
}

elsif ($switch eq "ethernet statistics") {
	$switchoutput = `netstat -e`;
	print NETSTAT "$switchoutput";	
	close(NETSTAT);
unless (open(MYFILE, "netstat.proc")) {
	die ("cannot open input file file1\n");
	}
$line = <MYFILE>;
while ($line ne "") {
	$line =~ s/Interface Statistics/\<font color=blue face=Arial \>Active Connections \<\/font\>/g;
	$line =~ s/Unknown/\<font color=red face=Arial size+1\>Unknown\<\/font\>/g;
	$line =~ s/Received /\<font color=red face=Arial size+1\>\tReceived \<\/font\>/g;
	$line =~ s/Sent /\<font color=red face=Arial size+1\>Sent \<\/font\>/g;
	print "<tr><td><p><font face=Verdana,Arial,Times New I2>$line</td></tr>";
	$line = <MYFILE>;
}
}

 	} else { 

#FORM Starts Here$$$$$$$$$$$$$$$$$$$$$$<<<<<>>>>>>>>

		print start_form() ;
print <<EOFHTML;
    <TABLE WIDTH="100%" HEIGHT="90">
    <TR><TD BGCOLOR="lightgreen"><B><FONT COLOR="black" SIZE="7">NETWORK STATUS UTILITY</FONT></B></TD></TR>
    </TABLE>
EOFHTML
	print h4("Select A Network Attribute To Check, then Press \"Check Network\"");
  	 print popup_menu('switch',
                            ['all connections','routing tables only','ethernet statistics'],
                            'all');
	print h3(submit("CHECK NETWORK"));
		print end_form(),; 		
print <<EOFHTML;
    <TABLE WIDTH="100%" HEIGHT="40">
    <TR><TD BGCOLOR="#ffbc2a"><B>Mollensoft Quick Fact... Do you know what \"DIMM\" stands for\?     \(Answer....\"Dual Inline Memory Module.\"\)</B></TD></TR>
    </TABLE>
<TABLE WIDTH="100%" HEIGHT="20">
<TR><TD BGCOLOR="yellow"><FONT COLOR="black" SIZE="-2">2001 Mollensoft FREEWARE <A HREF="http://www.mollensoft.com"><FONT COLOR=yellow">http://www.mollensoft.com</FONT></A></FONT></TD></TR>
</TABLE>

EOFHTML


		}

print end_html








