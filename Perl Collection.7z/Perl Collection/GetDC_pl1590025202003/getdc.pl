
# ======================================================================
#
# FILE NAME: Getdc.pl 
#
# AUTHOR: Christopher Irwin, BankofAmerica - Charlotte, NC
#         Email: Christopher.Irwin@bankofamerica.com
#         Phone: 704-388-0890
#
# DATE CREATED  : 05.05.2003  
# DATE LAST MODIFIED : 05.20.2003
#
# PURPOSE: Get a list of all DC's in a domain
# ======================================================================
use Win32::Registry;
 
# Get domain you want to lookup
print "Enter the FQDN (child.root.com) for which you want to find DC's:\n";
$DOMAIN = <stdin>;

# Going to open NSlookup and get needed info then put to file
$PROG = "| nslookup > nslookup.txt";                                                                 
open (LOOKUP, "$PROG") or die "couldn't open nslookup";
print LOOKUP "set type=srv\n";
print LOOKUP "_ldap._tcp.$DOMAIN\n";
print LOOKUP "exit\n";

# Close process
close(LOOKUP) or die "Can't close program: $!\n";
 
# Create DCLIST and open NSLOOKUP for reading
chomp $DOMAIN;
open (INPUT, 'c:\nslookup.txt') or die "Couldn't open file: $!\n";


# Pull out DC names
$i = 0;
while(<INPUT>){
   chomp;
   if(/svr hostname   = .*/) {
      if(/= .*/){
      $SRVNAME[$i] = "$&\n";
      $i++;
      }
   }
}

close(INPUT);

# Remove NSLOOKUP file
$DELFILE = 'c:\nslookup.txt';
unlink ($DELFILE);


# Check for Excel IF it is installed create an .xls file ELSE create a .log file

my $Intpath = "SOFTWARE\\MICROSOFT\\Office\\Excel";
my ($Inthkey, $Intkey, @Intkey_list);

if ($HKEY_LOCAL_MACHINE->Open($Intpath,$Inthkey)){

    open (OUTPUT, ">c:\\DCLIST.$DOMAIN.xls") or die "Couldn't open file: $!\n";
}

    else {
               open (OUTPUT, ">c:\\DCLIST.$DOMAIN.log") or die "Couldn't open file: $!\n";
       
       }

# Split out "=" so that only DC names are left
@SRVNAMESPLIT = (split /= /, "@SRVNAME");

# Sort in ASCIIbetical order
@SORTEDDCLIST = sort(@SRVNAMESPLIT);

#Print results to file and close.
print OUTPUT "@SORTEDDCLIST";
close (OUTPUT);
