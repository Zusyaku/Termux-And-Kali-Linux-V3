#####################################
# Image Gallery 2.5
# Created by Aaron Anderson
# sulfericacid@qwest.net
# http://sulfericacid.perlmonk.org
#####################################

Dedication: This script is dedicated to the love of my life, Alberta226.  With out her inspiring my getting into graphic design with Photoshop, this script never would have happened.  If I wasn't so interested in graphic design because of her, this script would not be available to any of you.  Thank you Alby *hugs*.



Script overview:
-------------------------
Complete image gallery for your website including web-based image uploads and image displays of unlimited amounts of images.


Requirements:
-------------------------
Image::Info
Image::Magick


Script Features/Ehancements from previous versions.
-------------------------------------------------------
1) Script was rewritten from grounds up using smaller database keys producing smaller files and possibly quicker access times.
2) Web-based image uploader requesting image title and description/caption to be listed among the image when it's viewed.
2a) This is now password protected, the earlier versions were not.
3) Full admin panel allowing you to view the thumbnail information, alter the image title/description and remove images on the fly.
3a) Admin panel not available on previous versions.
4) Automatic thumbnail creation installed.  This was not used on the last version, in the previous versions the images were pre-sized by HTML rather than actual thumbnails.  Loading time has been cut in more than half because of this.
5) GUI installed.  Previous version used popup windows to display images.
5a) GUI has back, forward and index buttons and there are two views.  Gallery View which shows up to 20 thumbnails per page and an Image Viewer which displays one image at a time with the image information. Image Viewer uses the back/forward/index buttons.
6) Advanced thumbnail checker.  If an thumbnail can not be found, the script tests them each time the script is run and will load a pre-set 'thumbnail not available' image.  No more broken images.
6a) The thumbnail not available image is customizable by you.



Files:
--------------------
admin.pl         -- Admin file; remove/alter image information
gallery25.pl     -- Public image viewer of entire gallery
uploadv25.pl     -- Web-based image uploader to add images to your gallery
header.txt       -- Add the header portion of your site to create site/script uniformity
footer.txt       -- Add the footer portion of your site to create site/script uniformity
nothumb.png      -- Thumbnail to be used incase a thumbnail cannot be loaded, inside thumbnails folder
menu             -- Folder for menu button icons
thumbnails       -- Folder for your thumbnails
back.gif         -- back button for GUI, inside menu
forward.gif      -- forward button for GUI, inside menu
index.gif        -- index button for GUI, inside menu



Installation:
--------------------
1) Make a new directory inside your cgi-bin (if required, some servers allow scripts to be run anywhere) and name it imagegallery or gallery or anything you want, doesn't matter.
2) Transfer all files and folders into this directory and chmod each of them to 755, chmod the thumbnails directory to 777.
2a) If you want, you can move the nothumb.png into a folder called thumbnails.  This is what I did.
3) Create the folder images and chmod to 777.
3a) If you don't want people to access your image folders directly, attach a blank index.html file into both images and thumbnails directories and people won't be able to access them.

In the end, the result should be something like 
www.yourpage.com/cgi-bin/imagegallery
www.yourpage.com/cgi-bin/imagegallery/images/
www.yourpage.com/cgi-bin/imagegallery/thumbnails/
www.yourpage.com/cgi-bin/imagegallery/menu



Configuration:
---------------------
You may need to change the shebang line to the location of perl on your server for each of these files.


>>>ADMIN.PL

(for example purposes, my gallery was setup in the folder imagegallery.  My url looks like www.mypage.com/imagegallery/ then with the images and thumbnails inside this folder.)

# partial file path to image directory (not including home)
my $imagedir = "/imagegallery/images/";

# FULL file path to thumbnails directory (including home/root directory)
my $fullimagedir = "/home/username/public_html/imagegallery/images";

# FULL URL to thumbnails directory
my $thumbsurl = "http://www.yourpage.com/imagegallery/thumbnails";

# partial file path to thumbnails directory (not including home/root directory)
my $thumbsdir = "/imagegallery/thumbnails";

# FULL file path to thumbnails directory (including home/root directory)
my $fullthumbsdir = "/home/username/public_html/imagegallery/thumbnails";

# The name of this script
my $script = "admin.pl";

# No Thumbs image -- One has been set by default, but you can create your own.
my $nothumb = "nothumb.png";

# Adminstrator password
my $pw = "password";


>>>GALLERY25.pl

(for example purposes, my gallery was setup in the folder imagegallery.  My url looks like www.mypage.com/imagegallery/ then with the images and thumbnails inside this folder.)

# full url path to image directory
my $imagedir = "http://www.yourpage.com/imagegallery/images";

# full url path to thumbnails directory
my $thumbsdir = "http://www.yourpage.com/imagegallery/thumbnails";

# partial url to this script (do not include home directory)
my $script = "/imagegallery/galleryv25.pl";

# partial url to menu directory (do not include home directory)
my $menu = "/imagegallery/menu";

# full file path to thumbnails directory
my $dir = "/home/username/public_html/imagegallery/thumbnails";

# index url -- The full url of this script
my $indexurl = "http://www.yourpage.com/imagegallery/galleryv25.pl";


>>>UPLOAD25.pl

(for example purposes, my gallery was setup in the folder imagegallery.  My url looks like www.mypage.com/imagegallery/ then with the images and thumbnails inside this folder.)

# full file path to image directory (cannot end in an end slash /)
my $uploaddir = "/home/username/public_html/imagegallery/images";

# full url to upload directory (cannot include filename or an end slash /)
my $url = "http://www.yourpage.com/imagegallery/images";

# full url to the thumbnails directory (cannot include filename or an end slash /)
my $thumbs = "http://www.yourpage.com/imagegallery/thumbnails";

# full file path to thumbnails directory (cannot end in an end slash /)
my $thumbdir = "/home/username/public_html/imagegallery/thumbnails";

# Adminstrator password
my $pw = "password";


>>> HEADER.TXT & FOOTER.TXT
Add the HTML source code of your source code accordingly so this script gets built into your layout.




Additonal information:
-------------------------------------
1) Do not attempt to upload animated gif files, this is not yet supported and will not create desired/working thumbnails
2) Though it's not required, it would be easier if you used the same admin password for both your admin.pl and upload25.pl files.
3) Just because a Thumbnail Unavailable image appears, it doesn't mean the image isn't uploaded.  You may accidently delete some thumbnails or one might not get set, but the images may still be working in Image View mode.
4) Do not upload images with a period in the file name other than the .extention.


Usage:
-------------------------------------
Install the script and run your upload25.pl file to upload images to your gallery

Display the URL to your gallery25.pl file on your site to view your gallery

Run admin.pl to edit image information or remove it from your gallery