Title: Image gallery 2.5
Description: Upload images through the web and instally create your very own image gallery! Thumbnails, full password proteced admin panel for image information editing or image removal, advanced thumbnail checker ensuring broken images aren't displayed on screen.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=572&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
