#!/usr/bin/perl

use strict;
use warnings;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);

use POSIX;

use DB_File;

####################################
# Configurations begin here
####################################

# partial file path to image directory (not including home)
my $imagedir = "/imagegallery/images/";

# FULL file path to thumbnails directory (including home/root directory)
my $fullimagedir = "/home/username/public_html/imagegallery/images";

# FULL URL to thumbnails directory
my $thumbsurl = "http://www.yourpage.com/imagegallery/thumbnails";

# partial file path to thumbnails directory (not including home/root directory)
my $thumbsdir = "/imagegallery/thumbnails";

# FULL file path to thumbnails directory (including home/root directory)
my $fullthumbsdir = "/home/username/public_html/imagegallery/thumbnails";

# The name of this script
my $script = "admin.pl";

# No Thumbs image -- One has been set by default, but you can create your own.
my $nothumb = "nothumb.png";

# Adminstrator password
my $pw = "password";

####################################
# Do not edit below this line
####################################

my $cookiename = "gal25";
my $pass= param('pass');

my $tasty = cookie($cookiename);
my %upload;
my $upload = "imagegallery2.db";

tie %upload, "DB_File", "$upload", O_CREAT | O_RDWR, 0644, $DB_BTREE
  or die "Cannot open file 'upload': $!\n";




###############################################################################################################
# COOKIE CHECKING
###############################################################################################################
# First check if we saved a cookie last time
if($tasty)
{
print header(-expires=>'now'),
start_html("Image Gallery Control Panel");

&processing;

print end_html;
exit;
}
########################################################################################################
# Password checking
########################################################################################################
unless ($pass eq $pw)
    {
    print header(-expires=>'now'), start_html("Login");

print <<"FORM";
<form action="" method="POST">
<table width="296" border="2" align="center" cellpadding="2" cellspacing="0" bordercolor="#0033FF">
  <tr>
    <td width="286"><table width="100%" height="100%" border="0" align="center" cellpadding="2">
      <tr bgcolor="#0099FF">
        <td colspan="2"><div align="center">Administrator Login </div></td>
        </tr>
      <tr>
        <td width="65">Password:</td>
        <td width="196"><input name="pass" type="password" id="pass"></td>
      </tr>
      <tr>
        <td colspan="2"><div align="center">
          <input type="submit" name="Submit" value="Submit">
        </div></td>
        </tr>
    </table>
      <div align="center"></div>
      <div align="center"></div>
    <div align="center"></div></td>
  </tr>
</table>
</form>

FORM

    if (param())
    {
    if ($pass ne $pw) 
    {
    
    print "<b>Wrong password!</b>";
    exit;
    }
    }
    exit;
    } 

########################################################################################################
# Cookie setting
########################################################################################################
my $cookie = cookie(
    -NAME=> $cookiename,
    -VALUE=> $pass,
    #-PATH=> "/", # put in script location if you want the cookie to only strictly used on one page
    #-EXPIRES => "+1y", # Options: #m, #h, #s, #y
    );
    print header(-COOKIE => $cookie, -expires=>'now');
    print start_html("Image Gallery Admin Panel");

&processing;


sub processing
{
my %upload;
my $upload = "imagegallery2.db";

tie %upload, "DB_File", "$upload", O_CREAT | O_RDWR, 0644, $DB_BTREE
  or die "Cannot open file 'upload': $!\n";

###
# Setup our params
###
my $edit = url_param('edit');
my $del  = url_param('rem');

####################
# Check for DELETE call
####################
if ($del ne "")
{
  if (exists $upload{$del})
  {
    my ( $filename, $title, $comments, $width, $height, $count ) = split ( /::/, $upload{$del} );
    
    ###
    # Rewriting $filename to a .png
    ###
    my $thumbs = $filename;
    $thumbs    =~ m/(.*)\.(.*)/;
    $thumbs    = "$1.png";

    ###
    # Deleting files from both image folders
    ###
    delete $upload{$del};
    if (-r "$fullthumbsdir/$thumbs") {
    unlink "$fullimagedir/$filename" or die "Cannot delete image: $!";
    unlink "$fullthumbsdir/$thumbs";
}
    print "<center><font color=blue>Image removed.</font></center>";  


my $num = -1;
foreach (sort { $a<=>$b } keys %upload)
{
     $num++;
     my ( $filename2, $title2, $comments2, $width2, $height2, $count2 ) = split ( /::/, $upload{$_} );
     my $joined = join("::", $filename2, $title2, $comments2, $width2, $height2, $count2);
     $upload{$num} = $joined;
}

delete $upload{++$num};

  }
  else {
     print "<center><font color=red>ERROR!  Image does not exist.</font></center>";
  }
}

####################
# Check for submit for update call
####################
if (param('Submit'))
{
 my $newcomments = param('comments');
 my $newtitle    = param('title');
 my $id        = param('id');
 my ( $filename, $title, $comments, $width, $height, $count ) = split ( /::/, $upload{$id} );
 my $info = join("::", $filename, $newtitle, $newcomments, $width, $height, $count );

 $upload{$id} = $info;
 print "<center><font color=blue>Information updated.</font></center>";
}

####################
# Check for EDIT call
####################
if ($edit ne "")
{
  if (exists $upload{$edit})
  {
    &image_details;
  }
  else
  {
    print "<center><font color=red>Image not found</font></center><br>";
   }
}
  



#############################
#  
# This script goes out to the highest rank PS guru and the keeper of my heart, my life, my thoughts.. Alberta226.
# Before you, Perl was my life.  But it wasn't until after I met you that I realized that before you, I didn't have a life..
# You've given me the world, the skies and the stars.  I love you *hugs*
#
#############################






##########################################
### Begin printing out the actual images
##########################################
my $page = url_param('page');
$page ||= 1; # if no url_param exists, make it 1


my $first = ($page - 1) * 20;
my $last  = $first + 19;


my $count = "0";

foreach (keys %upload)
{
  $count++;
}

if ($count eq "0") {
print "<center><h2><font color=red>Directory is currently empty.</font></h2></center>";
}

my $counter = "0";

print "<center><table>";
for (grep defined($_), (reverse sort { $a <=> $b } keys %upload)[$first .. $last]) {

    my ( $filename, $title, $comments, $width, $height, $count ) = split ( /::/, $upload{$_} );

    print " <tr>" unless ( $counter % 5 );

my $thumbs = $filename;
$thumbs    =~ m/(.*)\.(.*)/;
$thumbs    = "$1.png";
$title     =~ s/(\S{11})/$1 /g;
$comments      =~ s/(\S{11})/$1 /g;



$width  = $width +20;
$height = $height + 20;

    print qq(<td valign="top" width="110" height="110" colspan="2">);
if (-r "$fullthumbsdir/$thumbs") {
    print qq(<a href="$script?image=$_"><img src="$thumbsdir/$thumbs" height="100" width="100"></a>)
    }
else
    {
    print qq( <a href="$script?image=$_"><img src="$thumbsurl/nothumb.png" height="100" width="100"></a>);
    }

    print <<"ALL";
    <br>
    <font size=2><center>[<a href="$script?edit=$_">edit</a> | <a href="$script?rem=$_">rem</a>]</center></font>
    </td>

ALL

unless ( ++$counter % 5 ) {
        print "</tr>\n";
    }
}
print "</table></center>\n";

#######################
# Print links to extra pages
#######################
print "<center><table><td>";

my @keys  = sort keys %upload;
my $group = 0;

while (my @group = splice(@keys, 0, 20)) {

  $group++;


my $url = "$script";
  print "<a href=\"$url?page=$group\">Page: $group</a>|";

}

  print "</td></table></center>";


##########################
# Print and parse the edit form and functions
##########################

sub image_details
{
my ( $filename, $title, $comments, $width, $height, $count ) = split ( /::/, $upload{$edit} );
my $thumbs1 = $filename;
$thumbs1    =~ m/([a-zA-Z0-9]+)\.()/;
$thumbs1    = "$1.png";

   print <<"ALL";
<form action="$script" method="POST">
<center><table width="385" border="1" cellpadding="3" cellspacing="0" bordercolor="#0000FF">
  <tr bgcolor="#CCCCCC">
    <td colspan="3"><b>Edit Image:</b></td>
  </tr>
  <tr>
    <td width="64">filename:</td>
    <td width="205">$filename</td>
ALL

if (-r "$fullthumbsdir/$thumbs1") {
    print qq(<td width="90" rowspan="4"><img src="$thumbsdir/$thumbs1" width="100" height="100"></td>)
    }
else
    {
    print qq(<td width="90" rowspan="4"><img src="$thumbsurl/$nothumb" width="100" height="100"></td>);
    }

print <<"ALL";
  </tr>
  <tr>
    <td>count:</td>
    <td>$count</td>
  </tr>
  <tr>
    <td>title:</td>
    <td><input name="title" type="text" value="$title" size="30"></td>
  </tr>
  <tr>
    <td>comments:</td>
    <td><textarea name="comments" cols="30" rows="5">$comments</textarea></td>
  </tr>
  <tr bgcolor="#CCCCCC">
    <td colspan="3"><div align="center">
      <input type="hidden" name="id" value="$edit">
      <input type="submit" name="Submit" value="Submit">
    </div></td>
  </tr>
</table>
</form>
</center>
ALL

}
}
######################## SUB ENDS HERE


print end_html;

