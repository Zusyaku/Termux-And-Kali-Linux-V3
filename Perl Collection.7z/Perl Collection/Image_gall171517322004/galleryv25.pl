#!/usr/bin/perl -w

use warnings;
use CGI qw/:standard/;
use CGI::Carp qw(fatalsToBrowser);
use strict;

use POSIX;

use DB_File;

my %upload;
my $upload = "imagegallery2.db";

####################################
# Configurations begin here
####################################

# full url path to image directory
my $imagedir = "http://www.yourpage.com/imagegallery/images";

# full url path to thumbnails directory
my $thumbsdir = "http://www.yourpage.com/imagegallery/thumbnails";

# partial url to this script (do not include home directory)
my $script = "/imagegallery/galleryv25.pl";

# partial url to menu directory (do not include home directory)
my $menu = "/imagegallery/menu";

# full file path to thumbnails directory
my $dir = "/home/username/public_html/imagegallery/thumbnails";

# index url -- The full url of this script
my $indexurl = "http://www.yourpage.com/imagegallery/galleryv25.pl";

####################################
# Do not edit below this line
####################################

print header;

open(HEADER, "< header.txt") or die "Cannot open file header.txt for reading: $!";
while(<HEADER>)
{
  print "$_\n";
}
close(HEADER);

tie %upload, "DB_File", "$upload", O_CREAT | O_RDWR, 0644, $DB_BTREE
  or die "Cannot open file 'upload': $!\n";


my $id = url_param('image');


my $page = url_param('page');
$page ||= 1; # if no url_param exists, make it 1


my $first = ($page - 1) * 20;
my $last  = $first + 19;

if ($id ne "")
{
  if (exists $upload{$id})
  {
     my ( $filename, $title, $desc, $width, $height, $count) = split ( /::/, $upload{$id} );
     $count++;
     
     my $info = join("::", $filename, $title, $desc, $width, $height, $count);
     $upload{$id} = $info;

###########
# Set the back and forward buttons
###########

print <<"MENU";
<center><table width="50%" border="1" cellpadding="3" cellspacing="0" bordercolor="#0000CC">
<tr bgcolor="#CCCCCC"><td>
<center>

MENU

if ($id >= 1) {
my $forwardid = $id - 1;

print qq(<a href="$script?image=$forwardid"><img src="$menu/back.gif" alt="go back" border="0"></a>&nbsp;&nbsp;&nbsp);
}
else{
}

my $lastimage = "0";
foreach (keys %upload) {
$lastimage++;
}

print qq(<a href="$indexurl"><img src="$menu/index.gif" alt="index" border="0"></a>&nbsp;&nbsp;&nbsp);

my $lastimage = $lastimage - 1; # for forward button

if($id < "$lastimage") {
my $backid = $id + 1;

print qq(<a href="$script?image=$backid"><img src="$menu/forward.gif" alt="go forward" border="0"></a>&nbsp;&nbsp;&nbsp);
} 
else {
}

print <<"MENU";
</center>
</td></tr>
</table></center>

MENU

     print "<center><table width=\"$width\" height=\"$height\" border=0 cellpading=3 cellspacing=0>\n";
     print "<tr><td><img src=\"$imagedir/$filename\" width=\"$width\" height=\"$height\" alt=\"$filename\"></td></tr></table></center>\n";

     print <<"ALL";
       <center>
       <table width="50%" border="1" cellpadding="3" cellspacing="0" bordercolor="#0000CC">
       <tr bgcolor="#CCCCCC">
       <td colspan="2"><strong><font face="Courier New, Courier, mono">Image information: </font></strong></td>
       </tr>
       <tr bgcolor="#FFFFFF">
       <td>Filename:</td>
       <td>$filename&nbsp;</td>
       </tr>
       <tr bgcolor="#FFFFFF">
       <td>Title:</td>
       <td>$title&nbsp;</td>
       </tr>
       <tr bgcolor="#FFFFFF">
       <td>Dimensions</td>
       <td>$width x $height </td>
       </tr>
       <tr bgcolor="#FFFFFF">
       <td>Description:&nbsp;</td>
       <td>$desc &nbsp;</td>
      </tr>
      </table>
      </center>
ALL

     print end_html;
   }
   else {
     print "<font color=red>ERROR!  Image cannot be found.  Process denied.</font>";
   } }
else {

print "<center><table>\n";

my $counter = 0;

for (grep defined($_), (reverse sort { $a <=> $b } keys %upload)[$first .. $last]) {

    my ( $filename, $title, $desc, $width, $height, $count ) = split ( /::/, $upload{$_} );
    $count || 0;

    print " <tr>" unless ( $counter % 5 );

my $thumbs = $filename;
$thumbs    =~ m/(.*)\.(.*)/;
$thumbs    = "$1.png";
$title     =~ s/(\S{11})/$1 /g;
$desc      =~ s/(\S{11})/$1 /g;

$width  = $width +20;
$height = $height + 20;

    print qq(<td valign="top" width="115" height="110" colspan="2">);
        if (-r "$dir/$thumbs") {
            print qq(<a href="$script?image=$_"><img src="$thumbsdir/$thumbs" height="100" width="100"></a>);
           }
         else {
            print qq(<a href="$script?image=$_"><img src=\"$thumbsdir/nothumb.png"></a>);
         }
    print <<"ALL";
    <br>
    <font size=2><b>title: </b>$title</font>
    <br>
    <b><font size=2>views: </b>$count</font>
    </td>

ALL

unless ( ++$counter % 5 ) {
        print "</tr>\n";
    }
}
print "</table></center>\n";




print "<center><table><td>";

my @keys  = sort keys %upload;
my $group = 0;

while (my @group = splice(@keys, 0, 20)) {

  $group++;


my $url = "$script";
  print "<a href=\"$url?page=$group\">Page: $group</a> | ";

}

  print "</td></table></center>";





open(FOOTER, "< footer.txt") or die "Cannot open file footer.txt for reading: $!";
while(<FOOTER>)
{
  print "$_\n";
}
close(FOOTER);

}