#!/usr/bin/perl -w

use CGI::Carp qw(fatalsToBrowser);

use warnings;
use CGI qw/:standard/;

use POSIX;
use DB_File;
use Image::Magick;

##################################
# Configurations start here
##################################
# required if you need to install and link to Image::Info or Image::Magic
use lib "";


# full file path to image directory (cannot end in an end slash /)
my $uploaddir = "/home/username/public_html/imagegallery/images";

# full url to upload directory (cannot include filename or an end slash /)
my $url = "http://www.yourpage.com/imagegallery/images";

# full url to the thumbnails directory (cannot include filename or an end slash /)
my $thumbs = "http://www.yourpage.com/imagegallery/thumbnails";

# full file path to thumbnails directory (cannot end in an end slash /)
my $thumbdir = "/home/username/public_html/imagegallery/thumbnails";

# Adminstrator password
my $pw = "password";

##################################
# Do not edit below this line
##################################

my $cookiename = "gal25";
my $pass= param('pass');


my $tasty = cookie($cookiename);



sub processing 
{

my %upload;
my $upload = "imagegallery2.db";

tie %upload, "DB_File", "$upload", O_CREAT|O_RDWR, 0644, $DB_BTREE
	or die "Cannot open file 'upload': $!\n";

my $mode = 0755;

my $title1 = param("title1");
my $title2 = param("title2");
my $title3 = param("title3");
my $title4 = param("title4");

my $comments1 = param("comments1");
my $comments2 = param("comments2");
my $comments3 = param("comments3");
my $comments4 = param("comments4");

print <<"ALL";

<center>Upload formats allowed: jpg, gif, bmp, png, tiff<br><form method="post" action="" enctype="multipart/form-data">
<table bgcolor="D3D3D3" border="1" cellspacing="0" cellpadding="0" width="600"><tr><td bgcolor="000080"><center><b><font color=white>IMAGE 1</b>
</center></td> 
<td bgcolor="000080"><center ><b><font color=white>IMAGE 2</b>
</center></td> 
<tr><td>Title: </td> <td>Title: </td> <tr><td><input name="title1" type="text" value="$title1"  size="50" maxlength="400" /> 
<td><input name="title2" type="text" value="$title2"  size="50" maxlength="400" /> 
<tr><td>Comments: </td> <td>Comments: </td> <tr><td><input name="comments1" type="text" value="$comments1"  size="50" maxlength="400" /> 
<td><input name="comments2" type="text" value="$comments2"  size="50" maxlength="400" /> 
<tr><td>Upload: </td> <td>Upload: </td> <tr><td><input type="file" name="upload1"  size="50" maxlength="400" /> <td><input type="file" name="upload2"  size="50" maxlength="400" /> <tr><td bgcolor="000080"><center><b><font color=white>IMAGE 3</b>
</center></td> 
<td bgcolor="000080"><center ><b><font color=white>IMAGE 4</b>
</center></td> 
<tr><td>Title: </td> <td>Title: </td> <tr><td><input name="title3" type="text" value="$title3"  size="50" maxlength="400" /> 
<td><input name="title4" type="text" value="$title4"  size="50" maxlength="400" /> 
<tr><td>Comments: </td> <td>Comments: </td> <tr><td><input name="comments3" type="text" value="$comments3"  size="50" maxlength="400" /> 
<td><input name="comments4" type="text" value="$comments4"  size="50" maxlength="400" /> 
<tr><td>Upload: </td> <td>Upload: </td> <tr><td><input type="file" name="upload3"  size="50" maxlength="400" /> <td><input type="file" name="upload4"  size="50" maxlength="400" /> <tr><td colspan="2" /><div align="center">
  <input type="submit" name="button" value="submit" />
</div>
 </tr></td></td></tr></tr></td></td></tr></tr></td></td></tr></tr></tr></td></td></tr>
 </tr></td></td></tr></tr></td></td></tr></tr></tr></table>
<div></div></form></center>

ALL

  hr;

print "</center>";

if ( param('upload1') ) {

my $num = 1;

&dirty_work($num);

    print "<br>";
    print "<center><font color=blue>Files were uploaded and created successfully</font></center><br>";
}

if ( param('upload2') ) {

my $num = 2;

&dirty_work($num);
}

if ( param('upload3') ) {

my $num = 3;

&dirty_work($num);
}

if ( param('upload4') ) {

my $num = 4;
&dirty_work($num);
}

sub dirty_work {
my $num = shift;
    # take form data
    my $remotefile = param("upload$num");
# make new variable to prevent overwriting of form data
    my $filename = $remotefile;
    
    my $title = param("title$num");
    $title =~ s/&/&\#38/g;
    my $comments = param("comments$num");
    $comments =~ s/&/&\#38/g;
    # remove all directories in the file name path
    $filename =~ s/^.*[\\\/]//;

##################################
# Check for duplicate filenames
##################################

my $checkcount = "0";
foreach (keys %upload)
{
$checkcount++;
}

$filename =~ m/(.*)\.(.*)/;
$filename = "$1$checkcount.$2";
$localfile = $filename;

    my $localfile = "$uploaddir/$filename";
    my $type = uploadInfo($remotefile)->{'Content-Type'};
    unless ( $type eq 'image/pjpeg' || $type eq 'image/gif' || $type eq 'image/bmp') {
        print "Wrong!  This is not a supported file type.";
        exit;
}


    # open a new file and transfer bit by bit from what's in the buffer
    open( SAVED, ">>$localfile" );    # || die $!;
    while ( $bytesread = read( $remotefile, $buffer, 1024 ) ) {
        print SAVED $buffer;
    }
    close SAVED;

    chmod $mode, "$localfile";        # or die "can't chmod: $!";

    use Image::Info qw(image_info dim);
  
    # assigning info to a filename (better be an image)
    my $info = image_info("$localfile");

   # if for any reason we can't open the file, this error trap should pick it up
    if ( my $error = $info->{error} ) {
        #die "Can't parse image info: $error\n";
    }
    # unommit next line if you want to use/post the image's color
    #my $color = $info->{color_type};

    # declaring the width and heighth of your image
    my ( $w, $h ) = dim($info);

########################################
# Write our stuff to file
########################################

my $keynum = "0";
foreach (keys %upload) {
  $keynum++;
}

my $count = "0";
my $combo = join("::", $filename, $title, $comments, $w, $h, $count);
$upload{$keynum} = "$combo";

##########
# Image Magick goodies
##########
my ($image, $x);

$image=Image::Magick->new;
$x = $image->Read($localfile);
warn "$x" if "$x";

$x = $image->Resize(width=>100, height=>100);

$localfile = $filename;
$localfile =~ m/(.*)\.(.*)/;
$newfilename = "$thumbdir/$1.png";
$x = $image->Write($newfilename);

warn "$x" if "$x";

}

} ## end processing sub here

























###############################################################################################################
# COOKIE CHECKING
###############################################################################################################
# First check if we saved a cookie last time
if($tasty)
{
print header(-expires=>'now'),
start_html("Image Gallery Control Panel");

&processing;

print end_html;
exit;
}
########################################################################################################
# Password checking
########################################################################################################
unless ($pass eq $pw)
    {
    print header(-expires=>'now'), start_html("Login");


print <<"FORM";
<form action="" method="POST">
<table width="296" border="2" align="center" cellpadding="2" cellspacing="0" bordercolor="#0033FF">
  <tr>
    <td width="286"><table width="100%" height="100%" border="0" align="center" cellpadding="2">
      <tr bgcolor="#0099FF">
        <td colspan="2"><div align="center">Administrator Login </div></td>
        </tr>
      <tr>
        <td width="65">Password:</td>
        <td width="196"><input name="pass" type="password" id="pass"></td>
      </tr>
      <tr>
        <td colspan="2"><div align="center">
          <input type="submit" name="Submit" value="Submit">
        </div></td>
        </tr>
    </table>
      <div align="center"></div>
      <div align="center"></div>
    <div align="center"></div></td>
  </tr>
</table>
</form>

FORM


    if (param())
    {
    if ($pass ne $pw) 
    {
    
    print "<b>Wrong password!</b>";
    exit;
    }
    #exit;
    }
    exit;
    } 

########################################################################################################
# Cookie setting
########################################################################################################
my $cookie = cookie(
    -NAME=> $cookiename,
    -VALUE=> $pass,
    );
    print header(-COOKIE => $cookie, -expires=>'now');
    print start_html("Image Gallery V2 Upload Form");

&processing;


print end_html;
