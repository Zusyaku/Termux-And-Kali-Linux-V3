#!C:\Perl\bin\perl.exe

###################################################################
# Jason's Web Page Builder, This is the first Edition and it very # 
# basic. I just wanted to get the basic principle working before  #
# adding any special features like table editors. The following   #
# version allows the user to give their own page a title, select  #
# the bgcolor, font color, add some content and create some links #
# Email any questions to jason_myerscough@hotmail.com             #
###################################################################

use CGI qw(:standard);

####################-Delcare my private variables

my($title, $bgcolor, $tcolor, @content, $link1, $link2, $link3, $link4, $name1, $name2, $name3, $name4, @linkz, @namez);

####################-Get Info from the web page

$title = param('title');
$bgcolor = param('bgcolor');
$tcolor = param('tcolor');
@content = param('content');

$link1 = param('link1');  
$link2 = param('link2'); 
$link3 = param('link3'); 
$link4 = param('link4'); 
 
$name1 = param('name1');
$name2 = param('name2');
$name3 = param('name3');
$name4 = param('name4');

@linkz = ($link1, $link2, $link3, $link4);
@namez = ($name1, $name2, $name3, $name4);

print "Content-type: text/html\n\n";

print "<html><title>$title</title><body bgcolor=$bgcolor text=$tcolor>";
print "@content";

$i =0;
foreach (@linkz){
	$i++;
	print "<li><a href=\"$_\">$namez[$i-1]</a>";
}
print "</body></html>"; 