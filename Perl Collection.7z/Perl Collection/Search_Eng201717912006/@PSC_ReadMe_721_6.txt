Title: Search Engine
Description: The purpose of the project was to create a desktop based search engine. Some of the main features are:-
1.It supports And - for example if you have two files where you have 2 or more words in common the it should give the names of the files where both the words appear in the same document but not necessarily together.
2.It supports Or &#8211; for example if as arguments 2 operators are given then by default it gives the names of the files where each of those keywords appear.
3.It supports Not &#8211; for example &#8211; given some arguments it would print the file names where the pattern is not present.
4.It supports Exact phrase match &#8211; Given the exact phrase, it matches all the documents where it has the exact pattern together.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=721&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
