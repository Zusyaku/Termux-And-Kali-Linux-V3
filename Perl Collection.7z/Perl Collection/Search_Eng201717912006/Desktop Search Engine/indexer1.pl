#!/usr/bin/perl

use File::Find;
use DB_File;
use Fcntl;
undef $/; 
require 5;
unlink("indexer.db");

$input_dir = "/home/james/Perl_Programs/tarun/php" ;

$DB_File::DB_BTREE->{cachesize} = 100_000_000; # 10meg cache
$DB_File::DB_BTREE->{psize} = 32*1024; # 32k pages

$DB_BTREE->{'flags'} = R_DUP;
$x = tie %hash, "DB_File", "indexer.db", O_RDWR|O_CREAT ,0644 , $DB_BTREE;

find(\&edits,$input_dir);
untie %hash;

#This function categorizes various kinds of files
$file_count = 0;
my(%wordCache);
sub edits(){
#print "File name is $_\n\t\tFull path is $File::Find::name\n";
$path = $File::Find::name;
	if(! -f)
	{
		return;
	}
	if(/\.(txt|c|cpp|pl)?$/)
	{
		$file = $path;
		open INFILE,$file;
		my($words) = <INFILE>;
		&WordsinFile($words,$path);
	}

	if(/\.(htm|html|php|java)?$/i)
	{
		$file = $path;
		open INFILE,$file;
		my($words) = <INFILE>;
		$words =~ s/&nbsp;/ /gi;
		$words =~ s/<[^>]*|>//gi;      # Strip out all HTML tags
		$words =~ s/[\'\"]//gi;
		$words =~ s/\.(\s+)/$1/gi;
		&WordsinFile($words,$path);
	}

	else {return;}
}


# Function to split words in a file and create the hash

sub WordsinFile{

my($words,$filepath) = @_;
my(%worduniq);

# Split text into array of words

my(@words) = split(/[^a-zA-Z0-9\xc0-\xff\+\/\_]+/, lc $words);

@words = grep { $worduniq{$_}++ == 0 }         # Remove duplicates
         grep { s/^[^a-zA-Z0-9\xc0-\xff]+//; $_ }  # Strip leading punct
	 @words;

foreach $word (sort @words)
{
	$wordCache{$word} = $filepath;
}
	if(++$file_count >=1000)
	{
		&FlushWordCache();
	}
}
  $key = $value = 0;
 
  for ($status = $x->seq($key,$value,R_FIRST);
  	$status == 0;
  	$status = $x->seq($key,$value,R_NEXT))
  {
   	print "The key is $key \t\t\t and the filename is $value\n"
  }

sub FlushWordCache {
    my($word,$entry);
	
    # Do merge in sorted order to improve cache response of on-disk DB
    foreach $word (sort keys %wordCache) {
        $entry = $wordCache{$word};
         if(defined $hash{$word}) {
              my($codedList);
              $codedList = $hash{$word};
             @entry = &MergeLists($codedList,$entry);
         }
        # Store merged list into database
	
	$hash{$word} = $entry;
    }
    %wordCache = (); # Empty the holding queue
}

sub MergeLists {
     my($list);
    foreach (@_) { $list .= $_; }              # append all the lists
    my(@unpackedList) = ($list);    # Unpack into integers
    my(%uniq); # sort and unique-ify
    #@unpackedList = grep { $uniq{$_}++ == 0 }  # Remove duplicates
                    #sort { $a <=> $b }         # Sort
     #               @unpackedList;
    return (@unpackedList);
}

undef $x;
