#!/usr/bin/perl

require 5;
use DB_File;
use Fcntl;


$x= tie(%hash,DB_File,'indexer.db', O_RDONLY, 0, $DB_File::DB_BTREE);

my(@final_files);
$count = 1;
$flag_union = 0;
$flag_insec = 0;
$flag_not = 0;
$flag_phrase = 0;
@phrase = @ARGV;
$CompletePhrase = $ARGV[0];

# $ operator at the beginning represents AND operator

if ($ARGV[0] =~ m/\$/) {
	$flag_insec = 1;
	shift;
	@phrase = @ARGV;
}

# ! operator at the beginning represents NOT operator
if ($ARGV[0] =~ m/\!/) {
	$flag_not = 1;
	shift;
	@phrase = @ARGV;
}

# If an exact phrase matching is given

if ((scalar(@ARGV)) ==1)
{
	@phrase = split(/[^a-zA-Z0-9\xc0-\xff\+\/\_]+/, lc $ARGV[0]);
	
	if((scalar(@phrase)) != 1)
	{
		$flag_phrase = 1;
		
	}
}

# Loop for checking each keyword extstence in files

foreach(@phrase)
{

my(@temp1);
my(@temp2);
$key = $_;
$value = 0;
$variable = $_;
@temp1 = ();
@temp2 = ();
@union = @difference = @isect = ();

for ($status = $x->seq($key,$value,R_CURSOR);
     $status == 0;
     $status = $x->seq($key,$value,R_NEXT))
	{
	if(($key =~ m/^$variable/i)){
		#print "The key is $key \t\t\t and the filename is $value\n";
		if($count >= 2){
			push(@temp1,$value);
			}
		else {
			push(@temp1,$value);
			push(@final_files,$value);
			}
		}
	}
	$count++;
	@temp2 = @final_files;

	%counter = ();
	foreach $element (@temp1, @temp2) { $counter{$element}++ }
	foreach $element (keys %counter) {
		push @union, $element;
		push @{ $counter{$element} > 1 ? \@isect : \@difference }, $element;
    	}
	@final_files = ();
	if($flag_insec || $flag_phrase){
		@final_files = @isect;
	}
	else{
		@final_files = @union;
	}	
}

# Loop for Not Operator
# It works by taking the difference between the UOD and the union

if($flag_not == 1)
{

my(@temp1);
my(@temp2);

$key = 0;
$value = 0;

@temp1 = ();
@temp2 = ();
@union = @difference = @isect = ();

for ($status = $x->seq($key,$value,R_FIRST);
     $status == 0;
     $status = $x->seq($key,$value,R_NEXT))
	{
		push(@temp1,$value);
	}
	
	my %rem_dup = map {$_,1} @temp1;
	@temp1 = keys %rem_dup;
	@temp2 = @final_files;

	%counter = ();
	foreach $element (@temp1, @temp2) { $counter{$element}++ }
	foreach $element (keys %counter) {
		push @union, $element;
		push @{ $counter{$element} > 1 ? \@isect : \@difference }, $element;
    	}
	@final_files = ();
	@final_files = @difference;
		
}

#Loop for checking is exact phrase is found

if($flag_phrase)
{
	my(@new_final);
	@new_final = ();
	foreach(@final_files)
	{
		open INFILE,$_;
		while($line = <INFILE>)
		{
			if($line =~ m/^$CompletePhrase/i)
			{
#  				print "Phrase found in file $_\n";
				push(@new_final,$_);
			}
		}
	}

my %rem_dup = map {$_,1} @new_final;
@new_final = keys %rem_dup;
@final_files = ();
@final_files = @new_final;
	
}
foreach (@final_files)
{
	print "The keyword is found in file $_\n";
}

undef $x;
untie(%hash);
