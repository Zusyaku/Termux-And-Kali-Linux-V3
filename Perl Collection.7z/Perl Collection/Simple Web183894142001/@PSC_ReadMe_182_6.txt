Title: Simple Web Database (Terminal Service Request) Vote For ME!
Description: This is an example of a Web Database Using Perl, Complete with a Form, Database Interface, secure access and web form input. It was written to enable customers to send computer problems to the Systems Administration Section via Web Posting (in case email fails). 
This is easy stuff... three simple steps.
1. Copy the following HTML file into your html docs directory...(make sure to rename your old index.htm to index.old.htm so you dont loose it!)
"index.htm"
2. Copy everything else into your http servers "CGI-BIN"
(Make Sure you copy the "tsr" directory into your "CGI-BIN" like
"\cgi-bin\tsr"
In the event of a catastrophic loss there is a backup file in your /tsr directory.
3. Call the "index.htm" file from your web browser and from there you can:
	a. Add Terminal Service Requests (TSR)
	b. Manage The TSR Database 
	c. Setup Access Authentification by IP and/or userid, password
Questions/Suggestions to mmollenkopf@hot.rr.com
BigAl Sends....

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=182&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
