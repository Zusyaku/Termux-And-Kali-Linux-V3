Title: Bluepig
Description: Bluepig is the console address book you can search
by name or phone number and edit any field you want with
your favorite editor like "vi or any".Every record is kept in file
that you can open it anytime or anywhere (platform independent)
this program is very small(about 150 lines) becuase this is my
first program with Perl. Try it!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=668&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
