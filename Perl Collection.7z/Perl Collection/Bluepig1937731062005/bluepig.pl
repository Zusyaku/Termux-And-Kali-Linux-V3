#!/usr/bin/perl
print "Enter database file name : ";
$dbfile = <STDIN>;chop($dbfile);
if(! -e $dbfile ){
	print "It's not exist ! new file is created\n";
	open(CREATE,">$dbfile")|| die "Error opening file\n";
	close(CREATE);
}else{
	while(1){
		print "***************************************************\n";
		print "Phonebook Menu : \n";
		print "add [sort]- add new contact to phonebook\n";
		print "edit [name|phone]- edit exsiting contact in phonebook\n";
		print "find [name|phone]- find the existing name from phonebook\n";
		print "show - show contact name only that kept in phonebook\n";
		print "showall - show name and phone of all contact\n";
		print "sort - sort database file ordered by alphanumberic\n";
		print "version - print software version and maintainancer\n";
		print "quit - quit this program\n";
		print "***************************************************\n>> ";
		$cmd = <STDIN>;chop($cmd);
		system("clear");print"Result : \n";
		if($cmd eq "add"){ addNewContact();
		}elsif($cmd eq "add sort"){ addNewContact();sortDatafile();
		}elsif($cmd eq "edit"){ editContact(0);
		}elsif($cmd eq "edit name"){ editContact(0);
		}elsif($cmd eq "edit phone"){ editContact(1);	
		}elsif($cmd eq "find"){ findWhat(0);
		}elsif($cmd eq "find name"){ findWhat(0);
		}elsif($cmd eq "find phone"){ findWhat(1);	
		}elsif($cmd eq "show"){ showContact();
		}elsif($cmd eq "showall"){ showAllContact();
		}elsif($cmd eq "sort"){ sortDatafile();
		}elsif($cmd eq "version"){ printVersion();
		}elsif($cmd eq "quit"){ last;
		}else{ print "Unknown command or not yet implemented\n"; }
	}
}
sub addNewContact {
	my($name,$phone);
	open(ADDNEW,">>$dbfile")|| die "Error opening file\n";
	print "Contact Name : ";
	$name = <STDIN>;chop($name);
	print "Phone number : ";
	$phone = <STDIN>;chop($phone);
	$data = $name.":".$phone."\n";
	print $data;
	print ADDNEW ($data);
	close(ADDNEW);
}
sub editContact {
	if($_[0]==0){
		print "contact name 2 edit : ";
		$keyword = <STDIN>;chop($keyword);
		findContact($keyword,0,"edit");
	}else{
		print "contact phone no. 2 edit : ";
		$keyword = <STDIN>;chop($keyword);
		findContact($keyword,1,"edit");
	}
}
sub findWhat {
	if($_[0]==0){
		print "Contact name 2 find : ";
		$keyword=<STDIN>;chop($keyword);
		findContact($keyword,0,"find");
	}else{
		print "Contact phone no. 2 find : ";
		$keyword=<STDIN>;chop($keyword);
		findContact($keyword,1,"find");
	}
}
sub showContact {
	open(SHOW,"$dbfile")|| die "Error opening file\n";
	$line = <SHOW>;$num=0;
	while($line ne ""){
		@pair = split(":",$line);
		print $pair[0]." ";
		$line = <SHOW>;
		$num++;
	}
	print "\nTotal contact = $num\n";
	close(SHOW);
}
sub showAllContact {
	open(SHOWALL,"$dbfile")|| die "Error opening file\n";
	print "Name\t\t\t\tPhoneNo.\n";
	$line = <SHOWALL>;$num=0;
	while($line ne ""){
		@pair = split(":",$line);
		print $pair[0]."\t\t\t\t".$pair[1];
		$line = <SHOWALL>;
		$num++;
	}
	print "Total contact = $num\n";
	close(SHOWALL);
}
sub sortDatafile {
	open(FORREAD,"$dbfile")|| die "Error opening file\n";
	$line = <FORREAD>;
	$index=0;
	while($line ne ""){
		@pair = split(":",$line);
		$unsorted[$index]=$pair[0].":".$pair[1];
		$line = <FORREAD>;
		$index++;
	}
	@sorted = sort @unsorted;
	close(FORREAD);
	open(FORWRITE,">$dbfile")|| die "Error opening file\n";
	foreach $node (@sorted){
		print FORWRITE $node;
	}
	close(FORWRITE);
}
#findContact(regx[keyword],col[name=0|phoneNo.=1],mode)
sub findContact {
	open(FIND,"$dbfile")|| die "Error opening file\n";
	$line = <FIND>;
	$num=0;$found=0;
	while($line ne ""){
		@pair = split(":",$line);
		$num++;
		chop($pair[1]);
		if($pair[$_[1]]=~/$_[0]/){
			$found++;
			if($pair[0] eq $_[0] ){
				print $pair[0]."\t\t".$pair[1]."\t Exact Match\n";
			}else{
				print $pair[0]."\t\t".$pair[1]."\n";
			}
			if($_[2] eq "edit"){
				system("vi +$num $dbfile");
				last;
			}
		}
		$line = <FIND>;
	}
	if($_[2] ne "edit"){ print "Found $found contacts \n"; }
	close(FIND);
}
sub printVersion {
	print "BluePig phonebook version 0.1\n";
	print "Licence : GPL \n";
	print "Written by Hussachai Puripunpinyo (student id : 45010898 class 4F)\n";
	print "Email : siberhus\@yahoo.com \n";
}
