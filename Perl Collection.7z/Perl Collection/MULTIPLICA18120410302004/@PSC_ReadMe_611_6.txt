Title: MULTIPLICATION CHALLLENGE
Description: This is a children's multiplication quiz-type game. There are two modes, FLASHCARD MODE and TEST MODE. In FLASHCARD MODE there are ten questions. It will not let you through unlesss you answwer correctly. In TEST MODE you get 25 questions and your answer is final. At the end you percentage is shown. Instructions included in ZIP file.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=611&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
