#!/usr/local/bin/perl-w

$right = 0; #right questions in test

print "Welcome to MULTIPLICATION CHALLENGE!\n";
$maxnum = 10;
START:
$right = 0;
$prcnt = 0;
print "What would you like to do?\n";
print "1) FLASHCARD MODE\n";
print "2) TEST MODE\n";
print "3) OPTIONS\n";
print "4) EXIT\n";
$sol = <stdin>;
if ($sol == 1)
{
    print "\nFLASHCARD MODE!\n";
    goto FLASH;
}
elsif ($sol == 2)
{
    print "\nTEST MODE\n";
    goto TEST;
}
elsif ($sol == 3)
{
    print "What is the maximum number?\n";
    $maxnum = <stdin>;
    $maxnum = $maxnum + 1;
    goto START;
}
elsif ($sol == 4)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
else
{
    print "Please pick from the list.\n";
    goto START;
}

FLASH: #FLASH MODE begins
print "";
NUMONE:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

ONE:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMTWO;
}
elsif ($sol == 640)
{
    goto START;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
else
{
    print "Try again!\n";
    goto ONE;
}

NUMTWO:

$a = int(rand $maxnum);
$b = int(rand $maxnum);

TWO:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMTHREE;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto TWO;
}

NUMTHREE:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

THREE:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMFOUR;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto THREE;
}

NUMFOUR:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

FOUR:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMFIVE;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto FOUR;
}

NUMFIVE:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

FIVE:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMSIX;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto FIVE;
}
NUMSIX:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

SIX:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMSEVEN;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto SIX;
}

NUMSEVEN:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

SEVEN:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMEIGHT;
}
elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto SEVEN;
}

NUMEIGHT:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

EIGHT:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMNINE;
}

elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto EIGHT;
}

NUMNINE:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

NINE:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto NUMTEN;
}

elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto NINE;
}

NUMTEN:
$a = int(rand $maxnum);
$b = int(rand $maxnum);

TEN:
print "$a * $b\n";
$sol = <stdin>;
if ($sol == $a*$b)
{
    print "Correct!\n";
    goto FINFLASH;
}

elsif ($sol == 505)
{
    print "Goodbye!\n";
    goto ENDPROG;
}
elsif ($sol == 640)
{
    goto START;
}
else
{
    print "Try again!\n";
    goto TEN;
}

FINFLASH: #FLASH MODE ends
print "Congratulations!\n";
print "You have finished FLASHCARD MODE!\n";
goto START;

TEST: #TEST MODE begins

for ($prob = 0; $prob < 25; $prob ++)
{
    $probnum = $prob + 1;
    print "Problem #$probnum\n";
    $a = int(rand $maxnum);
    $b = int(rand $maxnum);
    
    print "$a * $b\n";
    $sol = <stdin>;
    
    if ($sol == $a*$b)
    {
	$right = $right + 1;
	print "Correct!\n"
    }
    elsif ($sol == 505)
    {
	print "Goodbye!\n";
	goto ENDPROG;
    }
    elsif ($sol == 640)
    {
    goto START;
    }
    else
    {
	print "Sorry!\n";
    }
}
$prcnt = $right * 4;
print "You got $right questions correctly out of 25. This is $prcnt%.\n";
goto START;

print "Goodbye!\n";
ENDPROG:
$endp = <stdin>;
