#!/usr/bin/perl -w

use strict;
use warnings;
use POSIX;
use CGI qw/:standard/;


use DB_File;

my $add;
my %chat;
my $chat = "chat.db";


tie %chat, "DB_File", "$chat", O_CREAT|O_RDWR, 0644, $DB_BTREE
	or die "Cannot open file 'chat': $!\n";
	
print header, start_html;


print "<center><H2>CB History- last 100 things seen...</H2></center>";                                                

print "<table>";

for (grep defined($_), (keys %chat)[-100..-1]) {


my ( $name, $message, $time ) = split /~~/, $chat{$_};

    print "<tr><td>";
    print "<font color=blue>&lt;$name&gt;</font> $message";
    print "</td></tr>";
}
print "</table>";