Title: EVS v2.0- Email Verification System
Description: EVS is a system to ensure people are typing in their email addresses on your forms correctly. EVS was made to be setup to a mailing list but it certainly has a million and one other applicable jobs.
The user submits his/her email address and the system generates an ID/email combination and forms (and sends) a personalized link to their email account. All users are stored into a databased listed as "unverified" until the link is clicked and verified. 
(I appologize but since there are link tags in the script, I have to zip the file for you). The script is one file, so don't think it'll be a headache using.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=500&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
