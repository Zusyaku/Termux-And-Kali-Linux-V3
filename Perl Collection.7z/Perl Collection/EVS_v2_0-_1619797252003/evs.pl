#!/usr/bin/perl -w


use strict;
use CGI;
use POSIX;

my $query = CGI->new;
my %form = %{$query->Vars};


### Config Center
require SDBM_File;

my %dbm;
my %unv;
my $dbm_file = "evs.dbm";
my $unverified = "unv.dbm";
my $url = "http://sulfericacid.perlmonk.org/evs/evs.pl";

my $accountID = $query->url_param('accountID');
my $accountAD = $query->url_param('accountAD');

my $adminmail = "admin\@test.com";
my $sendmail = "/usr/lib/sendmail";
my $message = "Thank you for opting in on my mailing list please click
+ the link below to activate your listing.";


tie %dbm, 'SDBM_File', $dbm_file, O_CREAT|O_RDWR, 0644;
if (!tied %dbm) {
  print "database unsuccessful.\n";
}

tie %unv, 'SDBM_File', $unverified, O_CREAT|O_RDWR, 0644;
if (!tied %unv) {
  print "database unsuccessful.\n";
}

### END CONFIG


  use CGI qw/:standard/;
print header, start_html('Email Management');

print start_form(), table(

    Tr(
        td("Email: "),
        td(
            textfield(
                -name => 'email',
                -size => 40
            )
        )
    ),


    Tr( td(), td(submit) ),
  ),
  end_form(), hr();


my $email = param('email');

my $chars;

my @chars = ( "A" .. "Z", "a" .. "z", 0 .. 9, );
my $ID;

### randomize characters
do { $ID = join '', map { $chars[ rand @chars ] } 1..17; } 
while grep {$_ eq $ID} my @used;

### If USERMAIL exists add information to notverified DBM
if ($form{'email'}) {

$unv{$ID}= $email;

        print "<br>An email has been sent to $email.  Please check it 
+to verify your information.\n";


### email the users
my $accountAD = $email;
my $accountID = $ID;

open (MAIL, "|$sendmail -t") or die "Cannot access mail";
  print MAIL "To: $email\n";
  print MAIL "From: $adminmail\n";
  print MAIL "Subject: Verify your Email Address\n\n";
  print MAIL "$message\n\n";
  print MAIL "$url?accountID=$accountID&accountAD=$accountAD\n";
close (MAIL);
}

### If url_param() exists
if ($accountID && $accountAD) {

&params;
}

###  If url_param() exists check to see if it exists in DBM
sub params { 
if ( $accountID && ( $accountAD ne '' ) ) {
        
        if ( exists $unv{$accountID} ) { 
            if ( $unv{$accountID} eq $accountAD ) {
                $dbm{$accountAD} = $accountAD;
                delete $unv{$ID};
                print "Your address has been indexed successfully!<br>
+";
                print qq(Please click <a href="$url">here</a> to submi
+t another address);
exit;
            }
            else {
                print "Registration didn't match.<br>";
                print qq(Please click <a href="$url">here</a> to resen
+d information);
                           }
        
        }
            else {
                print "Email address not found.  Please re-submit your
+ details.<br>";
                print qq(Please click <a href="$url">here</a> to try a
+gain);
            exit;
            }
        }
    }   