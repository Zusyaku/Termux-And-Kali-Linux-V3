Title: Perpetu8 Financially v1.024b
Description: Perpetu8 Financially v1.024b
=============================
JaS Software  Copyright-02/2004
 This perl script was created to help me keep track of my checking account and keep track of the bills.
 The main display is that of a Perpetual Calendar (hence the name). Each cell can hold multiple entries showing payments, deposits or just setting aside money in a budget.
 The subtotal is continuously updated and displayed for each day. A week summary is also displayed at the right most column.
 Since this was built on top of a calendar system, you can enter values for the past, present, and future. An expected value is also calculated showing the intended money in the account. (ie. even though a check didn't clear yet, it still shows that the money is gone)
 This also works for future deposits (ie. paycheck) Keep entering expected paychecks and watch your money grow! WARNING: An error in entering a paycheck could falsely advise you that there is more money than supposed to be! (I found that one out REAL fast!)
 It can only work with one back account. And, there is an upload feature I haven't finished - been meaning to - anyways, it doesn't work, don't use it. I was hoping to be able to upload ".QIF Bank Statements", but the idea of filtering possible double entries gave me a head ache!
 Have Fun!

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=566&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
