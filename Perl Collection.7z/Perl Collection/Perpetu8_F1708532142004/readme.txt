Perpetu8 Financially  v1.024b
=============================
JaS Software   Copyright-02/2004

 Install this script in a web-accessible directory.  It comes with a sub-dir of the same name. This is required (for the way the script has been set-up, but can be changed if you modify the script)

 Please look at the diagram below... if you want your data directory set up differently, then change it in the script FIRST, before you run it for the first time.  It will then create the data directory in the location you specify.

 The script can be run right out of the box.  It will create any needed directories for its data, and any needed files (user,account,log).  This first time it is accessed, it will ask you to create an SUPER-USER account.  Pick a name and password.  Then, ADD another USER from the next display.  This will be a normal account.  It is best to do this, even if you are only going to be using it yourself.

 This is how the default expects the dirs to look like:
    install to /user/public_html
(your server may call your web accessible directory something else)

DIRECTORIES Before Install
 /user +
       /public_html +


DIRECTORIES After Install (with files)
 /user +
       /public_html +
                     perpetu8.cgi               (added)
                     perpetu8-template.html     (added)
                     perpetu8-financially.txt   (added)
                     readme.txt                 (added)
                    /perpetu8 +                 (added)
                              / index.html      (added)
                              / 1x1.gif         (added)

DIRECTORIES After FIRST SUCCESSFUL Run  (you can use your browser)
 /user +
       /perpetu8 +                              (added)
                  perpetu8-YYYYMMDD.log         (added)
                  perpetu8-clicker.dat          (added)
                  userlist.dat                  (added)
                 /profiles +                    (added)
                            ##########.dat      (added)
       /public_html +
                     perpetu8.cgi
                     perpetu8-template.html
                     perpetu8-financially.txt
                     readme.txt
                    /perpetu8 +
                              index.html
                              1x1.gif
 
