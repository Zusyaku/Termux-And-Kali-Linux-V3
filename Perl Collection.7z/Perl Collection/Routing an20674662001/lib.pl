##################################################
# Library file version 2.03 by vivitron
##################################################
#General routines
##################################################
#	- headers      (Generates HTTP headers)
#0	- 200 Ok	
#1	- 201 Created	
#2	- 202 Accepted	
#3	- 203 Non-Authoritative	
#4	- 204 Non Content	
#5	- 300 Multiple Choice	
#6	- 301 Moved Permanentely	
#7	- 302 Moved Temporarily	
#8	- 303 See Other	
#9	- 304 Not Modified	
#10	- 400 Bad Request	
#11	- 401 Unauthorized	
#12	- 402 Payment Required	
#13	- 403 Forbidden	
#14	- 404 Not Found	
#15	- 405 Method Not Allowed	
#16	- 406 None Acceptable	
#17	- 407 Proxy Authentication(Unauthorized) Required	
#18	- 408 Request Timeout	
#19	- 409 Conflict	
#20	- 410 Gone	
#21	- 411 Authorization Required	
#22	- Server:	
#23	- Date:	
#24	- Expires:	
#25	- Location:	
#26	- Last-modified:	
#27	- Set-cookie:	
#28	- Allow: Get, Post	
#29	- text/html	
#30	- image/gif	
#31	- image/jpeg	
#32	- text/plain	
#33	- text/richtext	
#34	- image/tiff	
#35	- image/x-rgb	
#36	- image/x-bitmap	
#37	- audio/basic	
#38	- audio/x-wav	
#39	- video/mpeg	
#40	- video/quicktime	
#41	- video/x-msvideo	
# Usage &headers('#');
######################
sub headers{

local(@in) = @_;

@in = sort {$a <=> $b} @in;

local($_,$name,$value,$age,$path,$num,@header);

@header = ('200 Ok',
'201 Created',
'202 Accepted',
'203 Non-Authoritative',
'204 Non Content',
'300 Multiple Choice',
'301 Moved Permanentely',
'302 Moved Temporarily',
'303 See Other',
'304 Not Modified',
'400 Bad Request',
'401 Unauthorized',
'402 Payment Required',
'403 Forbidden',
'404 Not Found',
'405 Method Not Allowed',
'406 None Acceptable',
'407 Proxy Authentication(Unauthorized) Required',
'408 Request Timeout',
'409 Conflict',
'410 Gone',
'411 Authorization Required',
'Server:',
'Date:',
'Expires:',
'Location:',
'Last-modified:',
'Set-cookie:',
'Allow: Get, Post',
'text/html',
'image/gif',
'image/jpeg',
'text/plain',
'text/richtext',
'image/tiff',
'image/x-rgb',
'image/x-bitmap',
'audio/basic',
'audio/x-wav',
'video/mpeg',
'video/quicktime',
'video/x-msvideo');

foreach(@in)
{
	if($_<22)
	{
		if(!$num)
		{
			print "HTTP/1.0 $header[$_]\n";
			$num++;
		}
	}
	elsif($_==22)
	{
		print "Server: $ENV{'SERVER_SOFTWARE'}\n";
	}
	elsif($_==23)
	{
		&date(0);
		print "Date: $result\n";
	}
	elsif(/\:/)
	{
		if($`==24)
		{
			&date($');
			print "Expires: $result\n";
		}
		elsif($`==25)
		{
			print "Location: http:\/\/$'\n";
		}
		elsif($`==26)
		{
			$age = -M "$'";
			$age *= 86400;
			&date(-$age);
			print "Last-modified: $result\n";
		}
		elsif($`==27)
		{
			($name,$value,$age,$path) = split(/\&/,$',4);
			if($age)
			{
				$age = "\; expires=".&date($age);
			}
			else
			{
				undef $age;
			}
			$path = "\; path=\/$path" if $path;
			print "Set-Cookie: $name\=$value$age$path\n";
		}
	}
	elsif($_>28&&$_<40)
	{
		print "Content-type: $header[$_]\n";
	}
	else
	{
		print "$header[$_]\n";
	}
}
print "\n";

return 1;
}
###################################################
# Read by vivitron - /3/23/99
###################################################
# Usage:
# &Read(*form);
###################################################
sub Read {

local (*in) = @_ if @_;

local ($i, $loc, $key, $val);


	read(STDIN,$in,$ENV{'CONTENT_LENGTH'});

@in = split(/&/,$in);

foreach $i (0..$#in)
{
	$in[$i] =~s/\+/ /g;
	($key, $val) = split(/=/,$in[$i],2);

	$key =~s/%(..)/pack("c",hex($1))/ge;
	$val =~s/%(..)/pack("c",hex($1))/ge;

	$in{$key} .= "\0" if (defined($in{$key}));
	$in{$key} .= $val;
}
return 1;
}
###################################################
# Browser Detection by vivitron - 5/06/99
###################################################
# Usage:
# $cbrowser = &browser;
###################################################
sub browser{
local($in,$versao,$nome,$_);
$in = @_;
($nome,$_) = split(/\//,$ENV{'HTTP_USER_AGENT'},2);
if ($nome eq "Mozilla")
{
	$ver  = substr($_,0,4);

	if(/MSIE/)
	{
		$result = $in ? "INTERNET EXPLORER $ver" : "MSIE $ver";
	}
	elsif(/Win95/)
	{
		$result = $in ? "NETSCAPE NAVIGATOR $ver" : "MOZILLA $ver";
	}
	elsif(/Opera/)
	{
		($in,$ver) = split(/\)/,$_,2);
		$result = "OPERA $ver";
	}
}
else
{
	$result = "$nome";
}
return ($result);
}
###################################################
# Query strings by vivitron - 11/26/98
###################################################
# Usage:
# &urls;
###################################################
sub urls {
$data=$ENV{'QUERY_STRING'};
@fields = split(/&/,$data);
foreach $fields(@fields){
   ($field_name,$field_val)=split(/=/,$fields);
$url{$field_name}=$field_val;
}
}
###################################################
# Laziness HTML headers by vivitron on one big boring day
###################################################
# Usage:
# &html();
###################################################
sub html {
print "Content-type: text/html \n\n";
return;
}
###################################################
# Stock lookup system by vivitron on a big cgifreebies project
###################################################
# Usage:
# @quotes = &quote(symbols);
# NOTE: seperate multiple symbols by commas.
###################################################
sub quote {
require Exporter;
use vars qw($VERSION @EXPORT @ISA $QURL);
use lib '/home/vivi/modules';
use LWP::UserAgent;
use HTTP::Request::Common;
$whichsyms = $_[0];
@q = '';
$QURL = ("http://quote.yahoo.com/d?f=snl1d1t1c1p2va2bapomwerr1dyj1x&s=");
@ISA = qw(Exporter);
@EXPORT = qw(&getquote &getonequote);
@chars = ( "A" .. "Z", "a" .. "z", 0 .. 9 );
@h = (	"Symbol","Name","Last","Trade Date","Trade Time","Change","% Change",
	"Volume","Avg. Daily Volume","Bid","Ask","Prev. Close","Open",
	"Day's Range","52-Week Range","EPS","P/E Ratio","Div. Pay Rate",
	"Div/Share","Div. Yield","Mkt. Cap","Exchange"  );

foreach $symbol (split(/,/, $whichsyms)) {
@q = getquote($symbol);
$results = '';
foreach $a (@q) {
  foreach (0..$#h) {
if ( $h[$_] eq "Symbol" ) {
$results .= "$$a[$_] ";
}
if ( $h[$_] eq "Name" ) {
$results .= "($$a[$_]) ";
}
if ( $h[$_] eq "Last" ) {
$results .= "$$a[$_] ";
}
if ( $h[$_] eq "% Change" ) {
$results .= "($$a[$_])\n";
}
}
}
}
return $results;
}
sub getquote {
    my @symbols = @_;
    my($x,@q,@qr,$ua,$url);
    $x = $";
    $" = "+";
    $url = $QURL."@symbols";
    $" = $x;
    $ua = LWP::UserAgent->new;
    $ua->env_proxy();
    foreach (split('\015?\012',$ua->request(GET $url)->content)) {
	@q = grep { s/^"?(.*?)\s*"?\s*$/$1/; } split(',');
	push(@qr,[@q]);
    }
    return wantarray() ? @qr : \@qr;
}
sub getonequote {
    my @x;
    @x = &getquote($_[0]);
    return @{$x[0]} if defined @x;
}

###################################################
# Error routine breaker by vivitron - 11/30/98
###################################################
# Usage:
# &error("Error here");
# Set $base for custom template
###################################################
sub error {
if ( $_[0] =~ /Define/ ) {
print :"Location: http://search.dmoz.org/cgi-bin/search?search=$url{'search'}\n\n";
exit;
}
if ( -e "$base/error.temp") {
open (F, "< $base/error.temp");
@text = <F>;
close(F);

print "Content-type: text/html \n\n";
foreach $te (@text) {
$te =~ s/%%error%%/$_[0]/g;
$te =~ s/\%%error%%/$_[0]/g;
print "$te";
}
exit;
}
else {
#We want a generic thing here
print "Content-type: text/html \n\n";
print qq|<html><head><title>System Failure Error</title></head>
<br>
<h1 align="center">System Failure</h1>
<br>
We are sorry to inform you that there has been a critical error, we will try to take care of this shortly!
Please, to help us, contact us and tell us how you encountered this error.<br>
The error is: $_[0]
<br>
|;
exit;
}
}

###################################################
# Template parser by vivitron - 2/03/99
###################################################
# Usage:
# print template("file", \%fields);
###################################################
sub template {
print "Content-type: text/html \n\n";
my ($filename, $fillings) = @_;
my $text;
local $/;
local *F;
open (F, "< templates/$filename\0")                       || &error("$filename");
$text = <F>;
close(F);
$text =~ s/\%%banner%%/$bannerurl/g;
$text =~ s{ %% ( .*? ) %% }
                     { exists( $fillings->{$1} )
                       ? $fillings->{$1}
                       : ""
                       }gsex;
        

             return $text;
}
###################################################
# Cookies by vivitron - 12/01/99
###################################################
#Usage:
#require "cookie-lib.pl"
#$cookie{MyCookie} = "MyValue";
#&set_cookie($expiration, $domain, $path, $secure);
#&get_cookie();
#&delete_cookie("MyCookie");
####################################################
sub get_cookie {
  local($chip, $val);
  foreach (split(/; /, $ENV{'HTTP_COOKIE'})) {
    s/\+/ /g;
    ($chip, $val) = split(/=/,$_,2); # splits on the first =.
    $chip =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
    $val =~ s/%([A-Fa-f0-9]{2})/pack("c",hex($1))/ge;
    $cookie{$chip} .= "\1" if (defined($cookie{$chip})); # \1 is the multiple separator
    $cookie{$chip} .= $val;
print "$val";  
}
}


sub set_cookie {
  local($expires,$domain,$path,$sec) = @_;
    local(@days) = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
    local(@months) = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
  local($seconds,$min,$hour,$mday,$mon,$year,$wday) = gmtime($expires) if ($expires > 0); 
  $seconds = "0" . $seconds if $seconds < 10;
  $min = "0" . $min if $min < 10; 
  $hour = "0" . $hour if $hour < 10; 
  local(@secure) = ("","secure");
  if (! defined $expires) { $expires = " expires\=Fri, 31-Dec-2010 00:00:00 GMT;"; }
  elsif ($expires == -1) { $expires = "" } 
  else { 
    $year += 1900; 
    $expires = "expires\=$days[$wday], $mday-$months[$mon]-$year $hour:$min:$seconds GMT; "; 
  }
  if (! defined $domain) { $domain = $ENV{'SERVER_NAME'}; } 
  if (! defined $path) { $path = "/"; } #set default path = "/"
  if (! defined $secure) { $secure = "0"; }
  local($key);
  foreach $key (keys %cookie) {
    $cookie{$key} =~ s/ /+/g;
    print "Set-Cookie: $key\=$cookie{$key}; $expires path\=$path; domain\=$domain; $secure[$sec]\n";
  }
}
sub delete_cookie {
  local(@to_delete) = @_;
  local($name);
  foreach $name (@to_delete) {
   undef $cookie{$name};
   print "Set-Cookie: $name=deleted; expires=Thu, 01-Jan-1970 00:00:00 GMT;\n";
  }
}

sub split_cookie {
  local ($param) = @_;
  local (@params) = split ("\1", $param);
  return (wantarray ? @params : $params[0]);
}

sub getcookies {
local (*in) = @_ if @_;

local ($i, $loc, $key, $val);


#	read(STDIN,$in,$ENV{'CONTENT_LENGTH'});
$in = $ENV{'HTTP_COOKIE'};
@in = split(/;/,$in);

foreach $i (0..$#in)
{
	$in[$i] =~s/\+/ /g;
	($key, $val) = split(/=/,$in[$i],2);

	$key =~s/%(..)/pack("c",hex($1))/ge;
	$val =~s/%(..)/pack("c",hex($1))/ge;

	$in{$key} .= "\0" if (defined($in{$key}));
	$in{$key} .= $val;
}
return 1;
}
#Ad_rerun routine. This routine rotates the ads in and out and updates the correct files
#Addon to beta 2.3.a on 7/26/00 by vivitron
sub ad_rerun {
srand();
open(FILE,"$datadir/main.txt");
@ads = <FILE>;
close(FILE);
for ($i = 0; $i <= $#ads; $i++) {
chomp($ads[$i]);
($file,$weight,$page,$max) = split(/\|/, $ads[$i]);
$page = "/" . $page;
for ($j = 1; $j <= $weight; $j++) {
if (($page ne "/" && $page eq $ENV{'DOCUMENT_URI'}) || ($page eq "/")) { splice(@choose,0,0,$i); }
}
}
$adnum = int(rand($#choose));
($file,$weight,$page,$max) = split(/\|/, $ads[$choose[$adnum]]);
open(FILE,"$datadir/$file-ad.txt");
@adtext = <FILE>;
close(FILE);
foreach $line(@adtext) { $cad .= "$line"; }
open(FILE,"$datadir/$file-count.txt");
flock(FILE,2);
$count = <FILE>;
close(FILE);
$count++;
unless ($max && $count >= $max) {
open(FILE,">$datadir/$file-count.txt");
flock(FILE,2);
print FILE "$count";
close(FILE);
return;        
}
else {
splice(@ads,$choose[$adnum],1);
open(FILE,">$datadir/main.txt");
foreach $ad(@ads) { print FILE "$ad\n"; }
close(FILE);
unlink("$datadir/$file-count.txt");
unlink("$datadir/$file-ad.txt");
return;
}
}
1;


