#!C:\Perl\bin\perl

########################################################
# Routing and remote access connection manager written by Dustin A. Lambert
# Allows webbased admin of Routing And Remote Access Connections in NT
# Change the connection vairable below to the connection name, then your set!
#########################################################
require 'lib.pl';
urls();
Read(*form);
my $script = $ENV{'SCRIPT_NAME'};
my $passfile = "password"; #Can be anything
my $connection = "USITSelmerDialUP"; # Change to RAS Connection name
### End of configuration ###
if (($form{'newpass'}) || ($url{'action'} eq "changepass")) { newlogin();}
if ( $url{'action'} eq "logout") { login();}
if (( $form{'pass'} ) || ($url{'pass'})) {
open(PASSFILE, "< $passfile") or newlogin();
$pass = <PASSFILE>;
close(PASSFILE);
if (($form{'pass'} ne $pass) && ($url{'pass'} ne crypt($pass,2))) {
error("Invalid Password! Please go <a href=\"$script\">back</a> and try again. Contact the System Admin for assistance");
exit;
}
$pass = crypt($pass,2);
$action = $url{'action'};
if ( $action eq "test") { #begin test internet connection 
if ( $url{'run'} ) {  # WE are running the test
my $tester = 0;
use LWP::Simple;
$tester = 0;
print qq|
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <p><font face="Verdana, Arial, Helvetica, sans-serif" color="#003366"><b><font size="2" color="#000099">Test 
    Internet Connection</font></b></font></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">The 
    test has begun, results are below...</font></b></p>
  <table width="55%" border="2" cellspacing="0" cellpadding="0" bgcolor="#003399" bordercolor="#999999">
    <tr bgcolor="#CCCCCC"> 
      <td height="22" width="28%"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Phase</b></font></div>
      </td>
      <td height="22" width="52%"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Site</b></font></div>
      </td>
      <td height="22" width="20%"> 
        <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Result</b></font></div>
      </td>
    </tr>
    <tr> 
      <td height="20" width="28%"> 
        <div align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">1</font></div>
      </td>
      <td height="20" width="52%"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">http://www.cnet.com</font></td>
      <td height="20" width="20%" align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">|;

$html = get("http://www.cnet.com") or fail();
if ( $fail < 1 ) {
print "PASSED\n";
} else {
print "FAILED\n";
} 
$fail = 0;
print qq|</font></td>
    </tr>
    <tr> 
      <td width="28%"> 
        <div align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">2</font></div>
      </td>
      <td width="52%"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">http://www.microsoft.com</font></td>
      <td width="20%" align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">|;      
$html = get("http://www.microsoft.com") or fail();
if ( $fail < 1 ) {
print "PASSED\n";
} else {
print "FAILED\n";
} 
$fail = 0;
print qq|
</font></td>
    </tr>
    <tr bgcolor="#999999"> 
      <td colspan="2"> 
        <div align="right"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"><b>Internet 
          Connection:</b></font></div>
      </td>
      <td width="20%"><div align="center"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2">|;
      if ( $tester > 1) { print "DOWN"; } else { print "UP"; } 
      print qq|</div></font></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p></body></html>|;
exit;
}#End actual test

###########
#Display main page
html();
print qq|
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <p><font face="Verdana, Arial, Helvetica, sans-serif" color="#003366"><b><font size="2" color="#000099">Test 
    Internet Connection</font></b></font></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">This 
    test is to test to see if the internet is working properly...</font></b></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">Please 
    note: This test will take a few minutes to run, please be patient and do not 
    run the test multiple times!</font></b></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099"><a href="$script?pass=$pass&action=test&run=1" class="bottom">Run 
    Test</a></font></b></p>
  <p>&nbsp;</p>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p></body></html>
|;
exit;
} #End test internet connection
if ( $action eq "stop" ) { # stop internet connection
if ( $url{'stop'} ) {
html();
print qq|
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <p><font face="Verdana, Arial, Helvetica, sans-serif" color="#003366"><b><font size="2" color="#000099">Stop 
    Internet Connection</font></b></font></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">The 
    internet connection command to stop the internet has been issued. If there 
    were any results, they are listed below.</font></b></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">|;
  system("netsh interface set interface name=$connection admin=DISABLED");
system("netsh interface set interface name=$connection connect=DISCONNECTED");
  print qq|</font></b></p>
  <p>&nbsp;</p>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p></body></html>
|;
exit;
} 
html();
print qq|
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <p><font face="Verdana, Arial, Helvetica, sans-serif" color="#003366"><b><font size="2" color="#000099">Stop 
    Internet Connection</font></b></font></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">This 
    will DISABLE and DISCONNECT the internet. No one will be able to access the 
    internet until it is started once again. Please use with caution.</font></b></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099"><a href="$script?pass=$pass&action=stop&stop=1" class="bottom">Stop 
    Internet </a></font></b></p>
  <p>&nbsp;</p>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p></body></html>|;
exit;
} # End stop internet connection
if ( $action eq "start" ) { # start internet connection
if ( $url{'start'} ) {
html();
print qq|
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <p><font face="Verdana, Arial, Helvetica, sans-serif" color="#003366"><b><font size="2" color="#000099">Start 
    Internet Connection</font></b></font></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">The 
    internet connection command to start the internet has been issued. If there 
    were any results, they are listed below.</font></b></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">|;
system("netsh interface set interface name=$connection admin=ENABLED");
system("netsh interface set interface name=$connection connect=CONNECTED");
  print qq|</font></b></p>
  <p>&nbsp;</p>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p></body></html>
|;
exit;
} 
html();
print qq|
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none}
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <p><font face="Verdana, Arial, Helvetica, sans-serif" color="#003366"><b><font size="2" color="#000099">Start 
    Internet Connection</font></b></font></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099">This 
    will ENABLE and CONNECT the internet. The internet will be available to everyone after 5-10 minutes. Please use with caution.</font></b></p>
  <p><b><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000099"><a href="$script?pass=$pass&action=start&start=1" class="bottom">Start 
    Internet </a></font></b></p>
  <p>&nbsp;</p>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p></body></html>|;
exit;
} # End start internet connection


html(); #Main Screen
print qq| 
<html>
<head>
<title>System Administration - Control Panel</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.bottom {  font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; font-style: normal; color: #000066; text-decoration: none }
-->
</style>
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Control Panel</font></b></font></p>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr>
      <td>
        <div align="center"><font color="#FFFFFF"><b><a href="$script?pass=$pass&action=test">Test Internet Connection</a></b></font></div>
      </td>
    </tr>
  </table>
  <br>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr> 
      <td> 
        <div align="center"><font color="#FFFFFF"><b><a href="$script?pass=$pass&action=stop">Stop Internet</a></b></font></div>
      </td>
    </tr>
  </table>
  <br>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr> 
      <td> 
        <div align="center"><font color="#FFFFFF"><b><a href="$script?pass=$pass&action=start">Start Internet</a></b></font></div>
      </td>
    </tr>
  </table>
  <br>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr> 
      <td> 
        <div align="center"><font color="#FFFFFF"><b><a href="$script?pass=$pass&action=changepass">Change 
          Password </a></b></font></div>
      </td>
    </tr>
  </table>
  <br>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr> 
      <td> 
        <div align="center"><font color="#FFFFFF"><b><a href="$script?pass=$pass&action=logout">Logout</a></b></font></div>
      </td>
    </tr>
  </table>
  <p><a href="$script"><span class="bottom">[<b>RE</b>login]</span></a> <span class="bottom"><a href="$script?pass=$pass&action=test" class="bottom">[test 
    internet connection]</a> <a href="$script?pass=$pass&action=stop" class="bottom">[stop 
    internet]</a> <a href="$script?pass=$pass&action=start" class="bottom">[start 
    internet]</a> <a href="$script?pass=$pass&action=changepass" class="bottom">[change 
    password]</a> <a href="$script?pass=$pass&action=logout" class="bottom">[logout]</a> 
    </span></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
<p>&nbsp;</p>
</body></html>
|;
exit;
}
login();
exit;
sub newlogin {
if ( $form{'newpass'} ) {
open(PASS, "> $passfile") or error("We cannot open your password file ($passfile\) to update your password!");
print PASS $form{'newpass'};
close(PASS);
html();
print qq|
<html>
<head>
<title>System Administration Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Authenication </font></b></font></p>
  <p>Congrats! Your password has now been update and is printed below. Please 
    write this down and be sure not to lose it. </p>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr>
      <td>
        <div align="center"><font color="#FFFFFF"><b>$form{'newpass'}</b></font></div>
      </td>
    </tr>
  </table>
  <p><a href="$script">[login]</a></p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
</body>
</html>
|;
exit;
}
html();
print qq|
<html>
<head>
<title>System Administration Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Authenication </font></b></font></p>
  <p>It seems that either<br>
    (a). Your password has been reset<br>
    or<br>
    (b). You have just setup the authenication system<br>
    Because your password file is missing. You may now setup your system by entering 
    your password below.</p>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr>
      <td>
        <div align="center"><font color="#FFFFFF"><form action="$script" method="post"><input type="text" name="newpass"><br><input type="submit" name="Setup" value="Login"></form></font></div>
      </td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
</body>
</html>
|;
exit;
}
sub login {
html();
print qq|
<html>
<head>
<title>System Administration Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" link="#00CC00" vlink="#00CC00" alink="#00CC00">
<div align="center">
  <p><font size="4" face="Verdana, Arial, Helvetica, sans-serif"><b><font color="#990000">System 
    Admin - Authenication </font></b></font></p>
  <p>Please enter your password below:</p>
  <table width="35%" border="1" bordercolor="#003399" bgcolor="#993300">
    <tr>
      <td>
        <div align="center"><font color="#FFFFFF"><form action="$script" method="post"><input type="text" name="pass"><br><input type="submit" name="Login" value="Login"></form></font></div>
      </td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p><font face="Arial, Helvetica, sans-serif" size="-3">System Administration 
    Version Alpha 2 was created by Dustin A. Lambert</font></p>
</div>
</body>
</html>
|;
exit;
}
sub fail { $tester++; $fail = 1; return;}