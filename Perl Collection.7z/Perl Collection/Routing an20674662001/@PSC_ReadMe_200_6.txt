Title: Routing and Remote Access Connection Manager
Description: THe Routing And Remote access program is a program written for small companies in my local area that wanted more security on their employees, but also wanted them to be able to fix connections when they went down. This program provides very basic authenication, just enough to satisfy its need, and allows them to start and stop the connection, as well as test the connection. It serves it's purpose well and is very flexible. Simple place the two perl scripts in a cgi-bin, (or somewhere where you have a small webserver), and change the $connection variable and it will run out of the box.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=200&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
