#!/usr/bin/perl


#
#                 OTP PASSWORD VALIDATOR (Stripped Version)
#
#                   Version: 1.1d
#                 Developer: Berardi Michele
#                       Tel: +39 347 319 2000
#                    E-Mail: mfxuab@tin.it
#                       Web: http://berardimichele.interfree.it
#                       Web: http://berardi.too.it
#


#perl2exe_info CompanyName=http://berardimichele.interfree.it
#perl2exe_info FileDescription=OTP PASSWORD VALIDATOR(Stripped Version) (Perl)
#perl2exe_info FileVersion=1.0.0.0
#perl2exe_info InternalName=otp_validator
#perl2exe_info LegalCopyright=(C) 2008 Berardi Michele
#perl2exe_info LegalTrademarks=Opensource Software
#perl2exe_info OriginalFilename=otp_validator.pl
#perl2exe_info ProductName=OTP PASSWORD VALIDATOR for Openvpn
#perl2exe_info ProductVersion=1.0.0.0

use FindBin qw($Bin); 
$scriptpath = $Bin;

use Getopt::Long qw(:config no_ignore_case no_auto_abbrev pass_through);

if ("$^O" == "MSWin32") {
$folderseparator='\\';
}
else
{
$folderseparator='/';
}



sub delete_otp_from_file {

my($file, $RESERVED_1, $search) = @_;

my $otpmatched = 0;
my $i = 0;
my $tmpwd = $search;

open (F,"+<$file") || die "[OTP VALIDATOR LOG]  Can't open for reading - $file\n";


$current_filepos = 0;

while (<F>) {

chomp $_;

$cleaning_pad = "-" x length($_);

if ($_ eq $cleaning_pad) {
# skip used otp..
}
else
{
if (($_) eq ($tmpwd)) {

seek(F,$current_filepos,0);
print F $cleaning_pad;

$otpmatched = 1;

      	 last

     }
}

$current_filepos = tell(F);

}
close (F);

return $otpmatched;

}


#
# START APPLICATION
#

# save the exit code to a file..




GetOptions ("susername=s" => \$username);
GetOptions ("spassword=s" => \$password);
GetOptions ("idpwdfile=s" => \$idpwdfile);
GetOptions ("exitfile=s" => \$exitfile);
GetOptions ("otpfilepath=s" => \$OTPFILEPATH);

#$OTPFILEPATH = $idpwdfile;
$OTPFILEPATH = $scriptpath . $folderseparator . $username . ".otp" unless defined $OTPFILEPATH;


$otpexist = delete_otp_from_file($OTPFILEPATH,$RESERVED_1 . $RESERVED_2,$password);

if (defined $exitfile)
{
open (exitfile_FILE,">$exitfile") || die "[OTP VALIDATOR LOG]  Can't open for output exitfile - $exitfile\n";
# $otp_validator_exitcode = 0 -> all is ok
# $otp_validator_exitcode = 1 -> otp error
$otp_validator_exitcode = 0 ^ !($otpexist eq 1);
print exitfile_FILE $otp_validator_exitcode;
close (exitfile_FILE);
}

exit !($otpexist eq 1);
