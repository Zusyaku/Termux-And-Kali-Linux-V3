#!/usr/bin/perl


#
#                 OTP SIMPLE PASSWORD GENERATOR (Stripped Version)
#
#                   Version: 1.1c
#                 Developer: Berardi Michele
#                       Tel: +39 347 319 2000
#                    E-Mail: mfxuab@tin.it
#                       Web: http://berardimichele.interfree.it
#                       Web: http://berardi.too.it
#
# usage:
# otp_simplepass.pl -howmany=<how many password must be generated> -len=<> -file=<output password file path> [-append] [-nodds]  [-nletters]  [-nnumbers]
#
# usage example:
# otp_simplepass.pl -howmany=30 -len=6 -file="C:\MiniWAS\VTOKEN\server\BCUSER.otp"
#
# append to a file (if exist) instead of create / overwrite existing:
# otp_simplepass.pl -howmany=30 -len=6 -file="C:\MiniWAS\VTOKEN\server\BCUSER.otp" -append

# exclusion switches:
#
# -nletters = don't use letters in otp
# -nnumbers = don't use numbers in otp
# -nodds = don't use odd characters in otp
#
# esample (use only letters):
# otp_simplepass.pl -howmany=30 -len=6 -file=BCUSER.otp -nnumbers -nodds

#perl2exe_info CompanyName=http://berardimichele.interfree.it
#perl2exe_info FileDescription=OTP SIMPLE PASSWORD GENERATOR(Stripped Version) (Perl)
#perl2exe_info FileVersion=1.0.0.0
#perl2exe_info InternalName=otp_simplepass
#perl2exe_info LegalCopyright=(C) 2008 Berardi Michele
#perl2exe_info LegalTrademarks=Opensource Software
#perl2exe_info OriginalFilename=otp_simplepass.pl
#perl2exe_info ProductName=OTP SIMPLE PASSWORD GENERATOR
#perl2exe_info ProductVersion=1.0.0.0

use FindBin qw($Bin); 
$scriptpath = $Bin;

use Getopt::Long qw(:config no_ignore_case no_auto_abbrev pass_through);

if ("$^O" == "MSWin32") {
$folderseparator='\\';
}
else
{
$folderseparator='/';
}


sub generatesimplepwd {

my $siz = $_[0];

my $pass;

my $letters = "a b c d e f g h i j k l m n o p q r s t u v w x y z" unless defined $_[1];
my $numbers= "0 1 2 3 4 5 6 7 8 9" unless defined $_[2];
my $odds="- _ % # |" unless defined $_[3];

my @allowedchars = split(" ",
	$letters . " " . $numbers . " " . $odds);

# default password size..
	if (!$siz) {
		$siz = 6;
	}


for (my $i=1; $i <= $siz ;$i++) {
	$randomposition = int(rand $#allowedchars);
	$pass .= $allowedchars[$randomposition];
}
return $pass;
}

GetOptions ("howmany=s" => \$howmany);
GetOptions ("len=s" => \$passlen);
GetOptions ("file=s" => \$file);
GetOptions ("append" => \$append);
GetOptions ("nletters" => \$no_letters);
GetOptions ("nnumbers" => \$no_numbers);
GetOptions ("nodds" => \$no_odds);

if (defined $append) {
open (F,">>$file") || die "[OTP SIMPLEPASS LOG]  Can't open for append - $file\n";
}
else
{
open (F,">$file") || die "[OTP SIMPLEPASS LOG]  Can't open for writing - $file\n";
}


for ($c=1; $c <= $howmany ;$c++) {
print F generatesimplepwd($passlen,$no_letters,$no_numbers,$no_odds) . "\n";
}

