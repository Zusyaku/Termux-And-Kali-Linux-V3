Title: ONE TIME PASSWORD ENHANCEMENT FOR SAP / ABAP  - A QUICK INTRODUCTION -
Description: This is an example of how to simply integrate a "One Time Password" (OTP)
as extra secure login phase (an advanced version whit rsa , smartcard , and virtual tokens is available too..) under SAP
using ABAP (as wrapper)
and PERL as multiplatform development language..
the abap part is (install instruction in the comment part too)in the zip file and here:
https://www.sdn.sap.com/irj/sdn/thread?threadID=865850

anyway you can download all the project
upgrades here:
http://berardimichele.interfree.it/src/perl/VTOKEN.zip

IF YOU APPRECIATE THE EFFORT YOU CAN DONATE HERE:
http://berardimichele.interfree.it/src/perl/donate.htm 

Hope this could be usefull.


Michele Berardi
System Developer
http://berardi.too.it

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=784&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
