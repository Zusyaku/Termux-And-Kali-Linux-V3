Title: Free IP 2 Country Geo Database Updated Live With Database Builder Software
Description: This is IP 2 Country Geo Database Builder Perl Script Totally Free. Runs from your computer or your server, Perl script which crawls the internet registries databases afrinic , apnic, arin, iana, lacnic, and ripencc, then process the latest updated files in the format you want in less than 5 to 15 minutes only. You can run the script from command line or automatically using your server crontab scheduled tasks.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=771&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
