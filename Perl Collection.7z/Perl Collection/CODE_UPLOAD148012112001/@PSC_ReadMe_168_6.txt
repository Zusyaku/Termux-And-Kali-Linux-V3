Title: Multi File Content Search & Replace v1.1
Description: Search for keyword(s) inside multiple files in a
directory and replace them with anything you
specify. Case sensitive/insensitive searching.
With/without Prompt before replacing. Time
elapsed during search and replace process.
Recursive directory searching coming soon.
THE PREVIOUS V1.0 HAD A MAJOR BUG, WHOEVER
DOWNLOADED IT, PLEASE GET THIS UPDATED VERSION.
I APOLOGISE TO ALL WHO USED THE PREVIOUS BUGGY
VERSION.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=168&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
