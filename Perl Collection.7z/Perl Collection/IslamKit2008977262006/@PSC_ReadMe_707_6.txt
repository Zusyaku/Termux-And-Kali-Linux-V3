Title: IslamKit
Description: Multi-lingual for all operating system free GPL open source code written in Perl, Quran, Quran Translations, Quran Transliterations, Quran Interpertations, Quran Recitations, and Quran Memroization Manager. Runs on any server Windows or Unix (Linux, FreeBSD, Solaries, BSD, etc) with Perl and MySQL database. Download More Database file from our site www.islamware.com.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=707&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
