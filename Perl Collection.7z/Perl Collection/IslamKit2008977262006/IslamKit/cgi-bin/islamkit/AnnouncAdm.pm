=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Announcements_Manager{
my ($Help);

	$Help = &Help_Link("Announcements_Manager");
	&Print_Page(&Announcements_Manager_Form(), "Announcements Manager", $Help);		
}
#==========================================================
sub Announcements_Manager_Form{
my ($Out);

	$Query = qq!SELECT ID FROM IslamAnnouncements ORDER BY Date DESC!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef @List;
	while(($ID) = $sth->fetchrow_array) {push @List, $ID;}
	$sth->finish;

	$Counter = 0;
	foreach $ID (@List) {
			$Counter++;
			$Query = qq!SELECT * FROM IslamAnnouncements WHERE ID=$ID!;
			$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			while ($Temp = $sth->fetchrow_hashref){%Item = %{$Temp}; last;}
			$sth->finish;

			$Delete = qq!<a href="#" onClick="Delete_Confirm(\'$Item{ID}\'); return false;">Delete</a>!;		

			$Edit = qq!<a href="$Script_URL?action=EditAnnouncement&ID=$Item{ID}">Edit</a>!;
			$Copy = qq!<a href="$Script_URL?action=CopyAnnouncement&ID=$Item{ID}">Copy</a>!;
			$Email = qq!<a href="mailto: $Item{Email}">$Item{Email}</a>!;
			$URL = qq!<a href="$Item{URL}">$Item{URL}</a>!;

			
		   my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst )= gmtime($Item{Date});
		   $mon++;
		   $Date = qq!$mon/$mday/$year  $hour:$min!;

			$Line = qq!<tr><td>$Counter</td><td nowrap>$Date</td><td>$Item{Subject}</td><td nowrap>$Item{Name}</td><td nowrap>$Email</td><td nowrap align="center">$Edit &nbsp; $Delete &nbsp; $Copy</td></tr>!;
			$Table .= $Line;
			
	}


$Out=<<HTML;
$Global{G1_Bullet}<A HREF="$Script_URL?action=NewAnnouncement">New Announcement</A>
<br><br>
<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFE888" width="100%" height="100%">
  <tr>
    <td nowrap align="center" bgcolor="#FFF2C1"><b>#</b></td>
    <td nowrap align="center" bgcolor="#FFF2C1"><b>Date</b></td>
    <td nowrap align="center" bgcolor="#FFF2C1"><b>Subject</b></td>
    <td nowrap align="center" bgcolor="#FFF2C1"><b>Name</b></td>
    <td nowrap align="center" bgcolor="#FFF2C1"><b>Email</b></td>
    <td nowrap align="center" bgcolor="#FFF2C1"><b>Action</b></td>
  </tr>
	$Table
</table>
<br><br>
<SCRIPT LANGUAGE="JavaScript">
<!--
function Delete_Confirm(ID) {
	var agree=confirm("Are you sure you want to Delete this Announcement\\n");
	if (agree){
				window.location = "$Script_URL?action=DeleteAnnouncement&ID=" +ID;
	}
}
-->
</SCRIPT>

HTML
	return $Out;
}
#==========================================================
sub NewAnnouncement{
my ($Help);

	$Help = &Help_Link("Announcements_Manager");
	$Param{FormTitle} = "Post New Announcement";
	&Print_Page(&Announcement_Form(), "Announcements Manager", $Help);		
}
#==========================================================
sub Announcement_Form{
my ($Out, $x, $Month, $Day, $Year);
	
	$Param{Subject} ||= "";
	$Param{Message} ||= "";
	$Param{Email} ||= "";
	$Param{Name} ||= "";
	$Param{URL} ||= "";

   my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst )= gmtime(&Time(time));
   $mon++;

	$Param{Hour} ||= $hour;
	$Hour = ""; 
	for $x(0..23) {
		if ($x == $Param{Hour}) {
			$Hour .= qq!<option value="$x" selected>$x!;
		}
		else{
			$Hour .= qq!<option value="$x">$x!;
		}
	}

	$Param{Minute} ||= $min;
	$Minute = "";
	for $x(0..59) {
		if ($x == $Param{Minute}) {
			$Minute .= qq!<option value="$x" selected>$x!;
		}
		else{
			$Minute .= qq!<option value="$x">$x!;
		}
	}

	$Param{Month} ||= $mon;
	$Month = "";
	for $x(1..12) {
		if ($x == $Param{Month}) {
			$Month .= qq!<option value="$x" selected>$x!;
		}
		else{
			$Month .= qq!<option value="$x">$x!;
		}
	}

	$Param{Day} ||= $mday;
	$Day = "";
	for $x(1..31) {
		if ($x == $Param{Day}) {
			$Day .= qq!<option value="$x" selected>$x!;
		}
		else{
			$Day .= qq!<option value="$x">$x!;
		}
	}

	$Param{Year} ||= $year;
	$Year = "";
	for $x(100..120) {
			$Y = $x+1900;
			if ($x == $Param{Year}) {
					$Year .= qq!<option value="$Y" selected>$Y!;
			}
			else{
					$Year .= qq!<option value="$Y">$Y!;
			}
	}

$Out=<<HTML;
<br>$Param{Error}
<form method="POST" action="$Script_URL">
<input type="hidden" name="action" value="SaveAnnouncement">
<input type="hidden" name="ID" value="$Param{ID}">

<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#FFD98A" width="100%">
    <tr>
      <td nowrap valign="top" bgcolor="#FFD98A" colspan="2" align="center"><b>$Param{FormTitle}</b></td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4"><b>Subject:</b></td>
      <td width="100%"><input type="text" name="Subject" size="60" value="$Param{Subject}"></td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4"><b>Date:</b></td>
      <td width="100%">
	
				<select size="1" name="Month">$Month</select>
				<select size="1" name="Day">$Day</select>
				<select size="1" name="Year">$Year</select>
				&nbsp;mm/dd/yyyy
				<select size="1" name="Hour">$Hour</select>:
				<select size="1" name="Minute">$Minute</select>
				&nbsp;hh:min
</td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4"><b>Email:</b></td>
      <td width="100%"><input type="text" name="Email" size="60" value="$Param{Email}"></td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4"><b>URL:</b></td>
      <td width="100%"><input type="text" name="URL" size="60" value="$Param{URL}"></td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4"><b>Name:</b></td>
      <td width="100%"><input type="text" name="Name" size="60" value="$Param{Name}"></td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4"><b>Message:<br>
      <br>
      </b>(HTML <br>
      allowed)</td>
      <td width="100%"><textarea rows="10" name="Message" cols="60">$Param{Message}</textarea></td>
    </tr>
    <tr>
      <td nowrap valign="top" bgcolor="#FFECC4" colspan="2" align="left">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
				<input type="submit" value="Submit" name="B1">&nbsp;
				<input type="reset" value="Reset" name="B2"></td>
    </tr>
  </table>
  <p>&nbsp;</p>
  <p>&nbsp;
</form>

HTML
	
return $Out;

}
#==========================================================
sub SaveAnnouncement{
	
	$Param{Subject} ||= "";
	$Param{Subject} =~ s/^\s+//;
	$Param{Subject} =~ s/\s+$//;
	$Param{Subject} =~ s/\cM//g;

	$Param{Message} ||= "";
	$Param{Message} =~ s/^\s+//;
	$Param{Message} =~ s/\s+$//;
	$Param{Message} =~ s/\cM//g;

	$Param{Email} ||= "";
	$Param{Email} =~ s/^\s+//;
	$Param{Email} =~ s/\s+$//;

	$Param{Name} ||= "";
	$Param{Name} =~ s/^\s+//;
	$Param{Name} =~ s/\s+$//;

	$Param{URL} ||= "";
	$Param{URL} =~ s/^\s+//;
	$Param{URL} =~ s/\s+$//;

	if (!$Param{Subject}) {
			$Param{Error} = qq!<p align="center"><font color="red" size="3"><b>Error: No subject entered.</b></font></p>!;
			&NewAnnouncement;
	}
	if (!$Param{Message}) {
			$Param{Error} = qq!<p align="center"><font color="red" size="3"><b>Error: No message entered.</b></font></p>!;
			&NewAnnouncement;
	}

	if ($Param{ID}) {
		$Query = qq!DELETE FROM IslamAnnouncements WHERE ID=$Param{ID}!;
		$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}

	$ID = time;
	$Query = qq!SELECT ID FROM IslamAnnouncements WHERE ID=?!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	while (1) {
			$sth->execute($ID) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
		    if (($Row) = $sth->fetchrow_array) {$ID++; }
			else{last;}
	}

	$Item{ID} = $ID;
	$Status = '1';

	 #year is year-1900 and month is 0..11.
	#$time = timelocal($sec,$min,$hours,$mday,$mon,$year);
	$Date = timegm(0, $Param{Minute}, $Param{Hour}, $Param{Day}, $Param{Month}-1, $Param{Year}-1900);
	$Date = ($Date);
	 
	$Date = $dbh->quote($Date);
	$Lang = $dbh->quote("");
	$URL = $dbh->quote($Param{URL});
	$Email = $dbh->quote($Param{Email});
	$Name = $dbh->quote($Param{Name});
	$Subject = $dbh->quote($Param{Subject});
	$Message = $dbh->quote($Param{Message});
	$Query = qq!INSERT INTO IslamAnnouncements VALUES($ID, $Status, $Date, $Lang, $URL, $Email, $Name, $Subject, $Message)!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	&Announcements_Manager;
}
#==========================================================
sub EditAnnouncement{
my ($Help);

	$Help = &Help_Link("Announcements_Manager");

	$Query = qq!SELECT * FROM IslamAnnouncements WHERE ID=$Param{ID}!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	
	while ($Temp = $sth->fetchrow_hashref){%Item = %{$Temp}; last;}
	$sth->finish;

	foreach $Key (%Item) {
			$Param{$Key} = $Item{$Key};
	}

	my ( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst )= gmtime($Item{Date});
	$mon++;

	$Param{Minute} = $min;
	$Param{Hour} = $hour;
	$Param{Day} = $mday;
	$Param{Month} = $mon;
	$Param{Year} = $year;

	$Param{FormTitle} = "Edit Announcement";
	&Print_Page(&Announcement_Form(), "Announcements Manager", $Help);		
}
#==========================================================
sub DeleteAnnouncement{

	if ($Param{ID}) {
		$Query = qq!DELETE FROM IslamAnnouncements WHERE ID=$Param{ID}!;
		$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}
	&Announcements_Manager;
}
#==========================================================
sub CopyAnnouncement{

	$Query = qq!SELECT * FROM IslamAnnouncements WHERE ID=$Param{ID}!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	while ($Temp = $sth->fetchrow_hashref){%Item = %{$Temp}; last;}
	$sth->finish;
	
	foreach $Key (%Item) {
			$Param{$Key} = $Item{$Key};
	}
	
	$Param{ID} = "";
	&NewAnnouncement;
}
#==========================================================
1;
