=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Announcements{
my ($Out, $Date_Class, $Date_Format, $Query, $sth);
my ($Form, @List, $Line, $Temp, $Body);

	&Read_Language_File($Global{Language_Announcements_File});

	$Out = &Translate_File($Global{Announcements_Template});
	$Form = &Translate($Global{Announcements_Form});

	#<!--Announcement_Date:10-->
	$Date_Class = ""; $Date_Format = "";
	if ($Form =~ m/(<!--)(Date)(:)(\d+)(-->)/  ){
				$Date_Class = $1 . $2 . $3. $4. $5;
				$Date_Format =  $4;
	}

	$Query = qq!SELECT ID FROM IslamAnnouncements ORDER BY Date DESC!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef @List;
	while(($ID) = $sth->fetchrow_array) {push @List, $ID;}
	$sth->finish;

	$Body = "";
	$Counter = 0;
	foreach $ID (@List) {
			$Counter++;
			$Query = qq!SELECT * FROM IslamAnnouncements WHERE ID=$ID!;
			$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			while ($Temp = $sth->fetchrow_hashref){%Item = %{$Temp}; last;}
			$sth->finish;

			$Line = $Form;
 			$Line =~ s/<!--Subject-->/$Item{Subject}/g;
			
			$Temp = &Format_Date($Date_Format, $Item{Date});
			$Line =~ s/$Date_Class/$Temp/g;
		
			$Line =~ s/<!--URL-->/$Item{URL}/g;
			$Line =~ s/<!--Message-->/$Item{Message}/g;
			$Line =~ s/<!--URL-->/$Item{URL}/g;
			$Line =~ s/<!--Name-->/$Item{Name}/g;
			$Line =~ s/<!--Email-->/$Item{Email}/g;
			$Body .= $Line;

	}
	
	$Out =~ s/<!--Announcements-->/$Body/;

	$Plugins{Body} = "";
	&Display($Out, 1);
}
#==========================================================
1;