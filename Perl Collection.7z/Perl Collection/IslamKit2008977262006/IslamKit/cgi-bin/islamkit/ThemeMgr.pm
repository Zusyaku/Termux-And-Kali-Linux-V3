=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub ThemeManager{
my ($Message) = @_;
my ($Help);

	$Help = &Help_Link("Theme Manager");
	&Print_Page(&Theme_Admin_Form($Message), "Theme Manager", $Help);		
}
#==========================================================
sub Theme_Admin_Form{
my ($Message) = @_;
my ($Themes, @Themes, @Languages, @Defaults, %Default);
my ($Line, $Lang, $Theme, $Config, $Selected, $Out);

	$Themes = &ThemesMenuList;
	@Themes = &ThemesList;
	@Languages = &LanguagesList;

	@Defaults = split (/\|/, $Global{Themes});
	undef %Default;
	foreach $Line (@Defaults) {
			($Lang, $Theme) = split(/\:/, $Line);
			$Default{$Lang} = $Theme;
	}

	$Config = "";
	foreach $Language (@Languages) {
			$Config .= qq!<tr><td>$Language</td>!;
			$Config .= qq!<td><select name="ConfigTheme\:$Language" size="1">!;
			foreach $Theme (@Themes) {
					$Selected = "";
					if ($Default{$Language} eq $Theme) {$Selected = "SELECTED";}
					$Config .= qq!<option value="$Theme" $Selected>$Theme</option>!;
			}
			$Config .= qq!</select></td></tr>!;
	}

$Out=<<HTML;
<BR>
$Message
<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200"  ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Create New Theme</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL">
		<INPUT TYPE="hidden" NAME="action" VALUE="CreateTheme">
      <TD NOWRAP>Copy from theme:</TD>
      <TD WIDTH="90%">
		<select SIZE="1" NAME="CopyFromTheme">$Themes</select>
	</TD>
    </TR>
    <TR>
      <TD NOWRAP>New Theme Name:</TD>
      <TD WIDTH="90%">
			<INPUT TYPE="text" NAME="NewThemeName" SIZE="30">
			<INPUT TYPE="submit" VALUE="Create" NAME="Submit" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
    </TR>
    <TR>
      <TD WIDTH="100%" COLSPAN="2" ALIGN="center">
	  </TD>
	</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200"  ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Delete Theme</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL" NAME="Delete_Theme">
		<INPUT TYPE="hidden" NAME="action" VALUE="DeleteTheme">
      <TD NOWRAP>Select Theme:</TD>
      <TD WIDTH="90%"><select SIZE="1" NAME="Theme">$Themes</select>
			<INPUT TYPE="submit" VALUE="Delete" NAME="Submit" onClick="DeleteThemeConfirm(document.Delete_Theme.Theme[document.Delete_Theme.Theme.selectedIndex].value); return false;" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200"  ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Configure Themes</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL" NAME="Configure_Themes">
		<INPUT TYPE="hidden" NAME="action" VALUE="ConfigureThemes">
      <td nowrap colspan="2">Assign themes to languages</td></tr>
      <td colspan="2">
			  <table border="01" cellspacing="0" cellpadding="3">
			$Config
				</table>
			<br>
			<INPUT TYPE="submit" VALUE="Save Changes" NAME="Submit" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>


<SCRIPT LANGUAGE="JavaScript">
<!--
function DeleteThemeConfirm(Theme) {
	var agree=confirm("Are you sure you want to delete this Theme?\\nTheme: "+Theme+"\\n");
	if (agree){
			var agree=confirm("Please note once the Theme deleted, you will not be able to recover it again\\nAre you sure you still want to delete this Theme?\\n                   Theme: "+Theme+"\\n");
			if (agree){
					window.location = "$Script_URL?action=DeleteTheme&Theme=" +Theme;
			}
	}
	//document.Delete_Theme.submit();
}
-->
</SCRIPT>

HTML
	return $Out;
}
#==========================================================
sub ConfigureThemes{
my (%Themes, %Config, $Key, $Themes, $Language, $Theme);

	undef %Themes;
	foreach $Key (keys %Param) {
			if ($Key =~ /^ConfigTheme\:(.*)/ ) {
					$Themes{$1} = $Param{$Key};
			}
	}

	$Themes = "";
	while (($Language, $Theme) = each %Themes) {
			$Themes .= "$Language\:$Theme|";
	}
	$Themes =~ s/\|$//;

	undef %Config;
	$Config{Themes} = $Themes;
	&Update_Configuration(%Config);

	#------------------------------------------------------
	&ThemeManager(qq!<p align="center"><font size="3" color="red"><b>Theme configuration successfully saved</b></p>!);
}
#==========================================================
sub ThemesMenuList{
my ($Default) = @_;
my ($Out, @Files, $File, $Selected);

	undef @Files;
	opendir(Dir, $Global{Templates_Dir});
	foreach $File (readdir(Dir)) {
			push @Files, $File;
    }
	closedir(Dir);

	foreach $File (@Files) {
			if (-d "$Global{Templates_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
				$Selected = "";
				if (lc($File) eq lc($Default)) {$Selected="SELECTED";}
				$Out .= qq!<OPTION VALUE="$File" $Selected>$File</OPTION>!;
			}
	}

	return $Out;
 }
#==========================================================
sub ThemesList{
my (@Files, $File);

	undef @Files;
	opendir(Dir, $Global{Templates_Dir});
	foreach $File (readdir(Dir)) {
			if (-d "$Global{Templates_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
					push @Files, $File;
			}
    }
	closedir(Dir);
	return @Files;
 }
#==========================================================
sub LanguagesList{
my ($Language) = @_;
my ($Out, @Files, $File, $Selected);

	undef @Files;
	opendir(Dir, $Global{Language_Dir});
	foreach $File (readdir(Dir)) {
			if (-d "$Global{Language_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
					push @Files, $File;
			}
    }
	closedir(Dir);
	return @Files;
 }
#==========================================================
sub DeleteTheme{
my ($Dir, $Directory, @Files, @Directories);

	#------------------------------------------------------
	# delete the theme templates directory and all its contents
	$Dir = "$Global{Templates_Dir}/$Param{Theme}";
	if (-d $Dir) {
			undef @Files;

			@Directories = &Scan_Directory_Tree($Dir);
			@Directories  = sort @Directories;
			
			foreach $Directory (@Directories) {
					@Files = &Scan_Directory($Directory);
					if (@Files) {
						unlink (@Files) or &Exit("Can't remove theme files @Files: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
					}
					rmdir ("$Directory") or &Exit( "Can't remove theme directory $Directory: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			}

			@Files = &Scan_Directory($Dir);
			if (@Files) {
				unlink (@Files) or &Exit("Can't remove theme files @Files: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			}
			rmdir ("$Dir") or &Exit( "Can't remove theme directory $Dir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	}
	#------------------------------------------------------
	# delete the theme images directory and all its contents
	$Dir = "$Global{HTML_Dir}/theme/$Param{Theme}";
	if (-d $Dir) {
				undef @Files;
				@Directories = &Scan_Directory_Tree($Dir);
				@Directories  = sort @Directories;
				
				foreach $Directory (@Directories) {
						@Files = &Scan_Directory($Directory);
						if (@Files) {
							unlink (@Files) or &Exit("Can't remove theme files @Files: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
						}
						rmdir ("$Directory") or &Exit( "Can't remove theme directory $Directory: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
				}

				@Files = &Scan_Directory($Dir);
				if (@Files) {
					unlink (@Files) or &Exit("Can't remove theme files @Files: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
				}
				rmdir ("$Dir") or &Exit( "Can't remove theme directory $Dir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	}
	#------------------------------------------------------
	&ThemeManager(qq!<p align="center"><font size="3" color="red"><b>Theme successfully deleted</b></p>!);
}
#==========================================================
sub CreateTheme{
my ($TargetDir, $SourceDir, $File);
	
	$Param{NewThemeName} =~ s/^\s+//;
	$Param{NewThemeName} =~ s/\s+$//;
	$Param{NewThemeName} =~ s/\s+/ /g;
	
	if (!$Param{NewThemeName}) {
			&ThemeManager;
			return;
	}
	#------------------------------------------------------
	# copy the templates directory
	$TargetDir = "$Global{Templates_Dir}/$Param{NewThemeName}";
	$SourceDir ="$Global{Templates_Dir}/$Param{CopyFromTheme}";

	mkdir ($TargetDir, 0777) or &Exit("Can't creat theme directory $TargetDir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);

	opendir(Dir, $SourceDir) or &Exit("Can't open theme directory $SourceDir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	foreach $File (readdir(Dir)) {
			if ($File eq "." || $File eq ".." || !-f "$SourceDir/$File") {next;}
			copy("$SourceDir/$File",	"$TargetDir/$File") or &Exit("Can't copy file $SourceDir/$File to $TargetDir/$File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			chmod (0755, "$TargetDir/$File");
    }

	closedir(Dir);
	chmod (0755, $TargetDir);
	#------------------------------------------------------
	# copy the theme images directory
	$Global{Theme_Images_URL} = "$Global{HTML_URL}/theme/$Global{Theme}";

	$TargetDir = "$Global{HTML_Dir}/theme/$Param{NewThemeName}";
	$SourceDir ="$Global{HTML_Dir}/theme/$Param{CopyFromTheme}";

	mkdir ($TargetDir, 0777) or &Exit("Can't creat theme directory $TargetDir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);

	opendir(Dir, $SourceDir) or &Exit("Can't open theme directory $SourceDir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	foreach $File (readdir(Dir)) {
			if ($File eq "." || $File eq ".." || !-f "$SourceDir/$File") {next;}
			copy("$SourceDir/$File",	"$TargetDir/$File") or &Exit("Can't copy file $SourceDir/$File to $TargetDir/$File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			chmod (0755, "$TargetDir/$File");
    }

	closedir(Dir);
	chmod (0755, $TargetDir);
	#------------------------------------------------------
	&ThemeManager(qq!<p align="center"><font size="3" color="red"><b>New theme successfully created</b></p>!);
}
#==========================================================
sub Scan_Directory_Tree{
my ($Directory) = @_;
my (@Directories, %Found);

	%Found = &Scan_Dir($Directory);
	undef @Directories;
	while (($Key, $Value)= each %Found) {
			if ($Value) {
				push @Directories, $Key;
			}
	}
	return @Directories;
}
#==========================================================
sub Scan_Directory{
my ($Directory)=@_;
my (@Files, %Found);

	%Found = ();
	@Files = ();
	my $CRLF = "\015\012"; # how lines should be terminated; "\r\n" is not correct on all systems, for instance MacPerl defines it to "\012\015"
	%Found = &Scan_Dir($Directory);
	while (($Key, $Value)= each %Found) {
			if (!$Value) {
				push @Files, $Key;
			}
	}
	return @Files;
}
#==========================================================
sub Scan_Dir{
my ($Directory)=@_;
my (@Directories, @Files, %Found);
my ($Current_Directory);

	undef @Directories;
	undef %Found;
	undef @Files;
	if (!$Directory) {$Directory = '.';}
	push @Directories, $Directory;
	while (@Directories) {
		   $Current_Directory = shift (@Directories);
		   opendir (DIR, "$Current_Directory") 
					or &Exit( "Cannot open directory $Current_Directory: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);
		   @Files = readdir (DIR);
		   closedir (DIR);
		   foreach $File (@Files) {
					$Temp = "$Current_Directory/$File";
					  if (-d $Temp && $File ne "." && $File ne "..") {
								push @Directories, $Temp;
								$Found{$Temp} = 1;
								next;
					  }
					  else{
								if ($File ne "." && $File ne "..") {
										$Found{$Temp} = 0;
								}
					  }
			}
	}
	return %Found;
}
#==========================================================

1;