=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Check_Referer{
	$Check=&Check_Referers;
	if ($Check == 0) {
		print "Content-type: text/html\n\n";
		&Msg($Language{referer_error_title}, $Language{referer_error_msg}, 1);
		exit 0;
	}
}
#==========================================================
sub Get_Languages{
my (@Languages);

	$Global{Languages} ||= "English";
	@Languages=split(/\|/, $Global{Languages});
	return @Languages;
}
#==========================================================
sub Prepare_Language_List{
my (@Files, $file, $Langs);
my (%Config);

	undef @Files;
	opendir(Dir, "$Global{Language_Dir}");
	foreach $File (readdir(Dir)) {
			push (@Files, "$File");
    }

	closedir(Dir);

	@Files =sort @Files;
	
	$Langs = "";
	foreach $File(@Files) {
		if (-d "$Global{Language_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
					$Langs .= "|$File";
		}
 
	}
	$Langs =~ s/^\|//g;
	
	undef %Config;
	$Config{Languages} = $Langs;
	&Update_Configuration(%Config);
}
#==========================================================
sub Access_Lock_Status{

	if ($Global{Access_Lock_Status} == 0) {
		return 0;
	}
	else{
		&Read_Language_File($Global{Language_General_File});
		&Read_Language_File($Global{Language_Access_Lock_File});
		print "Content-Type: text/html\n\n";
		print  $Language{access_lock_header};
		print  $Language{access_lock_title};
		print  $Language{access_lock_description};
		print  $Language{access_lock_time};
		#print &Long_Date_Time;
		print  $Language{access_lock_signature};
		exit 0;
	}
	
}
#==========================================================
sub Exit{
my($Msg, $Title, $Level)=@_;
my ($Out);

	if ($Title eq "") {$Title="Error";	}
	$Out = &Error($Msg, $Title, $Level);
	print "Content-type: text/html\n\n";
	print "$Out";
	if ($dbh) {
			&DB_Disconnect();
	}
	exit 0;
}
#==========================================================
sub Quit{

	if ($dbh) {
			&DB_Disconnect();
	}
	exit 0;
}
#==========================================================
sub Read_Language_File{
my ($Filename) = shift;
my (@Variables, $Line, $Key, $Value);

	open(FILE, "$Filename") || &Exit("Error: Can't open language file $Filename: $!" ."<br>Line ". __LINE__ . ", File ". __FILE__);
	@Variables = <FILE>;
	close(FILE);
	
	foreach $Line (@Variables) {
		chomp($Line);
		($Key, $Value) = split ("~==~", $Line);
		$Value =~ s/\'/\&\#39\;/g;
		$Language{$Key} = "$Value";
	}

}
#==========================================================
sub Get_Language_File{ 
my ($Filename) = shift;
my (%Langs, @Variables, $Line);
my ($Key, $Value);

	open(FILE, "$Filename") || &Exit("Error: Can't open language file $Filename: $!" ."<br>Line ". __LINE__ . ", File ". __FILE__);
	@Variables = <FILE>;
	close(FILE);
	
	undef %Langs;
	foreach $Line (@Variables) {
		chomp($Line);
		($Key, $Value) = split("~==~", $Line);
		$Value =~ s/\'/\&\#39\;/g;
		$Langs{$Key} = "$Value";
	}

	return  %Langs;
}
#==========================================================
sub Get_List_Templates{ 
my (%Forms, @Forms, $Line);
my ($Key, $Value);

	open(FILE, "$Global{List_Template_File}") || &Exit("Error: Can't open listings template file $Global{List_Template_File}: $!"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@Forms = <FILE>;
	close(FILE);
	
	foreach $Line (@Forms) {
						$Line =~ s/\n$//g;
						$Line =~ s/^\s+//g;
						($Key, $Value) = split("~==~", $Line);
						$Value =~ s/\'/\&\#39\;/g;
						$Value =~ s/\\n/\n/g;
						if ($Key) {
								$Forms{$Key} = "$Value";
						}
	}

	return  %Forms;
}
#==========================================================
sub Yes_No{
my ($Status) = shift;

	if (!$Status) {return $Language{no_label};}
	return $Language{yes_label}
}
#==========================================================
sub Get_File{
my ($File)=shift;
my (@Temp, $Out);

	open(IN, "$File") || &Exit("Error, Can't open file $File: $!"."<br>Line ". __LINE__ . ", File ". __FILE__);
    @Temp = <IN>;
    close(IN);

	$Out = join("", @Temp);
	return $Out;
}
#==========================================================
sub Whos_Online{
my ($IP, $TimeOut, $Time, $Query, $sth, $User_ID, $Visitors, $Users, @Row);

	$IP = $ENV{REMOTE_ADDR};
	$IP = $dbh->quote($IP);

	$TimeOut = time - $Global{Whos_Online_Time_Out};

	$Query = qq!DELETE FROM Whos_Online WHERE Time < $TimeOut!;
	$sth = $dbh->do($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);

	$Query = qq!DELETE FROM Whos_Online WHERE IP=$IP!;
	$sth = $dbh->do($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);

	$Time = time;
	$Param{User_ID} ||= "";
	$User_ID =	 $dbh->quote($Param{User_ID});

	$Query = qq!INSERT INTO Whos_Online VALUES($IP, $User_ID, $Time)!;
	$sth = $dbh->do($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);

	$Query = qq!SELECT IP, User_ID FROM Whos_Online WHERE Time>=$TimeOut!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
	$sth ->execute || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
	
	$Visitors = 0; $Users = 0;

	while (@Row = $sth->fetchrow_array) {
			if ($Row[0]) {$Visitors ++;}
			if ($Row[1]) {$Users ++;}
	}
	$sth->finish;
	$Guests = $Visitors - $Users;
	if ($Guests < 0) {$Guests = 0;}

	$Plugins{Whos_Online} =  $Visitors;
	$Plugins{Whos_Online_Users} = $Users;
	$Plugins{Whos_Online_Guests} = $Guests;

	return ($Visitors, $Users,  $Guests);
}
#==========================================================
sub Check_SSL_Graphics{
	if ($Global{SSL_Status}){
		$Global{Images_URL} = $Global{Images_URL_SSL};	
	}
}
#==========================================================
sub ReadThemeConfig{
my (@Temp, %Classes, $K, $V);

	open(FILE, "$Global{ThemeConfigFile}") || &Exit("Error, Can't open file $Global{ThemeConfigFile}: $!"."<br>Line ". __LINE__ . ", File ". __FILE__);
    @Temp = <FILE>;
    close(FILE);
	
	undef %Classes;

	foreach $Line (@Temp) {
			$Line =~ s/\n$//;
			if (!$Line) {next;}
			($K, $V) = split(/\~\=\=\~/, $Line);
			if (!$K) {next;}
			$V =~ s/\\n/\n/g;
			$Classes{$K} = $V;
	}

	return %Classes;
}
#==========================================================
sub LanguagesList{
my ($Language) = @_;
my ($Out, @Files, $File, $Selected);

	undef @Files;
	opendir(Dir, $Global{Language_Dir});
	foreach $File (readdir(Dir)) {
			if (-d "$Global{Language_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
					push @Files, $File;
			}
    }
	closedir(Dir);
	return @Files;
 }
#==========================================================
sub ThemesList{
my (@Files, $File);

	undef @Files;
	opendir(Dir, "$Global{Data_Dir}/templates");
	foreach $File (readdir(Dir)) {
			if (-d "$Global{Data_Dir}/templates/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
					push @Files, $File;
			}
    }
	closedir(Dir);
	return @Files;
 }
#==========================================================
sub Get_IP_Hostname{
my ($IP_Address) = @_;
my (@Numbers, $IP_Number, $Host);

	@Numbers = split(/\./, $IP_Address);
	$IP_Number = pack("C4", @Numbers);
	$Host = (gethostbyaddr($IP_Number, 2))[0];
	return $Host;
}
#==========================================================
sub ReadGeneralClassesNames{
my ($Line, %Class);

	open (F, "$Global{Data_Dir}/GeneralClasses.pm") || &Exit("Cannot open configuration file $Global{Data_Dir}/SpecialClasses.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Class;
	foreach $Line (<F>){
			$Line =~ s/\n$//g;
			$Line =~ s/\s+//g;
			if (!$Line) {next;}
			$Class{$Line} = 1;
	}
	close(F);
	return keys %Class;
}
#==========================================================
sub ReadSpecialClassesNames{
my ($Line, %Class);

	open (F, "$Global{Data_Dir}/SpecialClasses.pm") || &Exit("Cannot open configuration file $Global{Data_Dir}/SpecialClasses.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Class;
	foreach $Line (<F>){
			$Line =~ s/\n$//g;
			$Line =~ s/\s+//g;
			if (!$Line) {next;}
			$Class{$Line} = 1;
	}
	close(F);
	return keys %Class;
}
#==========================================================
sub GetUploadFile {
my ($Name) = @_;
my ($Filename, $UploadFile, $Content, @Name);
	
	if (!$Paramx{$Name}) {
		return (undef, undef);
	}

	$Filename = "";
	$UploadFile = $Paramx{$Name};
	$UploadFile =~ /\r\n\r\n|\n\n/;         #separate header and body 
	$Filename = $`;                # front part
	$Content = $';             # rear part
	$Content =~ s/\r\n$//;  # the last \r\n was put in by Netscape

	# Parse uploaded files
	$Filename =~ /filename=\"(.+)\"/; 
	$Filename = $1;
	$Filename =~ s/\"//g; # remove "s
	$Filename =~ s/\s//g; # make sure no space(include \n, \r..) in the file name 
	@Name = split(/[\/|\\]/, $Filename); 
	$Filename = pop @Name;
	return ($Filename, $Content);
}
#==========================================================
sub RemoveDiacritic {
my ($Text) = @_;

	#Windows Arabic (1256) 
	#$Text =~ s/\xF0//g;		#ARABIC FATHATAN
	#$Text =~ s/\xF1//g;		#ARABIC DAMMATAN
	#$Text =~ s/\xF2//g;		#ARABIC KASRATAN
	#$Text =~ s/\xF3//g;		#ARABIC FATHA
	#$Text =~ s/\xF5//g;		#ARABIC DAMMA
	#$Text =~ s/\xF6//g;		#ARABIC KASRA
	#$Text =~ s/\xF8//g;		#ARABIC SHADDA
	#$Text =~ s/\xFA//g;	#ARABIC SUKUN
	$Text =~ s/\xF0|\xF1|\xF2|\xF3|\xF5|\xF6|\xF8|\xFA//g;
	#Allah Isolated form: ���  = \x{e1}\x{e1}\x{e5}, = Unicode &#65010; = &#xFDF2; = &#1604;&#1604;&#1607;

	# 1256  - Uindex - UISOname 
	#	F0 064B ARABIC FATHATAN 
	#	F1 064C ARABIC DAMMATAN 
	#	F2 064D ARABIC KASRATAN 
	#	F3 064E ARABIC FATHA 
	#	F5 064F ARABIC DAMMA 
	#	F6 0650 ARABIC KASRA 
	#	F8 0651 ARABIC SHADDA 
	#	FA 0652 ARABIC SUKUN 
	
	#Unicode Hex
	#$Text =~ s/\x{064B}//g;
	#$Text =~ s/\x{064C}//g;
	#$Text =~ s/\x{064D}//g;
	#$Text =~ s/\x{064E}//g;
	#$Text =~ s/\x{064F}//g;
	#$Text =~ s/\x{0650}//g;
	#$Text =~ s/\x{0651}//g;
	#$Text =~ s/\x{0652}//g;
	
	#Unicode Decimal
	#$Text =~ s/\&\#1611\;//g;	# 064B		,	ARABIC FATHATAN
	#$Text =~ s/\&\#1612\;//g;	# 064C		,	ARABIC DAMMATAN
	#$Text =~ s/\&\#1613\;//g;	# 064D	,	ARABIC KASRATAN
	#$Text =~ s/\&\#1614\;//g;	# 064E	 	,	ARABIC FATHA
	#$Text =~ s/\&\#1615\;//g;	# 064F		,	ARABIC DAMMA
	#$Text =~ s/\&\#1616\;//g;	# 0650		,	ARABIC KASRA
	#$Text =~ s/\&\#1617\;//g;	# 0651		,	ARABIC SHADDA
	#$Text =~ s/\&\#1618\;//g;	# 0652		,	ARABIC SUKUN
	#http://www.microsoft.com/typography/unicode/1256.htm
	
	$Text =~ s/\&\#1611\;|\&\#1612\;|\&\#1613\;|\&\#1614\;|\&\#1615\;|\&\#1616\;|\&\#1617\;|\&\#1618\;//g;

	return $Text;
}
#==========================================================

1;