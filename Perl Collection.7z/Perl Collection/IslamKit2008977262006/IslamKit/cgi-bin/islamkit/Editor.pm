=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Class_Editor{
my ($Help);

	$Param{EditorTheme} ||= $Global{Theme};
	$Help = &Help_Link("Class_Editor");
	&Print_Page(&Class_Editor_Form, "Class Editor - $Param{EditorTheme}", $Help);
}
#==========================================================
sub Class_Editor_Form{
my($Out, %Class, @Class, $Classes, %Custom);
my($Class_Index, $Class, $x, $y, $Key);

	$Param{EditorTheme} ||= $Global{Theme};
	#------------------------------------------------------------------
	open (FILE, "$Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm") || &Exit("Cannot open configuration file $Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	undef %Class;
	foreach $Line(@All){
			($K, $V) = split(/\~\=\=\~/ , $Line);
			$V =~ s/\n$//g;
			$V=~ s/\\n/\n/g;
			if (!$K) {next;}
			$Class{$K} = &Encode_HTML($V);
	}
	#------------------------------------------------------------------
	open (FILE, "$Global{Data_Dir}/GeneralClasses.pm") || &Exit("Cannot open configuration file $Global{Data_Dir}/GeneralClasses.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	undef %General;
	foreach $Line(@All){
			$Line =~ s/\n$//g;
			$Line =~ s/\s+//g;
			if (!$Line) {next;}
			$General{$Line} = 1;
	}
	@General = keys %General;
	#------------------------------------------------------------------
	open (FILE, "$Global{Data_Dir}/SpecialClasses.pm") || &Exit("Cannot open configuration file $Global{Data_Dir}/SpecialClasses.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	undef %Special;
	foreach $Line(@All){
			$Line =~ s/\n$//g;
			$Line =~ s/\s+//g;
			if (!$Line) {next;}
			$Special{$Line} = 1;
	}
	@Special = keys %Special;
	#------------------------------------------------------------------
	%Custom = %Class;
	foreach $Class (@General) { # User created custom classes
			delete $Custom{$Class};
	}
	foreach $Class (@Special) { # User created custom classes
			delete $Custom{$Class};
	}
	@Custom = keys %Custom;

	@General = sort @General;
	@Custom = sort @Custom;
	@Special = sort @Special;
	
	unshift @General, '';
	unshift @Custom, '';
	unshift @Special, '';

	push @Class, @General;
	push @Class, @Custom;
	push @Class, @Special;

	$Class_Index = "";
	for $x(0..$#Class) {
			$y = $x+1;
			 $Class_Index .= qq!Class_Index[$y] = \'$Class[$x]\';\n!;
	}

	$EditClassName = ""; $EditClassText = "";
	$Param{Class_Name} ||= $Class[0];

	$Classes = "";
	foreach $Class(@General) {
		if ($Class eq '') {
				$Classes .= qq!<option value="" style="background-color:#005B00; color:#FFFFCC;">--------------------- General Classes ---------------------</option>!;
				next;
		}
		$Selected = "";
		if ($Class eq $Param{Class_Name}) {$Selected ="selected"; $EditClassName = $Param{Class_Name}; $EditClassText = $Class{$Class};}
		$Classes .= qq!<option value="$Class{$Class}" style="background-color:#FFFFCC; color:#000000;" $Selected>$Class</option>!;
	}
	
	foreach $Class(@Custom) {
		if ($Class eq '') {
				$Classes .= qq!<option value="" style="background-color:#9B009B; color:#FFFFFF;">---------------- Custom General Classes ---------------</option>!;
				next;
		}
		$Selected = "";
		if ($Class eq $Param{Class_Name}) {$Selected ="selected"; $EditClassName = $Param{Class_Name}; $EditClassText = $Class{$Class};}
		$Classes .= qq!<option value="$Class{$Class}"  style="background-color:#D2F0FF; color:#000000;" $Selected>$Class</option>!;
	}

	foreach $Class(@Special) {
		if ($Class eq '') {
				$Classes .= qq!<option value="" style="background-color:#CC0000; color:#FFFFCC;">--------------------- Special Classes ---------------------</option>!;
				next;
		}
		$Selected = "";
		if ($Class eq $Param{Class_Name}) {$Selected ="selected"; $EditClassName = $Param{Class_Name}; $EditClassText = $Class{$Class};}
		$Classes .= qq!<option value="$Class{$Class}"  style="background-color:#CCFFCC; color:#000000;" $Selected>$Class</option>!;
	}
	$Global{AdminEditorRows} ||= 25;
	$Global{AdminEditorColumns} ||= 80;
	#------------------------------------------------------------------
	@Themes = &ThemesList;
	$Themes = "";
	$Themes .= qq!<option value="" style="background-color:#CC0099; color:#FFFFCC;">-- Theme --</option>!;
	foreach $Theme(sort @Themes) {
			$Selected = "";
			if ($Theme eq $Param{EditorTheme}) {$Selected = "selected";}
			$Themes .= qq!<option value="$Theme" style="background-color:#FFFFCC; color:#000000;" $Selected>$Theme</option>!;
	}
	#------------------------------------------------------------------
	@Colors = ('BLACK','RED','GREEN','BLUE','AQUA','GRAY','NAVY','SILVER','OLIVE','TEAL','LIME','PURPLE','WHITE','FUCHSIA','MAROON','YELLOW','#000000','#003300','#006600','#009900','#00CC00','#00FF00','#000033','#003333','#006633','#009933','#00CC33','#00FF33','#000066','#003366','#006666','#009966','#00CC66','#00FF66','#000099','#003399','#006699','#009999','#00CC99','#00FF99','#0000CC','#0033CC','#0066CC','#0099CC','#00CCCC','#00FFCC','#0000FF','#0033FF','#0066FF','#0099FF','#00CCFF','#00FFFF','#330000','#333300','#336600','#339900','#33CC00','#33FF00','#330033','#333333','#336633','#339933','#33CC33','#33FF33','#330066','#333366','#336666','#339966','#33CC66','#33FF66','#330099','#333399','#336699','#339999','#33CC99','#33FF99','#3300CC','#3333CC','#3366CC','#3399CC','#33CCCC','#33FFCC','#3300FF','#3333FF','#3366FF','#3399FF','#33CCFF','#33FFFF','#660000','#663300','#666600','#669900','#66CC00','#66FF00','#660033','#663333','#666633','#669933','#66CC33','#66FF33','#660066','#663366','#666666','#669966','#66CC66','#66FF66','#660099','#663399','#666699','#669999','#66CC99','#66FF99','#6600CC','#6633CC','#6666CC','#6699CC','#66CCCC','#66FFCC','#6600FF','#6633FF','#6666FF','#6699FF','#66CCFF','#66FFFF','#990000','#993300','#996600','#999900','#99CC00','#99FF00','#990033','#993333','#996633','#999933','#99CC33','#99FF33','#990066','#993366','#996666','#999966','#99CC66','#99FF66','#990099','#993399','#996699','#999999','#99CC99','#99FF99','#9900CC','#9933CC','#9966CC','#9999CC','#99CCCC','#99FFCC','#9900FF','#9933FF','#9966FF','#9999FF','#99CCFF','#99FFFF','#CC0000','#CC3300','#CC6600','#CC9900','#CCCC00','#CCFF00','#CC0033','#CC3333','#CC6633','#CC9933','#CCCC33','#CCFF33','#CC0066','#CC3366','#CC6666','#CC9966','#CCCC66','#CCFF66','#CC0099','#CC3399','#CC6699','#CC9999','#CCCC99','#FDF2CE','#CC00CC','#CC33CC','#CC66CC','#CC99CC','#CCCCCC','#CCFFCC','#CC00FF','#CC33FF','#CC66FF','#CC99FF','#CCCCFF','#CCFFFF','#FF0000','#FF3300','#FF6600','#FF9900','#FFCC00','#FFFF00','#FF0033','#FF3333','#FF6633','#FF9933','#FFCC33','#FFFF33','#FF0066','#FF3366','#FF6666','#FF9966','#FFCC66','#FFFF66','#FF0099','#FF3399','#FF6699','#FF9999','#FFCC99','#FFFF99','#FF00CC','#FF33CC','#FF66CC','#FF99CC','#FFCCCC','#FFFFCC','#FF00FF','#FF33FF','#FF66FF','#FF99FF','#FFCCFF','#FFFFFF');
	
	$AdminEditorBackground = "";
	foreach $Color (@Colors) {
			$Selected = "";
			if ($Color eq $Global{AdminEditorBackground}) {$Selected = "selected";}
			$AdminEditorBackground .= qq!<option value="$Color" style="background-color:$Color; color:#000000;" $Selected>$Color</option>!;
	}

	$AdminEditorForeground = "";
	foreach $Color (@Colors) {
			$Selected = "";
			if ($Color eq $Global{AdminEditorForeground}) {$Selected = "selected";}
			$AdminEditorForeground .= qq!<option value="$Color" style="background-color:$Color; color:#000000;" $Selected>$Color</option>!;
	}
	#------------------------------------------------------
	if ($Global{AdminVisualEditor}) {
			$Plugins{HeadCode} = &HTML_Editor_Code_Admin("Class");
			$EditorBorder = "1";
			$AdminVisualEditor = "checked";
	}
	else{
			$Plugins{HeadCode} = "";
			$EditorBorder = "0";
			$AdminVisualEditor = "";
	}
	#------------------------------------------------------

$Out =<<HTML;
<form method="POST" name ="Classes_Form" ACTION="$Script_URL">
<input type="hidden" name="action" value="Save_Editor_Class">
<input type="hidden" name="Class_Name" value="$EditClassName">
<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
<table border="0" width="100%" cellspacing="0" cellpadding="2">
  <tr><td width="100%" align="left">
		<select name="Themes" onChange="Change_Theme();">$Themes</select>
		<select name="Classes" onChange="Change_Class();">$Classes</select>

		<input type="submit" value="Save Class" style="color: #000080; border-style: ridge">&nbsp;&nbsp;
          <input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
  </tr>
  <tr><td width="100%" align="left"> 
			<table border="$EditorBorder" width="100%" cellspacing="0" cellpadding="0">
			  <tr><td width="100%" align="left" valign="top">
					<textarea ID="Class" name="Class" rows="$Global{AdminEditorRows}" cols="$Global{AdminEditorColumns}" style="border: 3px groove #808080; padding: 2; background-color:$Global{AdminEditorBackground}; color:$Global{AdminEditorForeground};border-style: groove">$EditClassText</textarea>
				</td>
			  </tr>
			</table>
	</td>
  </tr>
</table>
</form>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>Create General Class</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
    <tr>
		<form method="post" name ="New_Classes_Form" action="$Script_URL">
		<input type="hidden" name="action" value="Create_Custom_Class">
		<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
    <tr><td nowrap>New Class Name:</td>
      <td width="90%">
			<input type="text" value="" name="New_Custom_Class" size="30">&nbsp;
			<input type="submit" value="Create Class" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
    <tr><td width="100%" colspan="2" align="center"></td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>Editor Settings</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
    <tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="SaveEditorSetting">
		<input type="hidden" name="Editor" value="Class_Editor">
		<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
	<tr><td nowrap colspan="2" nowrap>
			<b>Text Mode:</b> &nbsp;
			Rows: <input type="text" name="AdminEditorRows" value="$Global{AdminEditorRows}" size="5">&nbsp;
			Columns: <input type="text" name="AdminEditorColumns" value="$Global{AdminEditorColumns}" size="5">&nbsp;
	</td>
	
    </tr>

	<tr><td nowrap colspan="2" nowrap>
			Background Color : <select name="AdminEditorBackground" >$AdminEditorBackground</select>
			Foreground Color: <select name="AdminEditorForeground" >$AdminEditorForeground</select>
	</td></tr>
	<tr><td nowrap colspan="2" nowrap>
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td></tr>

    <tr><td width="100%" colspan="2" align="center"></td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!--------------------------------------------------------------------------------->
<SCRIPT LANGUAGE="JavaScript">
<!--
function Change_Class() {
var Class_Index = new Array(); 
$Class_Index
	var Selected;
	Selected = document.Classes_Form.Classes.selectedIndex;
	Value = document.Classes_Form.Classes[Selected].value;
	document.Classes_Form.Class.value = document.Classes_Form.Classes[Selected].value;
	Selected++;
	document.Classes_Form.Class_Name.value = ''+Class_Index[Selected];
}

function Change_Theme() {
	var Theme;
	if (!document.Classes_Form.Themes.selectedIndex) {return false;}
	Theme = document.Classes_Form.Themes[document.Classes_Form.Themes.selectedIndex].value;
	window.location = "$Script_URL?action=Class_Editor&EditorTheme=" +Theme;
}

// -->
</SCRIPT>

<!-------------------------------------------------->
<script type="text/javascript">
function mySubmit() {
	//document.Classes_Form.save.value = "yes";
	//document.Classes_Form.onsubmit(); // workaround browser bugs.
	document.Classes_Form.submit();
};
</script>
<!-------------------------------------------------->
HTML

	return $Out;
}
#==========================================================
sub Save_Editor_Class{
my (@All, %Config, $Line, $Key, $Value, @Keys);

	if (!$Param{Class_Name}) {
				&Class_Editor;
				return;
	}

	$Param{Class} =~ s/\cM//g;

	open (FILE, "$Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm") || &Exit("Cannot open file $Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);

	undef %Config;
	foreach $Line(@All){
			$Line =~ s/\n$//;
			($Key, $Value) = split(/\~\=\=\~/ , $Line);
			$Value =~ s/\\n/\n/g;
			$Config{$Key} = $Value;
	}
	
	$Config{$Param{Class_Name}} = $Param{Class};

	open (FILE, ">$Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm") || &Exit("Cannot write file $Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@Keys = sort keys %Config;
	foreach $Key (@Keys) {
			$Value  = $Config{$Key};
			$Value  =~ s/\n/\\n/g;
			print FILE  "$Key~==~$Value\n";
	}
	close(FILE);

	&Read_Configuration;
	&Class_Editor;
}
#==========================================================
sub SaveEditorSetting{
my (%Config, $Key);

	undef %Config;
	$Param{AdminEditorRows} ||= 25;
	$Param{AdminEditorColumns} ||= 80;
	$Param{AdminEditorBackground} ||= '#99FFFF';
	$Param{AdminEditorForeground} ||= '#000000';

	$Param{AdminEditorWidth} ||= 700;
	$Param{AdminEditorHeight} ||= 300;
	$Param{AdminVisualEditor} ||= 0;

	$Config{AdminEditorRows} = $Param{AdminEditorRows};
	$Config{AdminEditorColumns} = $Param{AdminEditorColumns};
	$Config{AdminEditorBackground} = $Param{AdminEditorBackground};
	$Config{AdminEditorForeground} = $Param{AdminEditorForeground};
	$Config{AdminEditorWidth} = $Param{AdminEditorWidth};
	$Config{AdminEditorHeight} = $Param{AdminEditorHeight};
	$Config{AdminVisualEditor} = $Param{AdminVisualEditor};
	
	&Update_Configuration(%Config);

	foreach $Key (keys %Config) {
			$Global{$Key} = $Config{$Key};
	}

	if ($Param{Editor} eq "Class_Editor") {
		&Class_Editor;
	}
	elsif ($Param{Editor} eq "Template_Editor") {
			&Template_Editor;
	}
	else{
			&Template_Editor;
	}
}
#==========================================================
sub Template_Editor{
my ($Help);

	$Help = &Help_Link("Template_Editor");
	&Print_Page(&Template_Editor_Form, "Template Editor - $Param{File}", $Help);
}
#==========================================================
sub Template_Editor_Form{
my($Out, %Class, @Class, $Classes, @Files, $File);
my($Class_Index, $Class, $x, $y, %Details);
	
	$Param{EditorTheme} ||= $Global{Theme};
	$Directory = "$Global{Data_Dir}/templates/$Param{EditorTheme}";

	undef @Files;
	opendir(Dir,$Directory);
	foreach $File (readdir(Dir)) {
			if( -f "$Directory/$File" && $File ne "." && $File ne ".." && $File !~ /\.bak$/i && $File !~ /\.pm$/i) { 
				push @Files, $File;
			}
    }
	closedir(Dir);
	@Files = sort @Files;

	#----------------------------------------------------------------
	# Get the templates names
	undef %Details;
	open (FILE, "$Global{Data_Dir}/ThemeFiles.pm") || &Exit("Cannot open file $Global{Data_Dir}/ThemeFiles.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	foreach $Line(@All){
			$Line =~ s/\n$//; next if (!$Line);
			($Key, $Value) = split(/\=/ , $Line);
			next if (!$Key);
			$Value =~ s/\\n/\n/g;
			$Details{$Key} = $Value;
	}
	#----------------------------------------------------------------
	$Param{File} ||= $Files[0];
	$Files = "";
	foreach $File(@Files) {
		$Name = $File;
		if (defined $Details{$File}) {$Name = $Details{$File};}
		$Selected = "";
		if ($File eq $Param{File}) {$Selected = "selected";}
		$Files .= qq!<OPTION VALUE="$File" $Selected>$Name</OPTION>!;
	}
	#------------------------------------------------------------------
	@Themes = &ThemesList;
	$Themes = "";
	$Themes .= qq!<option value="" style="background-color:#CC0099; color:#FFFFCC;">-- Theme --</option>!;
	foreach $Theme(sort @Themes) {
			$Selected = "";
			if ($Theme eq $Param{EditorTheme}) {$Selected = "selected";}
			$Themes .= qq!<option value="$Theme" style="background-color:#FFFFCC; color:#000000;" $Selected>$Theme</option>!;
	}
	#------------------------------------------------------------------
	@Colors = ('BLACK','RED','GREEN','BLUE','AQUA','GRAY','NAVY','SILVER','OLIVE','TEAL','LIME','PURPLE','WHITE','FUCHSIA','MAROON','YELLOW','#000000','#003300','#006600','#009900','#00CC00','#00FF00','#000033','#003333','#006633','#009933','#00CC33','#00FF33','#000066','#003366','#006666','#009966','#00CC66','#00FF66','#000099','#003399','#006699','#009999','#00CC99','#00FF99','#0000CC','#0033CC','#0066CC','#0099CC','#00CCCC','#00FFCC','#0000FF','#0033FF','#0066FF','#0099FF','#00CCFF','#00FFFF','#330000','#333300','#336600','#339900','#33CC00','#33FF00','#330033','#333333','#336633','#339933','#33CC33','#33FF33','#330066','#333366','#336666','#339966','#33CC66','#33FF66','#330099','#333399','#336699','#339999','#33CC99','#33FF99','#3300CC','#3333CC','#3366CC','#3399CC','#33CCCC','#33FFCC','#3300FF','#3333FF','#3366FF','#3399FF','#33CCFF','#33FFFF','#660000','#663300','#666600','#669900','#66CC00','#66FF00','#660033','#663333','#666633','#669933','#66CC33','#66FF33','#660066','#663366','#666666','#669966','#66CC66','#66FF66','#660099','#663399','#666699','#669999','#66CC99','#66FF99','#6600CC','#6633CC','#6666CC','#6699CC','#66CCCC','#66FFCC','#6600FF','#6633FF','#6666FF','#6699FF','#66CCFF','#66FFFF','#990000','#993300','#996600','#999900','#99CC00','#99FF00','#990033','#993333','#996633','#999933','#99CC33','#99FF33','#990066','#993366','#996666','#999966','#99CC66','#99FF66','#990099','#993399','#996699','#999999','#99CC99','#99FF99','#9900CC','#9933CC','#9966CC','#9999CC','#99CCCC','#99FFCC','#9900FF','#9933FF','#9966FF','#9999FF','#99CCFF','#99FFFF','#CC0000','#CC3300','#CC6600','#CC9900','#CCCC00','#CCFF00','#CC0033','#CC3333','#CC6633','#CC9933','#CCCC33','#CCFF33','#CC0066','#CC3366','#CC6666','#CC9966','#CCCC66','#CCFF66','#CC0099','#CC3399','#CC6699','#CC9999','#CCCC99','#FDF2CE','#CC00CC','#CC33CC','#CC66CC','#CC99CC','#CCCCCC','#CCFFCC','#CC00FF','#CC33FF','#CC66FF','#CC99FF','#CCCCFF','#CCFFFF','#FF0000','#FF3300','#FF6600','#FF9900','#FFCC00','#FFFF00','#FF0033','#FF3333','#FF6633','#FF9933','#FFCC33','#FFFF33','#FF0066','#FF3366','#FF6666','#FF9966','#FFCC66','#FFFF66','#FF0099','#FF3399','#FF6699','#FF9999','#FFCC99','#FFFF99','#FF00CC','#FF33CC','#FF66CC','#FF99CC','#FFCCCC','#FFFFCC','#FF00FF','#FF33FF','#FF66FF','#FF99FF','#FFCCFF','#FFFFFF');
	
	$AdminEditorBackground = "";
	foreach $Color (@Colors) {
			$Selected = "";
			if (lc($Color) eq lc($Global{AdminEditorBackground})) {$Selected = "selected";}
			$AdminEditorBackground .= qq!<option value="$Color" style="background-color:$Color; color:#000000;" $Selected>$Color</option>!;
	}

	$AdminEditorForeground = "";
	foreach $Color (@Colors) {
			$Selected = "";
			if (lc($Color) eq lc($Global{AdminEditorForeground})) {$Selected = "selected";}
			$AdminEditorForeground .= qq!<option value="$Color" style="background-color:$Color; color:#000000;" $Selected>$Color</option>!;
	}
	
	$EditorText = "";
	if ($Param{File}) {
			$File = "$Global{Data_Dir}/templates/$Param{EditorTheme}/$Param{File}";
			open (FILE, "$File") || &Exit("Cannot open file $File: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
			@All = <FILE>;
			close(FILE);
			$EditorText = join("", @All);
			$EditorText = &Encode_HTML($EditorText);
	}
	#------------------------------------------------------
	if ($Global{AdminVisualEditor}) {
			$Plugins{HeadCode} = &HTML_Editor_Code_Admin("Text");
			$EditorBorder = "1";
			$AdminVisualEditor = "checked";
	}
	else{
			$Plugins{HeadCode} = "";
			$EditorBorder = "0";
			$AdminVisualEditor = "";
	}
	#------------------------------------------------------

$Out =<<HTML;
<form method="post" name ="Editor_Form" ACTION="$Script_URL">
<input type="hidden" name="action" value="Save_Template_Editor">
<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
<table border="0" width="100%" cellspacing="0" cellpadding="2">
  <tr><td width="100%" align="left">
		<select name="Themes" onChange="Change_Theme();">$Themes</select>
		<select name="File" onChange="Change_File();">$Files</select>

		<input type="submit" value="Save File" style="color: #000080; border-style: ridge">&nbsp;&nbsp;
          <input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
  </tr>
  <tr><td width="100%" align="left"> 
			<table border="$EditorBorder" width="100%" cellspacing="0" cellpadding="0">
			  <tr><td width="100%" align="left" valign="top">
					<textarea ID="Text" name="Text" rows="$Global{AdminEditorRows}" cols="$Global{AdminEditorColumns}" style="border: 3px groove #808080; padding: 2; background-color:$Global{AdminEditorBackground}; color:$Global{AdminEditorForeground};border-style: groove">$EditorText</textarea>
				</td>
			  </tr>
			</table>

	</td>
  </tr>
</table>
</form>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>Create Custom Page</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
    <tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="Create_Custom_Page">
		<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
    <tr><td nowrap>New Custom Page Name:</td>
      <td width="90%">
			<input type="text" value="" name="Name" size="40">&nbsp;
			<input type="submit" value="Create Page" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
    <tr><td width="100%" colspan="2" align="center"></td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>Create New File</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
    <tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="Create_New_Template">
		<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
    <tr><td nowrap>New File Name:</td>
      <td width="90%">
			<input type="text" value="" name="New_File" size="40">&nbsp;
			<input type="submit" value="Create File" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
    <tr><td width="100%" colspan="2" align="center"></td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>Editor Settings</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
    <tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="SaveEditorSetting">
		<input type="hidden" name="Editor" value="Class_Editor">
		<input type="hidden" name="EditorTheme" value="$Param{EditorTheme}">
	<tr><td nowrap colspan="2" nowrap>
			<b>Text Mode:</b> &nbsp;
			Rows: <input type="text" name="AdminEditorRows" value="$Global{AdminEditorRows}" size="5">&nbsp;
			Columns: <input type="text" name="AdminEditorColumns" value="$Global{AdminEditorColumns}" size="5">&nbsp;
	</td>
	
    </tr>
	<tr><td nowrap colspan="2" nowrap>
			Background Color : <select name="AdminEditorBackground" >$AdminEditorBackground</select>
			Foreground Color: <select name="AdminEditorForeground" >$AdminEditorForeground</select>
	</td></tr>
	<tr><td nowrap colspan="2" nowrap>
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td></tr>

    <tr><td width="100%" colspan="2" align="center"></td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!--------------------------------------------------------------------------------->
<SCRIPT LANGUAGE="JavaScript">
<!--
function Change_File() {
	var File;
	if (!document.Editor_Form.File.selectedIndex) {return false;}
	File = document.Editor_Form.File[document.Editor_Form.File.selectedIndex].value;
	window.location = "$Script_URL?action=Template_Editor&EditorTheme=$Param{EditorTheme}&File=" +File;
}

function Change_Theme() {
	var Theme;
	if (!document.Editor_Form.Themes.selectedIndex) {return false;}
	Theme = document.Editor_Form.Themes[document.Editor_Form.Themes.selectedIndex].value;
	window.location = "$Script_URL?action=Template_Editor&EditorTheme=" +Theme;
}

// -->
</SCRIPT>

HTML

	return $Out;
}
#==========================================================
sub Save_Template_Editor{
my ($File);

	$Param{EditorTheme} ||= $Global{Theme};
	$File = "$Global{Data_Dir}/templates/$Param{EditorTheme}/$Param{File}";
	chmod (0777, $File);
	open (FILE, ">$File") || &Exit("Error: Can't create file $File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);

    $Param{Text} =~ s/\cM//g;
    print FILE $Param{Text};
	close (FILE);
	chmod (0755, $File);

	&Read_Configuration;
	&Template_Editor;
}
#==========================================================
sub Create_New_Template{
my ($File);

	$Param{New_File} =~ s/^\s+//;
	$Param{New_File} =~ s/\s+$//;
	if ($Param{New_File} !~ /\./) {$Param{New_File} .= "\.html";}

	$File = "$Global{Data_Dir}/templates/$Param{EditorTheme}/$Param{New_File}";
	
	if (!-f $File) {
			open (FILE, ">$File") || &Exit("Error: Can't create file $File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			close (FILE);
			chmod (0755, $File);
	}
	$Param{File} = $Param{New_File};
	&Template_Editor;
}
#==========================================================
sub Custom_Functions{
my ($Help);

	$Help = &Help_Link("Custom_Functions");
	&Print_Page(&Custom_Functions_Form, "Custom Functions", $Help);
}
#==========================================================
sub Custom_Functions_Form{
my($Out, %Class, @Class, $Classes);
my($Class_Index, $Class, $x, $y);

	undef @Files;
	opendir(Dir, $Global{Custom_Dir});
	foreach $File (readdir(Dir)) {
			push (@Files, $File);
    }
	closedir(Dir);
	@Files = sort @Files;
	
	undef @Class;
	for $x (0..$#Files) {
		$File = $Files[$x];
		if( -f "$Global{Custom_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ /\.bak$/i) { 
			push @Class, $File;
			open (File, "$Global{Custom_Dir}/$File") || &Exit("Error: Can't open file $Global{Custom_Dir}/$File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			@Temp = <File>;
			$Temp = join ("", @Temp);
			$Temp = &Encode_HTML($Temp);
			$Class{$File} = $Temp;
			close (File);
		}
	}

	$Class_Index = "";
	for $x (0..$#Class) {
			$y = $x+1;
			 $Class_Index .= qq!Class_Index[$y] = \'$Class[$x]\';\n!;
	}

	$Classes = qq! <SELECT NAME="Classes" onChange="Change_Class();"> <OPTION>--- Please Select File ---!;
	foreach $Class(@Class) {
		$Classes .= qq!<OPTION VALUE="$Class{$Class}">$Class</OPTION>!;
	}
   $Classes .= qq!</SELECT>!;

$Out =<<HTML;
<DIV ALIGN="center">
<CENTER>
<FORM METHOD="POST" NAME ="Classes_Form" ACTION="$Script_URL">
<INPUT TYPE="hidden" NAME="action" VALUE="Save_Custom_Functions">
<INPUT TYPE="hidden" NAME="Class_Name" VALUE="">
<TABLE BORDER="0" WIDTH="100%" CELLSPACING="0" CELLPADDING="2">
  <TR>
	<TD WIDTH="100%" ALIGN="center">
		$Classes
		<INPUT TYPE="submit" VALUE="Save File" STYLE="color: #000080; border-style: ridge">&nbsp;
        <INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</td>
  </tr>
  <tr><td width="100%" align="center">
		<textarea rows="25" ID="Class" name="Class" cols="80" style="border-style: groove"></textarea>
	</td>
  </tr>

  <TR>
	<TD WIDTH="100%" ALIGN="center">
	</TD>
  </TR>
</TABLE>
</FORM>
<CENTER>
</DIV>

<DIV ALIGN="center">
<CENTER>
<FORM METHOD="POST" NAME ="Create_Custom_Functions_File" ACTION="$Script_URL">
<INPUT TYPE="hidden" NAME="action" VALUE="Create_Custom_Functions_File">
<TABLE BORDER="0" WIDTH="100%" CELLSPACING="0" CELLPADDING="2">
  <TR><TD WIDTH="100%" ALIGN="center">
	Create new file: <INPUT TYPE="text" NAME="New_File" VALUE="">
	<INPUT TYPE="submit" VALUE="Submit" STYLE="color: #000080; border-style: ridge">
	</TD>
  </TR>
</TABLE>
</FORM>
<CENTER>
</DIV>

<SCRIPT LANGUAGE="JavaScript">
<!--
function Change_Class() {
var Class_Index = new Array(); 

	if (!document.Classes_Form.Classes.selectedIndex) {return false;}
	document.Classes_Form.Class.value = document.Classes_Form.Classes[document.Classes_Form.Classes.selectedIndex].value;
	$Class_Index
	document.Classes_Form.Class_Name.value = ''+Class_Index[document.Classes_Form.Classes.selectedIndex];
}
// -->
</SCRIPT>

HTML

	return $Out;
}
#==========================================================
sub Save_Custom_Functions{
my ($File, $Command, $Out, $Temp_File);

	$File = "$Global{Custom_Dir}/$Param{Class_Name}";
	$Temp_File = "$Global{Temp_Dir}/compile.txt";

	open (FILE, ">$File") || &Exit("Error: Can't create file $File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
    $Param{Class} =~ s/\cM//g;
    print FILE $Param{Class};
	close (FILE);
	chmod (0755, $File);

	$Command = "perl -c $File 2> $Temp_File";
	system($Command);

	chdir($Global{CGI_Dir});

	$Out = "<B><center>Compiling Status:</center></B><BR>";
	open(FILE,"$Temp_File");
	while (<FILE>) {$Out .= $_ . "<BR>";	}
	close(FILE);
	#$Out=`$Command`;

	&Admin_Msg("Custom Script File <B>$Param{Class_Name}</B> Successfully Saved", " $Out", 1, 500);
}
#==========================================================
sub Create_Custom_Functions_File{
my ($File);

	$Param{New_File} =~ s/^\s+//;
	$Param{New_File} =~ s/\s+$//;
	if ($Param{New_File} !~ /\./) {$Param{New_File} .= "\.pm";}

	$File = "$Global{Custom_Dir}/$Param{New_File}";
	
	if ($Param{New_File}) {
		open (FILE, ">$File") || &Exit("Error: Can't create file $File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
		close (FILE);
		chmod (0755, $File);
	}

	&Admin_Msg("File Created", "File $File has been successfully created", 1, 500);
}
#==========================================================
sub Create_Custom_Class{
my (@All, %Config, $Line, $Key, $Value);
	
	$Param{New_Custom_Class} =~ s/\s+//g;

	open (FILE, "$Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm") || &Exit("Cannot open file $Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);

	undef %Config;
	foreach $Line(@All){
			$Line =~ s/\n$//;
			($Key, $Value) = split(/\~\=\=\~/ , $Line);
			$Value =~ s/\\n/\n/g;
			$Config{$Key} = $Value;
	}
	
	$Config{$Param{Class_Name}} = $Param{Class};
	
	if ($Param{New_Custom_Class} && ! exists $Config{$Param{New_Custom_Class}}) {
				$Config{$Param{New_Custom_Class}} = "";
	}

	open (FILE, ">$Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm") || &Exit("Cannot write file $Global{Data_Dir}/templates/$Param{EditorTheme}/Config.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	while (($Key, $Value) = each(%Config)) {
			$Value  =~ s/\n/\\n/g;
			print FILE  "$Key~==~$Value\n";
	}
	close(FILE);
	
	$Param{Class_Name} = $Param{New_Custom_Class};
	&Read_Configuration;
	&Class_Editor;
}
#==========================================================
sub Create_Custom_Page{
my ($Help, $Lang_File, $Template_File, $Msg);
my (@Langs, $Lang, @Themes, $Theme);

	$Param{Name} =~ s/^\s+//;
	$Param{Name} =~ s/\s+$//;

	if (!$Param{Name}) {&Admin_Msg("Error", "Please enter a filename to create the custom page you want.", 1);}
	
	@Langs = &LanguagesList;
	@Themes = &ThemesList;

	foreach $Lang(@Langs){
			$Lang_File = qq!$Global{Data_Dir}/language/$Lang/$Param{Name}\.page\.pm!;
			if (!-e $Lang_File) {
					open (Out, ">$Lang_File") || &Exit("Cannot create file $Lang_File: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
					print Out qq|page_title~==~Custom Page<BR><BR>\n|;
					print Out qq|page_body_text~==~This is an exmple of how to create unlimited custom pages. You create custom pages from the template editor. All you need to link to this custom page in your templates is to insert the class <B>&lt;!--CLASS::Page:Page_Name--&gt;</B> in your templates, where <B>Page_Name</B> is the name of the page you want to create. The program will automatically create a template file in the templates directory with the name <B>Page_Name.page.shtml</B> and a language files with the name <B>Page_Name.page.pm</B> in every language directory.<BR><BR> You can then edit these generated files in the normal way. Also you can use inside these files all the General Classes, your custom functions, and the banner classes. For example you may want to use the Header, Top and Bottom Navigations Classes.<BR>\n|;
					close Out;
					chmod (0755, $Lang_File);
			}
	}

	foreach $Theme(@Themes){
			$Template_File = qq!$Global{Data_Dir}/templates/$Theme/$Param{Name}\.page\.shtml!;
			if (-e $Template_File) {next;}

			open (Out, ">$Template_File") || &Exit("Cannot create file $Template_File: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);

print Out <<HTML;
<!--CLASS::Header-->
<DIV ALIGN="center"><CENTER>
<TABLE BORDER="0" WIDTH="100%" CELLPADDING="0" BGCOLOR="#FFFFFF" CELLSPACING="0">
<TR><TD ALIGN="center" WIDTH="100%">
<!--CLASS::Top_Navigation-->
<!--CLASS::Top_Area-->
<!--CLASS::Welcome_Area-->
<!-------------------------------------------------->
<TABLE BORDER="0" ALIGN="center" VALIGN="middle" WIDTH="600" CELLSPACING="1" CELLPADDING="4">
  <TR><TD WIDTH="100%">[[page_title]]</TD></TR>
  <TR><TD WIDTH="100%">
	[[page_body_text]]
	<BR>
	<B>How to edit these custom files</B><BR>
	Edit the language files <B>$Param{Name}\.page\.pm</B> from the Language Manager. Also edit the template file <B>$Param{Name}\.page\.shtml</B> from the template editor for each them.<BR>
	</TD></TR>
</TABLE>
<!-------------------------------------------------->
<BR>
<!--CLASS::Bottom_Navigation-->
<!--CLASS::Bottom-->
</TD></TR>
</TABLE>
</CENTER></DIV>
<!--CLASS::Footer-->
HTML

			close Out;
			chmod (0755, $Template_File);
	}# foreach $Theme(@Themes){

	$Msg = qq|&nbsp;<BR>Custom page <b>$Param{Name}</b> has been created.<BR><BR>Edit the language files <B>$Param{Name}\.page\.pm</B> from the Language Manager for each language. Also edit the template file <B>$Param{Name}\.page\.shtml</B> from the template editor for each them. To insert a link in your templates for this page, insert the class <B>&lt;!--CLASS::Page:$Param{Name}--&gt;</B> in your templates.<BR><br><br><A HREF="$Admin_Prog?action=Template_Editor&File=$Param{Name}\.page\.shtml&Theme=$Param{EditorTheme}">&nbsp;<b>Return to the template editor</b></a><br><br>|;

	$Help = &Help_Link("Template Editor");
	&Print_Page($Msg, "Template Editor", $Help);		
}
#==========================================================
sub VisualEditorAdm{
my ($Template);

	$Template = &Get_File($Global{VisualEditorAdmin_Template});
	$Template =~ s/<!--CLASS::Images_URL-->/$Global{Images_URL}/g;
	$Template =~ s/<!--CLASS::Meta_Title-->/$Global{Meta_Title}/g;
	$Template =~ s/<!--CLASS::Meta_Description-->/$Global{Meta_Description}/g;
	$Template =~ s/<!--CLASS::Meta_Keywords-->/$Global{Meta_Keywords}/g;
	$Template =~ s/<!--FormField-->/$Param{FormField}/g;
	print "Content-type: text/html\n\n";
	print $Template;
}
#==========================================================
1;