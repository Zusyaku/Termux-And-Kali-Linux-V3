=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
use Net::SMTP;
#==========================================================
# usage Email($From, $TO, $Subject,   $Message);
# $TO ="address1, address2, address3,....."
sub Email {
my($From, $TO, $Subject,   $Message) = @_;
my (@TO, $Send_TO);

	#print "Content-type: text/plain\n\n"; print "<br>($From, $TO, $Subject,   $Message)<br>";

	if (!$Global{Email_Status}) {return;}

	if( $Global{Mail_Program_Type} == 0 ){
			@TO=split(/\,/, $TO);
			foreach $Send_TO (@TO) {
					open (MAIL, "| $Global{Mail_Program_Or_SMTP_Server} -t") 
							or &Exit("Can't open mail  Program $Global{Mail_Program_Or_SMTP_Server}: $!");
					if ($Global{Email_Format} == 1 ) {
							print MAIL "Content-type:text/html\n";
					}
					else{
							print MAIL "Content-type:text/plain\n";
					}

					#print MAIL "To: $email ($realname)\n";
					#print MAIL "From: $fromaddr ($fromname)\n";

					print MAIL "To: $Send_TO\n";
					print MAIL "From: $From\n";
					print MAIL "Return-Path: $From\n";
					print MAIL "Reply-To: $From\n";
					print MAIL "X-Mailer: $Global{Email_X_Mailer}\n";
					print MAIL "X-Priority: $Global{Email_X_Priority}\n";
					print MAIL "Subject: $Subject\n\n";
					print MAIL "$Message\n";
					close MAIL;
			}
	}
	elsif( $Global{Mail_Program_Type} == 3 ){ #SMTP server
			&SMTP_Mail($From, $TO, $Subject,   $Message);
	}
	else{ # No mail program specified
				return 0;
	}
}
#==========================================================
sub SMTP_Mail{
my($From, $TO, $Subject,   $Message) = @_;
my($smtp, @OK);

	$smtp = Net::SMTP->new($Global{Mail_Program_Or_SMTP_Server}, Debug   => 01) || &Exit("Can't connect to SMTP server $Global{Mail_Program_Or_SMTP_Server}: $!");
	#$smtp->auth($Username, $Password); #If the SMTP server requires authentication
	$smtp->mail($From) || return 0;
	@OK = $smtp->recipient($TO) || return 0;

	$smtp->data();
	$smtp->datasend("From: $From\n");
	$smtp->datasend("To: $TO\n");
	$smtp->datasend("Return-Path: $From\n");
	$smtp->datasend("Reply-To: $From\n");
	$smtp->datasend("X-Mailer: $Global{Email_X_Mailer}\n");
	$smtp->datasend("X-Priority: $Global{Email_X_Priority}\n");
	
	if ($Global{Email_Format} == 1 ) {
			$smtp->datasend("Content-Type: text/html\n");
	}
	else{
			$smtp->datasend("Content-Type: text/plain\n");
	}

	$smtp->datasend("Subject: $Subject\n\n");
	$smtp->datasend("$Message\n");
	$smtp->dataend();
	$smtp->quit;
	return 1;
}
#============================================================
1;