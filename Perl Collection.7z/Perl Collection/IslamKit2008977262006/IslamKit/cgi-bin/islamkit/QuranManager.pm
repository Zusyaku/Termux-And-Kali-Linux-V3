=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub QuranManager {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Quran_Manager");
	&Print_Page(&QuranManagerForm($Msg), "Quran Manager",  $Help);
}
#==========================================================
sub QuranManagerForm {
my ($Msg) = @_;
my ($Out, $Bar);
	
	$Bar = &QuranManagerNavBar;
	
	@Names = &GetQuranNamesAll;
	$List = ""; $Counter = "";
	foreach $Name  (@Names) {
			%Config = &GetQuranConfig($Name);
			
			$Delete = qq!<a href="$Script_URL?action=ConfirmDeleteQuran&QuranName=$Name&Type=$Config{Type}">Delete</a>!;
			$Edit = qq!<a href="$Script_URL?action=EditQuran&QuranName=$Name&Type=$Config{Type}">Edit Quran</a>!;
			$EditSurahs = qq!<a href="$Script_URL?action=EditSurahs&QuranName=$Name&Type=$Config{Type}">Surahs</a>!;
			$Update = qq!<a href="$Script_URL?action=UpdateQuran&QuranName=$Name&Type=$Config{Type}">Update</a>!;
			$Config = qq!<a href="$Script_URL?action=QuranConfig&QuranName=$Name&Type=$Config{Type}">Config</a>!;

			if ($Config{Direction} > 0) {$Temp = "RTL";} else {$Temp = "LTR";}
			$Direction = qq!<a href="$Script_URL?action=QuranConfig&QuranName=$Name&Type=$Config{Type}">$Temp</a>!;

			if ($Config{Active} > 0) {$Temp = "Yes";} else {$Temp = "No";}
			$Active = qq!<a href="$Script_URL?action=QuranConfig&QuranName=$Name&Type=$Config{Type}">$Temp</a>!;
			
			if ($Config{Type} == 1) {
					$Temp = "Quran";
			}
			elsif ($Config{Type} == 2) {
					$Temp = "Translation";
			}
			elsif ($Config{Type} == 3) {
					$Temp = "Transliteration";
			}
			elsif ($Config{Type} == 4) {# Interpretation (Tafsir) of the Quran
					$Temp = "Interpretation";
			}
			$Type = qq!<a href="$Script_URL?action=QuranConfig&QuranName=$Name&Type=$Config{Type}">$Temp</a>!;
			
			$Counter++;

			$Line = qq|<tr>
				<td width="50" nowrap>&nbsp;<b>$Counter</b></td>
				<td width="150" nowrap>&nbsp;<b>$Name</b></td>
				<td width="100" nowrap align="center">&nbsp;$Type</td>
				<td width="50" nowrap align="center">$Active</td>
				<td width="50" nowrap align="center">$Direction</td>
				<td width="50" nowrap align="center">$Config{Sort}</td>
				<td width="75%">&nbsp; $Edit &nbsp; $EditSurahs &nbsp; $Config &nbsp; $Update &nbsp; $Delete</td></tr>|;
			$List .= $Line;
	}

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>
<br><br>
$Msg

<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bordercolor="#A7A783" width="100%">
  <tr>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;#&nbsp;</b></td>
	<td width="150" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Name&nbsp;</b></td>
	<td width="100" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Type&nbsp;</b></td>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Active&nbsp;</b></td>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Direction&nbsp;</b></td>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Sort&nbsp;</b></td>
	<td width="75%" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Action&nbsp;</b></td>
  </tr>
	$List

</table>
<br><br>
HTML
	return $Out;
}
#==========================================================
sub QuranManagerNavBar {
my ($Out);

$Out=<<HTML;
<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" rowspan="2" bgcolor="#F3F3ED">
	&nbsp;<a href="$Script_URL?action=AddQuran"><b>Add Quran</b></a>
	&nbsp;&nbsp;&nbsp;<a href="$Script_URL?action=UploadQuran"><b>Upload</b></a>
	&nbsp;&nbsp;&nbsp;<a href="$Script_URL?action=DownloadQuran"><b>Download</b></a>
	&nbsp;&nbsp;&nbsp;<a href="$Script_URL?action=ExtractQuran"><b>Extract</b></a>
	&nbsp;&nbsp;&nbsp;<a href="$Script_URL?action=TranslateQuran"><b>Names</b></a>
	</td>
  </tr>
</table>
HTML
	return $Out;
}
#==========================================================
sub AddQuran {
my ($Out, $Help, $Bar);

	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;
	#--------------------------------------------------------------------------
	opendir Dir, "$Global{Import_Dir}" || &Exit("Cannot open directory $Global{Import_Dir}: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
	@Files = sort readdir(Dir);
	closedir(Dir);
	$FilesMenu = qq!<option value=""></option>!;
	foreach $File (@Files) {
			if ($File eq "." || $File eq "..") {next;}
			if (-f  "$Global{Import_Dir}/$File") {
					$FilesMenu .= qq!<option value="$File">$File</option>!;
			}
	}
	#--------------------------------------------------------------------------
	$SurahNamesMenu = "";
	
	@Names = &LanguagesList;
	foreach $Name(@Names) {
			#if ($Name eq "English") {$Sel = "selected";} else {$Sel = "";}
			$SurahNamesMenu .= qq!<option value="$Name" $Sel>$Name</option>!;
	}
	#--------------------------------------------------------------------------
	$TypeMenu = "";
	for $Config (0..4) {
			$Sel = "";
			if ($Global{DefaultType} == $Config) {$Sel = "selected";}
			if ($Config == 0) {
					$Temp = "";
			}
			if ($Config == 1) {
					$Temp = "Quran";
			}
			elsif ($Config == 2) {
					$Temp = "Translation";
			}
			elsif ($Config == 3) {
					$Temp = "Transliteration";
			}
			elsif ($Config == 4) {# Interpretation (Tafsir) of the Quran
					$Temp = "Interpretation";
			}
			$TypeMenu .= qq!<option value="$Config" $Sel>$Temp</option>!;
	}

	#--------------------------------------------------------------------------
$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Add Quran
<br><br>
<form method="post" action="$Script_URL" target="_blank" enctype="multipart/form-data">
<input type="hidden" name="action" value="AddNewQuran">

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Add New Quran</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
    <tr>
	<tr><td colspan="2">
		Add new Quran from text files. Files located under the directory data/import.<br>
		The file must be ASCII text formated pipe separated as following:
		<ul>
		  <li>Each line is one full Ayah</li>
		  <li>Lines separated by CRLF character.</li>
		  <li>Each Line formated as following: <br>&lt;Surah number&gt;|&lt;Ayah number&gt;|&lt;Ayah quran&gt;CRLF</li>
		</ul>
	</td></tr>

    <tr><td nowrap><b>Source File: </b></td>
		<td width="100%">
			<select name="ImportFile" size="1">
				$FilesMenu
			</select>
		</td>
	</tr>

	<tr><td nowrap valign="top"><b>New Quran Name: </b></td>
		<td width="100%" valign="top"><input type="text" size="30" name="QuranName"> Unique name and ID</td>
	</tr>


    <tr><td nowrap><b>Surah Name: </b></td>
		<td width="100%">
			<select name="SurahNameLanguage" size="1">
				$SurahNamesMenu
			</select>
			Default Surah Name Language
		</td>
	</tr>

  <tr>
    <td nowrap><b><span lang="en-us">Type:</span></b></td>
    <td width="100%">
			<select name="Type" size="1">
				$TypeMenu
			</select>
	</td>
  </tr>


  <tr>
    <td nowrap><b><span lang="en-us">Diacritic:</span></b></td>
    <td width="100%"><input type="checkbox" name="Diacritic" value="1"> Create Searchable version without diacritics (Arabic).</td>
  </tr>

  <tr>
    <td nowrap><b><span lang="en-us">Format:</span></b></td>
    <td width="100%"><input type="checkbox" name="Format" value="1"> Create Searchable version without Html Tags (Transliterations).</td>
  </tr>

  <tr>
    <td nowrap><b><span lang="en-us">Display:</span></b></td>
    <td width="100%"><input type="checkbox" name="PrintContent" value="1"> Print contents during process. Disable for large files.</td>
  </tr>

  <tr>
    <td nowrap><b><span lang="en-us">Empty Entry:</span></b></td>
    <td width="100%"><input type="checkbox" name="EmptyEntry" value="1"> Create empty entry only, do not process source file.</td>
  </tr>

	<tr>
      <td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Process" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>


HTML

	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub AddNewQuran {
my ($Filename, $Content, @Lines, $Name, $Query, $sth, $Temp, $Counter, $Empty,
$Line, $Surah, $Ayah, $Quran, $SurahNum, %Names, $SurahName, $AyahForm, 
$EmptyLines, %Config
);

	$| = 1;
	print "Content-type: text/html\n\n";
	
	print qq!<p><b>Processing request. This process may take a long time. Please wait...</b></p>!;
	
	if (!$Param{EmptyEntry}) {
		if ($Param{ImportFile} eq "") { # Import local file from directory data/import
				print "<br>No file name selected. No action taken!.<br>";
				print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
				return;
		}
		
		open (File, "$Global{Import_Dir}/$Param{ImportFile}") || &Exit("Cannot open file $Global{Import_Dir}/$Param{ImportFile}: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
	}

	if ($Param{Type} < 1 ) {
			print "<br>No quran Type selected. No action taken!.<br>";
			print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
			return;
	}
	
	$Param{QuranName} =~ s/^\s+//;
	$Param{QuranName} =~ s/\s+$//;

	if ($Param{QuranName} eq "") {
			print "<br>No quran name is entered. No action taken!.<br>";
			print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
			return;
	}
	#--------------------------------------------------------------------------
	%Config = &GetQuranConfig($Param{QuranName});
	if (%Config) {
			print qq|<font color="red"><b>This Quran Name already exists. Please enter unique name. No action taken!.</b></font><br>|;
			print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
			return;
	}
	#--------------------------------------------------------------------------
	#--------------------------------------------------------------------------
	print qq!<b>Quran Name: $Param{QuranName}</b><br><br>!;
	$Name = $dbh->quote($Param{QuranName});
	#--------------------------------------------------------------------------
	$Param{SurahNameLanguage} ||= 'English';
	$Query = qq!DELETE FROM SurahName WHERE Name=$Name!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	#--------------------------------------------------------------------------
	#%Names = &GetSurahNamesHash($Param{SurahNameLanguage});
	%SurahNames = &Get_Language_File("$Global{Language_Dir}/$Param{SurahNameLanguage}/SurahName.pm");

	foreach $SurahNum(keys %SurahNames) {
			$SurahName = $dbh->quote($SurahNames{$SurahNum});
			$Query = qq!INSERT INTO SurahName VALUES ($Name, $SurahNum, $SurahName)!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}
	#--------------------------------------------------------------------------
	$Query = qq!DELETE FROM QuranConfig WHERE Name=$Name AND Type=$Param{Type}!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	#Name VARCHAR(250),	Type INT, Active INT, Direction INT, Sort INT, AyahForm
	if ($Param{SurahNameLanguage} eq "Arabic") {
			$AyahForm = $dbh->quote($Global{DefaultAyahFormArabic});
	}
	else {
			$AyahForm = $dbh->quote($Global{DefaultAyahForm});
	}
	
	if ($Param{Diacritic} || $Param{Format}) {$Versions = 1;} else {$Versions = 0;}
	if ($Param{Type} == 1) {$ArabicDigits = 1;} else {$ArabicDigits = 0;}

	$Query = qq!INSERT INTO QuranConfig (Name,Type,Active,Direction, Sort, Versions, ArabicDigits, AyahForm)
														   VALUES ($Name, $Param{Type}, 1, 0, 0, $Versions, $ArabicDigits, $AyahForm)!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	#--------------------------------------------------------------------------
	@Langs = &LanguagesList();
	foreach $Lang (@Langs) {
			$Lang = $dbh->quote($Lang);
			$Query = qq!INSERT INTO QuranName VALUES ($Name, $Lang, $Name)!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}
	#--------------------------------------------------------------------------
	#--------------------------------------------------------------------------
	$Counter = 0; $Empty = 0; $EmptyLines = "";
	if (!$Param{EmptyEntry}) {
				while ($Line =<File>) {
						chomp ($Line);
						$Counter++;
						($Surah, $Ayah, $Quran) = split (/\|/, $Line);
						
						if ($Param{PrintContent}) {print "$Counter)- [$Surah][$Ayah] $Quran<br>";}
						else{print "$Counter)- [$Surah][$Ayah]<br>";};
						
						$Surah =~ s/\s+//;
						$Ayah =~ s/\s+$//;
						$Quran =~ s/^\s+//;
						$Quran =~ s/\s+$//;
						$Quran =~ s/\s+/ /g;

						if ($Surah <1 || $Surah > 114) {
								print qq!<font color="red"><b>Skipped... Incorrect Suran number: $Surah </b></font><br>!;
								next;
						}
						if ($Ayah <1 || $Ayah > 286) {
								print qq!<font color="red"><b>Skipped... Incorrect Ayah number: $Ayah </b></font><br>!;
								next;
						}
						
						if ($Quran eq "") {
								$Empty++;
								$EmptyLines .= qq!<font color="red"><b>$Surah|$Ayah</b></font><br>!;
								print qq!<font color="red"><b>Empty Ayah, No text found. </b></font><br>!;
						}
						#------------------------------------------------------------------
						$QuranText = $dbh->quote($Quran);
						#Name VARCHAR(150), Surah INT, Ayah INT, Quran TEXT
						$Query = qq!INSERT INTO Quran$Param{Type} VALUES ($Name, $Surah, $Ayah, $QuranText)!;
						$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
						#------------------------------------------------------------------
						# Create searchable version without Diacitic and html tags if required.
						$QuranText = $Quran;
						if ($Param{Diacritic}) { # Remove Tashkil
								$QuranText = &RemoveDiacritic($QuranText);
						}
						if ($Param{Format}) { # Remove html tags
								$QuranText =~ s/<[^>]+>//ig; # remove html code
						}
						if ($Param{Diacritic} || $Param{Format}) {
								$QuranText = $dbh->quote($QuranText);
								$Query = qq!INSERT INTO Search$Param{Type} VALUES ($Name, $Surah, $Ayah, $QuranText)!;
								$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
						}
				}
				#--------------------------------------------------------------------------
				if ($EmptyLines) {
						print qq!<br><br><b><font color="red">Empty Quran Ayahs Found: $Empty</font></b><br>!;
						print qq!<b>$EmptyLines</b>!;
				}
	}
	#--------------------------------------------------------------------------
	print qq!<br><br><b>Finshed...</b><br>!;
	print qq!<p align="center"><a href="javascript:window.close()"><b><font color="blue">Close This Window</font></b></a></p>!;	
}
#==========================================================
sub UploadQuranFile {
my ($Filename, $Content, @Lines, $Line, $Out) ;

	if ($Paramx{UploadFile}) {# Upload file
			($Filename, $Content) = &GetUploadFile('UploadFile');
			if ($Filename ne "") {
					if ($Content ne "") {
							open (File, ">$Global{Import_Dir}/$Filename") || &Exit("Cannot create file $Global{Import_Dir}/$Filename: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
							binmode File;
							print File $Content;
							close (File);
							$Out = qq|<br><br><b>&nbsp; File Successffuly Uploaded. <br>&nbsp; File: $Filename</b>|;
							if ($Filename =~ m/\.zip$/i) {
									&ExtractQuranZipFile("$Global{Import_Dir}/$Filename");
							}
					}
					else {
							$Out = qq|<br><br><b><font color="red">&nbsp; File upload failed. File empty.</font></b>|;
					}

			}
			else {
					$Out = qq|<br><br><b><font color="red">&nbsp; File upload failed. No file name selected.</font></b>|;
			}
	}
	else {
			$Out = qq|<br><br><b><font color="red">&nbsp; File upload failed. No file name selected.</font></b>|;
	}
	
	&UploadQuran($Out);
}
#==========================================================
sub DownloadQuranLink {

	if ($Param{DownloadURL} ne "") { # download from URL
			$Param{DownloadURL} =~ s/^\s+//;
			$Param{DownloadURL} =~ s/\s+$//;
			$Param{DownloadURL} =~ /([^\\\/]+)$/;
			$Filename = $1;
			use LWP::UserAgent;
			my $ua = LWP::UserAgent->new;
			$ua->timeout(300);
			$ua->agent('IslamKit www.islamware.com');
			my $response = $ua->get($Param{DownloadURL}, ':content_file'=>"$Global{Import_Dir}/$Filename");
			if ($response->is_success) {
					#print " ...OK\n";
					$SourceFile = "$Global{Import_Dir}/$Filename";
					$Out = qq|<br><br><b>File download success.</b>|;
			}
			else {
					#print " ...Fail\n";
					$Out = qq|<br><br><b>File download failed...!</b>|;
			}
	}
	else {
			$Out = qq|<br><br><b><font color="red">&nbsp; File download failed. No file name entered.</font></b>|;
	}
	
	&DownloadQuran($Out);
}
#==========================================================
sub UpdateQuran {
my ($Out, $Help, $Bar, $Menu, %Config);

	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;
	$Menu = &GetQuranMenuList;

	%Config = &GetQuranConfig($Param{QuranName});

	opendir Dir, "$Global{Import_Dir}" || &Exit("Cannot open directory $Global{Import_Dir}: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
	@Files = sort readdir(Dir);
	closedir(Dir);
	$FilesMenu = qq!<option value=""></option>!;
	foreach $File (@Files) {
			if ($File eq "." || $File eq "..") {next;}
			if (-f  "$Global{Import_Dir}/$File") {
					$FilesMenu .= qq!<option value="$File">$File</option>!;
			}
	}

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Update Quran
<br><br>
<form method="post" action="$Script_URL" target="_blank">
<input type="hidden" name="action" value="DoUpdateQuran">
<input type="hidden" name="QuranName" value="$Param{QuranName}">
	
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Update Quran</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
    <tr>
	<tr><td colspan="2">
		Update existing Quran from text files. Please note, this action can not be undone.<br>
		This will delete and replace the Quran version you will select to update.<br>
		You may consider doing database backup before doing this process for safety.<br>
		You can use this form to update any specific Ayahs or the whole Quran.<br>
		Only Ayahs informatin available in the uploaded text file will be updated.<br>
		The file must be ASCII text file formated pipe separated as following:
		<ul>
		  <li>Each line is one full Ayah</li>
		  <li>Lines separated by CRLF character.</li>
		  <li>Each Line formated as following: <br>&lt;Surah number&gt;|&lt;Ayah number&gt;|&lt;Ayah quran&gt;CRLF</li>
		</ul>
		<br>
				
	</td></tr>

    <tr><td nowrap valign="top"><b>Source File: </b></td>
		<td width="100%">
			<select name="ImportFile" size="1">
				$FilesMenu
			</select>
		<br>Files located under the directory data/import.
		</td></tr>

	<tr><td nowrap valign="top"><b>Quran Name: </b></td>
		<td width="100%" valign="top">
		<b>$Param{QuranName}</b>
		</td>
	</tr>
	<tr>
      <td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Process" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
  </table>
	</td>
</tr>
</table>
</form>
<br>


HTML

	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub DoUpdateQuran {
my ($Filename, $Content, @Lines, $Name);

	$| = 1;
	print "Content-type: text/html\n\n";
	print qq!<p><b>Uploading and processing file. This process may take a long time. Please wait...</b></p>!;
	
	if ($Param{ImportFile} eq "") { # Import local file from directory data/import
			print "<br>No file name selected. No action taken!.<br>";
			print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
			return;
	}

	open (File, "$Global{Import_Dir}/$Param{ImportFile}") || &Exit("Cannot open file $Global{Import_Dir}/$Param{ImportFile}: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
	@Lines = <File>;
	close (File);

	if (!@Lines) {
			print "<br>Data file is empty. No action taken!.<br>";
			print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
			return;
	}

	$Param{QuranName} =~ s/^\s+//;
	$Param{QuranName} =~ s/\s+$//;
	$Param{Type} ||=1;

	if ($Param{QuranName} eq "") {
			print "<br>No quran name is selected to update. No action taken!.<br>";
			print qq!<p align="center"><a href="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></p>!;	
			return;
	}
	
	print qq!<b>Quran Name: $Param{QuranName}</b><br><br>!;
	
	%Config = &GetQuranConfig($Param{QuranName});

	$Name = $dbh->quote($Param{QuranName});
	
	$Counter = 0; $Empty = 0;

	foreach $Line (@Lines) {
			chomp ($Line);
			
			$Counter++;
			($Surah, $Ayah, $Quran) = split (/\|/, $Line);
			
			print "$Counter)- [$Surah][$Ayah] $Quran<br>";
			
			$Surah =~ s/\s+//;
			$Ayah =~ s/\s+$//;
			$Quran =~ s/^\s+//;
			$Quran =~ s/\s+$//;
			$Quran =~ s/\s+/ /g;

			if ($Surah <1 || $Surah > 114) {
					print qq!<font color="red"><b>Skipped... Incorrect Suran number: $Surah </b></font><br>!;
					next;
			}
			if ($Ayah <1 || $Ayah > 286) {
					print qq!<font color="red"><b>Skipped... Incorrect Ayah number: $Ayah </b></font><br>!;
					next;
			}
			
			if ($Quran eq "") {
					$Empty++;
					print qq!<font color="red"><b>Empty Ayah, No text found. </b></font><br>!;
			}
			#------------------------------------------------------------------
			$Query = qq!DELETE FROM Quran$Config{Type} WHERE Name=$Name AND Surah=$Surah AND Ayah=$Ayah!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

			if ($Config{Versions} == 1) {
					$Query = qq!DELETE FROM Search$Config{Type} WHERE Name=$Name AND Surah=$Surah AND Ayah=$Ayah!;
					$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			}
			#------------------------------------------------------------------
			$Quran = $dbh->quote($Quran);
			$Query = qq!INSERT INTO Quran$Config{Type} VALUES ($Name, $Surah, $Ayah, $Quran)!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

			if ($Config{Versions} == 1) {
					$Query = qq!INSERT INTO Search$Config{Type} VALUES ($Name, $Surah, $Ayah, $Quran)!;
					$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			}
	}
	
	print qq!<br><br><b>Finshed...</b><br>!;
	print qq!<p align="center"><a href="javascript:window.close()"><b><font color="blue">Close This Window</font></b></a></p>!;	
}
#==========================================================
sub DeleteQuran {
my ($Out, $Help, $Bar, $Menu);

	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;
	$Menu = &GetQuranMenuList;

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Delete Quran
<br><br>
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Delete Quran</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
		<form method="post" action="$Script_URL" name="DeleteForm">
		<input type="hidden" name="action" value="ConfirmDeleteQuran">
	<tr><td colspan="2">
		Delete existing Quran from the system database. Please note, this action can not be undone. You may consider doing database backup before doing this process for safety.<br>
	</td></tr>
    <tr><td nowrap><b>Quran name: </b></td>
      <td width="100%">
			<select name="QuranName" size="1">
			$Menu
			</select>
			<input type="submit" value="Delete" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
HTML
	
	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub ConfirmDeleteQuran {
my ($Help, $Out, $Bar);
	
	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}

	$Bar = &QuranManagerNavBar;
	
$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Confirm Delete Quran
<br><br>
<form method="post" action="$Script_URL" name="DeleteForm">
<input type="hidden" name="action" value="DoDeleteQuran">
<input type="hidden" name="QuranName" value="$Param{QuranName}">
<p align="center"><b><font size="4" color="#FF0000">Delete Quran Confirmation</font></b></p>
<br>
<p align="justify"> 
	Are you sure you want to delete the selected Quran from the system database. <br>
	Please note, this action can not be undone. <br>
	You may consider doing database backup before doing this delete process.</p>
<br>
<b>Quran Name: $Param{QuranName}</b>
<br><br><br>
<a href="$Script_URL?action=DoDeleteQuran&QuranName=$Param{QuranName}"><b>Yes Delete</b></a>
&nbsp;&nbsp;&nbsp;
<a href="$Script_URL?action=QuranManager"><b>Cancel</b></a>

</form>
HTML

	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub DoDeleteQuran {
my (%Config, $Name, $Query);

	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}
	
	%Config = &GetQuranConfig($Param{QuranName});

	$Name = $dbh->quote($Param{QuranName});
	
	$Query = qq!DELETE FROM Quran$Config{Type} WHERE Name=$Name!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	$Query = qq!DELETE FROM Search$Config{Type} WHERE Name=$Name!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	$Query = qq!DELETE FROM QuranConfig WHERE Name=$Name AND Type=$Config{Type}!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	$Query = qq!DELETE FROM SurahName WHERE Name=$Name!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	
	$Query = qq!DELETE FROM QuranName WHERE Name=$Name!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	&QuranManager;
}
#==========================================================
sub ExportQuran {

	&QuranManager;
}
#==========================================================
sub DoExportQuran {

	&QuranManager;
}
#==========================================================
sub GetQuranMenuList {
my (@Names, $Menu);

	@Names = &GetQuranNamesAll();
	$Menu = "";
	foreach $Name(@Names) {
				$Menu .= qq!<option value="$Name">$Name</option>!;
	}
	return $Menu;
}
#==========================================================
	#SELECT * FROM pet WHERE name REGEXP "^b"; case sensitive
	#SELECT * FROM pet WHERE name REGEXP "^[bB]";
	#SELECT * FROM pet WHERE name REGEXP BINARY "^b";
	#SELECT * FROM pet WHERE name REGEXP "fy$";
	#SELECT * FROM pet WHERE name REGEXP "w";
	#SELECT * FROM pet WHERE name REGEXP "^.....$";
	#SELECT * FROM pet WHERE name REGEXP "^.{5}$";
	#If you want to compare a blob case-insensitively you can always convert the blob to upper case before doing the comparison: 
	#SELECT 'A' LIKE UPPER(blob_col) FROM table_name;

#==========================================================
sub QuranConfig {
my ($Help, $Out, $Bar, %Config);
	
	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}

	$Bar = &QuranManagerNavBar;
	%Config = &GetQuranConfig($Param{QuranName});
	
	$TypeMenu = "";
	$Type = "";
	for $Config (1..4) {
			$Sel = "";
			if ($Config{Type} == $Config) {$Sel = "selected";}
			if ($Config{Type} == 1) {
					$Temp = "Quran";
			}
			elsif ($Config{Type} == 2) {
					$Temp = "Translation";
			}
			elsif ($Config{Type} == 3) {
					$Temp = "Transliteration";
			}
			elsif ($Config{Type} == 4) {# Interpretation (Tafsir) of the Quran
					$Temp = "Interpretation";
			}
			$Type = $Temp;
			$TypeMenu .= qq!<option value="$Config" $Sel>$Temp</option>!;
	}
	
	$Active = "";
	if ($Config{Active}) {$Active = "checked";}
	
	$DirectionMenu = "";
	if ($Config{Direction} ==1) {
		$DirectionMenu = qq!<option value="0">Left to right</option><option value="1" selected>Right to left</option>!;
	}
	else {
		$DirectionMenu = qq!<option value="0" selected>Left to right</option><option value="1">Right to left</option>!;
	}
	
	$ArabicDigits = "";
	if ($Config{ArabicDigits} ==1) {
		$ArabicDigits = qq!<option value="1" selected>Yes</option><option value="0">No</option>!;
	}
	else {
		$ArabicDigits = qq!<option value="1">Yes</option><option value="0" selected>No</option>!;
	}

	$Formats = "";
	for $Format(1..20) {
			$Find = &Encode_HTML($Config{"Find$Format"});
			$Replace = &Encode_HTML($Config{"Replace$Format"});
			$Formats .=qq|
		  <tr>
			<td width="25" nowrap>&nbsp;$Format</td>
			<td width="50%">&nbsp;<input type="text" name="Find$Format" value="$Find" size="40"></td>
			<td width="50%">&nbsp;<input type="text" name="Replace$Format" value="$Replace" size="40"></td>
		  </tr>
				|;
	}	

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Quran Configuration
<br><br>
<form method="post" action="$Script_URL" name="QuranConfig">
<input type="hidden" name="action" value="SaveQuranConfig">
<input type="hidden" name="QuranName" value="$Param{QuranName}">

<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#E3E3D7" width="600">
  <tr>
    <td nowrap><b><span lang="en-us">Name:</span></b></td>
    <td width="100%">
		<input type="text" name="Name" size="40" value="$Config{Name}">
	</td>
  </tr>
  <tr>
    <td nowrap><b><span lang="en-us">Type:</span></b></td>
    <td width="100%">$Type
			<!--<select name="Type" size="1">$TypeMenu</select>-->
	</td>
  </tr>
  <tr>
    <td nowrap><b><span lang="en-us">Active:</span></b></td>
    <td width="100%">
		<input type="checkbox" name="Active" value="1" $Active>
	</td>
  </tr>
  <tr>
    <td nowrap><b><span lang="en-us">Direction:</span></b></td>
    <td width="100%">
			<select name="Direction" size="1">
				$DirectionMenu
			</select>
	</td>
  </tr>
	
  <tr>
    <td nowrap><b><span lang="en-us">Arabic Number:</span></b></td>
    <td width="100%">
			<select name="ArabicDigits" size="1">
				$ArabicDigits
			</select>
				Use Arabic Unicode Digits For Ayah Numbers.
	</td>
  </tr>

  <tr>
    <td nowrap><b><span lang="en-us">Sort:</span></b></td>
    <td width="100%">
		<input type="text" name="Sort" size="5" value="$Config{Sort}">
	</td>
  </tr>

  <tr>
    <td nowrap valign="top"><b>Ayah Form: </b></td>
	  <td width="100%"><textarea rows="8" name="AyahForm" cols="70">$Config{AyahForm}</textarea></td>
  </tr>

  <tr>
    <td nowrap valign="top"><b>Format: </b></td>
	 <td width="100%" valign="top">
		<p align="justify">Use these forms to format the display of specific text in each Ayah. For example to colorize Ayahs text in Interpertations surrounded by "{" and "}" letters, replace each "{" with "&lt;font color="red"&gt;{" and replace each "}" with "}&lt;/font&gt;". Remember to close any Html tags you open.</p>
		<table border="1" cellpadding="2" cellspacing="0" style="border-collapse: collapse" bordercolor="#CC9900" width="100%">
		  <tr>
			<td width="25" bgcolor="#DEDEBC" nowrap align="center"><b>#</b></td>
			<td width="33%" bgcolor="#DEDEBC" nowrap align="center"><b>
			<span lang="en-us">Find What</span></b></td>
			<td width="34%" bgcolor="#DEDEBC" nowrap align="center"><b>
			<span lang="en-us">Replace With</span></b></td>
		  </tr>
			$Formats
		</table>

		</td>
	</tr>

	<tr>
      <td colspan="2" align="center">
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
	</tr>

</table>


</form>
HTML
	
	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub SaveQuranConfig {
my (%Config, %Config1, $Name, $QuranName, $AyahForm, $Query);

	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}
	
	$Param{Name}=~ s/^\s+//;
	$Param{Name} =~ s/\s+$//;
	$Param{Name} ||= $Param{QuranName};
	$Param{ArabicDigits} ||= 0;

	%Config = &GetQuranConfig($Param{QuranName});
	#--------------------------------------------------------------------------
	# Renaming?
	$Name = $dbh->quote($Param{Name});
	%Config1 = &GetQuranConfig($Param{Name});
	if (%Config1) {
			$Param{Name} = $Param{QuranName}; # Keep original name. Do not overwrite other names.
	}
	#--------------------------------------------------------------------------
	$Name = $dbh->quote($Param{Name});
	$QuranName = $dbh->quote($Param{QuranName});
	#--------------------------------------------------------------------------
	if ($Param{Active}) {$Active = 1;} else {$Active = 0;}
	if ($Param{Direction} eq "1") {$Direction = 1;} else {$Direction = 0;}
	$Param{Sort} =~ s/\D+//;
	if ($Param{Sort} < 1) {$Param{Sort} = 0;	}
	
	$Param{Type} ||= 1;
	
	$Param{AyahForm} =~ s/\cM//g;
	
	$AyahForm = $dbh->quote($Param{AyahForm});

	$Formats = "";
	for $Format(1..20) {
			$Find = &Decode_HTML($Param{"Find$Format"});
			$Replace = &Decode_HTML($Param{"Replace$Format"});
			$Find = $dbh->quote($Find);
			$Replace = $dbh->quote($Replace);
			$Formats .= qq!Find$Format=$Find, Replace$Format=$Replace,!;
	}	
	$Formats =~ s/\,$//g;

	$Query = qq!UPDATE QuranConfig SET Name=$Name, Active=$Active, Direction=$Direction, 
											Sort=$Param{Sort}, ArabicDigits=$Param{ArabicDigits}, AyahForm=$AyahForm, $Formats 
											WHERE Name=$QuranName!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	
	if ($Param{Name} ne $Param{QuranName}) {
			$Query = qq!UPDATE Quran$Config{Type} SET Name=$Name WHERE Name=$QuranName!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

			$Query = qq!UPDATE SurahName SET Name=$Name WHERE Name=$QuranName!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}

	&QuranManager;
}
#==========================================================
sub EditQuran {
my (%Config, $Out, $Help, $Bar, $Menu);
	
	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}
	
	%Config = &GetQuranConfig($Param{QuranName});

	$Param{Surah} ||= 1;
	$Param{Ayah} ||= 1;

	$Ayahs = &GetSurahAyahsCount($Param{Surah});
	$List = "";
	
	if ($Config{Direction}) {$Direction = "dir=rtl";} else {$Direction = "";}
	
	$Global{AdminQuranEditorAyahs} ||= 20;
	
	$FromAyah = $Param{Ayah};
	
	for $Count (0..$Global{AdminQuranEditorAyahs}-1) {
			$Ayah = $Param{Ayah} + $Count;
			if ($Ayah > $Ayahs) {last;}
			$ToAyah = $Ayah;
			$Quran = &GetAyahQuran($Param{QuranName}, $Config{Type}, $Param{Surah}, $Ayah);
			
			$List .= qq|<tr><td width="50" $Dir>&nbsp;$Ayah</td><td width="100%">&nbsp;
								<textarea rows="4" name="Ayah:$Ayah" cols="70" $Direction
									style="background-color: #FFFFF9; color: #000000; border-color: #333300;border-width:1px; padding: 3;
								font-family: Tahoma, verdana, helvetica; font-size: 16px; font-weight: bold;
								line-height: 150%;">$Quran</textarea></td></tr>|;
	}

	$NextAyah = $Param{Ayah} + $Global{AdminQuranEditorAyahs};
	if ($NextAyah > $Ayahs) {$NextAyah = $Ayahs - $Global{AdminQuranEditorAyahs};}
	if ($NextAyah < 1) {$NextAyah = 1;}

	$EditNext = qq!<a href="$Script_URL?action=EditQuran&QuranName=$Param{QuranName}&Surah=$Param{Surah}&Ayah=$NextAyah"><b>Next >></b></a>!;

	$PrevAyah = $Param{Ayah} - $Global{AdminQuranEditorAyahs};
	if ($PrevAyah < 1) {$PrevAyah = 1;}
	$EditPrev = qq!<a href="$Script_URL?action=EditQuran&QuranName=$Param{QuranName}&Surah=$Param{Surah}&Ayah=$PrevAyah"><b><< Prev</b></a>!;
	
	$SurahName = $SurahNameEnglishTransliteration[$Param{Surah}];
	#--------------------------------------------------------------------------	
	# Make the Surah Menu
	my %SurahNames = &GetQuranSurahNames($Param{QuranName});
	$SurahMenu = "";
	for $Surah (1..114) {
			if ($Surah == $Param{Surah}) {$Sel ="selected";} else {$Sel = "";}
			$SurahMenu .= qq!<option value="$Surah" $Sel>$Surah)- $SurahNames{$Surah} (&GetSurahAyahsCount($Surah))</option>!;
	}
	#--------------------------------------------------------------------------	
	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Edit Quran
<br><br>

<form method="post" action="$Script_URL" name="EditForm">
<input type="hidden" name="action" value="SaveEditQuran">
<input type="hidden" name="QuranName" value="$Param{QuranName}">
<input type="hidden" name="Surah" value="$Param{Surah}">

<table $Direction border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#CACAAC" width="100%">
<tr>
	<td nowrap><font color="#000080"><b>Quran Name: </b></font>$Param{QuranName} &nbsp;</td>
	<td align="center" width="100">&nbsp;&nbsp;&nbsp;</td>
	<td nowrap><font color="#000080"><b>Surah: </b></font>
				<select name="NewSurah" onChange="ChangeSurah(this.value);">$SurahMenu</select>
	</td>
	<td align="center" width="100%">&nbsp;</td>
</tr>
</table>

<table $Direction border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#CACAAC" width="100%">
<tr><td align="left">$EditPrev</td><td align="center">Displaying Ayah $FromAyah to $ToAyah</td><td align="right">$EditNext</td></tr>
</table>

<table $Direction border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#CACAAC" width="100%">
  <tr>
    <td width="50" bgcolor="#E7E7DA" nowrap align="center">
    <p dir="ltr"><b>Ayah</b></td>
    <td width="100%" bgcolor="#E7E7DA" nowrap align="center"><b>Quran</b></td>
  </tr>
	$List
	<tr>
      <td colspan="2" align="center">
			&nbsp;&nbsp;&nbsp;&nbsp;
			$EditPrev
				&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
				&nbsp;&nbsp;&nbsp;&nbsp;
			$EditNext
			&nbsp;&nbsp;&nbsp;&nbsp;
	</td>
	</tr>
</table>
</form>

<br>

<script language="javascript">
function ChangeSurah(Surah) {
	window.location = "$Script_URL?action=EditQuran&QuranName=$Param{QuranName}&Ayah=1&Surah=" +Surah+'';
}
</script>

HTML
	
	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub SaveEditQuran {
my (%Config, $Name, $K, $V, $Ayah, $Query);

	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}
	
	%Config = &GetQuranConfig($Param{QuranName});
	$Name = $dbh->quote($Param{QuranName});

	while (($K, $V) = each (%Param)) {
		if ($K =~ /Ayah\:(\d+)/) {
				$Ayah = $1;
				$V =~ s/\cM|\n|\r//g;
				$V =~ s/\s+/ /g;
				$V =~ s/^\s+//g;
				$V =~ s/\s+$//g;
				$V = $dbh->quote($V);
				$Query = qq!UPDATE Quran$Config{Type} SET Quran=$V WHERE Name=$Name AND Surah=$Param{Surah} AND Ayah=$Ayah!;
				$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
		}
	}
	
	&EditQuran;
}
#==========================================================
sub EditSurahs {
my (%Config, $Surah, $Temp, $List);

	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}
	
	%Config = &GetQuranConfig($Param{QuranName});
	my %SurahNames = &GetQuranSurahNames($Param{QuranName});
	#my %SurahNamesTrans = &GetSurahNamesHash('EnglishTrans');
	my %SurahNamesTrans = &Get_Language_File($Global{Language_SurahNames_File});

	
	$List = "";

	for $Surah(1..114) {
			#$Temp = &Web_Encode($SurahNames{$Surah});
			$Temp = $SurahNames{$Surah};
			$List .= qq|
						  <tr>
							<td width="50" nowrap>&nbsp;$Surah</td>
							<td width="100%" nowrap>&nbsp; 
								<input type="text" name="Surah$Surah" size="30" value="$Temp">
								$SurahNamesTrans{$Surah}</td>
						  </tr>
							|;
	}


	#--------------------------------------------------------------------------	
	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Edit Surahs Names
<br><br>
<p><b> Quran: $Param{QuranName}</b></p>

<form method="post" action="$Script_URL" name="EditForm">
<input type="hidden" name="action" value="SaveEditSurahs">
<input type="hidden" name="QuranName" value="$Param{QuranName}">

<table border="1" cellpadding="2" cellspacing="0" style="border-collapse: collapse" bordercolor="#CACAAC" width="100%">
  <tr>
    <td width="80" bgcolor="#E7E7DA" nowrap align="center"><b>Surah #</b></td>
    <td width="100%" bgcolor="#E7E7DA" nowrap align="center"><b>Surah Name</b></td>
  </tr>
  $List

	<tr>
      <td colspan="2" align="center">
			&nbsp;
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
			&nbsp;
	</td>
	</tr>

</table>
</form>
HTML
	
	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub SaveEditSurahs {

	if (!$Param{QuranName}) {
			&QuranManager;
			return;
	}
	
	my $QuranName = $dbh->quote($Param{QuranName});

	#my %SurahNamesTrans = &GetSurahNamesHash('EnglishTrans');
	my %SurahNamesTrans = &Get_Language_File($Global{Language_SurahNames_File});

	for $Surah(1..114) {
			$Temp = "Surah$Surah";
			$SurahName = $Param{$Temp};
			$SurahName ||= $SurahNamesTrans{$Surah};
			$SurahName = $dbh->quote($SurahName);
			$Query = qq!UPDATE SurahName SET SurahName=$SurahName WHERE Name=$QuranName AND Surah=$Surah!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}
	&QuranManager;
}
#==========================================================
sub TranslateQuran {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Quran_Manager");
	&Print_Page(&TranslateQuranForm($Msg), "Quran Manager",  $Help);
}
#==========================================================
sub TranslateQuranForm {
my ($Msg) = @_;
my ($Out, $Bar);
	
	$Param{TranslateLang} ||= $Global{Language};
	$Bar = &QuranManagerNavBar;

	@Names = &GetQuranNamesAll();
	@Types = ("", "Quran", "Translation", "Transliteration", "Interpretation");

	$Counter = 0; $List = "";

	foreach $Name (@Names) {
		%Quran = &GetQuranConfig($Name);
		$LangName = &GetQuranLangName($Name, $Param{TranslateLang});
		$Counter++;
		$Line = qq|<tr>
			<td width="50" nowrap>&nbsp;<b>$Counter</b></td>
			<td width="150" nowrap>&nbsp;<b>$Name</b></td>
			<td width="100" nowrap align="center">&nbsp;$Types[$Quran{Type}]</td>
			<td width="75%">&nbsp;<input type="text" name="Quran\_$Name" id="Quran\_$Name" value="$LangName" size="40" onChange="ConvertFieldToUnicode(\'Quran\_$Name\')"></td></tr>|;
		$List .= $Line;
	}

	@Langs = &LanguagesList();
	$LangMenu = "";
	foreach $Lang (@Langs) {
			if ($Lang eq $Param{TranslateLang}) {$Sel = "selected";} else {$Sel = "";}
			$LangMenu .= qq!<option value="$Lang" $Sel>$Lang</option>!;
	}

$Out=<<HTML;	
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Translate Quran Names
<br><br>
$Msg

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Translate Quran Names</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">

<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>

<form name="LangForm" id="LangForm" method="post" action="$Script_URL">
<input type="hidden" name="action" value="TranslateQuranLanguageChange">
  <tr>
    <td nowrap valign="top"><b>Language:</b></td>
    <td width="100%">
			<select name="NewLang" size="1" onChange="submit();">$LangMenu</select>
	</td>
  </tr>
</form>

<form name="TranslateForm" id="TranslateForm" method="post" action="$Script_URL">
<input type="hidden" name="action" value="SaveTranslateQuran">
<input type="hidden" name="TranslateLang" value="$Param{TranslateLang}">

<tr><td colspan="2">
	Please note, any text you enter will be converted to unicode in the form &#xxxx; to be able to display any language.
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bordercolor="#A7A783" width="100%">
  <tr>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;#&nbsp;</b></td>
	<td width="150" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Name&nbsp;</b></td>
	<td width="100" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Type&nbsp;</b></td>
	<td width="75%" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Language Name&nbsp;</b></td>
  </tr>
	$List
</table>
	</td>
  </tr>

	<tr><td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
</form>

  </table>
	</td>
</tr>
</table>
<br>

<!-------------------------------------------------->
<script language="javascript">

function ConvertFieldToUnicode(FieldID){
	var Obj = GetElementById(FieldID);
	var text = Obj.value;
	//alert(text);
	text = ConvertToUnicode(text);
	Obj.value = text
}

function ConvertToUnicode(ConvStr){
	var strlen = ConvStr.length;
	var newstr = '';
	var chCode;
	for(var i=0; i<strlen; i++){
		//$line =~ s/([^\x00-\x7f])/sprintf("&#%d;", ord($1))/ge;
		//newstr = newstr + "&#" + strcharConv.charCodeAt(i) + ";"
		//The charCodeAt() method returns the Unicode of the character at a specified position.
		chCode = ConvStr.charCodeAt(i);
		if (chCode > 0x7f) {
				newstr += "&#" + chCode + ";"
		}
		else {
				newstr += String.fromCharCode(chCode)+ '';
		}
		
	}
	return newstr;
}

/* Cross browser related methods */
function GetElementById(id) {
	if (document.all) {
		return document.all(id);
	} else
		if (document.getElementById) {
			return document.getElementById(id);
		}
}

</script>
<!-------------------------------------------------->
HTML
	return $Out;
}
#==========================================================
sub SaveTranslateQuran {
my ($Lang, $K, $Name, $LangName, $Query);

	$Lang = $dbh->quote($Param{TranslateLang});

	while (($K, $LangName)= each %Param) {
		if ($K =~ m/Quran\_(.+)/) {
				$Name = $1;
				$LangName =~ s/^\s+//;
				$LangName =~ s/\s+$//;
				
				$Name =  $dbh->quote($Name);
				$LangName =  $dbh->quote($LangName);

				$Query = qq!DELETE FROM QuranName WHERE Name=$Name AND Language=$Lang!;
				$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

				$Query = qq!INSERT INTO QuranName VALUES ($Name, $Lang, $LangName)!;
				$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
		}
	}
	&TranslateQuran(qq!<p align="center"><font color="red"><b>Changes Saved Successfully.</p>!);
}
#==========================================================
sub TranslateQuranLanguageChange{
	 
	$Param{TranslateLang} = $Param{NewLang};
	&TranslateQuran;
}
#==========================================================
sub UploadQuran {
my ($Msg) = @_;
my ($Out, $Help, $Bar);
	
	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Upload Quran Files
<br><br>
$Msg
<form method="post" action="$Script_URL" enctype="multipart/form-data">
<input type="hidden" name="action" value="UploadQuranFile">

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Upload Quran File</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
    <tr>
	<tr><td colspan="2">
		Upload Quran file from your local computer to your import directory. <br>
		You can upload Quran files archives in zip files to save time and bandwidth.<br> Contents of zip files will be extracted.
	<br><br>
	</td></tr>

    <tr><td nowrap><b>Upload File: </b></td><td width="100%"><input type="file" size="50" name="UploadFile" ></td></tr>

	<tr>
      <td colspan="2">
			
			&nbsp;&nbsp;&nbsp;&nbsp;<br>
			<input type="submit" value="Upload" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
				<br><br><br>
	</td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br><br>
HTML

	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub DownloadQuran {
my ($Msg) = @_;
my ($Out, $Help, $Bar);
	
	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Download Quran Files
<br><br>
$Msg
<form method="post" action="$Script_URL" enctype="multipart/form-data">
<input type="hidden" name="action" value="DownloadQuranLink">

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Download Quran Link</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
    <tr>
	<tr><td colspan="2">
		Download Quran file from online web server to your import directory. 
		You can download Quran files archives in zip files to save time and bandwidth. Contents of zip files will be extracted.
	</td></tr>

    <tr><td nowrap><b>Download URL: </b></td><td width="100%"><input type="text" size="60" name="DownloadURL" ></td></tr>

	<tr>
      <td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Download" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br><br>
HTML
	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
#==========================================================
sub ExtractQuran {
my ($Msg) = @_;
my ($Out, $Help, $Bar);
	
	$Help = &Help_Link("Quran_Manager");
	$Bar = &QuranManagerNavBar;
	@Files = &GetDirectoryZipFilesList($Global{Import_Dir});
	$FileList = "";
	foreach $File (@Files) {
				$FileList .= qq!<option value="$File">$File</option>!;
	}

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=QuranManager">Quran Manager</a> >>Download Quran Files
<br><br>
$Msg
<form method="post" action="$Script_URL" enctype="multipart/form-data">
<input type="hidden" name="action" value="DoExtractQuran">

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Extract Quran Archive</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
    <tr>
	<tr><td colspan="2">
		Extract zip archive files located in your import directory. <br>
		Contents of the zip files will be extracted in the same import directory.<br>
	<br><br>
	</td></tr>

    <tr><td nowrap><b>Select Archive File: </b></td><td width="100%"><select name="Filename">$FileList</select></td></tr>

	<tr>
      <td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
			<input type="submit" value="Extract" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
				<br><br>
	</td>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br><br>
HTML
	&Print_Page($Out, "Quran Manager",  $Help);
}
#==========================================================
sub GetDirectoryZipFilesList {
my ($Directory) = @_;
my (@Files, @Found, $File, $Temp);

   opendir (DIR, "$Directory");
   @Files = readdir (DIR);
   closedir (DIR);
	undef @Found;
   foreach $File (@Files) {
			$Temp = "$Directory/$File";
			if ($File ne "." && $File ne ".." && $File =~ /\.zip$/i) {
					push @Found, $File;
			}
	}
	return @Found;
}
#==========================================================
sub DoExtractQuran {
my ($File);

	if (!$Param{Filename}) {
			&ExtractQuran(qq!<p align="center"><font color="red"><b>Error: No File Name Selected.</p>!);
			return;
	}

	$File = "$Global{Import_Dir}/$Param{Filename}";
	&ExtractQuranZipFile($File);

	&ExtractQuran(qq!<p align="center"><font color="red"><b>File Extracted Successfully.</p>!);
}
#==========================================================
sub ExtractQuranZipFile {
my ($Archive) = @_;
my ($Dest, $Zip);

	$Dest = $Archive;
	$Dest =~ s/[^\\\/]+$//;
	$Zip = Archive::Zip->new();
	$Zip->read($Archive) == AZ_OK || return;
	#$zip->extractTree( $root, $dest, $volume ) 
	$Zip->extractTree( "", $Dest, "") 
}
#==========================================================

1;