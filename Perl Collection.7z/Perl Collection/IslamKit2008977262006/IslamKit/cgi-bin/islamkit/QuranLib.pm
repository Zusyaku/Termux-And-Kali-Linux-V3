=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
#Following Ayaat require compulsary (wajib) sajda:
#1) Sura 32 - As Sajdah (The Adoration) - Ayat 15
#2) Sura 41 - Ha Mim (Ha Mim) - Ayat 38
#3) Sura 53 - An Najm (The Star) - Ayat 62
#4) Sura 96 - Al Alaq (The Clot) - Ayat 19
#
#Following Ayaat require recommended (mustahab) sajda:
#5) Sura 7 - Al A'raf (The Elevated Places) - Ayat 206
#6) Sura 13 - Ar Ra'ad (The Thunder) - Ayat 15
#7) Sura 16 - An Nahl (The Bee) - Ayat 50
#8) Sura 17 - Bani Israil (The Children of Israil) - Ayat 109
#9) Sura 19 - Marium (Mary) - Ayat 58
#10) Sura 22 - Al Haj (The Pilgrimage) - Ayat 18
#11) Sura 25 - Al Furqan (The Criterion) - Ayat 60
#12) Sura 27 - An Naml (The Ant) - Ayat 26
#13) Sura 38 - Saad (Saad) - Ayat 24
#14) Sura 84 - Al Inshiqaq (The Bursting Asunder) - Ayat 21

%SajdahCompulsaryAyats = (
														32 => 15, 	#Surah 32 as-Sajdah / Ayat 15
														41 => 38, 	#Surah 41 al-Fusilat / Ayat 38
														53 => 62, 	#Surah 53 an-Najm / Ayat 62
														96 => 19	    #Surah 96 al-Alaq / Ayat 19
													);

%SajdahRecommendedAyats = (
														7 => 206,		#Sura 7 - Al A'raf (The Elevated Places) - Ayat 206
														13 => 15,		#Sura 13 - Ar Ra'ad (The Thunder) - Ayat 15
														16 => 50,		#Sura 16 - An Nahl (The Bee) - Ayat 50
														17 => 109,	#Sura 17 - Bani Israil (The Children of Israil) - Ayat 109
														19 => 58,		#Sura 19 - Marium (Mary) - Ayat 58
														22 => 18,		#Sura 22 - Al Haj (The Pilgrimage) - Ayat 18
														25 => 60,		#Sura 25 - Al Furqan (The Criterion) - Ayat 60
														27 => 26,		#Sura 27 - An Naml (The Ant) - Ayat 26
														38 => 24,		#Sura 38 - Saad (Saad) - Ayat 24
														84 => 21		#Sura 84 - Al Inshiqaq (The Bursting Asunder) - Ayat 21
													);
	#----------------------------------------------------------------
#Surah Number   Order of Revelation
%OrderOfRevelation = (
								1=>5,
								2=>87,
								3=>89,
								4=>92,
								5=>112,
								6=>55,
								7=>39,
								8=>88,
								9=>113,
								10=>51,
								11=>52,
								12=>53,
								13=>96,
								14=>72,
								15=>54,
								16=>70,
								17=>50,
								18=>69,
								19=>44,
								20=>45,
								21=>73,
								22=>103,
								23=>74,
								24=>102,
								25=>42,
								26=>47,
								27=>48,
								28=>49,
								29=>85,
								30=>84,
								31=>57,
								32=>75,
								33=>90,
								34=>58,
								35=>43,
								36=>41,
								37=>56,
								38=>38,
								39=>59,
								40=>60,
								41=>61,
								42=>62,
								43=>63,
								44=>64,
								45=>65,
								46=>66,
								47=>95,
								48=>111,
								49=>106,
								50=>34,
								51=>67,
								52=>76,
								53=>23,
								54=>37,
								55=>97,
								56=>46,
								57=>94,
								58=>105,
								59=>101,
								60=>13,
								61=>109,
								62=>110,
								63=>104,
								64=>108,
								65=>99,
								66=>107,
								67=>77,
								68=>2,
								69=>78,
								70=>79,
								71=>71,
								72=>40,
								73=>3,
								74=>4,
								75=>31,
								76=>98,
								77=>33,
								78=>80,
								79=>81,
								80=>24,
								81=>7,
								82=>82,
								83=>86,
								84=>83,
								85=>27,
								86=>36,
								87=>8,
								88=>68,
								89=>10,
								90=>35,
								91=>26,
								92=>9,
								93=>11,
								94=>12,
								95=>28,
								96=>1,
								97=>25,
								98=>100,
								99=>93,
								100=>14,
								101=>30,
								102=>16,
								103=>13,
								104=>32,
								105=>19,
								106=>29,
								107=>17,
								108=>15,
								109=>18,
								110=>114,
								111=>6,
								112=>22,
								113=>20,
								114=>21
								);

#Where each surah revealed, Mekkah or Medianh
#Medinah surahs: 2, 3, 4, 5, 8, 9, 13, 22, 24, 33, 47, 48, 49, 55, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 76, 98, 99, 110 
@SurahRevelationMedinah = (2, 3, 4, 5, 8, 9, 13, 22, 24, 33, 47, 48, 49, 55, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 76, 98, 99, 110); # Medinah surahs

@SurahAyahsCount = (0,7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,
										135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,
										53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,
										12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,
										20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6);

@SurahPartFrom = (0, 1, 1, 3, 4, 6, 7, 8, 9, 10, 11, 11, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18, 18, 19, 19, 20,
									20, 21, 21, 21, 21, 22, 22, 22, 23, 23, 23, 24, 24, 25, 25, 25, 25, 26, 26, 26, 26, 26, 26, 27, 27, 27,
									27, 27, 27, 28, 28, 28, 28, 28, 28, 28, 28, 28, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 30, 30, 30,
									30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
									30, 30, 30, 30, 30, 30, 30, 30);
@SurahPartTo = (0, 1, 3, 4, 6, 7, 8, 9, 10, 11, 11, 12, 13, 13, 13, 14, 14, 15, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21,
									21, 21, 22, 22, 22, 23, 23, 23, 24, 24, 25, 25, 25, 25, 25, 26, 26, 26, 26, 26, 27, 27, 27, 27, 27, 27, 27, 
									28, 28, 28, 28, 28, 28, 28, 28, 28, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 29, 30, 30, 30, 30, 30, 30, 30,
									30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 
									30, 30, 30);

@PartStartingSurah = (0, 1, 2, 2, 3, 4, 4, 5, 6, 7, 8, 9, 11, 12, 15, 17, 18, 21, 23, 25, 27, 29, 33, 36, 39, 41, 46, 51, 58, 67, 78);
@PartStartingAyah = (0, 1, 142, 253, 93, 24, 148, 82, 111, 88, 41, 93, 6, 53, 1, 1, 75, 1, 1, 21, 56, 46, 31, 28, 32, 47, 1, 31, 1, 1, 1);

#==========================================================
sub GetSurahAyahsCount {
my ($Surah) = @_;
	if ($Surah<1 || $Surah>114) {return undef;}
	return $SurahAyahsCount[$Surah];
}
#==========================================================
#			Update Part By Suran and Ayah
sub GetPartByAyah {
my ($Surah, $Ayah) = @_;
my ($Found, $x, $Part);

	$Found = 0;
	for ($x=$SurahPartTo[$Surah]; $x>=$SurahPartFrom[$Surah]; $x--) {
		if ($Ayah >= $PartStartingAyah[$x]) {
			$Part = $x;
			$Found = 1;
			last;
		}
	}

	if ($Found == 0){$Part = $SurahPartTo[$Surah-1];}
	return $Part;
}
#==========================================================
sub SurahCount{
	return 114;
}
#==========================================================
sub AyahCount {
	return 6236;
}
#==========================================================
sub SajdahCompulsaryAyats {
	return %SajdahCompulsaryAyats;
}
#==========================================================
sub SajdahRecommendedAyats {
	return %SajdahRecommendedAyats;
}
#==========================================================
sub IsSajdahCompulsaryAyah {
my ($surah, $ayah) = @_;
	
	if ($surah < 1 || $surah > 114) {return 0;}
	if ($SajdahCompulsaryAyats{$surah} eq $ayah ) {
			return 1;
	}
	else {
			return 0;
	}
}
#==========================================================
sub IsSajdahRecommendedAyah {
my ($surah, $ayah) = @_;
	
	if ($surah < 1 || $surah > 114) {return 0;}
	if ($SajdahRecommendedAyats{$surah} eq $ayah ) {
			return 1;
	}
	else {
			return 0;
	}
}
#==========================================================
sub IsSajdahAyah {
my ($surah, $ayah) = @_;

	if ($SajdahCompulsaryAyats{$surah} eq $ayah) {return 1;}

	elsif ($SajdahRecommendedAyats{$surah} eq $ayah) {return 2;}

	else {return 0;}
}
#==========================================================
sub OrderOfRevelation {
	return %OrderOfRevelation;
}
#==========================================================
sub SurahOrderOfRevelation {
my ($surah) = @_;
	if ($surah < 1 || $surah > 114) {return undef;}
	return $OrderOfRevelation{$surah};
}
#==========================================================
#Where each surah revealed, Mekkah or Medianh
sub GetMedinahSurahs {
	return @SurahRevelationMedinah;
}
#==========================================================
#Where each surah revealed, Mekkah or Medianh
#Medinah surahs: 2, 3, 4, 5, 8, 9, 13, 22, 24, 33, 47, 48, 49, 55, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 76, 98, 99, 110 
#Return: 1 for Medinah, 0 for Mekkah.
sub SurahRevelation {
my ($surah) = @_;

	if ($surah < 1 || $surah > 114) {return undef;}
	foreach my $medinah (@SurahRevelationMedinah) {
			if ($medinah == $surah) {
					return 1; # Revealed in Medinah
			}
	}
	return 0; # Revealed in Makkah
}
#==========================================================
#==========================================================

1;