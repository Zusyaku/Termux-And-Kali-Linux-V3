=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Quran {
my ($Template, %SurahNames, $x, $Pages, @Reciters, $SurahNum, %Reciter,
		$Link, $AyahNum, $Menu, $Part, $Option, $Sel, $Ayah, $Temp, $SurahAyahs,
		$Surah, $Reciter, $Page, $Pages, @Names, $Value, %Config
	);

	$Template =&Translate_File($Global{Quran_Template});
	%SurahNames = &Get_Language_File($Global{Language_SurahNames_File});
	#use SurahName;
	#&CreateSurahNamesLanguageFile;
	$Template =~ s/<!--Action-->/$Script_URL/g;
	$Template =~ s/<!--Language-->/$Global{Language}/g;
	#------------------------------------------------------
	if (!$Param{Surah}) {
			$Param{Surah} = $Cookies{IslamKitSurah}?$Cookies{IslamKitSurah} : $Global{DefaultSurah};
	}

	if (!$Param{Ayah}) {
			$Param{Ayah} = $Cookies{IslamKitAyah}?$Cookies{IslamKitAyah} : $Global{DefaultAyah};
	}

	if (!$Param{Ayahs}) {
			$Param{Ayahs} = $Cookies{IslamKitAyahs}?$Cookies{IslamKitAyahs} : $Global{DefaultAyahs};
	}

	if (!$Param{Layout}) {
			$Param{Layout} = $Cookies{IslamKitLayout}?$Cookies{IslamKitLayout} : $Global{DefaultLayout};
	}

	if (!$Param{SurahReciter}) {
			$Param{SurahReciter} = $Cookies{IslamKitSurahReciter}?$Cookies{IslamKitSurahReciter} : $Global{DefaultSurahReciter};
	}

	if (!$Param{AyahReciter}) {
			$Param{AyahReciter} = $Cookies{IslamKitAyahReciter}?$Cookies{IslamKitAyahReciter} : $Global{DefaultAyahReciter};
	}

	if (!$Param{QuranName}) {
			$Param{QuranName} = $Cookies{IslamKitQuran}?$Cookies{IslamKitQuran} : $Global{DefaultQuranName};
	}
	
	if (!$Param{Translation}) {
			$Param{Translation} = $Cookies{IslamKitTranslat}?$Cookies{IslamKitTranslat} : $Global{DefaultTranslation};
	}

	if (!$Param{Transliteration}) {
			$Param{Transliteration} = $Cookies{IslamKitTranslit}?$Cookies{IslamKitTranslit} : $Global{DefaultTransliteration};
	}

	if (!$Param{Interpertation}) {
			$Param{Interpertation} = $Cookies{IslamKitInterpert}?$Cookies{IslamKitInterpert} : $Global{DefaultInterpertation};
	}
	#------------------------------------------------------
	$Param{Surah} ||= $Global{DefaultSurah};
	$Param{Ayah} ||= $Global{DefaultAyah};
	$Param{Ayahs} ||= $Global{DefaultAyahs};
	$Param{SurahReciter} ||= $Global{DefaultSurahReciter};
	$Param{AyahReciter} ||= $Global{DefaultAyahReciter};

	$Param{Part} = &GetPartByAyah($Param{Surah}, $Param{Ayah});
	$Pages =  int (&GetSurahAyahsCount($Param{Surah}) / $Param{Ayahs}) + 1;
	$Param{Pages} = $Pages;
	
	$Param{Page} = 1;
	for $x(1..$Pages) {
		if (($x*$Param{Ayahs}) >= $Param{Ayah}) {$Param{Page} = $x; last;}
	}

	if (!$Param{SurahReciter}) {
			@Reciters = &GetSurahRecitersID();
			$Param{SurahReciter} = $Reciters[0];
	}
	if (!$Param{AyahReciter}) {
			@Reciters = &GetAyahRecitersID();
			$Param{AyahReciter} = $Reciters[0];
	}
	#------------------------------------------------------
	$Template =~ s/<!--Pages-->/$Param{Pages}/g;
	$Template =~ s/<!--Surah-->/$Param{Surah}/g;
	$Template =~ s/<!--Page-->/$Param{Page}/g;
	$Template =~ s/<!--Part-->/$Param{Part}/g;
	$Template =~ s/<!--Ayah-->/$Param{Ayah}/g;
	$Template =~ s/<!--Ayahs-->/$Param{Ayahs}/g;
	$Template =~ s/<!--QuranName-->/$Param{QuranName}/g;
	$Template =~ s/<!--Translation-->/$Param{Translation}/g;
	$Template =~ s/<!--Transliteration-->/$Param{Transliteration}/g;
	$Template =~ s/<!--Interpertation-->/$Param{Interpertation}/g;
	$Template =~ s/<!--Layout-->/$Param{Layout}/g;
	$Template =~ s/<!--SurahReciter-->/$Param{SurahReciter}/g;
	$Template =~ s/<!--AyahReciter-->/$Param{AyahReciter}/g;
	$Template =~ s/<!--TermsEncoded-->/$Param{TermsEncoded}/g;
	$Template =~ s/<!--AyahRepeat-->/$Param{AyahRepeat}/g;
	$Template =~ s/<!--CurrentReciteAyah-->/$Param{Ayah}/g;
	#------------------------------------------------------
	$SurahNum = sprintf("%03d", $Param{Surah});
	%Reciter = &GetReciterByFolder($Param{SurahReciter}, 1);
	$Link = qq!$Global{SurahAudio_URL}/$Reciter{Folder}/$SurahNum\.mp3!;
	$Template =~ s/<!--ReciteSurahLink-->/$Link/g;
	$Template =~ s/<!--SaveSuraLink-->/$Link/g;
	#------------------------------------------------------
	$AyahNum = sprintf("%03d", $Param{Ayah});
	%Reciter = &GetReciterByFolder($Param{AyahReciter}, 2);
	$Link = qq!$Global{AyahAudio_URL}/$Reciter{Folder}/$SurahNum$AyahNum\.mp3!;
	$Template =~ s/<!--ReciteAyahLink-->/$Link/g;
	$Template =~ s/<!--SaveAyahLink-->/$Link/g;
	#------------------------------------------------------
	if ($Param{QuranName}) {
			#%SurahNames = &GetQuranSurahNames($Param{QuranName});
	}
	elsif ($Param{Translation}) {
			#%SurahNames = &GetQuranSurahNames($Param{Translation});
	}
	elsif ($Param{Transliteration}) {
			#%SurahNames = &GetQuranSurahNames($Param{Transliteration});
	}
	elsif ($Param{Interpertation}) {
			#%SurahNames = &GetQuranSurahNames($Param{Interpertation});
	}
	#------------------------------------------------------
	# Part Menu
	#------------------------------------------------------
	$Menu = "";
	for $Part (1..30) {
			$Option = $Language{PartMenuOption};
			$Option =~ s/<!--Part-->/$Part/g;
			if ($Part == $Param{Part}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--PartMenu-->/$Menu/g;
	#------------------------------------------------------
	#------------------------------------------------------
	# Ayah Menu
	#------------------------------------------------------
	$Menu = "";
	for $Ayah (1..58) {
			$Option = $Language{AyahsMenuOption};
			$Temp = $Ayah * 5;
			$Option =~ s/<!--Value-->/$Temp/g;
			if ($Temp == $Param{Ayahs}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--AyahsMenu-->/$Menu/g;
	#------------------------------------------------------
	#------------------------------------------------------
	# Ayahs (Page Size) Menu
	#------------------------------------------------------
	$Menu = "";
	$SurahAyahs = &GetSurahAyahsCount($Param{Surah});
	for $Ayah (1..$SurahAyahs) {
			$Option = $Language{AyahMenuOption};
			$Option =~ s/<!--Value-->/$Ayah/g;
			if ($Ayah == $Param{Ayah}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--AyahMenu-->/$Menu/g;
	#------------------------------------------------------
	# Surah Menu
	#------------------------------------------------------
	$Menu = "";
	for $Surah (1..114) {
			$Option = $Language{SurahMenuOption};
			$Option =~ s/<!--Surah-->/$Surah/g;
			$Option =~ s/<!--Name-->/$SurahNames{$Surah}/g;
			$Option =~ s/<!--Ayahs-->/$SurahAyahsCount[$Surah]/g;
			if ($Surah == $Param{Surah}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--SurahMenu-->/$Menu/g;
	#------------------------------------------------------
	# Layout Menu
	#------------------------------------------------------
	$Menu = "";
	for $x (1..5) {
			$Option = $Language{QuranLayoutMenuOption};
			if ($x == $Param{Layout}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Name-->/$Language{"QuranLayoutName$x"}/g;
			$Option =~ s/<!--Value-->/$x/g;
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--LayoutMenu-->/$Menu/g;
	#------------------------------------------------------
	# Full Surah Reciters Menu
	#------------------------------------------------------
	$Menu = "";
	@Reciters = &GetSurahRecitersID();
	foreach $Reciter (@Reciters) {
			%Reciter = &GetReciter($Reciter);
			$Option = $Language{SurahReciterMenuOption};
			if ($Reciter{Folder} eq $Param{SurahReciter}) {$Sel = "selected";} else { $Sel = "";}
			$Name = &GetReciterName($Reciter);
			$Option =~ s/<!--Name-->/$Name/g;
			$Option =~ s/<!--ID-->/$Reciter/g;
			$Option =~ s/<!--Value-->/$Reciter{Folder}/g;
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--SurahRecitersMenu-->/$Menu/g;
	#------------------------------------------------------
	# Ayah Reciters Menu
	#------------------------------------------------------
	$Menu = "";
	@Reciters = &GetAyahRecitersID();
	foreach $Reciter (@Reciters) {
			%Reciter = &GetReciter($Reciter);
			$Option = $Language{AyahReciterMenuOption};
			if ($Reciter{Folder} eq $Param{AyahReciter}) {$Sel = "selected";} else { $Sel = "";}
			$Name = &GetReciterName($Reciter);
			$Option =~ s/<!--Name-->/$Name/g;
			$Option =~ s/<!--ID-->/$Reciter/g;
			$Option =~ s/<!--Value-->/$Reciter{Folder}/g;
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--AyahRecitersMenu-->/$Menu/g;
	#------------------------------------------------------
	# Ayah Repeat Menu
	#------------------------------------------------------
	$Menu = "";
	foreach $x (0..100) {
			$Option = $Language{AyahRepeatMenuOption};
			if ($x eq $Param{AyahRepeat}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Name-->/$x/g;
			$Option =~ s/<!--Value-->/$x/g;
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--AyahRepeatMenu-->/$Menu/g;
	#------------------------------------------------------
	# Ayah Loop
	#------------------------------------------------------
	if ($Param{AyahLoop}) {$Option = "checked";} else {$Option = "";}
	$Template =~ s/<!--AyahLoopCheck-->/$Option/g;
	if ($Param{AyahLoop}) {$Temp = "true";} else { $Temp = "false";}
	$Template =~ s/<!--AyahLoop-->/$Temp/g;
	#------------------------------------------------------
	# Page menu
	#------------------------------------------------------
	$Menu = "";
	for $Page (1..$Pages) {
			$Option = $Language{PageMenuOption};
			$Option =~ s/<!--Page-->/$Page/g;
			if ($Page == $Param{Page}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--PageMenu-->/$Menu/g;
	#------------------------------------------------------
	# Quran Menu
	#------------------------------------------------------
	$Menu = "";
	@Names = &GetQuranNames(1);
	unshift @Names, "";
	foreach  $Value (@Names) {
			$Name = &GetQuranName($Value);
			$Name ||= $Value;
			$Name ||= $Language{QuranNoneOption};
			%Config = &GetQuranConfig ($Name);
			$Option = $Language{QuranMenuOption};
			$Option =~ s/<!--Name-->/$Name/g;
			$Option =~ s/<!--Value-->/$Value/g;
			if ($Name eq $Param{QuranName}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--QuranMenu-->/$Menu/g;
	#------------------------------------------------------
	# Quran Translation Menu
	#------------------------------------------------------
	$Menu = "";
	@Names = &GetQuranNames(2);
	unshift @Names, "";
	foreach  $Value (@Names) {
			$Name = &GetQuranName($Value);
			$Name ||= $Value;
			$Name ||= $Language{TranslationNoneOption};
			%Config = &GetQuranConfig ($Name);
			$Option = $Language{TranslationMenuOption};
			$Option =~ s/<!--Name-->/$Name/g;
			$Option =~ s/<!--Value-->/$Value/g;
			if ($Name eq $Param{Translation}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--TranslationMenu-->/$Menu/g;
	#------------------------------------------------------
	# Quran Transliteration Menu
	#------------------------------------------------------
	$Menu = "";
	@Names = &GetQuranNames(3);
	unshift @Names, "";
	foreach  $Value (@Names) {
			$Name = &GetQuranName($Value);
			$Name ||= $Value;
			$Name ||= $Language{TransliterationNoneOption};
			%Config = &GetQuranConfig ($Name);
			$Option = $Language{TransliterationMenuOption};
			$Option =~ s/<!--Name-->/$Name/g;
			$Option =~ s/<!--Value-->/$Value/g;
			if ($Name eq $Param{Transliteration}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--TransliterationMenu-->/$Menu/g;
	#------------------------------------------------------
	# Quran Transliteration Menu
	#------------------------------------------------------
	$Menu = "";
	@Names = &GetQuranNames(4);
	unshift @Names, "";
	foreach  $Value (@Names) {
			$Name = &GetQuranName($Value);
			$Name ||= $Value;
			$Name ||= $Language{InterpertationNoneOption};
			%Config = &GetQuranConfig ($Name);
			$Option = $Language{InterpertationMenuOption};
			$Option =~ s/<!--Name-->/$Name/g;
			$Option =~ s/<!--Value-->/$Value/g;
			if ($Name eq $Param{Interpertation}) {$Sel = "selected";} else { $Sel = "";}
			$Option =~ s/<!--Selected-->/$Sel/g;
			$Menu .= $Option;
	}
	$Template =~ s/<!--InterpertationMenu-->/$Menu/g;
	#------------------------------------------------------
	
	#------------------------------------------------------
	&Display($Template,1);
}
#==========================================================
sub ReadQuran {
my ($Ayahs, $FromAyah, $ToAyah, %Config, $Template, $Format, 
		%QuranFormat, %QuranConfig, %TranslatFormat, %TranslatConfig, 
		%TranslitFormat, %TranslitConfig, %InterpertFormat, %InterpertConfig,
		$ThemeForm, $QuranFormLine, $TranslatFormLine, $TranslitFormLine, $InterpertFormLine,
		$SearchTerms, @Terms, %Reciter, $QuranForm, $TranslitForm, $TranslatForm, $InterpertForm,
		%SurahReciter, %AyahReciter, $Diacritics, $Sajdah,
		$Count, $CurAyah, $QuranThemeForm,  $QuranThemeFormLine, $Name, $Surah, $Ayah, $Quran,
		$K, $V, $Word, @Words, $Clean, $SurahNum, $AyahNum, $Link, $Temp, $sth1, $sth2, $sth3, $sth4
);

	$Template =&Translate_File($Global{QuranViewer_Template});
	$Template =~ s/<!--Action-->/$Script_URL/g;
	$Template =~ s/<!--Language-->/$Global{Language}/g;
	#------------------------------------------------------
	$Param{Surah} ||= $Global{DefaultSurah};
	$Param{Ayah} ||= 1;
	$Param{Page} ||= 1;
	$Param{Layout} ||= 1;
	$Param{Ayahs} ||= $Global{DefaultAyahs};
	$Param{QuranName} ||= "";
	$Param{Translation} ||= "";
	$Param{Transliteration} ||= "";
	$Param{Interpertation} ||= "";
	$Param{Layout} ||= "";
	$Param{SurahReciter} ||= "";
	$Param{AyahReciter} ||= "";
	$Param{AyahRepeat} ||= "";
	$Param{AyahLoop} ||= "";
	#------------------------------------------------------
	if ($Param{QuranName}) {
			%QuranConfig = &GetQuranConfig($Param{QuranName});
			if (!%QuranConfig) {$Param{QuranName} = "";}
	}
	if ($Param{Translation}) {
			%TranslatConfig = &GetQuranConfig($Param{Translation});
			if (!%TranslatConfig) {$Param{Translation} = "";}
	}
	if ($Param{Transliteration}) {
			%TranslitConfig = &GetQuranConfig($Param{Transliteration});
			if (!%TranslitConfig) {$Param{Transliteration} = "";}
	}
	if ($Param{Interpertation}) {
			%InterpertConfig = &GetQuranConfig($Param{Interpertation});
			if (!%InterpertConfig) {$Param{Interpertation} = "";}
	}
	#------------------------------------------------------
	&Set_Cookies("IslamKitSurah", $Param{Surah}, 1);
	&Set_Cookies("IslamKitAyah", $Param{Ayah}, 1);
	&Set_Cookies("IslamKitAyahs", $Param{Ayahs}, 1);
	&Set_Cookies("IslamKitQuran", $Param{QuranName}, 1);
	&Set_Cookies("IslamKitTranslat", $Param{Translation}, 1);
	&Set_Cookies("IslamKitTranslit", $Param{Transliteration}, 1);
	&Set_Cookies("IslamKitInterpert", $Param{Interpertation}, 1);
	&Set_Cookies("IslamKitLayout", $Param{Layout}, 1);
	&Set_Cookies("IslamKitSurahReciter", $Param{SurahReciter}, 1);
	&Set_Cookies("IslamKitAyahReciter", $Param{AyahReciter}, 1);
	&Set_Cookies("IslamKitAyahRepeat", $Param{AyahRepeat}, 1);
	&Set_Cookies("IslamKitAyahLoop", $Param{AyahLoop}, 1);
	#------------------------------------------------------
	if ($Param{Page} < 1) {$Param{Page} =1 ;}
	
	$Ayahs = &GetSurahAyahsCount($Param{Surah});

	$FromAyah = ($Param{Page}-1) * $Param{Ayahs} +1;
	$ToAyah = $FromAyah + $Param{Ayahs};
	if ($ToAyah > $Ayahs) {$ToAyah = $Ayahs;}
	
	undef %QuranFormat;
	if (%QuranConfig) {
		for $Format(1..20) {
				if ($QuranConfig{"Find$Format"} ne "") {
						$QuranFormat{$QuranConfig{"Find$Format"}} = $QuranConfig{"Replace$Format"};
				}
		}
	}
	undef %TranslatFormat;
	if (%TranslatConfig) {
		for $Format(1..20) {
				if ($TranslatConfig{"Find$Format"} ne "") {
						$TranslatFormat{$TranslatConfig{"Find$Format"}} = $TranslatConfig{"Replace$Format"};
				}
		}
	}
	undef %TranslitFormat;
	if (%TranslitConfig) {
		for $Format(1..20) {
				if ($TranslitConfig{"Find$Format"} ne "") {
						$TranslitFormat{$TranslitConfig{"Find$Format"}} = $TranslitConfig{"Replace$Format"};
				}
		}
	}
	undef %InterpertFormat;
	if (%InterpertConfig) {
		for $Format(1..20) {
				if ($InterpertConfig{"Find$Format"} ne "") {
						$InterpertFormat{$InterpertConfig{"Find$Format"}} = $InterpertConfig{"Replace$Format"};
				}
		}
	}
	#--------------------------------------------------------------------------
	#--------------------------------------------------------------------------
	if ($Param{QuranName}) {
			$QuranName = $dbh->quote($Param{QuranName});
			$Query = qq!SELECT * FROM Quran1 WHERE Name=$QuranName AND Surah=$Param{Surah} AND Ayah>=$FromAyah AND Ayah<=$ToAyah ORDER BY Ayah ASC!;
			$sth1 = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth1->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}

	if ($Param{Translation}) {
			$QuranName = $dbh->quote($Param{Translation});
			$Query = qq!SELECT * FROM Quran2 WHERE Name=$QuranName AND Surah=$Param{Surah} AND Ayah>=$FromAyah AND Ayah<=$ToAyah ORDER BY Ayah ASC!;
			$sth3 = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth3->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}

	if ($Param{Transliteration}) {
			$QuranName = $dbh->quote($Param{Transliteration});
			$Query = qq!SELECT * FROM Quran3 WHERE Name=$QuranName AND Surah=$Param{Surah} AND Ayah>=$FromAyah AND Ayah<=$ToAyah ORDER BY Ayah ASC!;
			$sth2 = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth2->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}

	if ($Param{Interpertation}) {
			$QuranName = $dbh->quote($Param{Interpertation});
			$Query = qq!SELECT * FROM Quran4 WHERE Name=$QuranName AND Surah=$Param{Surah} AND Ayah>=$FromAyah AND Ayah<=$ToAyah ORDER BY Ayah ASC!;
			$sth4 = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth4->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}
	#--------------------------------------------------------------------------
	#--------------------------------------------------------------------------
	$ThemeForm = "";
	if ($Param{QuranName}) {
			$QuranFormLine = $Global{"QuranForm$Param{Layout}"};
			$QuranFormLine =~ s/<!--AyahForm-->/$QuranConfig{AyahForm}/g;
			$QuranFormLine = &Translate($QuranFormLine);
	}
	else{
			$QuranFormLine = "";
	}
	if ($Param{Translation}) {
			$TranslatFormLine = $Global{"TranslatForm$Param{Layout}"};
			$TranslatFormLine =~ s/<!--AyahForm-->/$TranslatConfig{AyahForm}/g;
			$TranslatFormLine = &Translate($TranslatFormLine);
	}
	else{
			$TranslatFormLine = "";
	}
	if ($Param{Transliteration}) {
			$TranslitFormLine = $Global{"TranslitForm$Param{Layout}"};
			$TranslitFormLine =~ s/<!--AyahForm-->/$TranslitConfig{AyahForm}/g;
			$TranslitFormLine = &Translate($TranslitFormLine);
	}
	else {
			$TranslitFormLine = "";
	}
	if ($Param{Interpertation}) {
			$InterpertFormLine = $Global{"InterpertForm$Param{Layout}"};
			$InterpertFormLine =~ s/<!--AyahForm-->/$InterpertConfig{AyahForm}/g;
			$InterpertFormLine = &Translate($InterpertFormLine);
	}
	else{
			$InterpertFormLine = "";
	}
	#----------------------------------------------------------------
	#p($Param{TermsEncoded});
	$SearchTerms = lc(&RemoveDiacritic($Param{TermsEncoded}));
	@Terms = split (' ', $SearchTerms);
	#----------------------------------------------------------------
	$QuranThemeFormLine = &Translate($Global{"QuranThemeForm$Param{Layout}"});
	
	if ($Param{SurahReciter}) {%SurahReciter = &GetReciterByFolder($Param{SurahReciter}, 1);}
	if ($Param{AyahReciter}) {%AyahReciter = &GetReciterByFolder($Param{AyahReciter}, 2);}

	$QuranForm = "";
	$TranslitForm = "";
	$TranslatForm = "";
	$InterpertForm = "";
	
	$Diacritics = qq!\&\#1611\;|\&\#1612\;|\&\#1613\;|\&\#1614\;|\&\#1615\;|\&\#1616\;|\&\#1617\;|\&\#1618\;!;

	for $Count (0..$Param{Ayahs}-1) {
			$CurAyah = $FromAyah + $Count;
			if ($CurAyah > $Ayahs) {last;}

			$QuranThemeForm = $QuranThemeFormLine;

			if ($Param{QuranName}) {
					$QuranForm = $QuranFormLine;
					if (($Name, $Surah, $Ayah, $Quran) = $sth1->fetchrow_array) {
							while (($K, $V) = each %QuranFormat) { # Find & Replace Tags
									$Quran =~ s/$K/$V/ig;
							}
							#------------------------------------------------------------
							# Format search terms
							if ($SearchTerms) {
									if ($QuranConfig{Versions} == 0) { # No Diacritic or html tags Version
											foreach $Term (@Terms) {
												$Quran =~ s/$Term/$Global{Search_Prefix}$Term$Global{Search_Suffix}/ig;
											}
									}
									else {	#Diacritic or html formated version
											@Words = split (' ', $Quran);
											$Quran = "";
											foreach $Word (@Words) {
													$Clean = $Word;
													$Clean =~ s/$Diacritics//g; # Remove Diacritic
													$Clean =~ s/<[^>]+>//ig; # remove html code
													foreach $Term (@Terms) {
															if ($Clean =~ m/$Term/i) {
																	$Word = qq!$Global{Search_Prefix}$Word$Global{Search_Suffix}!;
																	last;
															}
													}
													$Quran .= " " . $Word;
											}
									}
							}
							#------------------------------------------------------------
							$QuranForm =~ s/<!--Quran-->/$Quran/g;
							$SurahNum = sprintf("%03d", $Surah);
							$AyahNum = sprintf("%03d", $Ayah);
							$Link = qq!$Global{AyahAudio_URL}/$AyahReciter{Folder}/$SurahNum$AyahNum\.mp3!;
							$QuranForm =~ s/<!--AyahAudio-->/$Link/g;
							$QuranForm =~ s/<!--Ayah-->/$Ayah/g;
							$QuranForm =~ s/<!--Surah-->/$Surah/g;
							$Link = qq!top.ReciteAyah(\'$Surah\', \'$Ayah\');!;
							$QuranForm =~ s/<!--ReciteAyah-->/$Link/g;
							if ($QuranConfig{ArabicDigits}) {$Temp = &ConvertToArabicDigits($Ayah);}
							else{$Temp = $Ayah;}
							$QuranForm =~ s/<!--AyahNum-->/$Temp/g;
							
							$Sajdah = &IsSajdahAyah($Surah, $Ayah);
							if ($Sajdah ==1) {$QuranForm =~ s/<!--Sajdah-->/$Language{SajdahCompulsaryAyah}/g;}
							elsif ($Sajdah ==2) {$QuranForm =~ s/<!--Sajdah-->/$Language{SajdahRecommendedAyah}/g;}
							else {$QuranForm =~ s/<!--Sajdah-->//g;}
					}
			}

			if ($Param{Translation}) {
					$TranslatForm = $TranslatFormLine;
					if (($Name, $Surah, $Ayah, $Quran) = $sth3->fetchrow_array) {
							while (($K, $V) = each %TranslatFormat) {
									$Quran =~ s/$K/$V/ig;
							}
							#------------------------------------------------------------
							# Format search terms
							if ($SearchTerms) {
									if ($TranslatConfig{Versions} == 0) { # No Diacritic or html tags Version
											foreach $Term (@Terms) {
												$Quran =~ s/$Term/$Global{Search_Prefix}$Term$Global{Search_Suffix}/ig;
											}
									}
									else {	#Diacritic or html formated version
											@Words = split (' ', $Quran);
											$Quran = "";
											foreach $Word (@Words) {
													$Clean = $Word;
													$Clean =~ s/$Diacritics//g; # Remove Diacritic
													$Clean =~ s/<[^>]+>//ig; # remove html code
													foreach $Term (@Terms) {
															if ($Clean =~ m/$Term/i) {
																	$Word = qq!$Global{Search_Prefix}$Word$Global{Search_Suffix}!;
																	last;
															}
													}
													$Quran .= " " . $Word;
											}
									}
							}
							#------------------------------------------------------------
							$TranslatForm =~ s/<!--Quran-->/$Quran/g;
							$SurahNum = sprintf("%03d", $Surah);
							$AyahNum = sprintf("%03d", $Ayah);
							$Link = qq!$Global{AyahAudio_URL}/$AyahReciter{Folder}/$SurahNum$AyahNum\.mp3!;
							$TranslatForm =~ s/<!--AyahAudio-->/$Link/g;
							$TranslatForm =~ s/<!--Ayah-->/$Ayah/g;
							$TranslatForm =~ s/<!--Surah-->/$Surah/g;
							$Link = qq!top.ReciteAyah(\'$Surah\', \'$Ayah\');!;
							$TranslatForm =~ s/<!--ReciteAyah-->/$Link/g;
							if ($TranslatConfig{ArabicDigits}) {$Temp = &ConvertToArabicDigits($Ayah);}
							else{$Temp = $Ayah;}
							$TranslatForm =~ s/<!--AyahNum-->/$Temp/g;
							$Sajdah = &IsSajdahAyah($Surah, $Ayah);
							if ($Sajdah ==1) {$TranslatForm =~ s/<!--Sajdah-->/$Language{SajdahCompulsaryAyah}/g;}
							elsif ($Sajdah ==2) {$TranslatForm =~ s/<!--Sajdah-->/$Language{SajdahRecommendedAyah}/g;}
							else {$TranslatForm =~ s/<!--Sajdah-->//g;}
					}
			}

			if ($Param{Transliteration}) {
					$TranslitForm = $TranslitFormLine;
					if (($Name, $Surah, $Ayah, $Quran) = $sth2->fetchrow_array) {
							while (($K, $V) = each %TranslitFormat) {
									$Quran =~ s/$K/$V/ig;
							}
							#------------------------------------------------------------
							# Format search terms
							if ($SearchTerms) {
									if ($TranslitConfig{Versions} == 0) { # No Diacritic or html tags Version
											foreach $Term (@Terms) {
												$Quran =~ s/$Term/$Global{Search_Prefix}$Term$Global{Search_Suffix}/ig;
											}
									}
									else {	#Diacritic or html formated version
											@Words = split (' ', $Quran);
											$Quran = "";
											foreach $Word (@Words) {
													$Clean = $Word;
													$Clean =~ s/$Diacritics//g; # Remove Diacritic
													$Clean =~ s/<[^>]+>//ig; # remove html code
													foreach $Term (@Terms) {
															if ($Clean =~ m/$Term/i) {
																	$Word = qq!$Global{Search_Prefix}$Word$Global{Search_Suffix}!;
																	last;
															}
													}
													$Quran .= " " . $Word;
											}
									}
							}
							#------------------------------------------------------------
							$TranslitForm =~ s/<!--Quran-->/$Quran/g;
							$SurahNum = sprintf("%03d", $Surah);
							$AyahNum = sprintf("%03d", $Ayah);
							$Link = qq!$Global{AyahAudio_URL}/$AyahReciter{Folder}/$SurahNum$AyahNum\.mp3!;
							$TranslitForm =~ s/<!--AyahAudio-->/$Link/g;
							$TranslitForm =~ s/<!--Ayah-->/$AyahNum/g;
							$TranslitForm =~ s/<!--Surah-->/$SurahNum/g;
							$Link = qq!top.ReciteAyah(\'$Surah\', \'$Ayah\');!;
							$TranslitForm =~ s/<!--ReciteAyah-->/$Link/g;
							if ($TranslitConfig{ArabicDigits}) {$Temp = &ConvertToArabicDigits($Ayah);}
							else{$Temp = $Ayah;}
							$TranslitForm =~ s/<!--AyahNum-->/$Temp/g;
							$Sajdah = &IsSajdahAyah($Surah, $Ayah);
							if ($Sajdah ==1) {$TranslitForm =~ s/<!--Sajdah-->/$Language{SajdahCompulsaryAyah}/g;}
							elsif ($Sajdah ==2) {$TranslitForm =~ s/<!--Sajdah-->/$Language{SajdahRecommendedAyah}/g;}
							else {$TranslitForm =~ s/<!--Sajdah-->//g;}
					}
			}

			if ($Param{Interpertation}) {
					$InterpertForm = $InterpertFormLine;
					if (($Name, $Surah, $Ayah, $Quran) = $sth4->fetchrow_array) {
							while (($K, $V) = each %InterpertFormat) {
									$Quran =~ s/$K/$V/ig;
							}
							#------------------------------------------------------------
							# Format search terms
							if ($SearchTerms) {
									if ($InterpertConfig{Versions} == 0) { # No Diacritic or html tags Version
											foreach $Term (@Terms) {
												$Quran =~ s/$Term/$Global{Search_Prefix}$Term$Global{Search_Suffix}/ig;
											}
									}
									else {	#Diacritic or html formated version
											@Words = split (' ', $Quran);
											$Quran = "";
											foreach $Word (@Words) {
													$Clean = $Word;
													$Clean =~ s/$Diacritics//g; # Remove Diacritic
													$Clean =~ s/<[^>]+>//ig; # remove html code
													foreach $Term (@Terms) {
															if ($Clean =~ m/$Term/i) {
																	$Word = qq!$Global{Search_Prefix}$Word$Global{Search_Suffix}!;
																	last;
															}
													}
													$Quran .= " " . $Word;
											}
									}
							}
							#------------------------------------------------------------
							$InterpertForm =~ s/<!--Quran-->/$Quran/g;
							$SurahNum = sprintf("%03d", $Surah);
							$AyahNum = sprintf("%03d", $Ayah);
							$Link = qq!$Global{AyahAudio_URL}/$AyahReciter{Folder}/$SurahNum$AyahNum\.mp3!;
							$InterpertForm =~ s/<!--AyahAudio-->/$Link/g;
							$InterpertForm =~ s/<!--Ayah-->/$AyahNum/g;
							$InterpertForm =~ s/<!--Surah-->/$SurahNum/g;
							$Link = qq!top.ReciteAyah(\'$Surah\', \'$Ayah\');!;
							$InterpertForm =~ s/<!--ReciteAyah-->/$Link/g;
							if ($InterpertConfig{ArabicDigits}) {$Temp = &ConvertToArabicDigits($Ayah);}
							else{$Temp = $Ayah;}
							$InterpertForm =~ s/<!--AyahNum-->/$Temp/g;
							$Sajdah = &IsSajdahAyah($Surah, $Ayah);
							if ($Sajdah ==1) {$InterpertForm =~ s/<!--Sajdah-->/$Language{SajdahCompulsaryAyah}/g;}
							elsif ($Sajdah ==2) {$InterpertForm =~ s/<!--Sajdah-->/$Language{SajdahRecommendedAyah}/g;}
							else {$InterpertForm =~ s/<!--Sajdah-->//g;}
					}
			}

			$QuranThemeForm =~ s/<!--QuranForm-->/$QuranForm/g;
			$QuranThemeForm =~ s/<!--TranslitForm-->/$TranslitForm/g;
			$QuranThemeForm =~ s/<!--TranslatForm-->/$TranslatForm/g;
			$QuranThemeForm =~ s/<!--InterpertForm-->/$InterpertForm/g;
	
			$ThemeForm .= $QuranThemeForm;
	}
	
	#Diacritics 
	#$Text =~ s/\xF0|\xF1|\xF2|\xF3|\xF5|\xF6|\xF8|\xFA//g;	#Windows 1256
	#$Text =~ s/\&\#1611\;|\&\#1612\;|\&\#1613\;|\&\#1614\;|\&\#1615\;|\&\#1616\;|\&\#1617\;|\&\#1618\;//g; # Unicode

	$QuranTheme = &Translate($Global{"QuranTheme$Param{Layout}"});
	$QuranTheme =~ s/<!--ThemeForm-->/$ThemeForm/g;

	$Template =~ s/<!--QuranForm-->/$QuranTheme/g;

	$sth1->finish if ($sth1);
	$sth2->finish if ($sth2);
	$sth3->finish if ($sth3);
	$sth4->finish if ($sth4);
	#--------------------------------------------------------------------------
	&Display($Template, 1);
}
#==========================================================
sub SearchQuran {
my ($Template, $Query, %Types, $sth, $Count, $AyahLine, $Lines);
my ($Name, $Type, $Surah, $Ayah, $Line);

	$Template =&Translate_File($Global{QuranSearch_Template});
	$Template =~ s/<!--Action-->/$Script_URL/g;
	$Template =~ s/<!--Language-->/$Global{Language}/g;
	#------------------------------------------------------
	$Param{Surah} ||= "";
	$Template =~ s/<!--Terms-->/$Param{Search}/g;
	$Template =~ s/<!--TermsEncoded-->/$Param{TermsEncoded}/g;
	#--------------------------------------------------------------------------
	$Query = q! SELECT Name, Type FROM QuranConfig!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Types;
	while (($Name,  $Type) = $sth->fetchrow_array){
		$Types{$Name} = $Type;
	}

	@Query = &PrepareSearchQuery();
	
	$AyahLine = &Translate($Language{SearchAyahForm});
	$Count = 0;
	$Lines = "";

	foreach  $Query (@Query) {
			if ($Query) {
					$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
					$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
					while (($Name, $Surah, $Ayah) = $sth->fetchrow_array){
							$Count++;
							$Line = $AyahLine;
							$Line =~ s/<!--Count-->/$Count/g;
							$Line =~ s/<!--Name-->/$Name/g;
							$Line =~ s/<!--Surah-->/$Surah/g;
							$Line =~ s/<!--Ayah-->/$Ayah/g;

							$SurahNum = sprintf("%03d", $Surah);
							$AyahNum = sprintf("%03d", $Ayah);
							$Link = qq!$Global{AyahAudio_URL}/$Reciter{Folder}/$SurahNum$AyahNum\.mp3!;
							$Line =~ s/<!--AyahAudio-->/$Link/g;

							$Type = $Types{$Name};
							$Temp = "\'$Name\',$Type,$Surah,$Ayah";
							$Line =~ s/<!--ID-->/$Temp/g;
							
							$Line .= $Language{SearchAyahFormJoiner};
							$Lines .= $Line;
							if ($Global{Maximum_Search_Results} > 0) {
									if ($Count >= $Global{Maximum_Search_Results}) {last;}
							}
					}
					$sth->finish;
			}
	}
	$Lines =~ s/$Language{SearchAyahFormJoiner}$//g;
	$Template =~ s/<!--SearchResults-->/$Lines/g;

	&Display($Template, 1);
}
#==========================================================
sub PrepareSearchQuery {
my (@Terms, %Required, %Execlud, %Optional, @Query, $Limit);
my ($AND, $OR, $NOT, $sth, $Data, $x, $Start, $End, $Term, $What, $Query);
	
	$Param{TermsEncoded} =~ s/<[^>]+>//ig; # remove html code
	$Param{TermsEncoded} =~ s/\$//g;
	$Param{TermsEncoded} =~ s/^\s+//;
	$Param{TermsEncoded} =~ s/\s+$//;
	$Param{TermsEncoded} =~ s/\s+/ /g;

	if (!$Param{TermsEncoded}) {
		$Global{Total_Matched_Count} = 0;
		return undef;
	}

	@Terms = &PerpareSearchTerms($Param{TermsEncoded});

	if (!@Terms) {
			$Global{Total_Matched_Count} = 0;
			return undef;
	}
	
	undef %Required; undef %Execlud; undef %Optional;
	foreach $Term (@Terms) {
		if ($Term =~ /^\+/) {$Term =~s/\+//; $Required{$Term}=1;}      
		elsif ($Term =~ /^\-/) {$Term =~s/\-//; $Execlud{$Term}=1;}      
		elsif ($Term =~ /^\|/) {$Term =~s/\|//; $Optional{$Term}=1;}      
		else {$Required{$Term}=1;}
	}

	$What = "Quran";
	undef @Query;

	$Query = ""; $AND = ""; $OR = ""; $NOT = "";
	if ($Param{QuranName}) {
			$Name = $dbh->quote($Param{QuranName});
			%Config = &GetQuranConfig ($Param{QuranName});
			if ($Config{Versions} == 0) {
					$Query = qq!SELECT Name, Surah, Ayah FROM Quran1 WHERE Name=$Name AND !;
			}
			else{ # Diacritic or html formated version exists
					$Query = qq!SELECT Name, Surah, Ayah FROM Search1 WHERE Name=$Name AND !;
			}
			
			#foreach $Term(keys %Required) {$AND .= "$What LIKE N\'%$Term%' AND ";}
			foreach $Term(keys %Required) {$AND .= "$What LIKE \'%$Term%' AND ";}
			$AND =~ s/AND\s*$//;

			foreach $Term(keys %Optional) {$OR .= "$What LIKE \'%$Term%\' OR ";}
			$OR =~ s/OR\s*$//;

			foreach $Term(keys %Execlud) {$NOT .= "$What NOT LIKE \'%$Term%\' AND ";}
			$NOT =~ s/AND\s*$//;

			if ($AND) {$Query .= " ($AND)";}
			if ($OR && $AND) {$Query .= " OR ($OR) AND ";}
			elsif ($OR){$Query .= " ($OR) AND ";}

			if ($NOT) {$Query .= " ($NOT) AND ";}
			$Query =~ s/AND\s*$//;

			$Query .= " ORDER BY Name, Surah, Ayah";
	}
	push @Query, $Query;

	$Query = ""; $AND = ""; $OR = ""; $NOT = "";
	if ($Param{Translation}) {
			$Name = $dbh->quote($Param{Translation});
			%Config = &GetQuranConfig ($Param{Translation});
			if ($Config{Versions} == 0) {
					$Query = qq!SELECT Name, Surah, Ayah FROM Quran2 WHERE Name=$Name AND !;
			}
			else{
					$Query = qq!SELECT Name, Surah, Ayah FROM Search2 WHERE Name=$Name AND !;
			}
			foreach $Term(keys %Required) {$AND .= "$What LIKE \'%$Term%' AND ";}
			$AND =~ s/AND\s*$//;

			foreach $Term(keys %Optional) {$OR .= "$What LIKE \'%$Term%\' OR ";}
			$OR =~ s/OR\s*$//;

			foreach $Term(keys %Execlud) {$NOT .= "$What NOT LIKE \'%$Term%\' AND ";}
			$NOT =~ s/AND\s*$//;

			if ($AND) {$Query .= " ($AND)";}
			if ($OR && $AND) {$Query .= " OR ($OR) AND ";}
			elsif ($OR){$Query .= " ($OR) AND ";}

			if ($NOT) {$Query .= " ($NOT) AND ";}
			$Query =~ s/AND\s*$//;

			$Query .= " ORDER BY Name, Surah, Ayah";
	}
	push @Query, $Query;

	$Query = ""; $AND = ""; $OR = ""; $NOT = "";
	if ($Param{Transliteration}) {
			$Name = $dbh->quote($Param{Transliteration});
			%Config = &GetQuranConfig ($Param{Transliteration});
			if ($Config{Versions} == 0) {
					$Query = qq!SELECT Name, Surah, Ayah FROM Quran3 WHERE Name=$Name AND !;
			}
			else{
					$Query = qq!SELECT Name, Surah, Ayah FROM Search3 WHERE Name=$Name AND !;
			}
			foreach $Term(keys %Required) {$AND .= "$What LIKE \'%$Term%' AND ";}
			$AND =~ s/AND\s*$//;

			foreach $Term(keys %Optional) {$OR .= "$What LIKE \'%$Term%\' OR ";}
			$OR =~ s/OR\s*$//;

			foreach $Term(keys %Execlud) {$NOT .= "$What NOT LIKE \'%$Term%\' AND ";}
			$NOT =~ s/AND\s*$//;

			if ($AND) {$Query .= " ($AND)";}
			if ($OR && $AND) {$Query .= " OR ($OR) AND ";}
			elsif ($OR){$Query .= " ($OR) AND ";}

			if ($NOT) {$Query .= " ($NOT) AND ";}
			$Query =~ s/AND\s*$//;

			$Query .= " ORDER BY Name, Surah, Ayah";
	}
	push @Query, $Query;

	$Query = ""; $AND = ""; $OR = ""; $NOT = "";
	if ($Param{Interpertation}) {
			$Name = $dbh->quote($Param{Interpertation});
			%Config = &GetQuranConfig ($Param{Interpertation});
			if ($Config{Versions} == 0) {
					$Query = qq!SELECT Name, Surah, Ayah FROM Quran4 WHERE Name=$Name AND !;
			}
			else{
					$Query = qq!SELECT Name, Surah, Ayah FROM Search4 WHERE Name=$Name AND !;
			}
			foreach $Term(keys %Required) {$AND .= "$What LIKE \'%$Term%' AND ";}
			$AND =~ s/AND\s*$//;

			foreach $Term(keys %Optional) {$OR .= "$What LIKE \'%$Term%\' OR ";}
			$OR =~ s/OR\s*$//;

			foreach $Term(keys %Execlud) {$NOT .= "$What NOT LIKE \'%$Term%\' AND ";}
			$NOT =~ s/AND\s*$//;

			if ($AND) {$Query .= " ($AND)";}
			if ($OR && $AND) {$Query .= " OR ($OR) AND ";}
			elsif ($OR){$Query .= " ($OR) AND ";}

			if ($NOT) {$Query .= " ($NOT) AND ";}
			$Query =~ s/AND\s*$//;

			$Query .= " ORDER BY Name, Surah, Ayah";
	}
	push @Query, $Query;
	
	return (@Query);
}
#==========================================================
sub PerpareSearchTerms {
my ($Terms) = @_;
my (@Terms, $Terms1, $Temp, $x, $Found);
		
		$Terms =~ s/<[^>]+>//ig; # remove html code
		$Terms = &RemoveDiacritic ($Terms);
		$Terms || return undef;
		#$Terms =~ s/\$//g;
		#$Terms =~ s/\?//g; 
		#$Terms =~ s/\(//g;
		#$Terms =~ s/\)//g;
		#$Terms =~ s/\[//g;
		#$Terms =~ s/\]//g;

		#$Terms = lc($Terms);
		$Terms =~ s/^\s+//;
		$Terms =~ s/\s+$//;
		$Terms =~ s/\s+/ /g;
		#$Terms =~ s/\'/\\'/g;
        $Terms =~ s/\s*\+\s*/ and /ig;

		$Global{Required_Search_Term} = $Terms;

		$Terms =~ s/ and not / -/ig;
		$Terms =~ s/ and / \+/ig;
        $Terms =~ s/ not / -/ig;        
		$Terms =~ s/ or / \|/ig;

		#$Terms =~ s/\*+/\\S*\\W/g;
		$Terms =~ s/(\*+)/\%/g;
		$Terms1 = $Terms;

		while( $Terms1 =~ m|"([^\"\\]*(?:\\.[^\"\\]*)*)"|gx ) { 
						$Temp = $1;
						$Temp1= $Temp;
						$Temp1 =~ s/^\s+//;
						$Temp1 =~ s/\s+$//;
						$Temp1 =~ s/\s+/\_/g;
						$Terms =~ s/$Temp/$Temp1/g;
		}
		
		$Terms =~ s/\"//g;
		$Global{Required_Search_Term} =~ s/\"//g;

		@Terms = split(/\s+/, $Terms);

		$Found = 0;
		for $x (0..$#Terms) {
			$Terms[$x] =~ s/\_/ /g;

			if ($Terms[$x] =~ /\-/) {
					$Global{Required_Search_Term} =~ s/$Terms[$x]//g;
			}
			if ($Terms[$x] eq $Global{Required_Search_Term}) {
					$Found = 1;
			}
		}

		$Global{Required_Search_Term} =~ s/\s+/ /g;
		if (!$Found) {
				unshift @Terms , "|$Global{Required_Search_Term}";
		}
		return (@Terms);
}
#==========================================================
sub ReciteAyah {
my ($Template, $SurahNum, $AyahNum, %Reciter, $Link);

	$Template =&Translate_File($Global{ReciteAyah_Template});
	$Template =~ s/<!--Action-->/$Script_URL/g;
	$Template =~ s/<!--Language-->/$Global{Language}/g;
	#------------------------------------------------------
	$SurahNum = sprintf("%03d", $Param{Surah});
	$AyahNum = sprintf("%03d", $Param{Ayah});
	%Reciter = &GetReciter($Param{Reciter});
	$Link = qq!$Global{AyahAudio_URL}/$Reciter{Folder}/$SurahNum$AyahNum\.mp3!;
	$Template =~ s/<!--ReciteAyahLink-->/$Link/g;
	#------------------------------------------------------
	&Display($Template,1);
}
#==========================================================
sub ReciteSurah{
my ($Template, $SurahNum, %Reciter, $Link);

	$Template =&Translate_File($Global{ReciteSurah_Template});
	$Template =~ s/<!--Action-->/$Script_URL/g;
	$Template =~ s/<!--Language-->/$Global{Language}/g;
	#------------------------------------------------------
	$SurahNum = sprintf("%03d", $Param{Surah});
	%Reciter = &GetReciter($Param{SurahReciter});
	$Link = qq!$Global{SurahAudio_URL}/$Reciter{Folder}/$SurahNum\.mp3!;
	$Template =~ s/<!--ReciteSurahLink-->/$Link/g;
	#------------------------------------------------------
	#<script language="javascript" event="EndOfStream( lResult )" for="MediaPlayer">top.location.replace("xxxxxxx");alert("xxxxxxxxxx");</script>
	&Display($Template,1);
}
#==========================================================
1;