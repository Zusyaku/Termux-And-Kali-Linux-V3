=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub AdminAction{

if ($Param{action} eq 'Configuration') {&Configuration;}
elsif ($Param{action} eq 'Save_Configuration') {&Demo; &Save_Configuration;}
elsif ($Param{action} eq 'Get_Path_Tips') {	&Get_Path_Tips;}
elsif ($Param{action} eq 'General_Options') {&DB_Start;&General_Options;}
elsif ($Param{action} eq 'Save_General_Options') {&Demo; &Save_General_Options;}
elsif ($Param{action} eq "Lock_Access") {&Lock_Access;}
elsif ($Param{action} eq "Save_Access_Lock") {&Demo; &Save_Access_Lock;}
elsif ($Param{action} eq "Help") {&Help;}

#--------------------------------Quran Manager--------------------------------
elsif ($Param{action} eq "QuranManager") {&StartQuranManager; &QuranManager;}
elsif ($Param{action} eq "AddQuran") {&StartQuranManager; eval "use SurahName;"; &AddQuran;}
elsif ($Param{action} eq "AddNewQuran") {&Demo; &StartQuranManager; eval "use SurahName;"; &AddNewQuran;}
elsif ($Param{action} eq "DeleteQuran") {&StartQuranManager; &DeleteQuran;}
elsif ($Param{action} eq "ConfirmDeleteQuran") {&StartQuranManager; &ConfirmDeleteQuran;}
elsif ($Param{action} eq "DoDeleteQuran") {&Demo; &StartQuranManager; &DoDeleteQuran;}
elsif ($Param{action} eq "UpdateQuran") {&StartQuranManager; &UpdateQuran;}
elsif ($Param{action} eq "DoUpdateQuran") {&Demo; &StartQuranManager; &DoUpdateQuran;}

elsif ($Param{action} eq "ExportQuran") {&StartQuranManager; &ExportQuran;}
elsif ($Param{action} eq "DoExportQuran") {&Demo; &StartQuranManager; &DoExportQuran;}

elsif ($Param{action} eq "UploadQuran") {&StartQuranManager; &UploadQuran;}
elsif ($Param{action} eq "DownloadQuran") {&StartQuranManager; &DownloadQuran;}

elsif ($Param{action} eq "DownloadQuranLink") {&Demo; &StartQuranManager; &DownloadQuranLink;}
elsif ($Param{action} eq "UploadQuranFile") {&Demo; &StartQuranManager; &UploadQuranFile;}

elsif ($Param{action} eq "ExtractQuran") {&StartQuranManager; &ExtractQuran;}
elsif ($Param{action} eq "DoExtractQuran") {&Demo; &StartQuranManager; &DoExtractQuran;}

elsif ($Param{action} eq "QuranConfig") {&StartQuranManager; &QuranConfig;}
elsif ($Param{action} eq "SaveQuranConfig") {&Demo; &StartQuranManager; &SaveQuranConfig;}
elsif ($Param{action} eq "EditQuran") {&StartQuranManager; &EditQuran;}
elsif ($Param{action} eq "SaveEditQuran") {&Demo; &StartQuranManager; &SaveEditQuran;}

elsif ($Param{action} eq "EditSurahs") {&StartQuranManager; eval "use SurahName;"; &EditSurahs;}
elsif ($Param{action} eq "SaveEditSurahs") {&Demo; &StartQuranManager; eval "use SurahName;"; &SaveEditSurahs;}

elsif ($Param{action} eq "TranslateQuran") {&StartQuranManager; &TranslateQuran;}
elsif ($Param{action} eq "SaveTranslateQuran") {&Demo; &StartQuranManager; &SaveTranslateQuran;}
elsif ($Param{action} eq 'TranslateQuranLanguageChange') {&StartQuranManager; &TranslateQuranLanguageChange;}

#--------------------------------Audio Manager--------------------------------
elsif ($Param{action} eq 'AudioManager') {&StartAudioManager; &AudioManager;}
elsif ($Param{action} eq 'AddReciter') {&StartAudioManager; &AddReciter;}
elsif ($Param{action} eq 'AddNewReciter') {&Demo; &StartAudioManager; &AddNewReciter;}
elsif ($Param{action} eq 'TranslateReciters') {&StartAudioManager; &TranslateReciters;}
elsif ($Param{action} eq 'SaveTranslateReciters') {&Demo; &StartAudioManager; &SaveTranslateReciters;}
elsif ($Param{action} eq 'TranslateRecitersLanguageChange') {&StartAudioManager; &TranslateRecitersLanguageChange;}
elsif ($Param{action} eq 'ConfirmDeleteReciter') {&StartAudioManager; &ConfirmDeleteReciter;}
elsif ($Param{action} eq 'DeleteReciter') {&Demo; &StartAudioManager; &DeleteReciter;}

elsif ($Param{action} eq 'UploadReciter') {&StartAudioManager; &UploadReciter;}
elsif ($Param{action} eq 'UploadReciterFiles') {&Demo; &StartAudioManager; &UploadReciterFiles;}
elsif ($Param{action} eq 'BrowseReciter') {&StartAudioManager; &BrowseReciter;}

#--------------------------------Setup Wizard Functions--------------------------------
elsif ($Param{action} eq 'Setup_Wizard') {&Setup_Wizard;}
elsif ($Param{action} eq "Server_Test") {eval "use testserver;"; &Server_Test;}
elsif ($Param{action} eq 'Create_SQL_Tables') {&Demo; eval "use CreateTables;"; eval "use ForumTables;"; &DB_Start; &Create_SQL_Tables;}
#--------------------------------Server Backup Functions--------------------------------
elsif ($Param{action} eq "Server_Backup") {eval "use Backup;"; &Server_Backup;}
elsif ($Param{action} eq "Do_Server_Backup") {&Demo; eval "use Backup;"; &Do_Server_Backup;}
#--------------------------------About Functions--------------------------------
elsif ($Param{action} eq "Update") {eval"use About;"; &Update;}
elsif ($Param{action} eq "About") {eval"use About;"; &About;}
#--------------------------------Editor Functions--------------------------------
elsif ($Param{action} eq "VisualEditorAdm") {eval "use Editor;"; &VisualEditorAdm; exit 0;}
elsif ($Param{action} eq "Custom_Functions") {eval "use Editor;"; &Custom_Functions;}
elsif ($Param{action} eq "Save_Custom_Functions") {&Demo; eval "use Editor;"; &Save_Custom_Functions;}
elsif ($Param{action} eq "Create_Custom_Functions_File") {&Demo; eval "use Editor;"; &Create_Custom_Functions_File;}
elsif ($Param{action} eq "Template_Editor") {eval "use Editor;"; &Template_Editor;}
elsif ($Param{action} eq "Save_Template_Editor") {&Demo; eval "use Editor;"; &Save_Template_Editor;}
elsif ($Param{action} eq "Create_New_Template") {&Demo; eval "use Editor;"; &Create_New_Template;}
elsif ($Param{action} eq "Class_Editor") {eval "use Editor;"; &Class_Editor;}
elsif ($Param{action} eq "SaveEditorSetting") {&Demo; eval "use Editor;"; &SaveEditorSetting;}
elsif ($Param{action} eq "Save_Editor_Class") {&Demo; eval "use Editor;"; &Save_Editor_Class;}
elsif ($Param{action} eq "Special_Classes") {eval "use Editor;"; &Special_Classes;}
elsif ($Param{action} eq "Save_Special_Class") {&Demo; eval "use Editor;"; &Save_Special_Class;}
elsif ($Param{action} eq "Create_Custom_Class") {&Demo; eval "use Editor;"; &Create_Custom_Class;}
elsif ($Param{action} eq "Create_Custom_Page") {&Demo; eval "use Editor;"; &Create_Custom_Page;}
#--------------------------------System Announcements Functions--------------------------------
elsif ($Param{action} eq "Announcements_Manager") {eval "use AnnouncAdm;"; &DB_Start; &Announcements_Manager;}
elsif ($Param{action} eq "NewAnnouncement") {eval "use AnnouncAdm;"; &DB_Start; &NewAnnouncement;}
elsif ($Param{action} eq "SaveAnnouncement") {&Demo; eval "use AnnouncAdm;"; &DB_Start; &SaveAnnouncement;}
elsif ($Param{action} eq "EditAnnouncement") {eval "use AnnouncAdm;"; &DB_Start; &EditAnnouncement;}
elsif ($Param{action} eq "DeleteAnnouncement") {&Demo; eval "use AnnouncAdm;"; &DB_Start; &DeleteAnnouncement;}
elsif ($Param{action} eq "CopyAnnouncement") {eval "use AnnouncAdm;"; &DB_Start; &CopyAnnouncement;}
#--------------------------------Database & SQL Functions--------------------------------
elsif ($Param{action} eq "Database_Manager") {eval "use DatabaseMgr;"; &DB_Start; &Database_Manager;}
elsif ($Param{action} eq "SQL_Text_Backup") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Text_Backup;}
elsif ($Param{action} eq "Load_SQL_Text_Backup") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &Load_SQL_Text_Backup;}
elsif ($Param{action} eq "SQL_Tables_Load_Unload") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Tables_Load_Unload;}
elsif ($Param{action} eq "Load_Unload_SQL_Tables") {eval "use DatabaseMgr;"; &DB_Start; &Load_Unload_SQL_Tables;}
elsif ($Param{action} eq "Manage_SQL_Tables") {eval "use DatabaseMgr;"; &DB_Start; &Manage_SQL_Tables;}
elsif ($Param{action} eq "SQL_Table_Action") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Table_Action;}
elsif ($Param{action} eq "Manage_SQL_Databases") {eval "use DatabaseMgr;"; &DB_Start; &Manage_SQL_Databases;}
elsif ($Param{action} eq "SQL_Database_Action") {	&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Database_Action;}
elsif ($Param{action} eq "SQL_Commander") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Commander;}
elsif ($Param{action} eq "SQL_Server_Variables") {eval "use DatabaseMgr;"; &DB_Start; &SQL_Server_Variables;}
elsif ($Param{action} eq "SQL_Server_Status") {eval "use DatabaseMgr;"; &DB_Start; &SQL_Server_Status;}
elsif ($Param{action} eq 'SaveDatabaseOptions') {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SaveDatabaseOptions;}
elsif ($Param{action} eq "SQL_Administration") {eval "use DatabaseMgr;"; &DB_Start; &SQL_Administration;}
elsif ($Param{action} eq "SQLUserPriv") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Administration;}
elsif ($Param{action} eq "SQL_Administration_Connect") {&Demo; eval "use DatabaseMgr;"; &DB_Start; &SQL_Administration_Connect;}
#--------------------------------Language Manager Functions--------------------------------
elsif ($Param{action} eq "Language_Manager") {&LangMgrStart; &Language_Manager;}
elsif ($Param{action} eq "Create_New_Language") {&Demo; &LangMgrStart; &Create_New_Language;}
elsif ($Param{action} eq "Set_Default_Language") {&Demo; &LangMgrStart; &Set_Default_Language;}
elsif ($Param{action} eq "Delete_Language") {&Demo; &LangMgrStart; &Delete_Language;}
elsif ($Param{action} eq "Edit_Language_File") {&DB_Start; &LangMgrStart; &Edit_Language_File("");}
elsif ($Param{action} eq "Save_Language_File") {&Demo; &LangMgrStart; &Save_Language_File;}
elsif ($Param{action} eq "Initialize_Language") {&LangMgrStart; &Initialize_Language;}
elsif ($Param{action} eq "Search_Language") {&LangMgrStart; &Search_Language;}
elsif ($Param{action} eq "Replace_Language") {&Demo; &LangMgrStart; &Replace_Language;}
#--------------------------------Theme Manager Functions--------------------------------
elsif ($Param{action} eq 'ThemeManager') {&StartThemeMgr; &ThemeManager;}
elsif ($Param{action} eq 'CreateTheme') {&Demo; &StartThemeMgr; &CreateTheme;}
elsif ($Param{action} eq 'DeleteTheme') {&Demo; &StartThemeMgr; &DeleteTheme;}
elsif ($Param{action} eq 'ConfigureThemes') {&Demo; &StartThemeMgr; &ConfigureThemes;}
#------------------------------------------------------------------------------
else {&Admin_Menu;}
#----------------------------------------------
exit 0;
}
#=======================End of admin main action=====================
#==========================================================
sub StartQuranManager {
	eval "use QuranManager;";
	eval "use QuranLib;";
	&ModLoad("constant", "Archive::Zip qw( :ERROR_CODES :CONSTANTS )");
	&DB_Start;
}
#==========================================================
sub StartAudioManager{
	eval "use AudioManager;";
	eval "use QuranLib;";
	&ModLoad("constant", "Archive::Zip qw( :ERROR_CODES :CONSTANTS )");
	&DB_Start;
}
#==========================================================
sub LangMgrStart{
	eval "use LangaugeMgr;"; 
	&ModLoad("File::Copy");
}
#==========================================================
sub StartThemeMgr{
	eval "use ThemeMgr;";
	&ModLoad("File::Copy");
	&DB_Start;
	&ReadConfiguration;
}
#==========================================================
sub StartAdsMgr{
	eval "use BannerAdm;";
	eval "use AdStats;";
	&DB_Start;
	&ReadConfiguration;
	&Read_Language_File($Global{Language_Banner_File});
}
#==========================================================
#==========================================================
sub Get_Images_Links{

	$Global{R_Bullet} = qq!<IMG SRC="$Global{Images_URL}/415.gif" border="0">!;
	$Global{G_Bullet} = qq!<IMG SRC="$Global{Images_URL}/407.gif" border="0">!;
	$Global{Y_Bullet} = qq!<IMG SRC="$Global{Images_URL}/Yl_ball.gif" border="0">!;
	$Global{O_Bullet} = qq!<IMG SRC="$Global{Images_URL}/orgball.gif" border="0">!;
#	$Global{G1_Bullet} = qq!<IMG SRC="$Global{Images_URL}/grn02dot.gif" border="0">!;
	$Global{G1_Bullet} = qq!<IMG SRC="$Global{Images_URL}/208.gif" border="0">!;
	$Global{R1_Bullet} = qq!<IMG SRC="$Global{Images_URL}/sub_tree.gif" border="0">!;
	$Global{Sm_Red_Ball} = qq!<IMG SRC="$Global{Images_URL}/smredball.gif" border="0">!;
	$Global{Sm_Green_Ball} = qq!<IMG SRC="$Global{Images_URL}/smgreenball.gif" border="0">!;
	$Global{Sm_Mag_Ball} = qq!<IMG SRC="$Global{Images_URL}/smmagball.gif" border="0">!;
	$Global{Sm_Yel_Ball} = qq!<IMG SRC="$Global{Images_URL}/smyelball.gif" border="0">!;
	$Global{Sm_Redd_Ball} = qq!<IMG SRC="$Global{Images_URL}/sm_redd_ball.gif" border="0">!;
	$Global{Folder_Image} = qq!<IMG SRC="$Global{Images_URL}/accounts_folder.gif" border="0">!;
}
#==========================================================
sub Check_Admin_Authentication{

	$Cookies{IslamKitAdminUserID} ||= "";
	$Cookies{IslamKitAdminPassword} ||= "";
	$Global{IslamKitAdminUserID} ||= "";
	$Global{IslamKitAdminPassword} ||= "";

	$Cookies{IslamKitAdminUserID} = &Decrypt($Cookies{IslamKitAdminUserID}, '�����������');
	$Cookies{IslamKitAdminPassword} = &Decrypt($Cookies{IslamKitAdminPassword}, '�����������');

	$Global{IslamKitAdminUserID} = &Decrypt($Global{IslamKitAdminUserID}, '�����������');
	$Global{IslamKitAdminPassword} = &Decrypt($Global{IslamKitAdminPassword}, '�����������');

	if ($Global{IslamKitAdminUserID} eq $Cookies{IslamKitAdminUserID} &&
			$Global{IslamKitAdminPassword} eq $Cookies{IslamKitAdminPassword}) {
			#Ok login to the system
			&Set_Cookies("IslamKitAdminUserID", &Encrypt($Cookies{IslamKitAdminUserID}, '�����������'), "");
			&Set_Cookies("IslamKitAdminPassword", &Encrypt($Cookies{IslamKitAdminPassword}, '�����������'), "");
	}
	elsif ($Global{IslamKitAdminUserID} eq $Param{IslamKitAdminUserID} &&
			$Global{IslamKitAdminPassword} eq $Param{IslamKitAdminPassword}) {
			#Ok login to the system
			&Set_Cookies("IslamKitAdminUserID", &Encrypt($Param{IslamKitAdminUserID}, '�����������'), "");
			&Set_Cookies("IslamKitAdminPassword", &Encrypt($Param{IslamKitAdminPassword}, '�����������'), "");
	}
	else{
			print "Content-type: text/html\n\n";
			print &Admin_Login_Form;
			exit 0;
	}
}
#==========================================================
sub Admin_Login_Form{
my ($Out);

$Out =<<HTML;
<html>
<head>
<title>IslamKit Administration Center - www.islamware.com</title>
</head>
<body>

<br><br><br><br><br><br><br>
<form name="User_Login" method="post" action="$Script_URL">
<div align="center">
<table border="2" bgcolor="#CC3300" bordercolor="#990000"  cellspacing="0" cellpadding="0">
<tr><td>
<table border="0" bgcolor="#CC3300" cellspacing="0" cellpadding="03">
  <tr>
    <td align="center">
		<b>
        &nbsp;
        <font color="#FFFF66" face="Times New Roman">Islamware</font><font color="#FFFF00" face="Times New Roman"><sup><font color="#FFA791">&reg;</font></sup> </font>
        <font color="#FFFF66" face="Times New Roman">IslamKit Administration Center</font></b>&nbsp;&nbsp;
    </td>
  </tr>
  
  <tr>
    <td bgcolor="#FFFFD9" width="100%">
      <table border="0" cellspacing="0" cellpadding="2" width="100%">
        <tr><td>
              <b><font color="#304422">&nbsp;Please enter your system login information</font></b>
           </td></tr>
          <tr><td>
          <table border="0" width="100%" cellpadding="2">
            <tr>
              <td align="right"><b><font color="#000080">User ID:</font></b></td>
              <td align="left"><input type="text" name="IslamKitAdminUserID" size="20"></td>
            </tr>
            <tr>
              <td align="right"><b><font color="#000080">Password:</font></b></td>
              <td align="left"><input type="password" name="IslamKitAdminPassword" size="20"></td>
            </tr>
          </table>
          
          </td>
        </tr>
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
                <input type="submit" value="Login" name="Admin_Login">
          </td>
        </tr>
      </table>

    </td>
  </tr>
</table>
    </td>
  </tr>
</table>
</div>
</form>

<script language="JavaScript">
<!--
document.User_Login.IslamKitAdminUserID.focus();
// -->
</script>

</body>
</html>
HTML

	return $Out;
}
#==========================================================
sub Demo{

	if ($Global{Demo_Mode}) {
		&Admin_Msg("Sorry!, Demo, Can't Do it!!", "The Save, Delete, and some other functions are disabled for our server security in the demo.",1);
		exit 0;
	}
	return 0;
}
#==========================================================
sub Admin_Msg{
my ($Title, $Message, $Level, $Width)=@_;

	&Print_Page(&Msgs($Title, $Message, $Level, $Width));
	exit 0;
}
#==========================================================
sub Msgs{
my ($Title, $Message,$Level, $Width)=@_;
my ($Out, $Width1);

	$Width1 = $Width - 5;
	if ($Width <= 0) {$Width=350; $Width1=345;}

$Out=<<HTML;
<P>&nbsp;</P><P>&nbsp;</P>
<div align="center"><center>
<table border="0" width="$Width" bgcolor="#005329" >
  <tr><td width="100%" align="center" height="19"><b><font color="#FFFF00" face="Times New Roman">
	$Title
	</font></b>
    </td>
  </tr>
  </CENTER>
  <tr><td width="$Width1">
      <div align="center">
      <table border="0" width="$Width1" cellspacing="0" cellpadding="0" bgcolor="#E1E1C4">
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
          
          <div align="center">
            <table width="100%" border="0" cellpadding="3">
              <tr>
                <td width="100%" align="left">
				
				$Message
				
				</td>
              </tr>
            </TABLE>
          </DIV>
          </td>
        </tr>
  <center>
        <center>
        <tr><td valign="middle" align="center" bgcolor="#FFFFD9">
		<form><P align="center">
				<input type=button value="-- OK --" onClick="history.go(-$Level)">
		</form>
          </td>
        </tr>
      </table>
        </center>
      </div>
    </td>
  </tr>
</table>
  </center>
</div>
HTML

return $Out;
}
#==========================================================
sub Admin_Menu{
my ($Out, $Help);

	$Help = &Help_Link("index");

$Out=<<HTML;
<div align="center"><center>
  <table border="0" width="100%" cellspacing="0" cellpadding="3">
    <tr><td width="100%" align="center"><br><img border="0" src="$Global{Images_URL}/admwelcome.jpg"><br><br></td></tr>
    <tr><td width="100%">For technical support, please visit the vendor web site at <a href="http://www.islamware.com" target="_blank">www.islamware.com</a>.</td></tr>
  </table>
  </center>
</div>
<br>

<table width="100%" cellpadding="0" cellspacing="0" border="0" >
<tr><td width="100%">
<table width="100%" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" background="$Global{Images_URL}/lh1.gif" height="22"><b>Product News</b></td><td align="right">&nbsp;</td></tr>
</table>
</td></tr>

<tr><td width="100%">
<table width="100%" cellpadding="2" cellspacing="0" border="1" bordercolor="#FCE487">
   <tr><td valign="top">

   <iframe src="http://www.islamware.com/cgi-bin/forum/forum.cgi" width="100%" height="250" frameborder="0" marginheight="0" marginwidth="0" vspace="0" hspace="0" align="middle" scrolling="auto"></iframe>

   </td></tr> 
 </table>
</td></tr> 
</table>
<br><br>
HTML

	&Print_Page($Out, "Welcome...", $Help);
}
#==========================================================
sub Print_Page{
my ($Body, $Title, $Help) = @_;
my ($Out, $Main_Help, $AffiliatesManager);

	$Main_Help = &Help_Link_HREF('index');
	if (!$Body) {$Body = "";}
	if (!$Title) {$Title = "";}
	if (!$Help) {$Help = "";}

	$Admin_Prog = "$Global{CGI_URL}/$Global{Admin_Prog}";
	
	$Plugins{HeadCode} ||= "";
	$Plugins{JS_Code} ||= "";

$Out=<<HTML1;
<html>
<head>
<title>Islamware - www.islamware.com</title>
<meta name="description" content="Provides Islamic Software Products and Development Tools for Muslims and Islamic Developers">
<meta name="keywords" content="Islam, Quran, Qibla, Holy Quran, Pray, Islam, Musilm,">
$Plugins{HeadCode}
<!---------------------------------------->
<script language="JavaScript">
function JS_OnLoad() {
$Plugins{JS_Code}
}
</script>
<!---------------------------------------->
<style type="text/css">

body    {font-size: 12px; font-family: tahoma, verdana, arial, helvetica, sans-serif;}
td, th, p, div {font-size: 12px; font-family: tahoma, verdana, arial, helvetica, sans-serif;}

.footer      { font-family: tahoma, verdana; font-size: 11px; color: #E6E600 }
.footer a    { font-family: tahoma, verdana; font-size: 11px; color: #FFFF99; text-decoration: underline }
.footer a:hover { font-family: tahoma, verdana; font-size: 11px; color: #c60000; text-decoration: none }
.header      { color: #ffffcc; text-transform: uppercase }

input {background-color: #F4F4F4; color: #000000;border-color: #000000; border-width: 1px; border-style: solid;padding-left: 2; padding-right: 0; padding-top: 0; padding-bottom: 0; font-size:12px; font-weight: normal; font-family: tahoma, verdana;}
option {background-color: #F4F4F4; color: #000000;border-color: #000000; border-width: 1px; border-style: solid;padding-left: 2; padding-right: 0; padding-top: 0; padding-bottom: 0; font-size:12px; font-weight: normal; font-family: tahoma, verdana;}
</style>

<style>
body {     
scrollbar-base-color: #808040;
}
</style>

<style>

a            { color: #004F4F; font-family: Tahoma,Arial, Helvetica; text-decoration: underline}
a:hover      { color: #CC5200; font-family: Tahoma, Arial, Helvetica; text-decoration: none}

.topnav {color: #FF0000}
.topnav a      { font-family: Times,arial, tahoma, verdana; font-size: 14px; color: #B1B163; text-decoration: none}
.topnav a:hover { font-family: Times,arial,tahoma, verdana; font-size: 14px; color: #FFFF33; text-decoration: underline}

.nav {background-color: #005100}
.nav a      { font-family: tahoma, verdana; font-size: 12px; color: #ffbb00; text-decoration: none}
.nav a:hover { font-family: tahoma, verdana; font-size: 12px; color: #FFFF66; text-decoration: none}

.navhilite {cursor: hand; background-color: #008400}
.navhilite a      { font-family: tahoma, verdana; font-size: 12px; color: #FFFF66; text-decoration: none}
.navhilite a:hover { font-family: tahoma, verdana; font-size: 12px; color: #FFFF66; text-decoration: none}

.smlink a      { font-family: tahoma, verdana; font-size: 10px; color: #006600; text-decoration: none}
.smlink a:hover { font-family: tahoma, verdana; font-size: 10px; color: #FF0066; text-decoration: none}

</style>

</head>

<body onload="JS_OnLoad()" bgcolor="#244A4A" text="#402000" link="#0000ff" vlink="#800080" alink="#ff0000" topmargin="20" leftmargin="20" marginwidth="20" marginheight="20">

<div align="center"><center>
<table width="100%" cellpadding="0" cellspacing="0" border="2" bordercolor="#330000">
  <tr><td>

      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td background="$Global{Images_URL}/admtopbg.jpg"><img src="$Global{Images_URL}/adminlogo.jpg" border="0"></td>
		  <td align="center" width="100%" background="$Global{Images_URL}/admtopbg.jpg"><img src="$Global{Images_URL}/admtopcenter.jpg" border="0"></td>
          <td nowrap align="right" background="$Global{Images_URL}/admtopbg.jpg">
				<table cellpadding="0" cellspacing="0" border="0">
					<tr class="topnav" ><td align="right">
								<table cellpadding="5" cellspacing="1" border="0">
								<tr><td height="18" width="100%"><img src="$Global{Images_URL}/dot1x1.gif" border="0"></td></tr>
								<tr class="topnav" >
										<td><a href="$Admin_Prog"><b>Home</b></a></td>
										<td><a href="$Global{Prog_URL}" target="_blank"><b>Website</b></a></td>
										<td><a  href="#" $Main_Help><b>Help</b></a></td>
										<td><a href="$Admin_Prog?action=About"><b>About</b></a></td>
								<tr>
								</table>
					</td></tr>
				</table>
		  </td>
        </tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#003000">
        <tr><td><img src="$Global{Images_URL}/topbarmoz.jpg" border="0" width="100%" height="10"></td></tr>
      </table>

      <table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>

          <td bgcolor="#003000" valign="top" width="200">
            <center><img src="$Global{Images_URL}/admtitmanage.jpg" ALT="System Management"  border="0" width="175" height="20"></center>
            <table cellpadding="0" cellspacing="0" border="0" bgcolor="#003000" width="100%">
              <tr>
                <td>
                  <table cellpadding="3" cellspacing="1" border="0" bgcolor="#004000" width="100%">
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=QuranManager'"><A HREF="$Admin_Prog?action=QuranManager" TARGET="_top">&nbsp;Quran Manager</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=AudioManager'"><A HREF="$Admin_Prog?action=AudioManager" TARGET="_top">&nbsp;Audio Manager</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Language_Manager'"><A HREF="$Admin_Prog?action=Language_Manager" TARGET="_top">&nbsp;Language Manager</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Announcements_Manager'"><A HREF="$Admin_Prog?action=Announcements_Manager" TARGET="_top">&nbsp;Announcements Manager</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Database_Manager'"><A HREF="$Admin_Prog?action=Database_Manager" TARGET="_top">&nbsp;Database & SQL Manager</a></td></tr>
                  </table>
                </td>
              </tr>
            </table>

            <CENTER><IMG SRC="$Global{Images_URL}/admtitlayout.jpg" ALT="Layout &amp; Integration" border="0" width="175" HEIGHT="20"></CENTER>

            <table cellpadding="0" cellspacing="0" border="0" bgcolor="#003000" width="100%">
              <tr>
                <td>
                  <table cellpadding="3" cellspacing="1" border="0" bgcolor="#004000" width="100%">
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=ThemeManager'"><A HREF="$Admin_Prog?action=ThemeManager" TARGET="_top">&nbsp;Theme Manager</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Class_Editor'"><A HREF="$Admin_Prog?action=Class_Editor" TARGET="_top">&nbsp;Class Editor</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Template_Editor'"><A HREF="$Admin_Prog?action=Template_Editor" TARGET="_top">&nbsp;Template Editor</a></td></tr>
                  </TABLE>
                </td>
              </tr>
            </TABLE>

            <center><img src="$Global{Images_URL}/admtitsetup.jpg" ALT="System Setup" border="0" width="175" height="20"></center>

            <table cellpadding="0" cellspacing="0" border="0" bgcolor="#003000" width="100%">
              <tr><td>
                  <table cellpadding="3" cellspacing="1" border="0" bgcolor="#004000" width="100%">
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Configuration'"><A HREF="$Admin_Prog?action=Configuration" TARGET="_top">&nbsp;Configuration</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=General_Options'"><A HREF="$Admin_Prog?action=General_Options" TARGET="_top">&nbsp;General Options</a></td></tr>
						<tr><td NOWRAP bgcolor="#005100" class="nav" onMouseOver="this.className='navhilite';" onMouseOut="this.className='nav';" onClick="self.location='$Admin_Prog?action=Setup_Wizard'"><A HREF="$Admin_Prog?action=Setup_Wizard" TARGET="_top">&nbsp;Setup Wizard</a></td></tr>
                  </table>
                </td>
              </tr>
            </table>

          </td>

          <td width="100%" valign="top" bgcolor="#FFFFFF">

            <table width="100%" cellpadding="01" cellspacing="0" border="0" bgcolor="#F4DC93">
				<tr>
				<td align="center" width="100%" nowrap background="$Global{Images_URL}/bodytitle.jpg">
				<font size="3" face="Times"><b>$Title</b></font></td>
                <td align="center" nowrap background="$Global{Images_URL}/bodytitle.jpg">&nbsp;$Help&nbsp;</td>
              </tr>
            </table>


            <table width="100%" cellpadding="2" cellspacing="0" border="0">
              <tr><td> $Body </td></tr>
            </TABLE>

          </td>
        </tr>
      </table>


      <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#003000">
        <tr><td><IMG SRC="$Global{Images_URL}/clear10x10.gif" border="0" width="1" HEIGHT="2"></td></tr>
      </TABLE>
      
	  <table width="100%" cellpadding="2" cellspacing="0" border="0">
        <tr><td class="footer" background="$Global{Images_URL}/admcopyrightbg.jpg"><CENTER>Copyright � 2006 <A HREF="http://www.islamware.com/" TARGET="_blank">IslamWare</a><sup>&reg;</sup>. All Rights Reserved</CENTER></td></tr>
      </TABLE>

      <table width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#000000">
        <tr><td><IMG SRC="$Global{Images_URL}/clear10x10.gif" border="0" width="10" HEIGHT="1"></td></tr>
      </table>
    </td>
  </tr>
</table>
  </center>
</div>

</body>
</html>
HTML1
	
	print "Content-type: text/html\n\n";
	print "$Out";

}
#==========================================================
sub Error_Msg{
my ($Title, $Msg, $Level)=@_;
my $Out;

$Out=<<HTML;
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>IslamWare - www.islamware.com</title>
<STYLE >
<!--
 A:hover {color: #ff3300 ;} 
-->
</STYLE>

<STYLE TYPE="text/css">
<!--
.lwr  a:link    { color: white; }
.lwr  a:visited { color: white; }
.lwr  a:active  { color: #ff3300; }
.lwr  a:hover   { color: red; background-color : yellow;}
.lwr  a{ text-decoration: none }

.lbr  a:link    { color: blue; }
.lbr  a:visited { color: blue; }
.lbr  a:active  { color: #ff3300; }
.lbr  a:hover   { color: red; background-color : #FFFF00;}
.lbr  a{ text-decoration: none }
-->
</STYLE>
</head>

<body bgcolor="#E1E1C4" >

<div class="lbr" align="center">
  <center>

<table border="0" width="405" bgcolor="#005329" >
  <tr>
    <td width="100%" align="center" HEIGHT="19"><b>
	<font color="#FFFF00" FACE="TIMES NEW ROMAN, ARIAL">
	
	$Title
	
	</font></b>
    </td>
  </tr>
  <tr>
    <td width="400">
      <DIV align="center">
      <table border="0" width="400" cellspacing="0" cellpadding="0" bgcolor="#E1E1C4">
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
          <DIV align="center">
            <table width="100%" border="0" cellpadding="3">
              <tr>
                <td width="100%" ALIGN="LEFT">
				
				$Msg
				
				</td>
              </tr>
            </TABLE>
          </DIV>
          </td>
        </tr>
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
		  <FORM>
               <P align="center">

				<input type=button VALUE="--OK--" onClick="history.go(-$Level)">

  		  </form>
          </td>
        </tr>
      </table>
      </div>
    </td>
  </tr>
</table>
</center>
</div>
</body>
</html>

HTML
	return $Out;
}
#==========================================================
#==========================================================
sub Get_Path_Tips{

	if ($ENV{SCRIPT_FILENAME}){
			$CGI_Path = $ENV{SCRIPT_FILENAME};
			$CGI_Path =~ s,[^/\\]*$,,ig;
			$CGI_Path =~ s,[\\|\/]$,,ig;
	}

	$CGI_URL = "$ENV{HTTP_HOST}" . "$ENV{SCRIPT_NAME}";
	if ($CGI_URL !~ /^http/i) {$CGI_URL = "http://". $CGI_URL;}
	$CGI_URL =~ s,[^/\\]*$,,ig;
	$CGI_URL =~ s,[\\|\/]$,,ig;

	$OS = $^O;
	if (($OS eq "MSWin32") || ($OS eq "Windows_NT") || ($OS =~ /win/i)) {
			$OS = "Windows($OS)"; 
	}
	else { 
		$OS = "Unix($OS)"; 
	}

$Out =<<HTML;
<P align="center"><b>Help notes for determining your server path's</P>
<table border="01" cellspacing="0" cellpadding="3">
  <tr><td><b>CGI Directory:</b></td><td>$CGI_Path</td></tr>
  <tr><td><b>CGI URL:</b></td><td>$CGI_URL</td></tr>
  <tr><td><b>HTML Document Root:</b></td><td> $ENV{DOCUMENT_ROOT}</td></tr>
  <tr><td><b>HTML Root URL:</b></td><td> http://$ENV{HTTP_HOST}</td></tr>
</TABLE>
HTML

	print "Content-type: text/html\n\n";
	print "$Out";
	print qq!<P align="center"><A HREF="javascript:window.close()"><b><font color="BLUE">Close This Window</font></b></a></P>!;	

}
#==========================================================
sub Save_Configuration{
my (%Config);

	$Config{Site_Name} = $Param{Site_Name};
	$Config{CGI_Dir} = $Param{CGI_Dir};
	$Config{CGI_URL} = $Param{CGI_URL};
	$Config{HTML_Dir} = $Param{HTML_Dir};
	$Config{HTML_URL} = $Param{HTML_URL};

	$Config{Mail_Program_Type} = $Param{Mail_Program_Type};
	$Config{Mail_Program_Or_SMTP_Server} = $Param{Mail_Program_Or_SMTP_Server};
	$Config{DB_Host} = $Param{DB_Host};
	$Config{DB_Name} = $Param{DB_Name};
	$Config{DB_UserID} = $Param{DB_UserID};
	$Config{DB_Password} = $Param{DB_Password};
	$Config{DB_Port} = $Param{DB_Port};
	$Config{DB_Server} = $Param{DB_Server};
	$Config{DB_Driver} = $Param{DB_Driver};

	$Config{Email_Status} = $Param{Email_Status};

	$Config{Webmaster_Email} = $Param{Webmaster_Email};
	$Config{Contact_Us_Email} = $Param{Contact_Us_Email};
	$Config{Support_Email} = $Param{Support_Email};

	$Config{IslamKitAdminUserID} = &Encrypt($Param{IslamKitAdminUserID}, '�����������');
	$Config{IslamKitAdminPassword} = &Encrypt($Param{IslamKitAdminPassword}, '�����������');

	$Config{GMT_Offset}=$Param{GMT_Offset};

	&Update_Configuration(%Config);
	&Admin_Msg("Configuration Saved", "Program Configuration Successfully Saved.",2);
}
#==========================================================
sub Configuration{
my($Help);
	$Help = &Help_Link("Configuration");
	&Print_Page(&Configuration_Form,"Program Configuration", $Help);
}
#==========================================================
sub Configuration_Form{
my ($Out, $Check, $x, $y, @Check, $Mail_Program, $DB_Driver);
my($CGI_Path, $CGI_URL, $OS, @Drivers, @Servers, $Tip);
my($DB_Name, $DB_UserID, $DB_Password, $DB_Server);
my($IslamKitAdminUserID, $IslamKitAdminPassword);
my ($Boardawy_Plugin, $Passport);

	$Global{DB_Name} ||= "";
	$Global{DB_UserID} ||= "";
	$Global{DB_Password} ||= "";

	@Drivers = qw(mysql);;

	$DB_Driver = "";
	for $x(0..$#Drivers) {
				$Check="";
				if ($Global{DB_Driver}  eq $Drivers[$x] ) {$Check = "selected";}
				$DB_Driver .= qq!<option value="$Drivers[$x]" $Check>$Drivers[$x]</option>!;
	}

	#@Servers = ("MySQL", "MS_SQL");
	@Servers = ("MySQL");
	$DB_Server = "";
	for $x(0..$#Servers) {
				$Check = "";
				if ($Global{DB_Server}  eq $Servers[$x] ) {$Check = "selected";}
				$DB_Server .= qq!<option value="$Servers[$x]" $Check>$Servers[$x]</option>!;
	}

	$Check[0]=""; $Check[1]=""; $Check[2]=""; $Check[3]="";
	$Check[$Global{Mail_Program_Type}] = "selected";
	$Mail_Program=qq!<select name="Mail_Program_Type" size=1>
									<option value=0 $Check[0] >Sendmail</option>
									<option value=3  $Check[3]>SMTP Server</option>
									</select>
									!;

	$Email_Status=qq!<select name ="Email_Status" size ="1">!;
	if ($Global{Email_Status}) {
				$Email_Status .= qq!<option selected VALUE="1">ON</option>
													<option VALUE="0">OFF</option>!;
	}
	else{
				$Email_Status .= qq!<option VALUE="1">ON</option>
													<option  selected  VALUE="0">OFF</option>!;
	}
	$Email_Status .= "</select>";

	if ($Global{Demo_Mode}) {
			$DB_Name = "********";
			$DB_UserID = "********";
			$DB_Password = "********";
			$IslamKitAdminUserID = "********";
			$IslamKitAdminPassword = "********";
	}
	else{
			$DB_Name = $Global{DB_Name};
			$DB_UserID = $Global{DB_UserID};
			$DB_Password = $Global{DB_Password};
			$IslamKitAdminUserID = $Global{IslamKitAdminUserID};
			$IslamKitAdminPassword = $Global{IslamKitAdminPassword};
	}

	$OS = $^O;
	if (($OS eq "MSWin32") || ($OS eq "Windows_NT") || ($OS =~ /win/i)) {
			$OS = "$OS"; 
	}
	else { 
		$OS = "$OS"; 
	}
	
	$Tip = qq|<A  HREF="#" onClick="window.open('$Script_URL?action=Get_Path_Tips','Path_Tips','WIDTH=600,HEIGHT=230,scrollbars=yes,resizable=yes,left=50,top=50,screenX=150,screenY=100');return false">Tip</a>|;

$Out=<<HTML;
<form method="post" action="$Script_URL">
<input type="hidden" name="action" value="Save_Configuration">
  <div align="center">
    <center>
    <table border="01" width="100%"  cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
      <tr><td>CGI Directory:</td><td><input type="text" name="CGI_Dir" size="65" VALUE="$Global{CGI_Dir}" >$Tip</td></tr>
	  <tr><td> CGI Directory URL:</td><td><input type="text" name="CGI_URL" size="65" VALUE="$Global{CGI_URL}" >$Tip</td></tr>
      <tr><td>HTML Directory:</td><td><input type="text" name="HTML_Dir" size="65" VALUE="$Global{HTML_Dir}" >$Tip</td></tr>
	  <tr><td>HTML Directory URL:</td><td><input type="text" name="HTML_URL" size="65" VALUE="$Global{HTML_URL}" >$Tip	</td></tr>

      <tr><td>Mail Tool Type:</td><td>$Mail_Program&nbsp; Your OS: $OS</td></tr>
      <tr><td NOWRAP>Mail Program or SMTP Server:</td>
        <td width="70%">
		<input type="text" name="Mail_Program_Or_SMTP_Server" size="50" VALUE="$Global{Mail_Program_Or_SMTP_Server}" ></td>
      </tr>
      <tr><td>Email System Status:</td><td>$Email_Status</td></tr>
      
	  <tr><td>SQL Server Type:</td><td><select name="DB_Server" size=1>$DB_Server</select></td></tr>
	  <tr><td>SQL Database Driver:</td><td><select name="DB_Driver" size=1>$DB_Driver</select></td></tr>

      <tr><td>SQL Host:</td><td><input type="text" name="DB_Host" size="50" VALUE="$Global{DB_Host}" ></td></tr>
      <tr><td>SQL Database Name:</td><td><input type="text" name="DB_Name" size="40" VALUE="$DB_Name" ></td></tr>
      <tr><td>SQL Database User name:</td><td><input type="text" name="DB_UserID" size="40" VALUE="$DB_UserID" ></td></tr>
      <tr><td>SQL Database Password:</td><td><input type="password" name="DB_Password" size="40" VALUE="$DB_Password" ></td></tr>
      <tr><td>SQL Host Port:</td><td><input type="text" name="DB_Port" size="40" VALUE="$Global{DB_Port}" ></td></tr>

	  <tr><td>Webmaster E-mail Address:</td><td><input type="text" name="Webmaster_Email" size="60" VALUE="$Global{Webmaster_Email}" ></td></tr>
	  <tr><td>Contact Us E-mail Address:</td><td><input type="text" name="Contact_Us_Email" size="60" VALUE="$Global{Contact_Us_Email}" ></td></tr>
	  <tr><td>Technical Support E-mail Address:</td><td><input type="text" name="Support_Email" size="60" VALUE="$Global{Support_Email}" ></td></tr>
	  
	  <tr><td>Admin User ID:</td><td><input type="password" name="IslamKitAdminUserID" size="15" VALUE="$IslamKitAdminUserID" ></td></tr>
      <tr><td>Admin Password:</td><td><INPUT  TYPE="password" name="IslamKitAdminPassword" size="15" VALUE="$IslamKitAdminPassword" ></td></tr>
      <tr><td NOWRAP >Time Offset Based on GMT in Hours</td><td><input type="text" name="GMT_Offset" size="5" VALUE="$Global{GMT_Offset}" > (-hh.hh to +hh.hh)</td></tr>

	  <tr><td width="100%" colspan="2" align="center">
			<input type="submit" value="Save Changes"  style="color: #000080; border-style: ridge"> 
			<input type="reset" value="Reset Form"  style="color: #000080; border-style: ridge">&nbsp;
		  </td>
      </tr>

    </table>
    </center>
  </div>
</form>
HTML
	return $Out;
}
#==========================================================
sub Save_General_Options{
my (%Config, @Codes, %Codes, $Line, $Code, $Value);

	undef %Config;

	$Config{Time_Format} = $Param{Time_Format};
	$Config{Email_Format} = $Param{Email_Format};
	$Config{Email_X_Priority} = $Param{Email_X_Priority};

	$Config{Meta_Title} = $Param{Meta_Title};
	$Config{Meta_Description} = $Param{Meta_Description};        
	$Config{Meta_Keywords} = $Param{Meta_Keywords};

	$Config{Whos_Online_Time_Out} = $Param{Whos_Online_Time_Out};

	$Param{Search_Prefix} =~ s/\cM//g;
	$Config{Search_Prefix} = $Param{Search_Prefix};

	$Param{Search_Suffix} =~ s/\cM//g;
	$Config{Search_Suffix} = $Param{Search_Suffix};

	$Config{DefaultSurah} = $Param{DefaultSurah};
	$Config{DefaultAyah} = $Param{DefaultAyah};
	$Config{DefaultAyahs} = $Param{DefaultAyahs};
	$Config{DefaultLayout} = $Param{DefaultLayout};
	$Config{DefaultQuranName} = $Param{DefaultQuranName};
	$Config{DefaultTranslation} = $Param{DefaultTranslation};
	$Config{DefaultTransliteration} = $Param{DefaultTransliteration};
	$Config{DefaultInterpertation} = $Param{DefaultInterpertation};
	$Config{AdminQuranEditorAyahs} = $Param{AdminQuranEditorAyahs};

	$Config{DefaultSurahReciter} = $Param{DefaultSurahReciter};
	$Config{DefaultAyahReciter} = $Param{DefaultAyahReciter};

	$Config{AdminUploadReciterFiles} = $Param{AdminUploadReciterFiles};

	&Update_Configuration(%Config);

	&Admin_Msg("General Options Saved", "General Options Successfully Saved.",2);
}
#==========================================================
sub General_Options{
my ($Help);

	$Help = &Help_Link("General_Options");
	&Print_Page(&General_Options_Form, "General Options", $Help);
}
#==========================================================
sub General_Options_Form{
my ($Out, $CCard, $Prefx, $Sufx, $Approve_Terms, $Request_Adult_Verification);
my ($Approve_Terms, $Account, $Approve, $Status, $Sellers, $Buyers);
my (%Promot, $Promotional_Codes, $k, $v, $DefaultCurrency);
my (@List, $Line, $Key, $Value);

	$Prefx = &Encode_HTML($Global{Search_Prefix});
	$Sufx = &Encode_HTML($Global{Search_Suffix});

	$Time_Format = ""; $Time = &Time(time);
	for $x (0..27){
					$Selected = "";
					if ($x == $Global{Time_Format}){$Selected = "selected";}
					$Temp = &Format_Date($x, $Time);
					$Time_Format .= qq!<OPTION VALUE="$x" $Selected>$x - $Temp</OPTION>!;
	}

	if ($Global{Email_Format} == 1) {
			$Email_Format.=qq!<option selected VALUE="1">HTML</option><option VALUE="0">Text</option>!;
	}
	else{
			$Email_Format.=qq!<option VALUE="1">HTML</option><option  selected  value=0>Text</option>!;
	}
	#------------------------------------------------------
	# Ayah Menu
	#------------------------------------------------------
	$AyahsMenu = "";
	for $Ayahs(1..58) {
			$Temp = $Ayahs * 5;
			if ($Temp == $Global{DefaultAyahs}) {$Sel = "selected";} else { $Sel = "";}
			$AyahsMenu .= qq!<option value="$Temp" $Sel>$Temp</option>!
	}
	#------------------------------------------------------
	$SurahMenu = "";
	for $Surah(1..114) {
			if ($Surah == $Global{DefaultSurah}) {$Sel = "selected";} else { $Sel = "";}
			$SurahMenu .= qq!<option value="$Surah" $Sel>$Surah</option>!
	}
	#------------------------------------------------------
	$PartMenu = "";
	for $Part(1..30) {
			if ($Part == $Global{DefaultPart}) {$Sel = "selected";} else { $Sel = "";}
			$PartMenu .= qq!<option value="$Part" $Sel>$Part</option>!
	}
	#------------------------------------------------------
	$AyahMenu = "";
	for $Ayah(1..289) {
			if ($Ayah == $Global{DefaultAyah}) {$Sel = "selected";} else { $Sel = "";}
			$AyahMenu .= qq!<option value="$Ayah" $Sel>$Ayah</option>!
	}
	#------------------------------------------------------
	$EditAyahMenu = "";
	for $Ayah(1..289) {
			if ($Ayah == $Global{AdminQuranEditorAyahs}) {$Sel = "selected";} else { $Sel = "";}
			$EditAyahMenu .= qq!<option value="$Ayah" $Sel>$Ayah</option>!
	}
	#------------------------------------------------------
	$LayoutMenu = "";
	for $x(1..5) {
			if ($x == $Global{DefaultLayout}) {$Sel = "selected";} else { $Sel = "";}
			$LayoutMenu .= qq!<option value="$x" $Sel>$Language{"QuranLayoutName$x"}</option>!
	}
	#------------------------------------------------------
	# Quran Menu
	#------------------------------------------------------
	$QuranMenu = "";
	@Names = &GetQuranNames(1);
	unshift @Names, "";
	foreach  $Name(@Names) {
			if ($Name eq $Global{DefaultQuranName}) {$Sel = "selected";} else { $Sel = "";}
			$QuranMenu .= qq!<option value="$Name" $Sel>$Name</option>!;;
	}
	#------------------------------------------------------
	# Quran Menu
	#------------------------------------------------------
	$TranslatMenu = "";
	@Names = &GetQuranNames(2);
	unshift @Names, "";
	foreach  $Name(@Names) {
			if ($Name eq $Global{DefaultTranslation}) {$Sel = "selected";} else { $Sel = "";}
			$TranslatMenu .= qq!<option value="$Name" $Sel>$Name</option>!;;
	}
	#------------------------------------------------------
	# Quran Menu
	#------------------------------------------------------
	$TranslitMenu = "";
	@Names = &GetQuranNames(3);
	unshift @Names, "";
	foreach  $Name(@Names) {
			if ($Name eq $Global{DefaultTransliteration}) {$Sel = "selected";} else { $Sel = "";}
			$TranslitMenu .= qq!<option value="$Name" $Sel>$Name</option>!;;
	}
	#------------------------------------------------------
	# Quran Menu
	#------------------------------------------------------
	$InterpertMenu = "";
	@Names = &GetQuranNames(4);
	unshift @Names, "";
	foreach  $Name(@Names) {
			if ($Name eq $Global{DefaultInterpertation}) {$Sel = "selected";} else { $Sel = "";}
			$InterpertMenu .= qq!<option value="$Name" $Sel>$Name</option>!;;
	}
	#------------------------------------------------------
	#------------------------------------------------------
	# Full Surah Reciters Menu
	#------------------------------------------------------
	$SurahReciters = "";
	@Reciters = &GetSurahRecitersID();
	foreach $Reciter(@Reciters) {
			%Reciter = &GetReciter($Reciter);
			if ($Reciter{Folder} eq $Global{DefaultSurahReciter}) {$Sel = "selected";} else { $Sel = "";}
			$SurahReciters .= qq!<option value="$Reciter{Folder}" $Sel>$Reciter{Reciter}</option>!;
	}
	#------------------------------------------------------
	# Ayah Reciters Menu
	#------------------------------------------------------
	$AyahReciters = "";
	@Reciters = &GetAyahRecitersID();
	foreach $Reciter(@Reciters) {
			%Reciter = &GetReciter($Reciter);
			if ($Reciter{Folder} eq $Global{DefaultAyahReciter}) {$Sel = "selected";} else { $Sel = "";}
			$AyahReciters .= qq!<option value="$Reciter{Folder}" $Sel>$Reciter{Reciter}</option>!;
	}
	#------------------------------------------------------

$Out=<<HTML;
  <DIV ALIGN="left">
    <table border="01" width="100%" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
      <tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" VALUE="Save_General_Options">

	  <tr><td>Maximum Number For Search results:</td><td><input type="text" name="Maximum_Search_Results" size="10" VALUE="$Global{Maximum_Search_Results}">&nbsp; Set to 0 for unlimited</td></tr>
      <tr><td>Search Terms in Search Results Tags:</td><td><input type="text" name="Search_Prefix" size="35" VALUE="$Prefx">&nbsp;&nbsp;<input type="text" name="Search_Suffix" size="20" VALUE="$Sufx"></td></tr>

      <tr><td>Default Surah Number:</td><td><select name="DefaultSurah" size="1">$SurahMenu</select></td></tr>
      <tr><td>Default Surah Ayah Number:</td><td><select name="DefaultAyah" size="1">$AyahMenu</select></td></tr>
      
      <tr><td>Default Display Ayahs Count:</td><td><select name="DefaultAyahs" size="1">$AyahsMenu</select></td></tr>

      <tr><td>Default Quran Name:</td><td><select name="DefaultQuranName" size="1">$QuranMenu</select></td></tr>

      <tr><td>Default Translation Name:</td><td><select name="DefaultTranslation" size="1">$TranslatMenu</select></td></tr>
      <tr><td>Default Transliteration Name:</td><td><select name="DefaultTransliteration" size="1">$TranslitMenu</select></td></tr>
      <tr><td>Default Interpertation Name:</td><td><select name="DefaultInterpertation" size="1">$InterpertMenu</select></td></tr>

      <tr><td>Default Surah Reciter:</td><td><select name="DefaultSurahReciter" size="1">$SurahReciters</select></td></tr>
      <tr><td>Default Surah Ayah:</td><td><select name="DefaultAyahReciter" size="1">$AyahReciters</select></td></tr>

      <tr><td>Admin Quran Editor Ayahs:</td><td><select name="AdminQuranEditorAyahs" size="1">$EditAyahMenu</select></td></tr>

      <tr><td>Default View Layout:</td><td><select name="DefaultLayout" size="1">$LayoutMenu</select></td></tr>
	  <tr><td>Admin Upload Reciter Files:</td><td><input type="text" name="AdminUploadReciterFiles" size="5" VALUE="$Global{AdminUploadReciterFiles}"></td></tr>
		  
	  <tr><td>Outgoing Email Format:</td><td><select name ="Email_Format" size ="1">$Email_Format</select></td></tr>
      <tr><td>Outgoing Email X-Priority:</td><td><input type="text" name="Email_X_Priority" size="10" VALUE="$Global{Email_X_Priority}"></td></tr>

      <tr><td>Who's Online Time Out:</td><td><input type="text" name="Whos_Online_Time_Out" size="20" VALUE="$Global{Whos_Online_Time_Out}"> Seconds</td></tr>

	  <tr><td>Default Meta Title:</td><td><input type="text" name="Meta_Title" size="60" VALUE="$Global{Meta_Title}"></td></tr>
      <tr><td valign="top">Default Meta Description:</td><td><TEXTAREA ROWS="8" name="Meta_Description" COLS="60">$Global{Meta_Description}</TEXTAREA></td></tr>
      <tr><td valign="top">Default Meta Keywords:</td><td><TEXTAREA ROWS="8" name="Meta_Keywords" COLS="60">$Global{Meta_Keywords}</TEXTAREA></td></tr>

      <tr><td width="100%" COLSPAN="2" align="center">
			<input type="submit" VALUE="Save Changes" STYLE="color: #000080; border-style: ridge">
			<input type="reset" VALUE="Reset Form" STYLE="color: #000080; border-style: ridge">&nbsp;
		  </td>
		  </FORM>
      </tr>
    </TABLE>
  </DIV>
HTML

return $Out;
}

#==========================================================
sub Setup_Wizard{
my ($Help);

	$Help = &Help_Link("Setup_Wizard");
	&Print_Page(&Setup_Wizard_Form, "Setup Wizard", $Help);	
}
#==========================================================
sub Setup_Wizard_Form{
my ($Out);

$Out=<<HTML;
<br>
<table border="0" width="100%" cellspacing="0" cellpadding="3">
  <tr>
    <td width="100%">$Global{G1_Bullet}&nbsp;<a href="$Script_URL?action=Create_SQL_Tables">Create SQL Tables</a>
	</td>
  </tr>
  <tr>
    <td width="100%">$Global{G1_Bullet}&nbsp;<a href="$Script_URL?action=Server_Test">Display Server Configuration</a>
	</td>
  </tr>
</table>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
HTML
	
	return $Out;
}
#==========================================================
sub Server_Test{
my ($Help);
	$Help = &Help_Link("Server_Configuration");
	&Print_Page(&Get_Server_Test, "Server Configuration", $Help);
}
#==========================================================

1;