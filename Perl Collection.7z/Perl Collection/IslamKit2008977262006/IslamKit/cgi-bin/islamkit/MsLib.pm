=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Help{
my ($Title, $Link, $Out);
my ($x, $key);

	&Read_Language_File($Global{Language_Help_File});

	$Out = &Translate_File($Global{Help_Template});

	for $x (0..100) {
		$key = "<!--Help_Link:" . $x . "-->";
		$Link = qq!$Script_URL?action=GetHelp&Index=$x&Lang=$Global{Language}!;
		$Out =~ s/$key/$Link/g;
	}

	#<!--CLASS::Page:Page_Name-->
	while ($Out =~ m/(<!--)(CLASS::Help)(:)([^-->]+)(-->)/  ){
				$s = $1 . $2 . $3 . $4 . $5;
				$Temp = $4;
				$Temp =~ s/^\s+//g;
				$Temp =~ s/\s+$//g;
				$Temp || next;
				$x = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=GetHelp&Page=$Temp&Lang=$Global{Language}!;
				$Out =~ s/$s/$x/g;
	}

	$Plugins{Body} = "";
    &Display($Out, 1);
}
#==========================================================
sub GetHelp{
my ($Lang_File, $Out, $Default, $Template, $x, $K);

	$Param{Page} ||= 0;

	$Lang_File = "$Global{Lang_Dir}/Help_". $Param{Page} .".pm";
	if (-e $Lang_File) {
		&Read_Language_File($Lang_File);
	}
	else{
		&Exit("Can not find language file $Lang_File: $!\n" . "<br>Line " . __LINE__ . ", File ". __FILE__);
	}

	$Template = "$Global{Template_Dir}/Help_". $Param{Page} .".html";
	if (-e $Template) {
		$Out = &Translate_File($Template);
	}
	else{
		&Exit("Can not find template file $Template: $!\n" . "<br>Line " . __LINE__ . ", File ". __FILE__);
	}

	$Out = &Translate($Out);

	&Display($Out, 1);
}
#==========================================================
sub About_Us{

	&Read_Language_File($Global{Language_About_Us_File});
	$Plugins{Body}="";
    &Display($Global{About_Us_Template});

}
#==========================================================
sub Copyright{

	&Read_Language_File($Global{Language_Copyright_File});
	$Language{copyright_body}=~ s/<!--Legal_Contact_Email-->/$Global{Legal_Contact_Email}/g;
	$Plugins{Body}="";
    &Display($Global{Copyright_Template});

}
#==========================================================
sub Privacy_Policy{

	&Read_Language_File($Global{Language_Privacy_Policy_File});
	$Language{privacy_policy_body}=~ s/<!--Legal_Contact_Email-->/$Global{Legal_Contact_Email}/g;
	$Plugins{Body}="";
    &Display($Global{Privacy_Policy_Template});
}
#==========================================================
sub Terms_of_Use{

	&Read_Language_File($Global{Language_Terms_of_Use_File});
	$Language{terms_of_use_body}=~ s/<!--Legal_Contact_Email-->/$Global{Legal_Contact_Email}/g;
	$Plugins{Body}="";
    &Display($Global{Terms_of_Use_Template});

}
#==========================================================
sub Set_Language{

	&Read_Language_File($Global{Language_Set_Language_File});
	$Plugins{Body} = "";
	&Display(&Set_Language_Form, 1);

}
#==========================================================
sub Set_Current_Language{

	$Global{Language} = $Param{Language_Selected};
	$Param{Lang} = $Param{Language_Selected};
	&Set_Cookies("User_Language", $Param{Language_Selected}, 1 );
	$Param{Lang} = $Param{Language_Selected};
	$Global{Language} = $Param{Language_Selected};
	$Cookies{User_Language} = $Param{Language_Selected};
	&Read_Configuration;
	&Read_Language_File($Global{Language_General_File});
	&Set_Language;
}
#==========================================================
sub Set_Language_Form{
my(@Languages, $Template, $Form, $List);

	$Template = &Translate_File($Global{Set_Language_Template});
	$Template =~ s/<!--Action-->/$Script_URL/g;
	$Template =~ s/<!--Language-->/$Global{Language}/g;

	@Languages = split(/\|/, $Global{Languages});
	@Forms = (&Translate($Global{Set_Language_Form}), &Translate($Global{Set_Language_Form1}));

	$Counter = 0;
	$Forms = "";
	foreach $Lang (@Languages) {
			$Checked = "";
			if ($Lang eq $Global{Language}) {$Checked="CHECKED";}

			$Form = $Forms[int($Counter %2)];
			$Form =~ s/<!--Language-->/$Lang/;
			$Form =~ s/<!--Language_Name-->/$Lang/;
			$Form =~ s/<!--Checked-->/$Checked/;

			$Counter++;
			$Forms .= $Form;
	}
	
	$Template =~ s/<!--Language_List-->/$Forms/;

	return $Template;
}
#==========================================================
sub Search_Help{

	&Read_Language_File($Global{Language_Search_Tips_File});
	$Plugins{Body}="";
    &Display($Global{Search_Tips_Template});
}
#==========================================================
sub Advertise{
my($Template);

	&Read_Language_File($Global{Language_Advertise_File});
	$Plugins{Body} = "";
	&Display($Global{Advertise_Template});
}
#==========================================================
sub Custom_Page{
my($Sub, $File);

	&Read_Language_File($Global{Language_Custom_File});

	$Sub = $Param{Sub};
	$File = $Param{File};
	$Filename = qq!$Global{Custom_Dir}/$File\.pm!;
	eval "require $Filename";
	
	$Plugins{Body} = &$Sub($Param{Param});
	
	$Param{Temp} .= ".html" unless ($Param{Temp}=~ m/\./ );

	&Display("$Global{Template_Dir}/$Param{Temp}");
	
}
#==========================================================
sub GetPage{
my ($Lang_File, $Template_File, @Langs, $Lang);
	
	return "" unless $Param{Name};
	$Lang_File = qq!$Global{Data_Dir}/language/$Global{Language}/$Param{Name}\.page\.pm!;
	$Template_File = qq!$Global{Template_Dir}/$Param{Name}\.page\.shtml!;
	&Read_Language_File($Lang_File);
	$Plugins{Body} = "";
	&Display($Template_File);
}
#==========================================================
1;