=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Initialize_Program{
	
	$ENV{CONTENT_TYPE} ||="";
	if ($ENV{CONTENT_TYPE} =~ /multipart/) {
			&Get_Form_Multipart;
	}
	else {
			&Get_Form;
	};

	&Get_Cookies;
	&Read_Configuration;
	
	srand (time | $$);

	if ($Global{TimeHiRes}) {
			$Global{Program_Start_Time} = Time::HiRes::gettimeofday();
	}
	else{
			$Global{Program_Start_Time} = time;
	}
	
	$Global{Read_Classes_Done} = 0; # Classes has been translated and prepared flag
	$Global{Force_Read_Classes} = 0; # Force re-read classes flag
}
#==========================================================
sub Read_Configuration_Files{
my(@All, $K, $V, $Line, %Update);
	
	open (FILE, "$Global{Configuration_File}") || &Exit("Cannot open configuration file $Global{Configuration_File}: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	foreach $Line(@All){
			($K, $V) = split(/\~\=\=\~/ , $Line);
			$V =~ s/\n$//g;
			$V=~ s/\\n/\n/g;
			$Global{$K} = $V;
	}
}
#==========================================================
sub Update_Configuration{
my(%Data) = @_;
my(@All, $Key, $Value, $Line, %Config);

	open (FILE, "$Global{Configuration_File}") || &Exit("Cannot read configuration file $Global{Configuration_File}: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	
	undef %Config;

	foreach $Line(@All){
			$Line =~ s/\n$//;
			($Key, $Value) = split(/\~\=\=\~/ , $Line);
			$Value =~ s/\\n/\n/g;
			$Config{$Key} = $Value;
	}

	while (($Key, $Value) = each %Data) {
			$Config{$Key} = $Value;
	}

	if (!&Lock($Global{Configuration_File})) {&Exit("Cannot Lock file, server may be busy, please wait a few seconds and try again.<br> $Global{Configuration_File}: $!"."<br>Line ". __LINE__ . ", File ". __FILE__);}
	open (FILE, ">$Global{Configuration_File}") || &Exit("Cannot write configuration file $Global{Configuration_File}: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	
	while (($Key, $Value) = each(%Config)) {
			$Value  =~ s/\n/\\n/g;
			print FILE  "$Key~==~$Value\n";
	}

	close(FILE);

	&Unlock($Global{Configuration_File});
}
#==========================================================
sub UpdateConfiguration{
my (%Data) = @_;
my ($Query, $Keys, $Values, $K, $V);
	
	$Keys = ""; $Values = "";
	while (($K, $V) = each %Data) {
			$Keys .=  $dbh->quote($K).",";
			$Values .=   "(".$dbh->quote($K) ."," . $dbh->quote($V)."),";
	}
	$Keys =~ s/\,$//;
	$Values =~ s/\,$//;
	
	$Query = qq!DELETE FROM IslamConfig WHERE Name IN ($Keys)!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	$Query = qq!INSERT INTO IslamConfig (Name, Value) VALUES $Values!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
}
#==========================================================
sub ReadConfiguration{
my ($Query, $Temp, $sth, $K, $V);
	
	$Query = qq!SELECT * FROM IslamConfig!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	while(($K, $V) = $sth->fetchrow_array) {
			$Global{$K} = $V;
	}
}
#==========================================================
sub  InitializeLanguagePaths{ 

	$Global{Language_Dir} = "$Global{Data_Dir}/language";
	$Global{Lang_Dir} = "$Global{Language_Dir}/$Global{Language}";

	$Global{Language_Languages_File} = "$Global{Lang_Dir}/Languages.pm";
	$Global{Language_General_File} = "$Global{Lang_Dir}/General.pm";
	$Global{Language_Copyright_File} = "$Global{Lang_Dir}/Copyright.pm";
	$Global{Language_Announcements_File} = "$Global{Lang_Dir}/Announcements.pm";
	$Global{Language_Contact_Us_File} = "$Global{Lang_Dir}/Contact.pm";
	$Global{Language_Set_Language_File} = "$Global{Lang_Dir}/SetLanguage.pm";
	$Global{Language_About_Us_File} = "$Global{Lang_Dir}/AboutUs.pm";
	$Global{Language_Help_File} = "$Global{Lang_Dir}/Help.pm";

	$Global{Language_SurahNames_File} = "$Global{Lang_Dir}/SurahName.pm";
	
}
#==========================================================
sub InitializeTemplatesPaths{ 

	$Global{Quran_Template} = "$Global{Template_Dir}/Quran.html";
	$Global{QuranViewer_Template} = "$Global{Template_Dir}/QuranViewer.html";
	$Global{QuranSearch_Template} = "$Global{Template_Dir}/QuranSearch.html";
	$Global{ReciteSurah_Template} = "$Global{Template_Dir}/ReciteSurah.html";
	$Global{ReciteAyah_Template} = "$Global{Template_Dir}/ReciteAyah.html";
		
	$Global{FrontPage_Template} = "$Global{Template_Dir}/FrontPage.html";
	$Global{Copyright_Template} = "$Global{Template_Dir}/Copyright.html";
	$Global{Help_Template} = "$Global{Template_Dir}/Help.html";
	$Global{About_Us_Template} = "$Global{Template_Dir}/AboutUs.html";
	$Global{Set_Language_Template} = "$Global{Template_Dir}/SetLanguage.html";
	$Global{Announcements_Template} = "$Global{Template_Dir}/Announcements.html";
	$Global{General_Template} = "$Global{Template_Dir}/General.html";
	$Global{Contact_Us_Template} = "$Global{Template_Dir}/ContactUs.html";

}
#==========================================================
sub Help_Link{
my($Subject, $URL)=@_;
my($Out, $Sub, $Width, $Height);

	$Width = $Global{Admin_Help_Window_Width};
	$Height = $Global{Admin_Help_Window_Height};
	$Sub = $Subject;
	$Sub =~ s/\_/ /g;
	
	$Global{Help_URL} = "http://www.islamware.com/help/islamkit";

$Out=<<HTML;
<A HREF="#" onClick="window.open('$Global{Help_URL}/$Subject\.html','IslamKit_Help','WIDTH=$Width,HEIGHT=$Height,  toolbar=yes, directories=yes,menubar=yes, scrollbars=yes,resizable=yes,left=0,top=0,screenX=0,screenY=0');return false;"  ONMOUSEOVER="window.status=\'Help: $Sub\'; return true;" ONMOUSEOUT=" window.status=\'\'; return true;">What\'s This?</a>
HTML

	return $Out;
}
#==========================================================
sub Help_Link_HREF{
my($Subject)=@_;
my($Out, $Sub, $Width, $Height);
	
	$Width = $Global{Admin_Help_Window_Width};
	$Height = $Global{Admin_Help_Window_Height};
	$Sub = $Subject;
	$Sub =~ s/\_/ /g;
	$Global{Help_URL} = "http://www.islamware.com/help/islamkit";

$Out=<<HTML;
onClick="window.open('$Global{Help_URL}/$Subject\.html','IslamKit_Help','WIDTH=$Width,HEIGHT=$Height, toolbar=yes, directories=yes,menubar=yes, scrollbars=yes,resizable=yes,left=0,top=0,screenX=0,screenY=0');return false;"  ONMOUSEOVER="window.status='Help: $Sub'; return true;" ONMOUSEOUT=" window.status=''; return true;"
HTML

	return $Out;
}
#==========================================================
sub InitializeThemePaths{
my (@Langs, @Themes, $Line, $Lang, $Theme, %Themes);

	$Global{Default_Language} = $Global{Language};
	
	if ($Cookies{User_Language}) {
			$Global{Language} = $Cookies{User_Language};
			if (!-d "$Global{Data_Dir}/language/$Global{Language}") {
					&Delete_Cookies("User_Language");
					$Global{Language} = $Global{Default_Language};
			}
	}
	elsif ($Param{Lang}) {
		$Global{Language} = $Param{Lang};
	}
	else{
		$Global{Language} ||= "English";
	}

	if (!-d "$Global{Data_Dir}/language/$Global{Language}") {
			&Delete_Cookies("User_Language");
			$Global{Language} = $Global{Default_Language};
			@Langs = &LanguagesList;
			$Global{Language} = $Langs[0];
	}
	
	#$Global{Themes} = "English:Default|Arabic:demo"; # comment this line

	@Themes = split (/\|/, $Global{Themes});
	foreach $Line (@Themes) {
			($Lang, $Theme) = split(/\:/, $Line);
			$Themes{$Lang} = $Theme;
	}
	
	$Global{Theme} = $Themes{$Global{Language}};
	
	if (!$Global{Theme}) {
			@Themes = &ThemesList;
			$Global{Theme} = $Themes[0];
	}

	if (!-d "$Global{Data_Dir}/templates/$Global{Theme}") {
			@Themes = &ThemesList;
			$Global{Theme} = $Themes[0];
	}
	
}
#==========================================================
sub InitializeTheme{
my (%Custom, $K, $V);

	%Custom = &ReadThemeConfig;
	while (($K, $V) = each %Custom) {
			$Global{$K} = $V;
			$PluginsNames{$K} = "";
	}
}
#==========================================================
sub Read_Configuration{
my ($key, $value, %data);

	$Global{Data_Dir} = "$Global{CGI_Dir}/data";
	$Global{Configuration_File} = "$Global{Data_Dir}/SysConfig.pm";
	$Global{Lock_Dir} = "$Global{Data_Dir}/lock";
	$Global{Updates_File} = "$Global{Data_Dir}/Updates.pm";
	#----------------------------------------------------------
	&Read_Configuration_Files;
	#----------------------------------------------------------
	 # Comment this line
	#use Defaults; &Default_Parameters; &Get_General_Classes; &Get_Banner_Defaults; # Comment this line
	#----------------------------------------------------------
	$Global{Software_Version} = "1.0";
	$Global{Software_Build} = "072606";
	#----------------------------------------------------------
	&InitializeThemePaths;
	&InitializeLanguagePaths;
	#----------------------------------------------------------
	$Global{Templates_Dir} = "$Global{Data_Dir}/templates";
	$Global{Template_Dir} = "$Global{Templates_Dir}/$Global{Theme}";
	$Global{ThemeConfigFile} = "$Global{Template_Dir}/Config.pm";
	#----------------------------------------------------------
	&InitializeTheme; #Read theme classes
	#&Get_General_Classes; # comment this line
	&InitializeTemplatesPaths;
	#----------------------------------------------------------
	#----------------------------------------------------------
	 # comment this line
	#&Get_General_Classes; while (($K, $V) = each %Plugins) {$Plugins{$K} = &Translate($Global{$K});}
	#----------------------------------------------------------
	# Directories and URLs
	$Global{Building_Pages} = 0;
	$Global{Custom_Dir} = "$Global{Data_Dir}/lib";
	$Global{Mail_Lists_Dir} = "$Global{Data_Dir}/mail";
	$Global{Database_Dir} = "$Global{Data_Dir}/database";
	$Global{Import_Dir} = "$Global{Data_Dir}/import";
	$Global{Export_Dir} = "$Global{Data_Dir}/export";
	$Global{AyahAudio_Dir} = "$Global{HTML_Dir}/audio/ayah";
	$Global{SurahAudio_Dir} = "$Global{HTML_Dir}/audio/surah";

	$Global{Temp_Dir} = "$Global{Data_Dir}/temp";
	$Global{Images_URL} = "$Global{HTML_URL}/images";
	$Global{Download_Dir} = "$Global{HTML_Dir}/download";
	$Global{Download_URL} = "$Global{HTML_URL}/download";
	$Global{Upload_Dir} = "$Global{HTML_Dir}/upload";
	$Global{Upload_URL} = "$Global{HTML_URL}/upload";
	$Global{Base_Upload_Dir} = "$Global{HtmlDir}/upload";
	$Global{Base_Upload_URL} = "$Global{HTML_URL}/upload";
	$Global{AyahAudio_URL} = "$Global{HTML_URL}/audio/ayah";
	$Global{SurahAudio_URL} = "$Global{HTML_URL}/audio/surah";
	$Global{Theme_Images_URL} = "$Global{HTML_URL}/theme/$Global{Theme}";
	#----------------------------------------------------------
	# Data files
	$Global{Visitors_Log_File}="$Global{Data_Dir}/logs/islamkit.log.txt";
	#---------------------------------------------------------------------------------------
	$Global{Prog_URL} = "$Global{CGI_URL}/$Global{Main_Prog}";
	$Global{Admin_URL} = "$Global{CGI_URL}/$Global{Admin_Prog}";
	#---------------------------------------------------------------------------------------
	$Global{Update_URL} = "http://www.islamware.com/cgi-bin/update/update.cgi";
	#---------------------------------------------------------------------------------------
	#&Log_Visitor;
	#&Check_Forbidden_Remote_Hosts;
}
#==========================================================
#==========================================================
sub Check_Forbidden_Remote_Hosts{
my (@Forbid, $Host);

	@Forbid = split(/\,/, $Global{Forbidden_Remote_Hosts});
	foreach $Host (@Forbid) {
		$Host =~ s/\s+//g;
		if ($Host eq $ENV{REMOTE_ADDR}) {
			sleep(50);
			&Exit("$ENV{REMOTE_ADDR} is not allowed to view this page");
		}
	}
}
#==========================================================
sub Log_Visitor{
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst);
my ($LOG, $Query);

    $Query = "";
	if ($ENV{CONTENT_LENGTH} ) {
				read(STDIN, $Query, $ENV{CONTENT_LENGTH});
    } 
	elsif ($ENV{QUERY_STRING}) {
			$Query = $ENV{QUERY_STRING};
    }

	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
	$mon++;
	$year += 1900;
	
	$LOG = qq!$mday/$mon/$year/$hour:$min:$sec|$ENV{REMOTE_ADDR}|$Script_URL?$Query|$ENV{HTTP_REFERER}!;
	
	&Lock("$Global{Visitors_Log_File}");
	open(LOG, ">>$Global{Visitors_Log_File}");
	print LOG "$LOG\n";
	close(LOG);
	&Unlock("$Global{Visitors_Log_File}");
}
#==========================================================
1;
