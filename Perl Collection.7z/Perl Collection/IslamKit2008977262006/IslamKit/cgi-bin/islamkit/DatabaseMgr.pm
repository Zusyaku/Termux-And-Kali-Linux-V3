=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Database_Manager{
my($Help);

	$Help =&Help_Link("Database_Manager");

	&Print_Page(&Database_Manager_Form, "Database & SQL Manager", $Help);
}
#==========================================================
sub Database_Manager_Form{
my($Out, $Tables, $Temp, $Mode);

	@Tables = &DB_Show_Tables;

	$Tables = qq!<select name="Tables_Selected" size="5" multiple>!;
	foreach $Temp (@Tables) {
				$Tables .= qq!<option value="$Temp"> $Temp </option>!;
	} 
	$Tables .= qq!</select>!;
	
	if ($Global{DB_File_Priv}) {
			$Mode = qq!<option selected VALUE="1">Fast</option><option VALUE="0">Normal</option>!;
	}
	else{
			$Mode = qq!<option VALUE="1">Fast</option><option selected VALUE="0">Normal</option>!;
	}

$Out=<<HTML;
<br>
<div align="center"><center>
<table border="0" width="100%"  cellspacing="1" cellpadding="5">

	  <tr><td width="100%" >
		$Global{G1_Bullet}<A HREF="$Script_URL?action=SQL_Text_Backup" onClick="SQL_Text_Backup_Confirm(); return false;">Backup SQL Database Into Text Files</a>
		</td></tr>

      <tr><td width="100%" >
			$Global{G1_Bullet}<A HREF="$Script_URL?action=Load_SQL_Text_Backup" onClick="Load_SQL_Backup_Confirm(); return false;">Restore SQL Database From The Text Files Backup</a>
      </td></tr>

      <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=Load_Unload_SQL_Tables">Load/Unload SQL Database Tables</a>
      </td></tr>

      <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=Manage_SQL_Tables">Manage SQL Database Tables</a>
      </td></tr>

      <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=Manage_SQL_Databases">Manage SQL Databases</a>
      </td></tr>

      <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=SQL_Commander">SQL Commander</a>
      </td></tr>

      <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=SQL_Administration">SQL Server Administration</a>
      </td></tr>

	  <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=SQL_Server_Status">Display SQL Server Status</a>
      </td></tr>

	  <tr><td width="100%" >
		  $Global{G1_Bullet}<a  href="$Script_URL?action=SQL_Server_Variables">Display SQL Server Variables</a>
      </td></tr>

	  
	</TABLE>
    </CENTER>
  </DIV>
	<br>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>SQL Options</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
	<tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="SaveDatabaseOptions">
	<td colspan="2">Please select the database backup/restore and tables Load/Unload mode.</td></tr>
    <tr><td colspan="2">Mode: <select name="DB_File_Priv" size="1">$Mode</select></td></tr>
	<td colspan="2"><p align="justify"><b>Fast</b> mode uses the sql server OUTFILE/LOAD statements to backup and restore tables. Much faster but requires the <font color="#990000"><b>File_Priv</b></font> option set to 'Y' (Enabled) on the database for the user. Ask your server administrator for it.</p></td></tr>
	<td colspan="2"><p align="justify"><b>Normal</b> mode uses the sql server single SELECT/INSERT statements to backup and restore tables.</p></td></tr>
	<td colspan="2"><p align="justify"><b>Mode</b> used to backup or unload MUST be used for restore or load.</p></td></tr>
	<tr><td nowrap align="center" colspan="2">
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!-------------------------------------------------------------------------------->
<SCRIPT LANGUAGE="JavaScript">
<!--
function SQL_Text_Backup_Confirm() {
	var agree=confirm("Are you sure you want to create text backup of the current SQL Database contents?\\nSQL database tables will be unloaded to text files with the same names as the tables.\\n");
	if (agree){
					//window.location = "$Script_URL?action=SQL_Text_Backup";
					window.open('$Script_URL?action=SQL_Text_Backup','Database','WIDTH=600,HEIGHT=400,scrollbars=yes,toolbar=yes,location=no,directories=no,status=yes,menubar=no,alwaysRaised=yes,resizable=yes,left=1,top=1');
	}
}

function Load_SQL_Backup_Confirm() {
	var agree=confirm("Are you sure you want to DELETE the current SQL Database contents\\nand load a new contents from previously made text backup?\\n");
	if (agree){
			var agree=confirm("Please note this process can not be undone , you will not be able to recover the current SQL database contents again.\\nAre you sure you still want to load the backup Database?\\n");
			if (agree){
					//window.location = "$Script_URL?action=Load_SQL_Text_Backup";
					window.open('$Script_URL?action=Load_SQL_Text_Backup','Database','WIDTH=500,HEIGHT=400,scrollbars=yes,toolbar=yes,location=no,directories=no,status=yes,menubar=no,alwaysRaised=yes,resizable=yes,left=1,top=1');
			}
	}
}

//onClick=window.open('','Database','WIDTH=500,HEIGHT=400,scrollbars=yes,resizable=yes,left=0,top=0,screenX=0,screenY=0');
//link=open(GoTo, "$Title","toolbar=no, scrollbars=yes, directories=no,menubar=no,resizable=yes,width=400,height=500");
-->
</SCRIPT>

HTML

	return $Out;
}
#==========================================================
sub Load_Unload_SQL_Tables{
my ($Help);

	$Help = &Help_Link("Load_Unload_SQL_Tables");
	&Print_Page(&Load_Unload_SQL_Tables_Form, "Load / Unload SQL Tables", $Help);	
}
#==========================================================
sub Load_Unload_SQL_Tables_Form{
my($Out, $Tables, $Temp);

	@Tables = &DB_Show_Tables;

	$Tables = "";
	foreach $Temp (@Tables) {
				$Tables .= qq!<OPTION VALUE="$Temp"> $Temp </OPTION>!;
	} 

$Out=<<HTML;
<P ALIGN="left">To select more than one table, drag your mouse or click with the &lt;CTRL&gt; Key pressed.</P>

<FORM NAME="Tables_Action" METHOD="POST" ACTION="$Script_URL" TARGET="Database">
<INPUT TYPE="hidden" VALUE="SQL_Tables_Load_Unload" NAME="action">
  <DIV ALIGN="left">
    <TABLE $Global{Admin_Table_Attr} BORDER="1" CELLSPACING="0" CELLPADDING="5">
      <TR><TD ALIGN="right"><B>Select Table(s): </B></TD>
        <TD ALIGN="left">
			<SELECT NAME="Tables_Selected" SIZE="5" MULTIPLE>
			$Tables
			</SELECT>
		  </TD>
      </TR>
      <TR>
        <TD COLSPAN="2" ALIGN="center">
				<INPUT TYPE="submit" VALUE="Load" NAME="Table_Action" onClick="Load_SQL_Tables_Confirm(); return false;" STYLE="color: #000080; border-style: ridge">
				&nbsp;&nbsp;
				<INPUT TYPE="submit" VALUE="UnLoad" NAME="Table_Actionx" onClick="UnLoad_SQL_Tables_Confirm(); return false;" STYLE="color: #000080; border-style: ridge">
				<INPUT TYPE="hidden" VALUE="" NAME="Table_Actions">
        </TD>
      </TR>
    </TABLE>
  </DIV>
</FORM>

<SCRIPT LANGUAGE="JavaScript">
<!--
function Load_SQL_Tables_Confirm() {
	var agree=confirm("Are you sure you want to DELETE the selected SQL Tables contents\\nand Load a new contents from previously made text backup?\\n");
	if (agree){
			var agree=confirm("Please note this process can not be undone , you will not be able to recover the current SQL tables contents again.\\nAre you sure you still want to load the backup tables?\\n");
			if (agree){
				document.Tables_Action.Table_Actions.value=document.Tables_Action.Table_Action.value;
				var win= window.open('','Database','WIDTH=500,HEIGHT=400,toolbar=yes, location=yes,directories=yes,menubar=yes,scrollbars=yes,resizable=yes,left=0,top=0,screenX=0,screenY=0');
				win.document.open();
				win.document.focus();
				document.Tables_Action.submit();
			}
	}
}

function UnLoad_SQL_Tables_Confirm() {
	var agree=confirm("Are you sure you want to Unload selected SQL tables contents into text files?\\n");
	if (agree){
			var agree=confirm("Please note this process may take long time for big tables.\\nAre you sure you still want to unload these tables?\\n");
			if (agree){
				document.Tables_Action.Table_Actions.value=document.Tables_Action.Table_Actionx.value;
				var win= window.open('','Database','WIDTH=500,HEIGHT=400,toolbar=yes, location=yes,directories=yes,menubar=yes,scrollbars=yes,resizable=yes,left=0,top=0,screenX=0,screenY=0');
				win.document.open();
				win.document.focus();
				document.Tables_Action.submit();
			}
	}
}

-->
</SCRIPT>

HTML
	return $Out;
}
#==========================================================
sub SQL_Text_Backup{
my(@Tables);

	print "Content-type: text/html\n\n";
	@Tables = &DB_Show_Tables;
	&Do_SQL_Tables_Load_Unload("UnLoad", @Tables);

}
#==========================================================
sub Load_SQL_Text_Backup{
my(@Tables);
	
	print "Content-type: text/html\n\n";
	@Tables = &DB_Show_Tables;

	&Do_SQL_Tables_Load_Unload("Load", @Tables);

}
#==========================================================
sub SQL_Tables_Load_Unload{
my(@Tables);
	
	$| = 1;
	#print "Content-Type: text/plain\n\n";
	print "Content-type: text/html\n\n";
	@Tables = split(/\|\|/, $Param{Tables_Selected});
	&Do_SQL_Tables_Load_Unload($Param{Table_Actions}, @Tables);

}
#==========================================================
sub Do_SQL_Tables_Load_UnloadX{
my($Table_Action, @Tables) = @_;
my($Table, %Var, $File, $Counter, $Start, @Fields, %Skip, $Delimiter);

	undef %Var;
	$Start = time;
	
	# Skip built in Microsoft SQL server tables.
	$Skip{sysconstraints} = 1; 	$Skip{syssegments} = 1;

	foreach $Table(@Tables) {
			if ($Skip{$Table}) {print "<B>Skipping table $Table...</B><BR>"; next;}

			$File = "$Global{Database_Dir}/$Table"."\.sql\.pm";
			$Delimiter = '~||~';
			#----------------------------------------------
			if ($Table_Action eq "UnLoad") {
					print "<B>Unloading table $Table...</B><BR>";
					print "File: $File<BR>";
					open (FILE, ">$File") || &Exit("Cannot create $File: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);

					undef @Fields1;
					@Fields1 = &Get_Table_Fields($Table);

					$Query = qq!SELECT * FROM $Table!;
					$sth = $dbh->prepare($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
					$sth->execute || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
					 
					 $Rows = $sth->rows;
					 print "Rows: $Rows<BR><BR>";

					$Counter = 0;
					while (@Row = $sth->fetchrow_array) {
							$Line = "";

							foreach $Row (@Row) {
								$Row =~ s/\cM//g;
								$Row =~ s/\n//g;
								$Row =~ s/\r//g;
								$Line .= $Delimiter . $Row;
							}

							$Empty = @Fields1 - @Row;
							for $Row(1..$Empty) {
								$Line .= $Delimiter;
							}
							
							$Line =~ s/^\~\|\|\~//;

							print FILE "$Line\n";
							$Counter++;
							if (!($Counter % 10)) {print "<BR>\n";}
							print "$Counter ";
					}

					$sth->finish;
					close(FILE);

					print "<BR>Done...<BR><BR>";
			}#end if Unload
			#----------------------------------------------
			if ($Table_Action eq "Load") {
					print "<B>Loading table $Table...</B><BR>";
					
					if (-e "$File") {
							$Size = -s "$File";
							print "File Size: $Size Bytes<BR>";
							print "File: $File<BR>";
							
							&DB_Empty_Table($Table);
							
							open (FILE, "$File") || &Exit("Cannot open $File: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);
							
							$Counter = 0;
							
							while ($Line = <FILE>){
									$Line =~ s/\n$//; 
									$Line .= $Delimiter. "x";
									@Row = split (/\~\|\|\~/, $Line); 
									pop @Row;
									#$Row[$#Row] =~ s/\n$//; 
									$Line = "";
									foreach $Row (@Row) {
										$Line .=   $dbh->quote($Row) . ",";
									}
									$Line =~ s/\,$//;

									$Query = qq!INSERT INTO $Table VALUES($Line)!;
									$sth = $dbh->prepare($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
									$sth->execute || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);

									$Counter++;
									if (!($Counter % 10)) {print "<BR>\n";}
									print "$Counter ";
							}

							close(FILE);
							print "Done...<BR><BR>";
					}
					else{
							print "Error Loading table $Table: Table file $File does not exists\n";
					}
			}
			#----------------------------------------------
	}
	
	$Time = sprintf("%6.2f", (time - $Start)/60);
	print "<BR>Time consumed: $Time minutes<BR>";
	print qq!<P ALIGN="center"><A HREF="javascript:window.close()"><B><FONT COLOR="BLUE">Close This Window</FONT></B></a></P>!;
}
#==========================================================
sub SQL_Server_Status{
my(%Var, @Var, $Status, $Out);
my ($Help);

	$Help = &Help_Link("SQL_Manager");

	%Var = &DB_STATUS;
	@Var = sort keys %Var;
	
	$Status = "";

	foreach $Var (@Var) {
			$Status .= qq!<TR><TD noWrap>&nbsp;&nbsp;$Var</TD><TD WIDTH="80%">&nbsp;&nbsp;$Var{$Var}</td></tr>!;
	}

	$Back = &Go_Back(0);

$Out=<<HTML;
<BR>
 <DIV ALIGN="center">
    <CENTER>
    <TABLE WIDTH="100%" BORDER="01" CELLSPACING="0" CELLPADDING="5">
      <TR>
        <TD ALIGN="center" BGCOLOR="#F1F1E2">
				<B><FONT SIZE="4">Variable Name</FONT></B>
		</TD>
        <TD ALIGN="center" BGCOLOR="#F1F1E2">
				<B><FONT SIZE="4">Value</FONT></B>
		</TD>
      </TR>

		$Status

    </TABLE>
	$Back 
    </CENTER>
</DIV>
HTML

		&Print_Page($Out, "SQL Server Status", $Help);
}
#==========================================================
sub SQL_Server_Variables{
my(%Var, @Var, $Status, $Out);
my ($Help);

	$Help = &Help_Link("SQL_Manager");

	%Var = &DB_Variables;
	@Var = sort keys %Var;
	
	$Status = "";

	foreach $Var (@Var) {
			$Status .= qq!<TR><TD noWrap>&nbsp;&nbsp;$Var</TD><TD WIDTH="80%">&nbsp;&nbsp;$Var{$Var}</td></tr>!;
	}

	$Back = &Go_Back(0);

$Out=<<HTML;
<BR>
 <DIV ALIGN="center">
    <CENTER>
    <TABLE WIDTH="100%" BORDER="01" CELLSPACING="0" CELLPADDING="5">
      <TR>
        <TD ALIGN="center" BGCOLOR="#F1F1E2">
				<B><FONT SIZE="4">Variable Name</FONT></B>
		</TD>
        <TD ALIGN="center" BGCOLOR="#F1F1E2">
				<B><FONT SIZE="4">Value</FONT></B>
		</TD>
      </TR>

			$Status
    </TABLE>
	$Back 
    </CENTER>
</DIV>
HTML

		&Print_Page($Out, "SQL Server Variables", $Help);
}
#==========================================================
sub Manage_SQL_Tables{
my ($Help);

	$Help = &Help_Link("Manage_SQL_Tables");
	&Print_Page(&Manage_SQL_Tables_Form, "Manage SQL Tables", $Help);	
}
#==========================================================
sub Manage_SQL_Tables_Form{
my($Out, $Temp, @Tables, @DB, $Tables, $DB);

	@Tables = &DB_Show_Tables;
	$Tables = "";
	foreach $Temp (@Tables) {
				$Tables .= qq!<OPTION VALUE="$Temp">$Temp</OPTION>!;
	} 
	
	@DB = &Get_DB_List;
	$DB = "";
	foreach $Temp (@DB) {
				$DB .= qq!<OPTION VALUE="$Temp">$Temp</OPTION>!;
	} 
#DB_Variables
$Out=<<HTML;
<P><B>SQL Database Tables Management</B></P>

<FORM NAME="Tables_Action" METHOD="POST" ACTION="$Script_URL">
<INPUT TYPE="hidden" NAME="action" VALUE="SQL_Table_Action">
<INPUT TYPE="hidden" NAME="Table_Action" VALUE="Describe">
  <DIV ALIGN="left">
    <TABLE WIDTH="100%"  BORDER="1" CELLSPACING="0" CELLPADDING="5" $Global{Admin_Table_Attr}>
      <TR><TD ALIGN="right" WIDTH="200">
		<B>Selecte Table(s): </B></TD>
		 <TD>
		<SELECT NAME="Tables_Selected" SIZE="5" MULTIPLE>
			$Tables
          </SELECT>
			<P ALIGN="justify">To select more than one table, drag your mouse or click with the &lt;CTRL&gt; Key pressed.</P>
		</TD>
      </TR>
      <TR>
        <TD  ALIGN="right"><B>What to do: </B></TD>
		  <TD>
				<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="2">
						<TR><TD ALIGN="left"><INPUT TYPE="button" VALUE="Empty" NAME="Table_Action1" onClick="Empty_Table_Confirm(); return false;" STYLE="color: #000080; border-style: ridge"></TD>
						<TD>Delete all selected tables contents</TD</TR>

						<TR><TD ALIGN="left"><INPUT TYPE="submit" VALUE="Delete" NAME="Table_Action2" onClick="Delete_Table_Confirm(); return false;" STYLE="color: #000080; border-style: ridge"></TD>
						<TD>Delete selected tables and its contents</td></tr>

						<TR><TD ALIGN="left"><INPUT TYPE="submit" VALUE="Optimize" NAME="Table_Action3" onClick="Optimize_Table_Confirm(); return false;" STYLE="color: #000080; border-style: ridge"></TD>		
						<TD>Eliminate any wasted space</td></tr>

						<TR><TD ALIGN="left"><INPUT TYPE="submit" VALUE="Describe" NAME="Table_Action4"  onClick="Describe_Table_Confirm(); return false;" STYLE="color: #000080; border-style: ridge"></TD>
						<TD>Show selected tables information</td></tr>
				</TABLE>
        </TD>
      </TR>
    </TABLE>
  </DIV>
</FORM>

<TABLE BORDER="0" WIDTH="100%" CELLPADDING="0" CELLSPACING="0">
<TD WIDTH="100%"  HEIGHT="1" BGCOLOR="#66CC99"><IMG SRC="$Global{Images_URL}/dot1x1.gif" HEIGHT="1" BORDER="0"></td></tr>
</td></tr>
</TABLE>

<SCRIPT LANGUAGE="JavaScript">
<!--
function Empty_Table_Confirm() {
	var agree=confirm("Are you sure you want to Delete the contents of these SQL Tables\\n");
	if (agree){
			var agree=confirm("Please note once the Tables contents deleted, you will not be able to recover it again\\nAre you sure you still want to empty these SQL Tables?\\n");
			if (agree){
					document.Tables_Action.Table_Action.value='Empty';
					document.Tables_Action.submit();
			}
	}
}

function Delete_Table_Confirm() {
	var agree=confirm("Are you sure you want to delete these SQL Tables?\\n");
	if (agree){
			var agree=confirm("Please note once these Tables deleted, you will not be able to recover it again\\nAre you sure you still want to delete these SQL Tables\\n");
			if (agree){
					document.Tables_Action.Table_Action.value='Delete';
					document.Tables_Action.submit();
			}
	}
}

function Optimize_Table_Confirm() {
	var agree=confirm("Are you sure you want to optimize these SQL Tables?\\n");
	if (agree){
			var agree=confirm("Please note this  process may take long time if the tables has lots of data.\\nAre you sure you still want to optimize these SQL Tables?\\n");
			if (agree){
					document.Tables_Action.Table_Action.value='Optimize';
					document.Tables_Action.submit();
			}
	}
}

function Describe_Table_Confirm() {
					document.Tables_Action.Table_Action.value='Describe';
					document.Tables_Action.submit();
}

-->
</SCRIPT>
	
HTML
	return $Out;
}
#==========================================================
sub SQL_Table_Action{
my(@Tables, $Table, $Out, %Var, $Status);
my ($Help);

	@Tables = split(/\|\|/, $Param{Tables_Selected});

	$Help = &Help_Link("SQL_Manager");
	
	$Out = "";
	$Back = &Go_Back(0);
	
	if ($Param{Table_Action} eq "Describe"){
				foreach $Table (@Tables) {
						undef %Var;
						%Var = &DB_Show_Table($Table);
						undef @Var;
						@Var = sort keys %Var;
				
						$Status = "";

						foreach $Var (@Var) {
								$Status .= qq!<TR><TD noWrap>&nbsp;&nbsp;$Var</TD><TD WIDTH="80%">&nbsp;&nbsp;$Var{$Var}</td></tr>!;
						}

						$Out .= qq~
										<BR><B><FONT SIZE="3">Table: $Table </FONT></B><BR>
										 <DIV ALIGN="center">
											<CENTER>
											<TABLE WIDTH="100%" BORDER="01" CELLSPACING="0" CELLPADDING="3" $Global{Admin_Table_Attr}>
												<TR><TD ALIGN="center" BGCOLOR="#F1F1E2"><B>Variable Name</B></TD><TD ALIGN="center" BGCOLOR="#F1F1E2"><B>Value</B></td></tr>
													$Status
											</TABLE>
											</CENTER>
										</DIV>~;
					
				}
				$Out .= qq!<P ALIGN="center">$Back</P>!;
				&Print_Page($Out, "SQL Table Information", $Help);
	}
	elsif ($Param{Table_Action} eq "Empty"){
				foreach $Table (@Tables) {
						if ($Table) {
							&DB_Empty_Table($Table);
						}
				}
				
				&Manage_SQL_Tables;
	}
	elsif ($Param{Table_Action} eq "Delete"){
				foreach $Table (@Tables) {
						if ($Table) {
							&DB_Drop_Table($Table);
						}
				}
				
				&Manage_SQL_Tables;
	}
	elsif ($Param{Table_Action} eq "Optimize"){
				foreach $Table (@Tables) {
						if ($Table) {
							&DB_Optimize_Table($Table);
						}
				}
				
				&Manage_SQL_Tables;
	}
	else{
				&Manage_SQL_Tables;
	}

}
#==========================================================
sub SQL_Database_Action{

	if ($Param{Database_Action} eq "Delete Database"){
				&DB_Drop($Param{Drop_Database_Name});
	}

	if ($Param{Database_Action} eq "Create Database"){
				$Param{Create_Database_Name} =~ s/^\s+//g;
				$Param{Create_Database_Name} =~ s/\s+$//g;
				if ($Param{Create_Database_Name}) {
					&DB_Create($Param{Create_Database_Name});
				}
	}

	&Manage_SQL_Databases;

}
#==========================================================
sub Manage_SQL_Databases{
my ($Help);

	$Help = &Help_Link("Manage_SQL_Databases");
	&Print_Page(&Manage_SQL_Databases_Form, "Manage SQL Databases", $Help);	
}
#==========================================================
sub Manage_SQL_Databases_Form{
my($Out, $Temp, @DB, $DB);

	@DB = &Get_DB_List;
	$DB = "";
	foreach $Temp (@DB) {
				$DB .= qq!<OPTION VALUE="$Temp">$Temp</OPTION>!;
	} 

$Out=<<HTML;
<BR><BR>
<FORM NAME="Database_Action" METHOD="POST" ACTION="$Script_URL">
<INPUT TYPE="hidden" NAME="action" VALUE="SQL_Database_Action">
<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
<TR>
<TD>
  Delete Database:
</TD>
<TD>
	<SELECT  NAME="Drop_Database_Name"  SIZE="1">
	<OPTION SELECTED VALUE="">-----Select database-----</OPTION>
	$DB
  </SELECT>
  <INPUT TYPE="submit" VALUE="Delete Database" NAME="Database_Action" onClick="Delete_Database_Confirm(document.Database_Action.Drop_Database_Name[document.Database_Action.Drop_Database_Name.selectedIndex].value); return false;" STYLE="color: #000080; border-style: ridge">
  </TD>
</TR>
</TABLE>

<BR><BR>

<TABLE BORDER="1" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
<TR>
<TD>Create Database:</TD>
<TD>
			<INPUT TYPE="text" NAME="Create_Database_Name" VALUE="">
			<INPUT TYPE="submit" VALUE="Create Database" NAME="Database_Action" STYLE="color: #000080; border-style: ridge">
</TD>
</TR>
</TABLE>
</FORM>

<TABLE BORDER="0" WIDTH="100%" CELLPADDING="0" CELLSPACING="0">
<TD WIDTH="100%"  HEIGHT="1" BGCOLOR="#66CC99"><IMG SRC="$Global{Images_URL}/dot1x1.gif" HEIGHT="1" BORDER="0"></td></tr>
</td></tr>
</TABLE>

<SCRIPT LANGUAGE="JavaScript">
<!--
function Delete_Database_Confirm(Database) {
	if (! Database) {alert("Please select a Database"); return;}
	var agree=confirm("Are you sure you want to delete this SQL Database and all its Tables?\\nTable: "+Database+"\\n");
	if (agree){
			var agree=confirm("Please note once the Database deleted, you will not be able to recover it again\\nAre you sure you still want to delete this Database?\\nDatabase: "+Database+"\\n");
			if (agree){
					window.location = "$Script_URL?action=SQL_Database_Action&Database_Action=Delete+Database&Drop_Database_Name=" +Database;
			}
	}
	//document.Delete_Language.submit();
}

-->
</SCRIPT>
	
HTML
	return $Out;

}
#==========================================================
sub SQL_Commander{

my($Help);

	$Help =&Help_Link("Database_Manager");

	&Print_Page(&SQL_Commander_Form, "Database & SQL Manager", $Help);

}
#==========================================================
sub SQL_Commander_Form{
my($Result, $Query, $sth);

	$Param{Query} ||= "";
	$Param{Query} =~ s/^\s+//;
	$Param{Query} =~ s/\s+$//;

	$Result = "";
	if ($Param{Query} ne "") {
			$Query = $Param{Query};
			$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
			$Count = 0;
			while (@Row = $sth->fetchrow_array){
					$Result .= join ("<br>", @Row) . "<br>";
			}
			$sth->finish;
	}

$Out=<<HTML;
<P ALIGN="left">Please enter the SQL Statement you want to execute.</P>

<FORM NAME="Tables_Action" METHOD="POST" ACTION="$Script_URL">
<INPUT TYPE="hidden" NAME="action" VALUE="SQL_Commander">

 <DIV ALIGN="left">
    <TABLE $Global{Admin_Table_Attr} BORDER="1" CELLSPACING="0" CELLPADDING="2">
      <TR><TD ALIGN="left">
			<TEXTAREA NAME="Query" ROWS="6" COLS="80" >$Param{Query}</TEXTAREA>
		  </TD>
      </TR>
      <TR>
        <TD ALIGN="center">
				<INPUT TYPE="submit" VALUE="Run Statement"  STYLE="color: #000080; border-style: ridge">
				<INPUT TYPE="submit" VALUE="Reset" STYLE="color: #000080; border-style: ridge">
        </TD>
      </TR>
    </TABLE>
  </DIV>

</FORM>

 <DIV ALIGN="left">
    <TABLE $Global{Admin_Table_Attr} BORDER="1" CELLSPACING="0" CELLPADDING="2">
      <TR><TD ALIGN="left">
			$Result
		  </TD>
      </TR>
    </TABLE>
  </DIV>

HTML
	
	return $Out;
}
#==========================================================
sub Do_SQL_Tables_Load_Unload{
my ($Table_Action, @Tables) = @_;
my ($Table, %Var, $File, $Counter, $Start, @Fields, %Skip, $Delimiter);
my ($Escape, $EOLine, @Fields1);

	undef %Var;
	$Start = time;
	
	# Skip built in Microsoft SQL server tables.
	$Skip{sysconstraints} = 1; 	$Skip{syssegments} = 1;
	
	foreach $Table(@Tables) {
			if ($Skip{$Table}) {print "<B>Skipping table $Table...</B><BR>"; next;}

			$File = "$Global{Database_Dir}/$Table\.sql\.pm";
			#$File = "$Table"."\.sql\.pm";
			$Delimiter = '<~|||~>'; $Escape = "\\"; $EOLine = "'\n'";
			#----------------------------------------------
			if ($Table_Action eq "UnLoad") {
					print "<B>Unloading table $Table...</B><BR>";
					print "File: $File<BR>";

					if ($Global{DB_File_Priv}) {
						unlink $File;
						&Export_Table($Table, $Delimiter, $Escape, $EOLine, $File);
						next;
					}
					open (FILE, ">$File") || &Exit("Cannot create $File: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);

					undef @Fields1;
					@Fields1 = &Get_Table_Fields($Table);

					$Query = qq!SELECT * FROM $Table!;
					$sth = $dbh->prepare($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
					$sth->execute || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
					 
					 $Rows = $sth->rows;
					 print "Rows: $Rows<BR><BR>";

					$Counter = 0;
					while (@Row = $sth->fetchrow_array) {
							$Line = "";

							foreach $Row (@Row) {
								$Row =~ s/\cM//g;
								$Row =~ s/\n/\\n/g;
								$Row =~ s/\r/\\r/g;
								$Line .= $Delimiter . $Row;
							}

							$Empty = @Fields1 - @Row;
							for $Row(1..$Empty) {
								$Line .= $Delimiter;
							}
							
							$Line =~ s/^\<\~\|\|\|\~\>//;

							print FILE "$Line\n";
							
							$Counter++;
							if (!($Counter % 10)) {print "<BR>\n";}
							print "$Counter ";
					}

					$sth->finish;
					close(FILE);

					print "<BR>Done...<BR><BR>";
			}#end if Unload
			#----------------------------------------------
			if ($Table_Action eq "Load") {
					print "<B>Loading table $Table...</B><BR>";
					
					if (-e "$File") {
							$Size = -s "$File";
							print "File Size: $Size Bytes<BR>";
							print "File: $File<BR>";
							
							&DB_Empty_Table($Table);

							if ($Global{DB_File_Priv}) {
								&Import_Table($Table, $Delimiter, $Escape, $EOLine, $File);
								next;
							}
							
							open (FILE, "$File") || &Exit("Cannot open $File: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);
							
							$Counter = 0;
							
							while ($Line = <FILE>){
									$Line =~ s/\n$//; 
									$Line .= $Delimiter. "x";
									@Row = split (/\<\~\|\|\|\~\>/, $Line); 
									pop @Row;
									$Line = "";
									foreach $Row (@Row) {
										$Row =~ s/\\n/\n/g;
										$Row =~ s/\\r/\r/g;
										$Line .=   $dbh->quote($Row) . ",";
									}
									$Line =~ s/\,$//;

									$Query = qq!INSERT INTO $Table VALUES($Line)!;
									$sth = $dbh->prepare($Query) || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);
									$sth->execute || &DB_Exit($Query."<BR>Line ". __LINE__ . ", File ". __FILE__);

									$Counter++;
									if (!($Counter % 10)) {print "<BR>\n";}
									print "$Counter ";
							}

							close(FILE);
							print "Done...<BR><BR>";
					}
					else{
							print "Error Loading table $Table: Table file $File does not exists\n";
					}
			}
			#----------------------------------------------
	}
	
	$Time = sprintf("%6.2f", (time - $Start)/60);
	print "<BR>Time consumed: $Time minutes<BR>";
	print qq!<P ALIGN="center"><A HREF="javascript:window.close()"><B><FONT COLOR="BLUE">Close This Window</FONT></B></a></P>!;
}
#==========================================================
sub SaveDatabaseOptions{
my (%Config);

	undef %Config;
	$Param{DB_File_Priv} ||= 0;
	$Config{DB_File_Priv} = $Param{DB_File_Priv};
	&Update_Configuration(%Config);
	$Global{DB_File_Priv} = $Param{DB_File_Priv};
	&Database_Manager;
}
#==========================================================
sub SQL_Administration{
my ($Result, $Error) = @_;
my ($Help);
	
	$Help =&Help_Link("Database_Manager");

	$Error = &SQL_Root_Connect;
	
	&Print_Page(&SQL_Administration_Form($Error), "Database & SQL Manager", $Help);
	
	$dbh1->disconnect if($dbh1);
}
#==========================================================
sub SQL_Administration_Form{
my ($Error) = @_;
my ($Out, %Priv, %User, $Key, $Value);
	
		undef %Priv;
		if ($Param{action} eq "SQLUserPriv") {
				if ($Param{SubAction} eq "Update") {
						$Result = &SQLSetUserPriv;
				}
				%User = &SQLGetUserPriv;
				while (($Key, $Value) = each %User) {
						if ($Value eq "Y") {$Priv{$Key} = "checked";} else {$Priv{$Key} = "";}
				}
		}
	
$Out =<<HTML;
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>Root User Login</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
	<tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="SQL_Administration_Connect">
	<td colspan="2">Please enter the SQL server root user login. Login information not saved.</td></tr>
    <tr><td >User: </td><td><input type="password" name="SQL_Root_User" size="30" value="$Param{SQL_Root_User}"></td></tr>
	<td >Password: </td><td><input type="password" name="SQL_Root_Pass" size="30" value="$Param{SQL_Root_Pass}"></td></tr>
	<tr><td nowrap align="center" colspan="2">
			<input type="submit" value="Connect" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
$Error
<br><br>
<!--------------------------------------------------------------------------------->
<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200"  align="center" background="$Global{Images_URL}/lh1.gif" height="22">&nbsp;<b>User Privilages</b></td><td>&nbsp;</td></tr>
</table>
<!-------------------------------------------------------------------------------->
<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">
  <table border="0" cellspacing="0" cellpadding="4" $Global{Admin_Table_Attr}>
	<tr>
		<form method="post" action="$Script_URL">
		<input type="hidden" name="action" value="SQLUserPriv">
		<input type="hidden" name="SQL_Root_User" value="$Param{SQL_Root_User}">
		<input type="hidden" name="SQL_Root_Pass" value="$Param{SQL_Root_Pass}">

<td colspan="2">Show and update user privilages.</td></tr>
    <tr><td >User: </td><td><input type="text" name="User" size="30" value="$Param{User}"></td></tr>
    <tr><td colspan="1">Privilages: </td><td>
		<table border="0" cellspacing="0" cellpadding="2" $Global{Admin_Table_Attr}>
		<tr>
			<td>	Select_priv</td><td> <input type="checkbox" name="Select_priv" value="1" $Priv{Select_priv}></td>
			<td>Insert_priv</td><td> <input type="checkbox" name="Insert_priv" value="1" $Priv{Insert_priv}></td>
			<td>Update_priv</td><td> <input type="checkbox" name="Update_priv" value="1" $Priv{Update_priv}></td>
			<td>Delete_priv</td><td> <input type="checkbox" name="Delete_priv" value="1" $Priv{Delete_priv}></td>
	</tr>
	<tr>
			<td>Create_priv</td><td> <input type="checkbox" name="Create_priv" value="1" $Priv{Create_priv}></td>
			<td>Drop_priv</td><td> <input type="checkbox" name="Drop_priv" value="1" $Priv{Drop_priv}></td>
			<td>Reload_priv</td><td> <input type="checkbox" name="Reload_priv" value="1" $Priv{Reload_priv}></td>
			<td>Shutdown_priv</td><td> <input type="checkbox" name="Shutdown_priv" value="1" $Priv{Shutdown_priv}></td>
	</tr>
	<tr>
			<td>Process_priv</td><td> <input type="checkbox" name="Process_priv" value="1" $Priv{Process_priv}></td>
			<td>File_priv</td><td> <input type="checkbox" name="File_priv" value="1" $Priv{File_priv}></td>
			<td>Grant_priv</td><td> <input type="checkbox" name="Grant_priv" value="1" $Priv{Grant_priv}></td>
			<td>References_priv</td><td> <input type="checkbox" name="References_priv" value="1" $Priv{References_priv}></td>
	</tr>
	<tr>
			<td>Index_priv</td><td> <input type="checkbox" name="Index_priv" value="1" $Priv{Index_priv}></td>
			<td>Alter_priv</td><td> <input type="checkbox" name="Alter_priv" value="1" $Priv{Alter_priv}></td>
			</td><td></td><td>
			</td><td></td><td>
	</tr>
	</table>

	</td>
    </tr>
	<tr><td nowrap align="center" colspan="2">
			<input type="submit" value="Show" name="SubAction" style="color: #000080; border-style: ridge">&nbsp;
			<input type="submit" value="Update" name="SubAction" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
	</form>
    </tr>
  </table>
	</td>
</tr>
</table>
<br>
<!-------------------------------------------------------------------------------->
<b><font color="#CC0033" size="4">Output</font></b>
				<br>
$Result
HTML
}
#==========================================================
sub SQL_Administration_Connect{
my ($Status);

	$Status = &SQL_Root_Connect;
	&SQL_Administration("", $Status);
}
#==========================================================
sub SQL_Root_Connect{
my ($Status, $DSN1, $sth, $Query, $Temp);
	
   $Param{SQL_Root_User} ||= ""; $Param{SQL_Root_Pass} ||= "";
   $DSN1 = "DBI:$Global{DB_Driver}:database=mysql;host=$Global{DB_Host};port=$Global{DB_Port}";

   if ($dbh1 = DBI->connect($DSN1, $Param{SQL_Root_User}, $Param{SQL_Root_Pass})){
			$Status = "<b>Status: Connected</b>";
   }
	else{	
			$Status = qq!<b><font color="#CC0033">$DBI::errstr<br>$Query</font></b>!;
	}
	return $Status;
}
#==========================================================
sub SQLGetUserPriv{
my ($User, $Query, $sth, $Temp, %User);

	$Param{User} =~ s/^\s+//;
	$Param{User} =~ s/\s+$//;
	$Param{User} ||= $Global{DB_UserID};
	
	if ($dbh1) {
			$User = $dbh1->quote($Param{User});
			$Query = qq!SELECT * FROM user WHERE user=$User!;
			$sth = $dbh1->prepare($Query);
			$sth->execute;
			undef %User;
			while ($Temp = $sth->fetchrow_hashref){%User = %{$Temp}; last;}
			$sth->finish;
	}

	return %User;
}
#==========================================================
sub SQLSetUserPriv{
my (@Priv, $Privilages, $Key, $Query, $sth, @Row, $User_Priv);
	
	&Demo; 
	$Param{User} =~ s/^\s+//;
	$Param{User} =~ s/\s+$//;
	$Param{User} ||= return "";
	
	$User_Priv = "";

	@Priv = qw (
						Select_priv
						Insert_priv
						Update_priv
						Delete_priv
						Create_priv
						Drop_priv
						Reload_priv
						Shutdown_priv
						Process_priv
						File_priv
						Grant_priv
						References_priv
						Index_priv
						Alter_priv
					);
	$Privilages = "";
	foreach $Key (@Priv) {
			$Privilages .= "$Key=";
			if ($Param{$Key}) {$Privilages .= "\'Y\'";} else {$Privilages .= "\'N\'";}
			$Privilages .= ", ";
	}
	$Privilages =~ s/\,\s*$//;

	if ($dbh1 && $Param{User}) {
			$User = $dbh1->quote($Param{User});
			$Query = qq!UPDATE user set $Privilages WHERE user=$User!;
			$sth = $dbh1->prepare($Query);
			$sth->execute;
			while ((@Row) = $sth->fetchrow_array){$User_Priv .= join "<br>", @Row;}
			$sth->finish;
	}

	eval{system("mysqladmin reload -u$Param{SQL_Root_User} -p$Param{SQL_Root_Pass}")};
	return $User_Priv ;;#."<br>Query:$Query<br>";
}
#==========================================================
1;