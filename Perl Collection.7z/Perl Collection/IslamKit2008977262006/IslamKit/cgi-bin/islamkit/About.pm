=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub About{
my ($Out,$Msg);

$Msg=<<HTML;
<DIV ALIGN="center">
  <CENTER>
<TABLE WIDTH="100%" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200" ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>About This Product</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE WIDTH="100%" CELLPADDING="0" CELLSPACING="0" BORDER="1" BORDERCOLOR="#FFCC00">
<TR><TD>
	<TABLE BORDER="0" WIDTH="100%" CELLSPACING="0" CELLPADDING="3" $Global{Admin_Table_Attr}>
	  <TR><TD ALIGN="left" NOWRAP>&nbsp;<B>Product Name:</B></TD><TD WIDTH="90%">IslamKit</TD></TR>
	  <TR><TD ALIGN="left" VALIGN="top">&nbsp;<B>Version:</B></TD><TD>$Global{Software_Version} Build $Global{Software_Build}</TD></TR>
	  <TR><TD ALIGN="left" >&nbsp;<B>Company:</B></TD><TD>IslamWare</TD></TR>
	  <TR><TD ALIGN="left" >&nbsp;<B>Home Page:</B></TD><TD><A HREF="http://www.islamware.com" target="_blank">http://www.islamware.com</A></TD></TR>
	  <TR><TD ALIGN="left" >&nbsp;<B>Sales Contact:</B></TD><TD><A HREF="mailto: sales\@islamware.com">sales\@islamware.com</A></TD></TR>
	<TR><TD>&nbsp;<B>Updates:</b></TD><TD>Updates to the latest version and Upgrades are available from <A HREF="http://www.islamware.com" target="_blank">IslamWare</A> web site.</TD></TR>
	  <TR><TD COLSPAN="2">Copyright &copy; 2006 IslamWare<sup>&reg;</sup>. All rights reserved.</TD></TR>
	</TABLE>
   </TD>
  </TR>
</TABLE>

<BR>

HTML

		&Print_Page($Msg, "About IslamKit", "");	
}
#==========================================================
sub Update{
my ($CGI_Directory, $HTML_Directory, $License_Number, $Var);
	
	$CGI_Directory = $Global{CGI_Dir};
	$CGI_Directory =~ s/\\$//g;
	$CGI_Directory =~ s/\/$//g;

	$HTML_Directory = $Global{HTML_Dir};
	$HTML_Directory =~ s/|\\$//g;
	$HTML_Directory =~ s/\/$//g;

	#$License_Number = &Decrypt($Global{License_Number}, 'Ms09t#8s0qep');

	$Var = qq!Product=Auctionawy&License_Number=$Global{License_Number}&Domain_Name=$ENV{HTTP_HOST}&CGI_Directory=$CGI_Directory&HTML_Directory=$HTML_Directory&CGI_Directory_URL=$Global{CGI_URL}&HTML_Directory_URL=$Global{HTML_URL}!;
	#$Var =~ s/ /%20/g;
	$Var = &Web_Encode($Var);

	print qq!Location: $Global{Update_URL}?$Var\n\n!; 
	exit 0;
}
#==========================================================
1;