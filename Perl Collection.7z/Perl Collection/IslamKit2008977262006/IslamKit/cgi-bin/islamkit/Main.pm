=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub MainAction{

if ($Param{action} eq 'Quran') {&QuranStart; &Quran;}
elsif ($Param{action} eq 'Qibla') {&QiblaStart; &Qibla;}

elsif ($Param{action} eq 'ReadQuran') {&QuranStart; &ReadQuran;}
elsif ($Param{action} eq 'SearchQuran') {&QuranStart; &SearchQuran;}

elsif ($Param{action} eq 'ReciteSurah') {&QuranStart; &ReciteSurah;}
elsif ($Param{action} eq 'ReciteAyah') {&QuranStart; &ReciteAyah;}

#------------------------------------------------------------------------------
# General
elsif ($Param{action} eq 'Help') {&GeneralStart; &Help;}
elsif ($Param{action} eq 'GetHelp') {&GeneralStart; &GetHelp;}
elsif ($Param{action} eq 'About_Us') {&GeneralStart; &About_Us;}
elsif ($Param{action} eq "Set_Language"){&GeneralStart; &Set_Language;}
elsif ($Param{action} eq "Set_Current_Language"){&GeneralStart; &Set_Current_Language;}
elsif ($Param{action} eq "Custom"){&GeneralStart; &Custom_Page;}
elsif ($Param{action} eq "Search_Help"){&GeneralStart; &Search_Help;}
elsif ($Param{action} eq "Copyright"){&GeneralStart; &Copyright;}
elsif ($Param{action} eq "Privacy_Policy"){&GeneralStart; &Privacy_Policy;}
elsif ($Param{action} eq "Terms_of_Use"){&GeneralStart; &Terms_of_Use;}
elsif ($Param{action} eq "Advertise"){&GeneralStart; &Advertise;}
elsif ($Param{action} eq "GetPage"){&GeneralStart; &GetPage;}
#-----------------------------------------------------------------------------------
# Contact Us
elsif ($Param{action} eq "Contact_Us"){&ContactStart; &Contact_Us;}
elsif ($Param{action} eq "Send_Contact_Us"){&ContactStart; &Send_Contact_Us;}
#-----------------------------------------------------------------------------------
# Announcements
elsif ($Param{action} eq "Announcements"){eval "use Announcements;"; &Announcements;}
#-----------------------------------------------------------------------------------

#------------------------------------------------------------------------------
else {&QuranStart; &Quran;}
exit 0;
}
#=======================End of admin main action================
#==========================================================
sub QuranStart {
	eval "use Quran;";
	eval "use QuranLib;";
}
#==========================================================
sub QiblaStart {
	eval "use Qibla;";
}
#==========================================================
sub GeneralStart{
	eval "use MsLib;";
}
#==========================================================
sub ContactStart{
	eval "use ContactUs;";
	eval "use MailLib;";
}
#==========================================================
#==========================================================
1;