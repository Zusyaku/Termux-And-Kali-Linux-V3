#==========================================================
# IslamKit Configuration
# Please modify these four path and URL parameters according to your server

# This is the full absolute path to the executables directory
CGI_Dir=

# This is the full URL to the executables directory
CGI_URL=

# This is the full absolute path to the none executables (html or docs) directory
HTML_Dir=c:/apache/htdocs/islamkits

# This is the full URL to the none executables (html or docs) directory
HTML_URL=http://localhost/islamkits
#==========================================================
# If you rename any program executables files, then you have to rename it here also
Main_Prog=islamkit.cgi
Admin_Prog=admin.cgi
