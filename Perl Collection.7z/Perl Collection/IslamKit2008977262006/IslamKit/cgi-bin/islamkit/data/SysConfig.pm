Account_Confirmation_Email~==~Account Confirmation <webmaster@islamware.com>
AdminEditorBackground~==~#FFFFCC
AdminEditorColumns~==~80
AdminEditorForeground~==~BLACK
AdminEditorRows~==~25
AdminQuranEditorAyahs~==~10
AdminUploadReciterFiles~==~5
Admin_Help_Window_Height~==~450
Admin_Help_Window_Width~==~620
Admin_Table_Attr~==~ style="border: 0 outset #F7F7F7" bordercolor="#F7F7F7"
Contact_Us_Email~==~Contact Us <info@islamware.com>
DB_DSN~==~
DB_Driver~==~mysql
DB_File_Priv~==~0
DB_Host~==~localhost
DB_Name~==~islamkit
DB_Password~==~
DB_Port~==~3306
DB_Server~==~MySQL
DB_UserID~==~root
DefaultAyah~==~1
DefaultAyahLoop~==~0
DefaultAyahReciter~==~Huzify
DefaultAyahRepeat~==~0
DefaultAyahs~==~50
DefaultInterpertation~==~
DefaultLayout~==~4
DefaultPage~==~1
DefaultPart~==~1
DefaultQuranName~==~Arabic
DefaultSurah~==~1
DefaultSurahReciter~==~Jibreal
DefaultTranslation~==~
DefaultTransliteration~==~
DefaultType~==~0
Demo_Mode~==~0
Email_Format~==~1
Email_Status~==~1
Email_X_Mailer~==~Islamware
Email_X_Priority~==~1
Forbidden_Remote_Hosts~==~66.0.106.55, 66.35.208.60, 66.7.131.131, 66.7.131.135, 66.7.131.139
GMT_Offset~==~3
IslamKitAdminPassword~==~
IslamKitAdminUserID~==~
Language~==~English
Languages~==~English
Mail_Program_Or_SMTP_Server~==~/usr/lib/sendmail
Mail_Program_Type~==~0
Maximum_Search_Results~==~0
Meta_Description~==~Holy Quran database, Quran Translations, Quran Transliterations, Quran Interpertaions, Prayer Times, Qibla direction, and Sunrise calculator.
Meta_Keywords~==~Quran, Quran data, Holy Quran Database,Quran Translations, Quran Transliterations, Quran Interpertaions, Islam,Musilm,Qibla, Qibla direction, Qibla calculator, Qibla direction calculator, Sunrise, Sunrise calculator, Paryer Times, Prayer times calculator, Pray Times, Pray Time Caculator.
Meta_Title~==~IslamKit
PageViews~==~0
Search_Prefix~==~<font style="color: red; background-color: #66FF00;">
Search_Suffix~==~</font>
Secure_Key~==~IsLaMwArETiGeRhErE
Site_Name~==~Site_Name
Support_Email~==~Support <support@islamware.com>
Themes~==~English:Default
Webmaster_Email~==~Webmaster <webmaster@islamware.com>
Whos_Online_Time_Out~==~300
