SurahMenuOption~==~<option value="<!--Surah-->" <!--Selected-->><!--Surah-->- <!--Name--> (<!--Ayahs-->)</option>
PageMenuOption~==~<option value="<!--Page-->" <!--Selected-->><!--Page--></option>

QuranMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
QuranNoneOption~==~-- None --
TranslationMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
TranslationNoneOption~==~-- None --
TransliterationMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
TransliterationNoneOption~==~-- None --
InterpertationMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
InterpertationNoneOption~==~-- None --
AyahsMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Value--></option>
AyahMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Value--></option>
PartMenuOption~==~<option value="<!--Part-->" <!--Selected-->><!--Part--></option>

SearchAyahForm~==~<tr><td valign="top" align="center"><font color="#333300"><!--Count--></font></td><td valign="top" align="center"><a href="#X" onClick="top.ShowAyah(<!--ID-->);" style="CURSOR: pointer"><font color="#333300"><!--Name--></font></a></td><td valign="top" align="center"><a href="#X" onClick="top.ShowAyah(<!--ID-->);" style="CURSOR: pointer"><font color="#333300"><!--Surah--></font></a></td><td valign="top" align="center"><a href="#X" onClick="top.ShowAyah(<!--ID-->);" style="CURSOR: pointer"><font color="#333300"><!--Ayah--></font></a></td></tr>
SearchAyahFormJoiner~==~