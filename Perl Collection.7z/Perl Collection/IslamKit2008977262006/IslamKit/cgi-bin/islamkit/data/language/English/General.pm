September~==~September
page_views~==~Page Views
save_surah_as~==~Download Surah Recitation
referer_error_msg~==~This domain is not allowed to run this program
set_language~==~Language
October~==~October
referer_error_title~==~Domain Not Allowed
search_header_ayah~==~Ayah
Sunday~==~Sunday
reciter~==~Reciter:
critical_error_title~==~Critical Error
Marquee~==~<!--CLASS::Marquee-->
AyahMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Value--></option>
QuranLayoutName4~==~Color Rows
subscribe~==~Subscribe
MarqueeText~==~<span dir="ltr"><b><font size="3" face="Simplified Arabic,Arabic Transparent,Traditional Arabic" color="#FFFFCC">���� ����        � � � � � � � �        ��� ��� ���� ����</font></b></span>
quran_layout~==~Layout:
TransliterationNoneOption~==~-- None --
ayah~==~Ayah:
subscribe_button~==~<input type="submit" value="Subscribe" name="Subscribe" style="BORDER-RIGHT: #FFCC33 1px outset; BORDER-TOP: #FFCC33 1px outset; FONT-WEIGHT: bold; FONT-SIZE: 10pt; BORDER-LEFT: #FFCC00 1px outset; COLOR: #5E2F00; BORDER-BOTTOM: #FFCC66 1px outset; FONT-FAMILY: Arial; BACKGROUND-COLOR: #FEEB9E">
surah~==~Surah
Wednesday~==~Wednesday
noon~==~Noon
PartMenuOption~==~<option value="<!--Part-->" <!--Selected-->><!--Part--></option>
QuranLayoutName3~==~Continuous
and~==~and
January~==~January
April~==~April
August~==~August
SurahMenuOption~==~<option value="<!--Surah-->" <!--Selected-->><!--Surah-->- <!--Name--> (<!--Ayahs-->)</option>
interpertation~==~Interpertation:
PageMenuOption~==~<option value="<!--Page-->" <!--Selected-->><!--Page--></option>
QuranLayoutName1~==~Rows
SurahReciterMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
privacy_policy~==~Privacy
AyahsMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Value--></option>
language_direction~==~dir="ltr"
TransliterationMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
February~==~February
AyahReciterMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
recite_quran~==~Recitation
AyahRepeatMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
TranslationMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
quran_search_meta_title~==~Quran
home~==~Home
site_name~==~Site_Name
AM~==~AM
InterpertationNoneOption~==~-- None --
part~==~Part:
Friday~==~Friday
contact_us~==~Contact Us
March~==~March
quran_menu~==~Quran:
quran_search_meta_description~==~Holy Quran Multi-lingual database
seconds_consumed~==~ Seconds
search_header_name~==~Name
search~==~Search
page~==~Page:
page_ayahs~==~Page Ayahs:
copyright~==~Copyright � 2006 <!--CLASS::Site_Name-->. All rights reserved.
memorize_quran~==~Memorization
ayah_reciter~==~Reciter:
November~==~November
quran_control_menu~==~Quran Control Menu
QuranLayoutName5~==~Color Columns
December~==~December
about_us~==~About Us
nav_center_msg~==~<span dir="ltr"><b><font size="3" face="Simplified Arabic,Arabic Transparent,Traditional Arabic" color="#CFB070">&#1575;&#1584;&#1603;&#1585; &#1575;&#1604;&#1604;&#1607;&nbsp; - &#1589;&#1604;&#1609; &#1593;&#1604;&#1609; &#1585;&#1587;&#1608;&#1604; &#1575;&#1604;&#1604;&#1607;</font></b></span>
translation~==~Translation:
who_is_online~==~Currently Online
search_header_num~==~#
TranslationNoneOption~==~-- None --
transliteration~==~Transliteration:
incorrect_information~==~Incorrect information
ayah_loop~==~Loop: 
quran_viewer_meta_keywords~==~Quran, Quran data, Holy Quran Database,Islam,Musilm
search_quran~==~Search
May~==~May
ayah_repeat~==~Repeat: 
quran~==~Quran
copyright_label~==~Copyright
quran_viewer_meta_title~==~Quran
SearchAyahFormJoiner~==~
current_recite_ayah~==~Current Ayah:
Tuesday~==~Tuesday
search_for~==~Search for:
QuranLayoutMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
QuranLayoutName2~==~Columns
quran_viewer_meta_description~==~Holy Quran Multi-lingual database
June~==~June
July~==~July
help~==~Help
Thursday~==~Thursday
QuranNoneOption~==~-- None --
SearchAyahForm~==~<tr><td valign="top" align="center"><font color="#333300"><!--Count--></font></td><td valign="top" align="center"><a href="#X" onClick="top.ShowAyah(<!--ID-->);" style="CURSOR: pointer"><font color="#333300"><!--Name--></font></a></td><td valign="top" align="center"><a href="#X" onClick="top.ShowAyah(<!--ID-->);" style="CURSOR: pointer"><font color="#333300"><!--Surah--></font></a></td><td valign="top" align="center"><a href="#X" onClick="top.ShowAyah(<!--ID-->);" style="CURSOR: pointer"><font color="#333300"><!--Ayah--></font></a></td></tr>
PM~==~PM
Monday~==~Monday
InterpertationMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
who_is_online_guests~==~Online Guests:
Saturday~==~Saturday
announcements~==~Announcements
search_header_surah~==~Surah
QuranMenuOption~==~<option value="<!--Value-->" <!--Selected-->><!--Name--></option>
quran_search_meta_keywords~==~Quran, Quran data, Holy Quran Database,Islam,Musilm
SajdahCompulsaryAyah~==~&nbsp;<font color="red" face="Times New Roman">&#1769;</font>&nbsp;
SajdahRecommendedAyah~==~&nbsp;<font color="blue" face="Times New Roman">&#1769;</font>&nbsp;
