contact_us_page_title~==~Contact Us
contact_us_page_help~==~Thank you for giving us feedback on the site. Please be sure to give us a correct e-mail address. We appreciate you taking the time to let us know what you think, and we will do our best to incorporate appropriate suggestions into our site.
contact_us_form_help~==~Please fill out all the information below to give us your feedback.
phone_number_label~==~Phone Number:
comments_label~==~Message:
contact_label~==~Contact you:
email_address_label~==~Email Address:
subject_label~==~Subject:
yes_label~==~Yes
full_name_label~==~Full Name:
no_label~==~No
contact_us_email_subject~==~Contact us request
contact_us_received~==~Your Feedback Received
contact_us_received_description~==~Thank you for your feedback and comments, we will try to contact you as soon as we can.
invalid_email~==~Please enter a valid email address.<br>
missing_information~==~Missing information
error_name~==~Please enter your full name.<br>
error_phone~==~Please enter your phone number and area code.<br>
error_subject~==~Please enter your contact subject or title.<br>
error_message~==~Please enter your contact comments or questions.<br>
error_email~==~Please enter your contact email address.<br>
contact_email_body~==~Full name: <!--Name--><BR>Email: <!--Email--><BR>Phone: <!--Phone--><BR>Subject: <!-Subject--><BR>Comments: <BR><!--Message--><BR><BR>Contact: <!--Contact--><BR>Remote Address: <!--IP--> <!--Host--> <BR>
remote_address_label~==~Your IP:
contact_us_menu_label~==~Contact Us
submit_button~==~<input type="submit" name="Search" value="Send Request">
clear_form_button~==~<input type="reset" name="Reset" value="Reset">
cancel_button~==~<A HREF="javascript:history.go(-1)"><b>Cancel</b></A>
