main_help_title~==~<!--CLASS::Site_Name--> Help
faq~==~Frequently Asked Questions
main_help_header~==~Welcome to <!--CLASS::Site_Name--> Main Help Index.
main_tips_label~==~
quran_search_help_link~==~How to search Quran Database