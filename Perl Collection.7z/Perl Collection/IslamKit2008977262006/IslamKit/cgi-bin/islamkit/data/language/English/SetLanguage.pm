set_language_title~==~Set Your Default Language
set_language_help~==~<p align="justify">Specify the language you want to see your web pages in. To do so, select your preferred language and click <B>Set Language</B>. Each time you visit our site later you will not need to set your language, the system will keep your selected default language using a cookie on your computer.</P>
submit_button~==~<input type="submit" value="Set My Default Language">
reset_button~==~<input type="reset" value="Reset">
