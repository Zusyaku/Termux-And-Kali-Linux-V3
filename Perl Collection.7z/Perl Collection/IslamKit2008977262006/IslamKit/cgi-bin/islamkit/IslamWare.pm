=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Get_Random_Upload_Filename{
my($Dir, $File)=@_;
my($Tmp, @Name, $Ext, $T);
my ($x, @C, $R, $N);

	srand(time ^ $$);
	@C = ('a'..'k','0'..'4', 'm'..'q', 'r'..'z', '5'..'9');
	$R = "";
	for $x(0..14){
		$N = int(rand($#C + 1));
		$R .= $C[$N];
	}
	
	$File =~ s/^\s+//; 
	$File =~ s/\s+$//;
	$File =~ s/\s+/_/g;

	$Ext = "";
	@Name = split(/\./, $File);
	$Ext = pop @Name;
	$Name = join (".", @Name);
	$T = "";
   do {
			$Tmp  = "$Dir/$R$T\.$Ext";
			$T++;
   } until (!-e $Tmp);

   return $Tmp;
}
#==========================================================
sub Get_Random_File_Name{
my($Dir, $Ext) = @_;
my($Fname);

	do {
			$Fname = int (rand(999999999999)). "\.".$Ext;
			$Temp_File  = "$Dir/$Fname";
	} until (!-e $Temp_File);

	return $Fname;
}
#==========================================================
sub Go_Back{
my($GoType)=shift;
my($Out)="";

if ($GoType==0) {
      $Out=<<HTML;
              <CENTER>
			   <br><br>
			  <A HREF="javascript:history.go(-1)">Back to Previous Page</a>
			  </CENTER></font><br><br>
HTML
	 }
 else{
$Out=<<HTML;
		<center>
		<form>
				<input type=button value="<< Go Back " onClick="history.go(-1)">
		</form></center>
HTML
	}
return $Out;
}
#==========================================================
sub Msg{
my($Title, $Message, $Level)=@_;
my($Form);

	$Form = &Translate($Global{Message_Form});
	$Form =~ s/<!--Title-->/$Title/g;
	$Form =~ s/<!--Message-->/$Message/g;
	if (!$Level) {$Level = 1;}
	$Level *= -1;
	$Form =~ s/<!--Level-->/$Level/;
	return $Form;
}
#==========================================================
sub Error{
my($Message, $Title, $Level)=@_;
my($Form);

	if (!$Title) {$Title = "Critical Error";}
	if ($Level !~ /^\d+$/) {$Level = 1;}
	$Form = $Global{Error_Form};
	$Form =~ s/<!--Title-->/$Title/;
	$Form =~ s/<!--Message-->/$Message/;
	$Form =~ s/<!--Level-->/$Level/;
	return ($Form);
}
#==========================================================
sub Get_Form { 
my ($Buffer, @pair, $key, $value, $pair, $original_value);

	undef %Param;
    $Buffer = "";
	if ($ENV{CONTENT_LENGTH} ) {
				read(STDIN, $Buffer, $ENV{CONTENT_LENGTH});
				@pair=split(/&/, $Buffer);
				$Global{QUERY_STRING} = $Buffer;
    } 
	elsif ($ENV{QUERY_STRING}) {
		        @pair = split(/\\*\&/, $ENV{QUERY_STRING});
				$Global{QUERY_STRING} = $ENV{QUERY_STRING};
    }

    foreach $pair (@pair) {
			($key,$value)= split(/=/,$pair);
			$original_value=$value;
			$value =~ tr/+/ /;
			$value =~ s/%([A-Fa-f0-9]{2})/pack("C", hex($1))/ge;
			$value =~ s/\r$//g;
			$value =~ s/\n$//sg;  
			$key =~ s/\cM$//;

			$key =~ tr/\+/ /;
			$key =~ s/%([A-Fa-f0-9]{2})/pack("C", hex($1))/eg;
			$key =~ s/\r$//g;
			$key =~ s/\n$//g;
			$key =~ s/\cM$//;

			if(!$Param{$key}) {
					$Param{$key} = $value;
					$Paramx{$key}=$original_value;
			}
			else {
  					$Param{$key} = $Param{$key}."||".$value;
					$Paramx{$key}=$Paramx{$key}."||".$original_value;
			 }

	 }

}
#==========================================================
sub Get_Form_Multipart{
my ($Input, $Boundary, @List, $Key, $Value);
my ($Upload_File, $Upload_File_Name, @Upload_File);
my ($Upload_File_Content, $x, $Line);

	binmode(STDIN);
	binmode(STDOUT);
	binmode(STDERR);

	read(STDIN, $Input, $ENV{CONTENT_LENGTH});

	$Input =~ /^(.+)\r\n/;
    $Boundary = $1;
	@List = split(/$Boundary/, $Input); 

	#$Upload_File =~ /\r\n\r\n|\n\n/;         #separate header and body 
	#$Upload_File_Name = $`;                # front part
	#$Upload_File_Content = $';             # rear part
 	#$Upload_File_Content =~ s/\r\n$//;  # the last \r\n was put in by Netscape

	# Parse uploaded files
	#$Upload_File_Name =~ /filename=\"(.+)\"/; 
	#$Upload_File_Name = $1;  #print "[[Header= $Header ]](($Input))<br>";
	#$Upload_File_Name =~ s/\"//g; # remove "s
    #$Upload_File_Name =~ s/\s//g; # make sure no space(include \n, \r..) in the file name 
	#@File_Name = split(/[\/|\\]/, $Upload_File_Name); 
	#$Upload_File_Name = pop @File_Name;
	
	undef %Param;

	# Parse form parameters
	for $x (1..$#List) {
				$Line = $List[$x];
				$Line =~ s/^.+name=$//; 
				$Line =~ /\"(\w+)\"/; 
				$Key = $1; $Value =  $';
				$Original_Value=$Value;
				#$value =~ tr/+/ /;
				#$value =~ s/%([A-Fa-f0-9]{2})/pack("C", hex($1))/eg;

				#$key =~ tr/+/ /;
				#$key =~ s/%([A-Fa-f0-9]{2})/pack("C", hex($1))/eg;

				$Key=~ s/^(\r\n)+//g;
				$Key=~ s/(\r\n)+$//g;
				
				$Value=~ s/^(\r\n)+//g;
				$Value=~ s/(\r\n)+$//g;
				
				$Key=~ s/\cM//g;
				$Value=~ s/\cM//g;

				if(! exists $Param{$Key}) {
						$Param{$Key} = $Value;
						$Paramx{$Key} = $Original_Value;
				}
				else {
						$Param{$Key} = $Param{$Key}."||".$Value;
						$Paramx{$Key} =$ Paramx{$Key}."||".$Original_Value;
				 }
	}
	
}
#==========================================================
sub JS_Win{ 
my($URL, $Title)=@_;
my ($Out);
$Out=<<HTML;
	<SCRIPT LANGUAGE="javascript">
 	function PopUp(subjects) {
		var GoTo = "$Script_URL?action=Help&subject=" + subjects;
		link=open(GoTo, "$Title","toolbar=no, scrollbars=yes, directories=no,menubar=no,resizable=yes,width=400,height=500");
   }
	</SCRIPT>
HTML
	return $Out;
}
#==========================================================
sub Get_Script_URL{ 
my ($http);

	$Doc_Root = "";
	if ($ENV{DOCUMENT_ROOT}) {
	   $Doc_Root = $ENV{DOCUMENT_ROOT};
	}

	$http="http://";
	if ($ENV{HTTP_REFERER}) {
				if ($ENV{HTTP_REFERER} =~ m|^https://|i) {
					$http = "https://";
				}
	}

	$Domain = "";
	if ($ENV{HTTP_HOST}) {
			   $Domain = $http . $ENV{HTTP_HOST};
	}

	$Script_URL = "";
	if ($ENV{SCRIPT_NAME}) {
			   $Script_Name = $ENV{SCRIPT_NAME};
			   $Script_URL = $Domain . $Script_Name;
	  }
	
	return $Script_URL;
}
#==========================================================
sub Random_ID{
my ($x, @Codes, $Rand_ID, $Randum_Num);

	srand(time ^ $$);
	@Codes = ('a'..'k', 'm'..'n', 'p'..'z', '2'..'9');
	$Rand_ID = "";
	for ($x = 0; $x < 10; $x++) {
		$Randum_Num = int(rand($#Codes + 1));
		$Rand_ID .= $Codes[$Randum_Num];
	}
	return $Rand_ID;
}
#==========================================================
sub Generate_ID { 
my ($Pause, @Codes, $ID, $x);

   $Pause = time;
   @Codes = ("a".."n","p".."z",1..9);
   srand( time() ^ ($$ + ($$ << 15)) );
   $ID = "";
   for ($x=1; $x<=6;$x++){ 
        $ID .= "$Codes[rand(@Codes)]";
   }
   $ID .= "$Pause";
   return $ID;
}
#==========================================================
sub Get_Random_Password {
my($x, @C, $P);

   @C = ("a".."n",6..9,"p".."z",1..5);
   $P = "";
   for $x(1..8){ 
        $P .= $C[rand(@C)];
   }
   return(uc($P));
}
#==========================================================
sub DB_Exist{
my($DB_File_Name) = @_;
my(%data);

	if (-e $DB_File_Name) {return 1;}
	tie %data, "DB_File", $DB_File_Name or
								 &Exit("Cannot create database file $DB_File_Name: $!\n" . "<br>Line " . __LINE__ . ", File ". __FILE__);
	untie %data;
	return 0;
}
#==========================================================
sub Lock{
my ($File) = shift;
my(@Parts, $Time, $Start, $Spent, $Wait, $Lock_File);

	@Parts = split(/[\/|\\]/, $File);
	$File = pop @Parts;
	if (!$File) {return 0;}

	$Lock_File = $Global{Lock_Dir}. "/" . $File. "\.lck";
    $Start = 0;   $Spent = 0 ;   $Wait = 0;
    $Time = time;

	if (-e $Lock_File) {
			open(IN, $Lock_File);
			$Start = <IN>;
			close(IN);
        
			$Spent = $Time - $Start;
			if ($Spent <= 60) {
					while (-e "$Lock_File") {
							$Wait++;
							sleep 1;
							if ($Wait == 25) {return 0;}
					}
			 }
	}

    open (OUT, ">$Lock_File") or return 0;
    print OUT $Time;
    close (OUT);

    return (1);
}
#==========================================================
sub Unlock{
my ($File) =shift;
my(@Parts, $Lock_File);

	@Parts=split(/[\/|\\]/, $File);
	$File=pop @Parts;
	$Lock_File = $Global{Lock_Dir}. "/" . $File. "\.lck";
	return (unlink $Lock_File);
}
#==========================================================
sub Numeric { 

	$_ = shift;
    if ((/^\d+$/) || (/^\d+\.$/) || (/^\d+\.\d+$/) || (/^\.\d+$/)) {
			return 1;
    }
	return 0;
}
#==========================================================
sub Format_Digits{
my($N) = @_;
	1 while $N =~ s/^([-+]?\d+)(\d{3})/$1,$2/;
	return $N;
}
#==========================================================
sub Format_Decimal{
my($Value) = @_;
my($D, $F, $Z );

	if (!$Value) { return "0.00";}
	$Value =~ s/\s//g;
	($D, $F)=split(/\./, $Value);
	$Z = "0" x (2-length($F));
	$Value = $D.".". $F. $Z;
	return $Value;
}
#==========================================================
sub Check_Email_Address{
my ($E) = shift;
my ($D);

    if ($E =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/ ||  ($E !~ /^.+\@localhost$/ && $E !~ /^.+\@\[?(\w|[-.])+\.[a-zA-Z]{2,3}|[0-9]{1,3}\]?$/)) {
       return (0); #Invalid email address
    }

   if ($E =~ /^\.|^\@/ || $E =~/^www\./ || $E =~/\.\@|\@\.|\.\./ ) {
	   return (0);
   }

	if ($E=~tr/@// !=1){return (0);}
	$D = $E;
	$D =~s/^.*\@(.*)/$1/;
	if ($D =~/_|~|#/) {return (0);} #Email addresses cannot contain _, ~ or # after the @ sign.
	if ( !($E =~/\.[a-z]{2,}$/i)) {return (0);} #All email addresses end in a dot and some letters (such as .com, .net, .uk, .ac etc.).

	return (1); #Valid email address
}
#==========================================================
sub Check_URL{ 
my ($URL) = shift;

   if ($URL !~ /^mailto:.*\@\S+\./i && $URL !~ /^news:/i && $URL !~ /^(f|ht)tp:\/\/\S+\.\S+/i && $URL !~ /^https?:\/\/\S+\.\S+/i) { 
				return(0); #Invalid URL
	}
	return(1); 
}
#==========================================================
sub Get_Host{
my ($host, $ip_address, $ip_number, @numbers);

	if ($ENV{REMOTE_HOST}) {
				$host = $ENV{REMOTE_HOST};
	} 
	else{
				$ip_address = $ENV{REMOTE_ADDR};
				@numbers = split(/\./, $ip_address);
				$ip_number = pack("C4", @numbers);
				$host = (gethostbyaddr($ip_number, 2))[0];
	}

	if ($host eq "") {
				$host = "$ENV{REMOTE_ADDR}";
	}
	
	return $host;
}
#==========================================================
sub Check_Referers{ 
my (@Allowed_Domains) = @_;
my (@Referers, $Status, $Key);

    $Status =1;

    if ($ENV{HTTP_REFERER}) {
        foreach $Referer (@Allowed_Domains) {
            if ($ENV{HTTP_REFERER} =~ m|https?://([^/]*)$Referer|i) {
                $Status = 1; last;
            }
        }
    }
    else {
        $Status = 0;
    }
    return $Status;
}
#==========================================================
sub Create_Directory_Path{
my($Path, $Attr) = @_;
my (@Subs, $x, $Temp);

	@Subs = split (/[\\|\/]/, $Path);
	if (!$Attr) {$Attr = 0755;}

	for $x(0..$#Subs) {	
			$Temp = join("/", @Subs[0..$x]);
			if (!(-d $Temp)) {
					mkdir ($Temp, $Attr);
			}
	}
}
#==========================================================
sub Remove_HTML_Tags{ 
my ($S) = shift;
   $S =~ s/<[^>]+>//ig;
   return  $S ;
}
#==========================================================
sub Get_OS{ 
my($OS);

	$OS = $^O;
	if (($OS eq "MSWin32") || ($OS eq "Windows_NT") || ($OS =~ /win/i)) {
			$OS = "WIN"; 
	}
	else { 
		$OS = "UNIX"; 
	}
	return $OS;
}
#==========================================================
sub Encode_HTML{
my ($S) = shift;

	$S =~ s/\"/\&quot\;/g;
	$S =~ s/\'/\&\#39\;/g;
	$S =~ s/\</\&lt\;/g;
	$S =~ s/\>/\&gt\;/g;
	return $S;
}
#==========================================================
sub Decode_HTML{
my ($S) = shift;

	$S =~ s/\&quot\;/\"/ig;
	$S =~ s/\&\#39\;/\'/g;
	$S =~ s/\&lt\;/\</ig;
	$S =~ s/\&gt\;/\>/ig;
	return $S;
}
#==========================================================
sub Get_Random_ID{
my ($ID);

	srand ($$|time);
	$ID = int(rand(999999));
	$ID = unpack("H*", pack("Nnn", time, $$, $ID) );
	return $ID;
}
#==========================================================
sub Get_Referer { 
   return $ENV{HTTP_REFERER};
}
#==========================================================
sub HTML_Treat{
my ($T, $M) = @_;

	$T = &Web_Decode($T);

     if ($M eq "Show_Code") {
              $T =~ s/\</\&lt;/g;
			  $T =~ s/\>/\&gt;/g;
              $T =~ s/\&lt;CR\&gt;/<br>/g;
              $T =~ s/  /\&nbsp;\&nbsp;/g;
      }
     elsif ($M eq "Show_Safe_Code") {
			$T =~ s/<!--(.|\n)*-->//g;
			$T =~ s/\s-\w.+//g;
			$T =~ s/system\(.+//g;
			$T =~ s/grep//g;
			$T =~ s/\srm\s//g;
			$T =~ s/\srf\s//g;
			$T =~ s/\.\.([\/\:]|$)//g;
			$T =~ s/< *((SCRIPT)|(APPLET)|(EMBED))[^>]+>//ig;
	 }
     elsif ($M eq "Show_HTML") {
			$T =~ s/<!--(.|\n)*-->//g;
			$T =~ s/\s-\w.+//g;
			$T =~ s/system\(.+//g;
			$T =~ s/grep//g;
			$T =~ s/\srm\s//g;
			$T =~ s/\srf\s//g;
			$T =~ s/\.\.([\/\:]|$)//g;
			$T =~ s/< *((SCRIPT)|(APPLET)|(EMBED))[^>]+>//ig;
	 }
     elsif ($M eq "Remove_Code") {
			$T =~ s/<.+>?//g;
			$T =~ s/<!--(.|\n)*-->//g;
			$T =~ s/\s-\w.+//g;
			$T =~ s/system\(.+//g;
			$T =~ s/grep//g;
			$T =~ s/\srm\s//g;
			$T =~ s/\srf\s//g;
			$T =~ s/\.\.([\/\:]|$)//g;
			$T =~ s/< *((SCRIPT)|(APPLET)|(EMBED))[^>]+>//ig;
	 }
	 return $T;
}
#==========================================================
sub Web_Decode{  
my ($S)= shift;
	$S =~ s/%([A-Fa-f0-9]{2})/pack("C",hex($1))/eg;
	return $S;
}
#==========================================================
sub Web_Encode{  
my ($S) = shift;
   $S =~ s/([^a-zA-Z0-9_\-.])/uc sprintf("%%%02x",ord($1))/eg;
   return $S;
}
#==========================================================
sub Filter_Chars{
my ($T) = @_;
my ($A);

	$A = "a-zA-Z0-9" . $Global{allowed_characters};
	$_ = $T;
	eval "tr/$A/ /c"; #/cs
	return $_;
}
#==========================================================
sub Encrypt{
my ($T, $K) = @_;
my ($E);

	if (!$K) {$K = "IsLaMwArETiGeRhErE";}
	$E = &b2a(&rc4($K, $T));
	return $E;
}
#==========================================================
sub Decrypt{
my ($T, $K) = @_;
my ($D);

	if (!$K) {$K = "IsLaMwArETiGeRhErE";}
	$D = &rc4($K, &a2b($T));
	return $D;
}
#==========================================================
#What is RC4 ? 
#RC4 is fairly fast, secure and symmetric encryption algorithm. Devloped by Ron Rivest in 1987 was kept
#trade secret until 9th September 1994 when it was posted on a Cypherpunks mailing list. Generally the key 
#it uses is limited to 40 bits for various legal reasons but 128bits is the more common forms these days. 
#To prove it's strengh products like Oracle Secure SQL are examples. It's symmetric meaning it uses the 
#same key and steps as to encrypt when decrypting. 
#Well there's nothing much to explain in the article, except for guidelines: 
#The rc4 function is used for both encryption as well as decryption.
sub rc4 ($$){
my ($key,$buffer) = @_;

	my(@s,$x,$y,$i1,$i2,$i,$t);for($i=0;$i<256;$i++){$s[$i]=$i;}
	$i2=$i1=$y=$x=0;for($i=0;$i<256;$i++){$i2=(vec($key,$i1,8)+$s[$i]+$i2)%256;
	$t=$s[$i];$s[$i]=$s[$i2];$s[$i2]=$t;$i1=($i1+1)%length($key);}	
	for($i=0;$i<length($buffer);$i++){$x=($x+1)%256;$y=($s[$x]+$y)%256;
	$t=$s[$x];$s[$x]=$s[$y];$s[$y]=$t;$i1=($s[$x]+$s[$y])%256;
	vec($buffer,$i,8)^=$s[$i1];}

	return $buffer;
}
#==========================================================
sub b2a_e{
	if ($_[0] < 26) { return $_[0] + ord('A'); }
	if ($_[0] < 52) { return $_[0] - 26 + ord('a'); }
	if ($_[0] < 62) { return $_[0] - 52 + ord('0'); }
	if ($_[0] == 62) { return ord('+'); }
	if ($_[0] == 63) { return ord('*'); }

	return '!';
}
#==========================================================
sub a2b_d{

	return 63 if ($_[0] == ord('*') || $_[0] == ord('/'));
	return 62 if ($_[0] == ord('+'));
	return $_[0] + 26 - ord('a') if ($_[0] >= ord('a'));
	return $_[0] - ord('A') if ($_[0] >= ord('A'));
	return $_[0] + 52 - ord('0') if ($_[0] >= ord('0'));

	return 0;
}
#==========================================================
sub b2a ($){
my ($buffer) = @_;
my ($i,$j,$left);

	my $outbuf = "\000"x(int((length($buffer)*4+2)/3));

	for ($j=$i=0,$left=length($outbuf);$left > 0;$i+=4,$j+=3,$left-=4) {
		vec($outbuf,$i,8)   = &b2a_e(((vec($buffer,$j,8)>>2)&0x3f)) if ($left > 0);
		vec($outbuf,$i+1,8) = &b2a_e(((vec($buffer,$j,8)&0x03)<<4) + ((vec($buffer,$j+1,8)>>4)&0x0f)) if ($left > 1);
		vec($outbuf,$i+2,8) = &b2a_e(((vec($buffer,$j+1,8)&0x0F)<<2) + ((vec($buffer,$j+2,8)>>6)&3)) if ($left > 2);
		vec($outbuf,$i+3,8) = &b2a_e((vec($buffer,$j+2,8)&0x3F)) if ($left > 3);
	}

	return $outbuf;
}
#==========================================================
sub a2b {
my ($inbuf) = @_;
my ($i,$j,$left, $b0, $b1, $b2, $b3);

	my $buffer = "\000"x(int((length($inbuf)*3)/4));
	for ($j=$i=0,$left=length($inbuf);$left>0;$left-=4,$i+=4,$j+=3) {
		$b0 = &a2b_d(vec($inbuf,$i,8));
		$b1 = &a2b_d(vec($inbuf,$i+1,8));

		vec($buffer,$j,8)  = ($b0 << 2) | (($b1 >> 4) & 0x03);
		if ($left > 2) {
			$b2 = &a2b_d(vec($inbuf,$i+2,8));
			vec($buffer,$j+1,8) = (($b1 & 0x0F) << 4) | (($b2 >> 2) & 0x0F);
			if ($left > 3) {
				$b3 = &a2b_d(vec($inbuf,$i+3,8));
				vec($buffer,$j+2,8) = (($b2 & 0x03) << 6) | $b3;
			}
		}
	}

	return $buffer;
}
#==========================================================
sub Get_Cookies{ 
my ($N, $V);

	foreach (split(/; /,$ENV{HTTP_COOKIE})) {
		($N, $V) = split(/=/);
		$N =&Web_Decode($N);
		$V =&Web_Decode($V);
		$Cookies{$N} = $V;
    }
}
#==========================================================
sub Set_Cookies{
my ($N, $V, $Exp) = @_;
my ($Secure, $Expires);
	
	$N = &Web_Encode($N);
	$V = &Web_Encode($V);
	$Secure = "";
   
	if (!$Exp) { #Browser session
		$Expires = "";
	}
	elsif ($Exp == -1) { #delete it
  		$Expires = "expires=Wed, 09-nov-1970 00:00:00 GMT;";
	}
	else {
	  	  $Expires = "expires=Wed, 09-nov-2050 00:00:00 GMT;";
	}

	print "Set-Cookie: $N=$V;$Expires;path=/\n";
}
#==========================================================
sub Delete_Cookies{
my (@Cookies) = @_;
my ($N, $Exp);

	$Exp = "Wednesday, 01-Jan-80 00:00:00 GMT";
	foreach $N (@Cookies) {
		delete $Set_Cookies{$N} if ($Set_Cookies{$N});
		print "Set-Cookie: $N=deleted; expires=$Exp;path=/\n";
	}
}
#==========================================================
sub SetCookieTime{
my ($N, $V, $Time) = @_;
my ($Expires);

	$Expires = &Format_Cookie_Date($Time);
	print "Set-Cookie: $N=$V;$Expires;path=/\n";
}
#==========================================================
sub Format_Cookie_Date{
my ($Time) = @_;
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst ) = localtime($Time);
my (@months) = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
my (@weekday) = ("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat");

	$sec = sprintf("%02d", $sec);
	$min = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);
	$mon = sprintf("%02d", $mon);
	$mday = sprintf("%02d", $mday);

	$year = $year + 1900;
	return qq!$weekday[$wday], $mday-$months[$mon]-$year $hour\:$min\:$sec GMT!;
}
#==========================================================
sub Local_Time{
my ($Time) = shift;
my ($Local_Time);

	if (!$Time) {$Time = time;}
	if(defined $Global{GMT_Offset}) {
			$Local_Time = $Time + (3600 * $Global{GMT_Offset}); 
	}
	
	#  daylight saving 
	if ((localtime(time))[8]) {$Local_Time += 3600;} 

	return $Local_Time;
}
#==========================================================
sub Time{
my ($Time) = @_;

	if (! int($Time)) {$Time = time;}
	$Global{GMT_Offset} ||= 0;
	$Time = int($Time + (3600 * $Global{GMT_Offset})); 

	#  daylight saving 
	if ((localtime(time))[8]) {$Time += 3600;} 

	return $Time;
}
#==========================================================
sub TimeAdjust{
my ($Time) = @_;

	if (! int($Time)) {$Time = time;}
	#  daylight saving 
	if ((localtime(time))[8]) {$Time += 3600;} 
	return $Time;
}
#==========================================================
sub TimeNow{
	return Time(time);
}
#==========================================================
sub Time_Diff{ 
my ($Start_Time, $End_Time)=@_;
my ($days, $hours, $minutes, $Out);

	($days, $hours, $minutes)=&Time_Left($Start_Time, $End_Time);
	$Out=&Format_Time_Left ($days, $hours, $minutes);
	return $Out;

}
#==========================================================
sub Time_Left{
my ($Starts, $Ends)=@_;
my ($Ticks, $secs, $hours, $days, $minutes);

	$Ticks=abs($Ends - $Starts);
	$sec=int($Ticks % 60);
	$Ticks=int($Ticks / 60); # $Ticks in minutes
	$minutes=$Ticks % 60;
	$Ticks=int($Ticks / 60); #$Ticks in hours
	$hours= $Ticks % 24; 
	$days=int($Ticks  /  24);
	return ($days, $hours, $minutes);
}
#==========================================================
sub Format_Time_Left{
my ($days, $hours, $minutes)=@_;
my ($D, $H, $M, $Out);

	$Out = "";
	if ($days > 0) {
			if ($days>1) {
				$D = "$days $Language{days}";
			}
			else{
				$D = "$days $Language{day}";
			}
	}

	if ($hours > 0) {
			if ($hours>1) {
					$H = "$hours $Language{hours}";
			}
			else{
					$H = "$hours $Language{hour}";
			}
	}

	if ($minutes > 0) {
			if ($minutes> 1) {
				$M = "$minutes $Language{minutes}";
			}
			else{
				$M = "$minutes $Language{minute}";
			}
	}

	if ($days > 0) {
		$Out = $D;
		if ($hours) {$Out .= $Language{plus_time};}
	}
	elsif ($hours > 0){
		$Out = $H;
		if ($minutes) {$Out .= $Language{plus_time};	}
	}
	else{
		$Out = $M;
	}
	return $Out;
}
#==========================================================
sub Format_Date{
my ($Format,  $Time) = @_;
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst);
my (@Days, @Months, $Time_now, $AP, $hr, $mn, $Now);

	$Time = &Time(time) if (! int($Time));

	@Days = ('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
	@Months = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

	($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst ) = gmtime($Time);
	$year += 1900;
	$mon++;

	$hr = $hour; $mn = $min;
	$AP = ($hour >= 12) ? $Language{PM} : $Language{AM};
	if ($hour > 12) { $hour -= 12; } elsif ($hour == 0) { $hour = 12;}

	$hr = sprintf("%02d", $hr);
	$mn = sprintf("%02d", $mn);

	$sec = sprintf("%02d", $sec);
	$min = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);
	$mon = sprintf("%02d", $mon);
	$mday = sprintf("%02d", $mday);

	$wday = $Language{$Days[$wday]};
	$month = $Language{$Months[$mon-1]};

	$Time_now = "$hour\:$min $AP";
	$Now = "$hr\:$mn";
	
	if ($Format == 0) {return "$mon/$mday/$year";}
	elsif ($Format == 1) {return "$mday/$mon/$year";}
	elsif ($Format == 2) {return "$year/$mon/$mday";}
	elsif ($Format == 3) {return "$year/$mday/$mon";}
	elsif ($Format == 4) {return "$mon/$mday/$year $Time_now";}
	elsif ($Format == 5) {return "$mday/$mon/$year $Time_now";}
	elsif ($Format == 6) {return "$year/$mon/$mday $Time_now";}
	elsif ($Format == 7) {return "$year/$mday/$mon $Time_now";}
	elsif ($Format == 8) {return "$month $mday, $year";}
	elsif ($Format == 9) {return "$wday, $month $mday, $year";}
	elsif ($Format == 10) {return "$wday $mday, $month $year $Time_now";}
	elsif ($Format == 11) {return "$wday, $month $mday, $year $Time_now";}
	elsif ($Format == 12) {return "$month $mday, $year $Time_now";}
	elsif ($Format == 13) {return "$month $mday, $year $hour\:$min\:$sec $AP";}
	elsif ($Format == 14) {return "$month\-$mday\-$year $hour\:$min\:$sec $AP";}
	elsif ($Format == 15) {return "$wday, $mday $month $year";}
	elsif ($Format == 16) {return "$wday, $mday $month, $year $Time_now";}
	elsif ($Format == 17) {return "$wday, $mday $month, $year - $Time_now";}
	elsif ($Format == 18) {return "$mon/$mday/$year $Now";}
	elsif ($Format == 18) {return "$mday/$mon/$year $Now";}
	elsif ($Format == 20) {return "$year/$mon/$mday $Now";}
	elsif ($Format == 21) {return "$year/$mday/$mon $Now";}
	elsif ($Format == 22) {return "$wday $mday, $month $year $Now";}
	elsif ($Format == 23) {return "$wday, $month $mday, $year $Now";}
	elsif ($Format == 24) {return "$month $mday, $year $hr\:$mn\:$sec";}
	elsif ($Format == 25) {return "$month\-$mday\-$year $hr\:$mn\:$sec";}
	elsif ($Format == 26) {return "$wday, $mday $month, $year $Now";}
	elsif ($Format == 27) {return "$wday, $mday $month, $year - $Now";}
	else{
			return "$mday/$mon/$year";
	}
}
#==========================================================
sub Format_Date1{
my($Format,  $Time) = @_;
my($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst );
my(@Days, @Months, $Time_now, $AP, $hr, $mn, $Now);

   $Time = &Time(time) if (! int($Time));

	@Days = ('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
	@Months = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

	($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $dst ) = gmtime($Time);
	$year += 1900;
	$mon++;

	$hr = $hour; $mn = $min;
	$AP = ($hour >= 12) ? 'PM' : 'AM';
	if ($hour > 12) { $hour -= 12; } elsif ($hour == 0) { $hour = 12;}

	$hr = sprintf("%02d", $hr);
	$mn = sprintf("%02d", $mn);

	$sec = sprintf("%02d", $sec);
	$min = sprintf("%02d", $min);
	$hour = sprintf("%02d", $hour);
	$mon = sprintf("%02d", $mon);
	$mday = sprintf("%02d", $mday);
	$wday = $Days[$wday];
	$month = $Months[$mon-1];

	$Time_now = "$hour\:$min $AP";
	$Now = "$hr\:$mn";
	
	if ($Format == 0) {return "$mon/$mday/$year";}
	elsif ($Format == 1) {return "$mday/$mon/$year";}
	elsif ($Format == 2) {return "$year/$mon/$mday";}
	elsif ($Format == 3) {return "$year/$mday/$mon";}
	elsif ($Format == 4) {return "$mon/$mday/$year $Time_now";}
	elsif ($Format == 5) {return "$mday/$mon/$year $Time_now";}
	elsif ($Format == 6) {return "$year/$mon/$mday $Time_now";}
	elsif ($Format == 7) {return "$year/$mday/$mon $Time_now";}
	elsif ($Format == 8) {return "$month $mday, $year";}
	elsif ($Format == 9) {return "$wday, $month $mday, $year";}
	elsif ($Format == 10) {return "$wday $mday, $month $year $Time_now";}
	elsif ($Format == 11) {return "$wday, $month $mday, $year $Time_now";}
	elsif ($Format == 12) {return "$month $mday, $year $Time_now";}
	elsif ($Format == 13) {return "$month $mday, $year $hour\:$min\:$sec $AP";}
	elsif ($Format == 14) {return "$month\-$mday\-$year $hour\:$min\:$sec $AP";}
	elsif ($Format == 15) {return "$wday, $mday $month $year";}
	elsif ($Format == 16) {return "$wday, $mday $month, $year $Time_now";}
	elsif ($Format == 17) {return "$wday, $mday $month, $year - $Time_now";}
	elsif ($Format == 18) {return "$mon/$mday/$year $Now";}
	elsif ($Format == 18) {return "$mday/$mon/$year $Now";}
	elsif ($Format == 20) {return "$year/$mon/$mday $Now";}
	elsif ($Format == 21) {return "$year/$mday/$mon $Now";}
	elsif ($Format == 22) {return "$wday $mday, $month $year $Now";}
	elsif ($Format == 23) {return "$wday, $month $mday, $year $Now";}
	elsif ($Format == 24) {return "$month $mday, $year $hr\:$mn\:$sec";}
	elsif ($Format == 25) {return "$month\-$mday\-$year $hr\:$mn\:$sec";}
	elsif ($Format == 26) {return "$wday, $mday $month, $year $Now";}
	elsif ($Format == 27) {return "$wday, $mday $month, $year - $Now";}
	else{
			return "$mday/$mon/$year";
	}
}
#==========================================================
sub Web_Server{ 
my ($Domain, $URL, $Form_Param, $M, $Referer) = @_;
my ($Target_URL, $Request, $Response, $UA, $Result);
		
	#For SSL Connections, Module Crypt::SSLeay must be installed, Crypt-SSLeay-x.xx

	$Target_URL = $Domain . $URL;
	$Form_Param=~ s/ /%20/g;

	$Result = "";
	$UA = new LWP::UserAgent;
	$UA->agent('IsalmWare /5.0');
	#$UA->timeout(120);
	
	$M ||= "GET";

	if ($M eq 'GET') {
			$Request = new HTTP::Request  GET=> "$Target_URL?$Form_Param";
			$Request->referrer($Referer) if $Referer;
	} else { 
			$Request = new HTTP::Request (POST => "$Target_URL");
			$Request->content_type('application/x-www-form-urlencoded');
			$Request->content($Form_Param);
			$Request->referrer($Referer) if $Referer;
	}

	$Response = $UA->request($Request);

	if ($Response->is_success) {
		  $Result = $Response->content();
	}

	return $Result; 
}
#==========================================================
sub Hex_Color{
my(@rgb) = @_;
	 return sprintf('#%02x%02x%02x',@rgb);
}
#==========================================================
sub Program_Name{
my ($Prog_Name);
	$0 = $^X unless ($^X =~ m%(^|[/\\])(perl)|(perl.exe)$%i);
	$0 =~  m%^(.*)[/\\](.*)%;
	$Prog_Name =$2;
	$Prog_Name ||= undef;
	return $Prog_Name;
}
#==========================================================
sub Program_Directory{
	$0 = $^X unless ($^X =~ m%(^|[/\\])(perl)|(perl.exe)$%i);
	my ($Prog_Directory) = $0 =~ m%^(.*)[/\\]%;
	$Prog_Directory ||= ".";
	return $Prog_Directory;
}
#==========================================================
sub Get_Temp_Directory{
my ($tmp);

	$tmp = $ENV{'TEMP'} || $ENV{'tmp'};
	if ($^O =~ /MSWin/) {
		$tmp ||= 'c:/temp';
	}
	else {
		$tmp ||= '/tmp';
	}
	return $tmp;
}
#==========================================================
sub ModLoad{
my (@Modules) = @_;
my ($Module, $Erro, $Out, $Name, $Arg);

	$Error = "";	
	foreach $Module (sort @Modules) {
			eval "use $Module;";
			if ($@) {
					($Name, $Arg) = split (/\s+/, $Module);
					$Name ||= $Module;
					$Error .= "$Name<br>";
			}
	}

	if ($Error) {
$Out=<<HTML;
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
<div align="center">
  <center>
  <table border="1" cellspacing="0" width="550" bordercolor="#800000" cellpadding="0">
    <tr>
      <td width="100%">
      <table border="0" cellspacing="0" width="100%" cellpadding="2">
        <tr>
          <td width="100%" bgcolor="#CC0000" align="center">
          <font color="#FFDE9B" face="Tahoma" size="4"><b>Server Error</b></font></td>
        </tr>
        <tr><td width="100%" bgcolor="#FFCAA6">The following required Perl modules are not installed on this server:<br><br></td></tr>
        <tr><td width="100%" bgcolor="#FFCAA6">$Error</td></tr>
        <tr><td width="100%" bgcolor="#FFCAA6"><br>Please contact your server administrator or hosting company to install these modules.<br><br>Perl modules can be downloaded from <a href="http://www.cpan.org" target="_blank">www.cpan.org</a> or installed using the programs ppm or cpan that comes with perl in the same bin directory. To install perl module, run the program ppm or cpan or perl -MCPAN -e shell, then type install module_name. Root access required for this action.<br><br></td></tr>
      </table>
      </td>
    </tr>
  </table>
  </center>
</div>
HTML
			print "Content-type: text/html\n\n";
			print "$Out";
			&Quit;
	}
}
#==========================================================
sub p{
my (@List) = @_;
	$Debug_Header ||= 0;
	if (!$Debug_Header) {
			$Debug_Header = 1;
			print "Content-type: text/html\n\n";
			print "<br>";
	}
	
	print join ("<br>", @List);
	print "<br>";
	
 }
#==========================================================
@ArabicDigits = ('&#1632;', '&#1633;','&#1634;','&#1635;','&#1636;','&#1637;','&#1638;','&#1639;','&#1640;','&#1641;');
sub ConvertToArabicDigits {
my ($Text) = @_;
	
	@Digits = split ("", $Text);
	$Text = "";

	foreach $Digit (@Digits) {
		$Text .= $ArabicDigits[$Digit];
	}
	return $Text;
}
#==========================================================
1;