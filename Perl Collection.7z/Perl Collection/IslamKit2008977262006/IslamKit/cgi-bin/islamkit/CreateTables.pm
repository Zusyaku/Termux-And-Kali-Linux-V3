=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Create_SQL_Tables{
my ($Help, $Out);

	$Help = &Help_Link("Setup_Wizard");
	$Out = qq!<p align="center"><font size="3" color="red"><b>Creating System SQL Tables</b></font></p>!;
	$Out .= &Create_Tables;
	&Print_Page($Out, "Setup Wizard", $Help);	
}
#==========================================================
sub Create_Tables{
my ($Out);

	$Out = "";
	
	$Out .= &Create_QuranNames_Table;
	$Out .= &Create_Reciters_Table;

	$Out .= &Create_AyahAudio_Table;
	$Out .= &Create_SurahAudio_Table;

	$Out .= &Create_Quran1_Table;
	$Out .= &Create_Quran2_Table;
	$Out .= &Create_Quran3_Table;
	$Out .= &Create_Quran4_Table;
	
	$Out .= &Create_QuranConfig_Table;
	$Out .= &Create_SurahName_Table;
	$Out .= &Create_Config_Table;
	$Out .= &Create_Whos_Online_Table;
	$Out .= &Create_Announcements_Table;

	return $Out;
}
#==========================================================
sub Create_QuranNames_Table {
my ($Table, $Out);

	$Table = qq!CREATE TABLE QuranName (
							Name VARCHAR(250),
							Language VARCHAR(250),
							LangName VARCHAR(250)
					)!;

	return &CreateTable("Quran Name", $Table);
}
#==========================================================
sub Create_Quran1_Table {
my ($Table, $Out);

	$Table = qq!CREATE TABLE Quran1 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out = &CreateTable("Quran1", $Table);

	$Table = qq!CREATE TABLE Search1 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out .= &CreateTable("Quran Search", $Table);
	return $Out;
}
#==========================================================
sub Create_Quran2_Table {
my ($Table, $Out);

	$Table = qq!CREATE TABLE Quran2 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out = &CreateTable("Translation", $Table);
	
	$Table = qq!CREATE TABLE Search2 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;
	$Out .= &CreateTable("Translation Search", $Table);
	return $Out;
}
#==========================================================
sub Create_Quran3_Table {
my ($Table, $Out);

	$Table = qq!CREATE TABLE Quran3 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out = &CreateTable("Transliteration", $Table);
	$Table = qq!CREATE TABLE Search3 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out .= &CreateTable("Transliteration Search", $Table);
	return $Out;
}
#==========================================================
sub Create_Quran4_Table {
my ($Table, $Out);

	$Table = qq!CREATE TABLE Quran4 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out = &CreateTable("Interpertation", $Table);

	$Table = qq!CREATE TABLE Search4 (
							Name VARCHAR(250),
							Surah INT,
							Ayah INT,
							Quran TEXT
					)!;

	$Out .= &CreateTable("Interpertation Search", $Table);
	return $Out;
}
#==========================================================
sub Create_QuranConfig_Table {
my ($Table);

	$Table = qq!CREATE TABLE QuranConfig (
							Name VARCHAR(250),	# Quran name
							Type INT DEFAULT 0,
							Active INT DEFAULT 1,
							Direction INT DEFAULT 0,
							Sort INT DEFAULT 0,
							Versions INT DEFAULT 0,
							ArabicDigits INT DEFAULT 0,
							AyahForm TEXT,
							Find1 VARCHAR(250),
							Find2 VARCHAR(250),
							Find3 VARCHAR(250),
							Find4 VARCHAR(250),
							Find5 VARCHAR(250),
							Find6 VARCHAR(250),
							Find7 VARCHAR(250),
							Find8 VARCHAR(250),
							Find9 VARCHAR(250),
							Find10 VARCHAR(250),
							Find11 VARCHAR(250),
							Find12 VARCHAR(250),
							Find13 VARCHAR(250),
							Find14 VARCHAR(250),
							Find15 VARCHAR(250),
							Find16 VARCHAR(250),
							Find17 VARCHAR(250),
							Find18 VARCHAR(250),
							Find19 VARCHAR(250),
							Find20 VARCHAR(250),
							Replace1 VARCHAR(250),
							Replace2 VARCHAR(250),
							Replace3 VARCHAR(250),
							Replace4 VARCHAR(250),
							Replace5 VARCHAR(250),
							Replace6 VARCHAR(250),
							Replace7 VARCHAR(250),
							Replace8 VARCHAR(250),
							Replace9 VARCHAR(250),
							Replace10 VARCHAR(250),
							Replace11 VARCHAR(250),
							Replace12 VARCHAR(250),
							Replace13 VARCHAR(250),
							Replace14 VARCHAR(250),
							Replace15 VARCHAR(250),
							Replace16 VARCHAR(250),
							Replace17 VARCHAR(250),
							Replace18 VARCHAR(250),
							Replace19 VARCHAR(250),
							Replace20 VARCHAR(250)
					)!;

	return &CreateTable("QuranConfig", $Table);
}
#==========================================================
sub Create_SurahName_Table {
my ($Table);

	$Table = qq!CREATE TABLE SurahName (
							Name VARCHAR(250),	# Quran name
							Surah VARCHAR(250),		# Surah number
							SurahName VARCHAR(250)		# Surah name
					)!;

	return &CreateTable("Surah names", $Table);
}
#==========================================================
sub Create_Reciters_Table {
my ($Table, $Out);

	$Table = qq!CREATE TABLE Reciters (
							ID INT,
							Folder VARCHAR(250),
							Reciter VARCHAR(250),
							Type INT
					)!;

	$Out = &CreateTable("Reciters", $Table);

	$Table = qq!CREATE TABLE ReciterName (
							ID INT,
							Language VARCHAR(250),
							Name VARCHAR(250)
					)!;

	$Out .= &CreateTable("Reciter Name", $Table);
	return $Out;
}
#==========================================================
sub Create_AyahAudio_Table {
my ($Table);

	$Table = qq!CREATE TABLE AyahAudio (
							Directory VARCHAR(250),
							Lang VARCHAR(250),
							Name VARCHAR(250)
					)!;

	return &CreateTable("Ayah Audio", $Table);
}
#==========================================================
sub Create_SurahAudio_Table {
my ($Table);

	$Table = qq!CREATE TABLE SurahAudio (
							Directory VARCHAR(250),
							Lang VARCHAR(250),
							Name VARCHAR(250)
					)!;

	return &CreateTable("Surah Audio", $Table);
}
#==========================================================
sub Create_Announcements_Table{
my ($Table);

$Table = qq!CREATE TABLE IslamAnnouncements (
							ID INT,
							Status VARCHAR(1),
							Date VARCHAR(10),
							Lang VARCHAR(100),
							URL VARCHAR(200),
							Email VARCHAR(200),
							Name VARCHAR(200),
							Subject VARCHAR(240),
							Message TEXT
				)!;

	return &CreateTable("Announcements", $Table);
}
#==========================================================
sub Create_Whos_Online_Table{
my($Table, $Out);

$Table = qq!CREATE TABLE Whos_Online (
							IP CHAR(30),
							User_ID CHAR(50), 
							Time INT
				)!;
   if ($dbh->do($Table)) {
			$Out .= " Who's Online Table Successfully Created.<BR>\n";
	}
   else {
			$Out .= " Error Creating Who's Online Table: $DBI::errstr.<BR>\n";
   }

	return $Out;
}
#==========================================================
sub CreateTable{
my ($Name, $Code) = @_;

   if ($dbh->do($Code)) {
			return (" $Name Table Successfully Created.<br>\n");
	}
   else {
			return (" Error Creating $Name Table: $DBI::errstr.<br>\n");
   }
}
#==========================================================
sub Create_Config_Table{
my ($Table);

	$Table = qq!CREATE TABLE IslamConfig (
							Name VARCHAR(250),
							Value VARCHAR(250)
						)!;

	return &CreateTable("Config", $Table);
}
#==========================================================
1;
