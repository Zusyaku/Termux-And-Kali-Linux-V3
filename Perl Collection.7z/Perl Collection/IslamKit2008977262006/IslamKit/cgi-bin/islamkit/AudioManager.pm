=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub AudioManager {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Audio_Manager");
	&Print_Page(&AudioManagerForm($Msg), "Audio Manager",  $Help);
}
#==========================================================
sub AudioManagerForm {
my ($Msg) = @_;
my ($Out, $Bar);
	
	$Bar = &AudioManagerNavBar;
	@Reciters = &GetRecitersID();
	$List = ""; $Counter = "";
	
	foreach $ID (@Reciters) {
			%Reciter = &GetReciter($ID);
			if ($Reciter{Type} == 1) {$TypeName = "Surah";} else {$TypeName ="Ayah"}		
			$Delete = qq!<a href="$Script_URL?action=ConfirmDeleteReciter&ID=$ID">Delete</a>!;
			$Edit = qq!<a href="$Script_URL?action=EditReciter&ID=$ID">Edit</a>!;
			$Upload = qq!<a href="$Script_URL?action=UploadReciter&ID=$ID">Upload</a>!;
			$Browse = qq!<a href="$Script_URL?action=BrowseReciter&ID=$ID">Browse</a>!;
			
			$Counter++;

			$Line = qq|<tr>
				<td width="50" nowrap>&nbsp;<b>$Counter</b></td>
				<td width="150" nowrap>&nbsp;<b>$Reciter{Folder}</b></td>
				<td width="150" nowrap>&nbsp;<b>$Reciter{Reciter}</b></td>
				<td width="100" nowrap align="center">&nbsp;$TypeName</td>
				<td width="75%">&nbsp; $Upload &nbsp; $Delete &nbsp; $Browse</td></tr>|;
			$List .= $Line;
	}

$Out=<<HTML;
$Bar
<br><a href="$Script_URL?action=AudioManager">Audio Manager</a> >>
<br><br>
$Msg

<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bordercolor="#A7A783" width="100%">
  <tr>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;#&nbsp;</b></td>
	<td width="150" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Folder&nbsp;</b></td>
	<td width="100" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Reciter&nbsp;</b></td>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Type&nbsp;</b></td>
	<td width="75%" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Action&nbsp;</b></td>
  </tr>
	$List

</table>
<br><br>
HTML
	return $Out;
}
#==========================================================
sub AudioManagerNavBar {
my ($Out);

$Out=<<HTML;
<table border="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" rowspan="2" bgcolor="#F3F3ED">
	&nbsp;<a href="$Script_URL?action=AddReciter"><b>Add Reciter</b></a>
	&nbsp;&nbsp;<a href="$Script_URL?action=TranslateReciters"><b>Names</b></a>
	</td>
  </tr>
</table>
HTML
	return $Out;
}
#==========================================================
sub AddReciter {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Audio_Manager");
	&Print_Page(&AddReciterForm($Msg), "Audio Manager",  $Help);
}
#==========================================================
sub AddReciterForm {
my ($Msg) = @_;
my ($Out, $Bar);
	
	$Param{Folder} ||= "";
	$Param{Reciter} ||= "";

$Out=<<HTML;	
<br><a href="$Script_URL?action=AudioManager">Audio Manager</a> >>Add Reciter
<br><br>
$Msg

<form method="post" action="$Script_URL">
<input type="hidden" name="action" value="AddNewReciter">

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Add New Reciter</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">

<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
    <tr>
	<tr><td colspan="2">
		Create new Reciter folder.
	</td></tr>

    <tr><td nowrap valign="top"><b>Folder Name: </b></td>
		<td width="100%"><input type="text" name="Folder" size="40" value="$Param{Folder}"><br>Enter folder name for this reciter (unique per type).</td>
	</tr>

    <tr><td nowrap valign="top"><b>Reciter Name: </b></td>
		<td width="100%"><input type="text" name="Reciter" size="40" value="$Param{Reciter}"><br>Enter name for this reciter.</td>
	</tr>

  <tr>
    <td nowrap valign="top"><b>Type:</b></td>
    <td width="100%">
			<select name="Type" size="1">
					<option value="" selected></option>
					<option value="1">Full Surah</option>
					<option value="2">Single Ayah</option>
			</select>
			<br>Select the contents of each audio file, either full Surah or single Ayah.
	</td>
  </tr>

	<tr>
      <td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Create" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>

  </table>
	</td>
</tr>
</table>
<br>
</form>

HTML
	return $Out;
}
#==========================================================
sub AddNewReciter {
	
	$Param{Folder} ||= "";
	$Param{Reciter} ||= "";
	$Param{Folder} =~ s/^\s+//;
	$Param{Folder} =~ s/\s+$//;
	$Param{Reciter} =~ s/^\s+//;
	$Param{Reciter} =~ s/\s+$//;

	if ($Param{Folder} eq "") {
			&AddReciter(qq!<font color="red"><b>Error: No Folder name entered.!);
			return;
	}

	if ($Param{Reciter} eq "") {
			&AddReciter(qq!<font color="red"><b>Error: No Reciter name entered.!);
			return;
	}
	
	#$Global{AyahAudio_Dir} = "$Global{HTML_Dir}/audio/ayah";
	#$Global{SurahAudio_Dir} = "$Global{HTML_Dir}/audio/surah";

	if (!$Param{Type}) {
			&AddReciter(qq!<font color="red"><b>Error: No Type selected.!);
			return;
	}

	%Reciter = &GetReciterByFolder($Param{Folder}, $Param{Type});
	if (%Reciter) {
			&AddReciter(qq!<font color="red"><b>Error: Folder already used for another reciter.!);
			return;
	}

	%Reciter = &GetReciterByName($Param{Reciter}, $Param{Type});
	if (%Reciter) {
			&AddReciter(qq!<font color="red"><b>Error: Reciter name already used for another reciter.!);
			return;
	}

	if ($Param{Type} == 1) { #Surah
		$Folder = "$Global{SurahAudio_Dir}/$Param{Folder}";
	}
	elsif ($Param{Type} == 2) { #Ayah
		$Folder = "$Global{AyahAudio_Dir}/$Param{Folder}";
	}

	mkdir ($Folder, 0755);
	chmod (0755, $Folder);
	#------------------------------------------------------------------
	$ID = 1;
	$Query = qq!SELECT ID FROM Reciters WHERE ID=?!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	while (1) {
			$sth->execute($ID) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
		    if (($Row) = $sth->fetchrow_array) {$ID++; }
			else{last;}
	}

	$Folder = $dbh->quote($Param{Folder});
	$Reciter = $dbh->quote($Param{Reciter});
	$Query = qq!INSERT INTO Reciters VALUES ($ID, $Folder, $Reciter, $Param{Type})!;
	$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	#------------------------------------------------------------------
	@Langs = &LanguagesList();
	foreach $Lang (@Langs) {
			$Lang = $dbh->quote($Lang);
			$Query = qq!INSERT INTO ReciterName VALUES ($ID, $Lang, $Reciter)!;
			$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	}
	
	&AudioManager(qq!<p align="center"><font color="red"><b>New Reciter Added Successfully.</p>!);
}
#==========================================================
sub TranslateReciters {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Audio_Manager");
	&Print_Page(&TranslateRecitersForm($Msg), "Audio Manager",  $Help);
}
#==========================================================
sub TranslateRecitersForm {
my ($Msg) = @_;
my ($Out, $Bar);
	
	$Param{TranslateLang} ||= $Global{Language};
	
	@Reciters = &GetRecitersID();

	$Counter = 0; $List = "";

	foreach $ID (@Reciters) {
		%Reciter = &GetReciter($ID);
		$Name = &GetReciterLangName($ID, $Param{TranslateLang});
		$Counter++;
		
		if ($Reciter{Type} == 1) {$TypeName = "Surah";} else {$TypeName ="Ayah"}		
		$Line = qq|<tr>
			<td width="50" nowrap>&nbsp;<b>$Counter</b></td>
			<td width="150" nowrap>&nbsp;<b>$Reciter{Folder}</b></td>
			<td width="150" nowrap>&nbsp;<b>$Reciter{Reciter}</b></td>
			<td width="100" nowrap align="center">&nbsp;$TypeName</td>
			<td width="75%">&nbsp;<input type="text" name="Reciter_$ID" id="Reciter_$ID" value="$Name" size="40" onChange="ConvertFieldToUnicode(\'Reciter_$ID\')"></td></tr>|;
		$List .= $Line;
	}

	@Langs = &LanguagesList();
	$LangMenu = "";
	foreach $Lang (@Langs) {
			if ($Lang eq $Param{TranslateLang}) {$Sel = "selected";} else {$Sel = "";}
			$LangMenu .= qq!<option value="$Lang" $Sel>$Lang</option>!;
	}

$Out=<<HTML;	
<a href="$Script_URL?action=AudioManager">Audio Manager</a> >>Translate Reciters
<br><br>
$Msg

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Translate Reciters Names</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">

<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>

<form name="LangForm" id="LangForm" method="post" action="$Script_URL">
<input type="hidden" name="action" value="TranslateRecitersLanguageChange">
  <tr>
    <td nowrap valign="top"><b>Language:</b></td>
    <td width="100%">
			<select name="NewLang" size="1" onChange="submit();">$LangMenu</select>
	</td>
  </tr>
</form>

<form name="TranslateForm" id="TranslateForm" method="post" action="$Script_URL">
<input type="hidden" name="action" value="SaveTranslateReciters">
<input type="hidden" name="TranslateLang" value="$Param{TranslateLang}">

<tr><td colspan="2">
	Please note, any text you enter will be converted to unicode in the form &#xxxx; to be able to display any language.
<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bordercolor="#A7A783" width="100%">
  <tr>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;#&nbsp;</b></td>
	<td width="150" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Folder&nbsp;</b></td>
	<td width="100" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Reciter&nbsp;</b></td>
	<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Type&nbsp;</b></td>
	<td width="75%" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Name&nbsp;</b></td>
  </tr>
	$List
</table>
	</td>
  </tr>

	<tr><td colspan="2">
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Save Changes" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>
</form>

  </table>
	</td>
</tr>
</table>
<br>

<!-------------------------------------------------->
<script language="javascript">

function ConvertFieldToUnicode(FieldID){
	var Obj = GetElementById(FieldID);
	var text = Obj.value;
	//alert(text);
	text = ConvertToUnicode(text);
	Obj.value = text;
}

function ConvertToUnicode(ConvStr){
	var strlen = ConvStr.length;
	var newstr = '';
	var chCode;
	for(var i=0; i<strlen; i++){
		//$line =~ s/([^\x00-\x7f])/sprintf("&#%d;", ord($1))/ge;
		//newstr = newstr + "&#" + strcharConv.charCodeAt(i) + ";"
		//The charCodeAt() method returns the Unicode of the character at a specified position.
		chCode = ConvStr.charCodeAt(i);
		if (chCode > 0x7f) {
				newstr += "&#" + chCode + ";"
		}
		else {
				newstr += String.fromCharCode(chCode)+ '';
		}
		
	}
	return newstr;
}

/* Cross browser related methods */
function GetElementById(id) {
	if (document.all) {
		return document.all(id);
	} else
		if (document.getElementById) {
			return document.getElementById(id);
		}
}

</script>
<!-------------------------------------------------->

HTML
	return $Out;
}
#==========================================================
sub SaveTranslateReciters {
my ($Lang, $K, $ID, $LangName, $Query);

	$Lang = $dbh->quote($Param{TranslateLang});

	while (($K, $LangName)= each %Param) {
		if ($K =~ m/\Reciter\_(\d+)/) {
				$ID = $1;
				$LangName =~ s/^\s+//;
				$LangName =~ s/\s+$//;

				$LangName =  $dbh->quote($LangName);

				$Query = qq!DELETE FROM ReciterName WHERE ID=$ID AND Language=$Lang!;
				$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

				$Query = qq!INSERT INTO ReciterName VALUES ($ID, $Lang, $LangName)!;
				$dbh->do($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
		}
	}
	&TranslateReciters;
}
#==========================================================
sub TranslateRecitersLanguageChange{
	 
	$Param{TranslateLang} = $Param{NewLang};
	&TranslateReciters;
}
#==========================================================
sub ConfirmDeleteReciter {
my ($Help);
	$Help = &Help_Link("Audio_Manager");
	&Print_Page(&DeleteReciterForm($Msg), "Audio Manager",  $Help);
}
#==========================================================
sub DeleteReciterForm {
my ($Out);
my (%Reciter);

	%Reciter = &GetReciter($Param{ID});
	if ($Reciter{Type} == 1) { #Surah
		$Folder = "$Global{SurahAudio_Dir}/$Reciter{Folder}";
		$Type = "Surah Reciter";
	}
	elsif ($Reciter{Type} == 2) { #Ayah
		$Folder = "$Global{AyahAudio_Dir}/$Reciter{Folder}";
		$Type = "Ayah Reciter";
	}

$Out=<<HTML;
<a href="$Script_URL?action=AudioManager">Audio Manager</a> >>Delete Reciter
<br><br>

<p align="center"><b><font size="4" color="#FF0000">Delete Reciter Confirmation</font></b></p>
<br>
<b> Are you sure you want to delete this reciter:</b>
<form method="post" action="$Script_URL">
<input type="hidden" name="action" value="DeleteReciter">
<input type="hidden" name="ID" value="$Param{ID}">

<b>
&nbsp; ID: $Param{ID} <br>
&nbsp; Folder: $Reciter{Folder} <br>
&nbsp; Name: $Reciter{Reciter} <br>
&nbsp; Type: $Type <br>
&nbsp; Path: $Folder <br>

</b>
<br>
<input type="checkbox" name="DeleteFolder" value="1"> Also delete this reciter folder and all his audio files?
<br><br>
			&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="Yes Delete" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
</form>
HTML
	return $Out;
}
#==========================================================
sub DeleteReciter {
my (%Reciter, $Folder, $Query, @Files, $File);

	%Reciter = &GetReciter($Param{ID});

	if ($Reciter{Type} == 1) { #Surah
		$Folder = "$Global{SurahAudio_Dir}/$Reciter{Folder}";
	}
	elsif ($Reciter{Type} == 2) { #Ayah
		$Folder = "$Global{AyahAudio_Dir}/$Reciter{Folder}";
	}

	$Query = qq!DELETE FROM Reciters WHERE ID=$Param{ID}!;
	$sth = $dbh->do($Query);

	$Query = qq!DELETE FROM ReciterName WHERE ID=$Param{ID}!;
	$sth = $dbh->do($Query);
	
	if ($Param{DeleteFolder}) {
			@Files = &GetDirectoryFiles($Folder);
			unlink (@Files);
			rmdir ("$Folder");
	}

	&AudioManager(qq!<p align="center"><font color="red"><b>Reciter Deleted Successfully.</p>!);
}
#==========================================================
sub GetDirectoryFiles {
my ($Directory) = @_;
my (@Files, @Found);

   opendir (DIR, "$Directory");
   @Files = readdir (DIR);
   closedir (DIR);
	undef @Found;
   foreach $File (@Files) {
			$Temp = "$Directory/$File";
			if ($File ne "." && $File ne "..") {
					push @Found, $Temp;
			}
	}
	return @Found;
}
#==========================================================
sub GetDirectoryList {
my ($Directory) = @_;
my (@Files, @Found);

   opendir (DIR, "$Directory");
   @Files = readdir (DIR);
   closedir (DIR);
	undef @Found;
   foreach $File (@Files) {
			$Temp = "$Directory/$File";
			if ($File ne "." && $File ne "..") {
					push @Found, $File;
			}
	}
	return @Found;
}
#==========================================================
sub UploadReciter {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Audio_Manager");
	&Print_Page(&UploadReciterForm($Msg), "Audio Manager",  $Help);
}
#==========================================================
sub UploadReciterForm {
my ($Msg) = @_;
my ($Out, %Reciter);

	%Reciter = &GetReciter($Param{ID});
	if ($Reciter{Type} == 1) { #Surah
		$Info = qq!Each file must contain the <b>full Surah</b> audio. File names must be formated  as xxx.mp3, where xxx is the Surah number, examples 001.mp3, 010.mp3, and 114.mp3.<br><br> You can upload audio mp3 files or zip files that contain archive of audio mp3 files. Contents of zip files will be extracted. You can upload zip files to save time and bandwidth.!;
		$Folder = "$Global{SurahAudio_Dir}/$Reciter{Folder}";
		$Type = "Surah Reciter";
	}
	elsif ($Reciter{Type} == 2) { #Ayah
		$Info = qq!Each file must contain the <b>full single Ayah</b> (Verse) audio. File names must be formated  as xxxyyy.mp3, where xxx is the Surah number and yyy is the Ayah number, examples 001001.mp3, 010002.mp3, and 114003.mp3.<br><br> You can upload audio mp3 files or zip files that contain archive of audio mp3 files. Contents of zip files will be extracted. You can upload zip files to save time and bandwidth.!;
		$Folder = "$Global{AyahAudio_Dir}/$Reciter{Folder}";
		$Type = "Ayah Reciter";
	}
	
	$List = "";
	for $x(1..$Global{AdminUploadReciterFiles}) {
			$List .= qq!<tr><td nowrap><b>File $x: </b></td><td width="100%"><input type="file" size="50" name="UploadFile$x" ></td></tr>!;
	}

$Out=<<HTML;
<br><a href="$Script_URL?action=AudioManager">Audio Manager</a> >>Upload Reciter > $Type > $Reciter{Reciter}
<br><br>
$Msg

<form method="post" action="$Script_URL" enctype="multipart/form-data">
<input type="hidden" name="action" value="UploadReciterFiles">
<input type="hidden" name="ID" value="$Param{ID}">

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Upload Reciter Audio</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">

<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
	<tr><td colspan="2">
		$Info
	</td></tr>

	<tr><td><b>ID: </b></td><td>$Param{ID}</td></tr>
	<tr><td><b>Folder: </b></td><td>$Reciter{Folder}</td></tr>
	<tr><td><b>Name: </b></td><td>$Reciter{Reciter}</td></tr>
	<tr><td><b>Type: </b></td><td>$Type</td></tr>
	<tr><td><b>Path: </b></td><td>$Folder</td></tr>

	$List

	<tr>
      <td colspan="2" align="center">
			<input type="submit" value="Upload" name="Submit" style="color: #000080; border-style: ridge">&nbsp;
			<input type="reset" value="Reset" name="Reset" style="color: #000080; border-style: ridge">
	</td>
    </tr>

  </table>
	</td>
</tr>
</table>
<br>
</form>

HTML
	return $Out;
}
#==========================================================
sub UploadReciterFiles {
my (%Reciter, $Folder, $K, $V);

	%Reciter = &GetReciter($Param{ID});

	if ($Reciter{Type} == 1) { #Surah
		$Folder = "$Global{SurahAudio_Dir}/$Reciter{Folder}";
	}
	elsif ($Reciter{Type} == 2) { #Ayah
		$Folder = "$Global{AyahAudio_Dir}/$Reciter{Folder}";
	}

	while (($K, $V) = each %Paramx) {
			if ($K =~ m/UploadFile\d+/) {
				($Filename, $Content) = &GetUploadFile($K);
				if ($Filename ne "") {
						if ($Content ne "") {
								open (File, ">$Folder/$Filename") || &Exit("Cannot create file $Folder/$Filename: $!\n" . "<BR>Line " . __LINE__ . ", File ". __FILE__);
								binmode File;
								print File $Content;
								close File;
						}
						if ($Filename =~ /\.zip$/i) {
								&ExtractAudioZipFile("$Folder/$Filename");
						}
				}
			}
	}
	
	&UploadReciter(qq!<p align="center"><font color="red"><b>Files Uploaded Successfully.</p>!);
}
#==========================================================
sub ExtractAudioZipFile {
my ($Archive) = @_;
my ($Dest, $Zip);
	
	$Dest = $Archive;
	$Dest =~ s/[^\\\/]+$//;
	$Zip = Archive::Zip->new();
	$Zip->read($Archive) == AZ_OK || return;
	#$zip->extractTree( $root, $dest, $volume ) 
	$Zip->extractTree( "", $Dest, "") 
}
#==========================================================
sub BrowseReciter {
my ($Msg) = @_;
my ($Help);
	$Help = &Help_Link("Audio_Manager");
	&Print_Page(&BrowseReciterForm($Msg), "Audio Manager",  $Help);
}
#==========================================================
sub BrowseReciterForm {
my ($Msg) = @_;
my ($Out, %Reciter);

	%Reciter = &GetReciter($Param{ID});
	if ($Reciter{Type} == 1) { #Surah
		$Folder = "$Global{SurahAudio_Dir}/$Reciter{Folder}";
		$Type = "Surah Reciter";
		$URL = $Global{SurahAudio_URL};
	}
	elsif ($Reciter{Type} == 2) { #Ayah
		$Folder = "$Global{AyahAudio_Dir}/$Reciter{Folder}";
		$Type = "Ayah Reciter";
		$URL = $Global{AyahAudio_URL};
	}
	
	@Files = &GetDirectoryList($Folder);
	$List = ""; $Counter = 0;
	@Files = sort @Files;
	foreach $File (@Files) {
			$Counter++;
			$Size = -s "$Folder/$File";
			if ($Size > (1024*1024)) {
				$SizeFormated = sprintf ("%.3f", ($Size / (1024*1024) )) . " MB";
			}
			elsif ($Size > 1024) {
				$SizeFormated =sprintf ("%.3f", ($Size / 1024 )) . " KB";
			}
			else {$SizeFormated = "$Size Bytes";}

			$Link = qq!$URL/$Reciter{Folder}/$File!;
			$List .= qq!<tr><td>$Counter</td><td><a href="$Link" target="_blank" nowrap><b>$File</b></a></td><td nowrap>$SizeFormated ($Size)</td></tr>!;
	}

$Out=<<HTML;
<br><a href="$Script_URL?action=AudioManager">Audio Manager</a> >>Browse Reciter > $Type > $Reciter{Reciter}
<br><br>
$Msg

<table width="500" cellpadding="0" cellspacing="0" border="0">
<tr><td width="200" align="center" align="center" background="$Global{Images_URL}/lh1.gif" height="22">
	<b>Reciter Audio Files</b></td><td>&nbsp;</td></tr>
</table>

<table border="1" width="500" bgcolor="#FDF2CE" cellspacing="0" cellpadding="0" bordercolor="#804000" style="border: 0 solid #804000; padding: 0">
<tr><td width="100%">

<table border="0" cellspacing="0" cellpadding="3" $Global{Admin_Table_Attr}>
	<tr><td colspan="2">
	</td></tr>

	<tr><td><b>ID: </b></td><td>$Param{ID}</td></tr>
	<tr><td><b>Folder: </b></td><td>$Reciter{Folder}</td></tr>
	<tr><td><b>Name: </b></td><td>$Reciter{Reciter}</td></tr>
	<tr><td><b>Type: </b></td><td>$Type</td></tr>
	<tr><td><b>Path: </b></td><td>$Folder</td></tr>

	<tr><td colspan="2">
		<table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bordercolor="#A7A783" width="100%">
		  <tr>
			<td width="50" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;#&nbsp;</b></td>
			<td width="100%" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;File&nbsp;</b></td>
			<td width="150" nowrap bgcolor="#E3E3D7" align="center"><b>&nbsp;Size&nbsp;</b></td>
		  </tr>
			$List
		</table>
		<br><br>
	</td></tr>

  </table>
	</td>
</tr>
</table>
<br>
HTML
	return $Out;
}
#==========================================================
1;