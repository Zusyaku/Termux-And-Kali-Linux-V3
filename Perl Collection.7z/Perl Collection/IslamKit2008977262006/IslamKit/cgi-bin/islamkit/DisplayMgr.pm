=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Translate_File{
my ($Template_File) = @_;
my (@Temp, $Out);

	open(FILE, "$Template_File") || &Exit("Error, Can't open file $Template_File: $!"."<br>Line ". __LINE__ . ", File ". __FILE__);
    @Temp = <FILE>;
    close(FILE);
	$Out = join("", @Temp);
	$Out = Translate($Out);
	return $Out;
}
#==========================================================
sub Translate{
my ($Text) = @_;
my ($K);
	
	if ($Text eq "") {return "";}
	@K =$Text=~ m/\[\[([^\]]*)\]\]/gs;
	foreach $K (@K) {
		$Text =~ s/\[\[$K\]\]/$Language{$K}/;
	}

	@K =$Text=~ m/\[\[([^\]]*)\]\]/gs;
	foreach $K (@K) {
		$Text =~ s/\[\[$K\]\]/$Language{$K}/;
	}
	return $Text;
}
#==========================================================
sub Translate_Classes{
my ($Text) = @_;
my ($K, %D);
	
	if ($Text eq "") {return "";}
	
	@K =$Text=~ m/<!--CLASS::([^-->]*)/gs;
	undef %D;
	foreach $K (@K) {
				if ($D{$K}) { next;}
				$D{$K} = 1;
				$Text =~ s/<!--CLASS::$K-->/$Plugins{$K}/g;
	}
	
	@K =$Text=~ m/<!--CLASS::([^-->]*)/gs;
	undef %D;
	foreach $K (@K) {
				if ($D{$K}) { next;}
				$D{$K} = 1;
				$Text =~ s/<!--CLASS::$K-->/$Plugins{$K}/g;
	}
	return $Text;
}
#==========================================================
sub Base_URL{
	if ($Global{SSL_Status}){return $Global{SSL_URL};}
	return $Global{CGI_URL};
}
#==========================================================
sub GetBenchmark{
my ($Time);

	if ($Global{TimeHiRes}) {
			$Time = Time::HiRes::gettimeofday();
	}
	else{
			$Time = time;
	}
	#return sprintf("%.5f", $Time - $Global{Program_Start_Time});
	return $Time - $Global{Program_Start_Time};
}
#==========================================================
sub Read_Classes{
my ($Line, $K, $V, $Cat, $Temp, %Category, %Affiliate);
my ($x, %User, $Out, $Ext, $Base, %Zones);

#	p("Read_Classes Start: " . &GetBenchmark . " , Line:" . __LINE__." , File: " . __FILE__ );

	#Check if we already done this before or not
	if ($Global{Read_Classes_Done} && !$Global{Force_Read_Classes}) {return;}
	$Global{Read_Classes_Done} = 1; # To avoid reading and translating classes again

	$Param{Cat_ID} ||=0;
	$Cat = "Cat_ID=" . $Param{Cat_ID};
	#------------------------------------------------------
	# https URL's
	#------------------------------------------------------
	$Base = &Base_URL;
	#------------------------------------------------------
	# http URL's
	$Plugins{Home} = qq!$Global{CGI_URL}/$Global{Main_Prog}?Lang=$Global{Language}!;
	$Plugins{Privacy_Policy} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Privacy_Policy&Lang=$Global{Language}!;
	$Plugins{Copyright} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Copyright&Lang=$Global{Language}!;
	$Plugins{Terms_of_Use} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Terms_of_Use&Lang=$Global{Language}!;
	$Plugins{About_Us} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=About_Us&Lang=$Global{Language}!;
	$Plugins{Language} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Set_Language&Lang=$Global{Language}!;
	$Plugins{Contact_Us} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Contact_Us&Lang=$Global{Language}!;
	$Plugins{Announcements} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Announcements&Lang=$Global{Language}!;
	$Plugins{Help} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Help&Lang=$Global{Language}!;
	$Plugins{Advertise} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Advertise&Lang=$Global{Language}!;
	$Plugins{Advertiser_Login} = qq!$Global{CGI_URL}/$Global{Banner_Stats_Prog}?Lang=$Global{Language}!;

	$Plugins{Quran} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Quran&Surah=1&Ayah=1&QuranName=$Global{DefaultQuranName}&Translation=$Global{DefaultTranslation}&Transliteration=$Global{DefaultTransliteration}&Interpertation=$Global{DefaultInterpertation}&Layout=$Global{Layout}&SurahReciter=$Global{DefaultSurahReciter}&AyahReciter=$Global{DefaultAyahReciter}&Lang=$Global{Language}!;
	$Plugins{Qibla} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Qibla&Lang=$Global{Language}!;
	$Plugins{PrayerTimes} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=PrayerTimes&Lang=$Global{Language}!;
	$Plugins{Sunrise} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=Sunrise&Lang=$Global{Language}!;
	
	$Plugins{ReadQuran} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=ReadQuran&QuranName=$Param{QuranName}&Translation=$Param{Translation}&Transliteration=$Param{Transliteration}&Interpertation=$Param{Interpertation}&Surah=$Param{Surah}&Ayah=$Param{Ayah}&Layout=$Param{Layout}&SurahReciter=$Global{DefaultSurahReciter}&AyahReciter=$Global{DefaultAyahReciter}&Lang=$Global{Language}!;
	$Plugins{SearchQuran} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=SearchQuran&QuranName=$Param{QuranName}&Translation=$Param{Translation}&Transliteration=$Param{Transliteration}&Interpertation=$Param{Interpertation}&Surah=$Param{Surah}&Page=$Param{Page}&SurahReciter=$Global{DefaultSurahReciter}&AyahReciter=$Global{DefaultAyahReciter}&Lang=$Global{Language}!;
	$Plugins{ReciteSurah} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=ReciteSurah&SurahReciter=$Global{DefaultSurahReciter}&AyahReciter=$Global{DefaultAyahReciter}&QuranName=$Param{QuranName}&Translation=$Param{Translation}&Transliteration=$Param{Transliteration}&Interpertation=$Param{Interpertation}&Surah=$Param{Surah}&Ayah=$Param{Ayah}&Page=$Param{Page}&Lang=$Global{Language}!;
	$Plugins{ReciteAyah} = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=ReciteAyah&SurahReciter=$Global{DefaultSurahReciter}&AyahReciter=$Global{DefaultAyahReciter}&QuranName=$Param{QuranName}&Translation=$Param{Translation}&Transliteration=$Param{Transliteration}&Interpertation=$Param{Interpertation}&Surah=$Param{Surah}&Ayah=$Param{Ayah}&Page=$Param{Page}&Lang=$Global{Language}!;
	#------------------------------------------------------
	$Plugins{Action} = qq!$Global{CGI_URL}/$Global{Main_Prog}!;
	$Plugins{CGI_Dir} = $Global{CGI_Dir};
	$Plugins{HTML_Dir} = $Global{HTML_Dir};
	$Plugins{CGI_URL} = $Global{CGI_URL};
	$Plugins{HTML_URL} = $Global{HTML_URL};
	#------------------------------------------------------
	&UpdateConfiguration(PageViews, $Global{PageViews}+1);
	$Plugins{PageViews} = $Global{PageViews};
	#------------------------------------------------------
	#$Plugins{Site_Name} = $Global{Site_Name};
	$Plugins{Site_Name} = $Language{site_name};
	$Plugins{Program_URL} = qq!$Global{CGI_URL}/$Global{Main_Prog}!;
	$Plugins{Images_URL} = $Global{Images_URL};
	$Plugins{Theme_Images_URL} = $Global{Theme_Images_URL};
	#------------------------------------------------------
	$Plugins{AyahAudio_URL} = $Global{AyahAudio_URL};
	$Plugins{SurahAudio_URL} = $Global{SurahAudio_URL};
	#------------------------------------------------------
	&Whos_Online;
	#------------------------------------------------------
	# Translate general classes
	@Class = &ReadGeneralClassesNames;
	foreach $K (@Class) {
			delete $PluginsNames{$K};
			$Plugins{$K} = &Translate($Global{$K});
	}
	
	#Do not translate special classes here, they are translated where they needed
	@Class = &ReadSpecialClassesNames;
	foreach $K (@Class) {
			delete $PluginsNames{$K};
	}
	
	# Translate custom classes. These Classes generated by admin in the Class editor and they are general
	foreach $K (keys %PluginsNames) {
			$Plugins{$K} = &Translate($Global{$K});
	}
	#------------------------------------------------------
	$Plugins{Meta_Title} = $Global{Meta_Title};
	$Plugins{Meta_Description} = $Global{Meta_Description};
	$Plugins{Meta_Keywords} = $Global{Meta_Keywords};
	#------------------------------------------------------
	$Plugins{HeadCode} ||= "";
	$Plugins{JS_Code} ||= ""; #Onload code
	#------------------------------------------------------
}
#==========================================================
sub Display{
my ($Template, $Translated) = @_; 
my ($K, $V, $Temp, $Out);
	
	#p("Benchmark: " . &GetBenchmark . " , Line:" . __LINE__." , File: " . __FILE__ );
	if (!$Global{Read_Classes_Done}) {&Read_Classes;}
	#p("Benchmark: " . &GetBenchmark . " , Line:" . __LINE__." , File: " . __FILE__ );
	#------------------------------------------------------
	if (!$Translated) {$Out = &Translate_File($Template);} else {$Out = $Template;}
	#------------------------------------------------------
	#<!--CLASS::Custom:file:user_subs(param1,...)--> <!--CLASS::Custom:url_grab:URL_Include-->
	#$Out = &Process_Custom_Functions("$Out");
	#$Out = &Do_SSI_Classes("$Out");
	#------------------------------------------------------
	if ($Global{TimeHiRes}) {
			$Global{Program_End_Time} = Time::HiRes::gettimeofday();
	}
	else{
			$Global{Program_End_Time} = time;
	}

	$Plugins{Benchmark} = sprintf("%.4f", $Global{Program_End_Time} - $Global{Program_Start_Time});
	if ($Global{Building_Pages}) {$Plugins{Benchmark} = "";}
	#p("Benchmark: " . &GetBenchmark . " , Line:" . __LINE__." , File: " . __FILE__ );
	#------------------------------------------------------
	while ($Out =~ m/<!--CLASS::(.*?)(?:\:|-->)/gs) {
		$K = $1;
		$Out =~ s/<!--CLASS::$K-->/$Plugins{$K}/;
	}
	while ($Out =~ m/<!--CLASS::(.*?)(?:\:|-->)/gs) {
		$K = $1;
		$Out =~ s/<!--CLASS::$K-->/$Plugins{$K}/;
	}
	#------------------------------------------------------
	#<!--CLASS::Date_Time:20-->
	while ($Out =~ m/<!--CLASS::Date_Time:(\d{1,3})-->/){
				$K = $1;
				$V =&Format_Date($K, &Time(time));
				$Out =~ s/<!--CLASS::Date_Time:$K-->/$V/g;
	}
	#------------------------------------------------------
	#<!--CLASS::Search_Main:20-->
	while ($Out =~ m/<!--CLASS::Search_Main:(\d{1,3})-->/){
				$K = $1;
				$V = &Search_Main_Form($K, $Param{Cat_ID});
				$Out =~ s/<!--CLASS::Search_Main:$K-->/$V/g;
	}
	#------------------------------------------------------
	#<!--CLASS::Banner:Zone_Name-->
	#<!--CLASS::Banner:Get:Campaign_Name-->
#	while ($Out =~ m/<!--CLASS::Banner:(.*?)-->/ ){
#				$K = $1;
#				$V = &Get_Banner_Class($K, $Global{Building_Pages});
#				$Out =~ s/<!--CLASS::Banner:$K-->/$V/;
#	}
	#------------------------------------------------------
	#<!--CLASS::Page:Page_Name-->
	while ($Out =~ m/<!--CLASS::Page:(.*?)-->/){
				$K = $1;
				$V = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=GetPage&Name=$K&Lang=$Global{Language}!;
				$Out =~ s/<!--CLASS::Page:$K-->/$V/g;
	}
	#------------------------------------------------------
	#<!--CLASS::Help:Page_Number-->
	while ($Out =~ m/<!--CLASS::Help:(.*?)-->/){
				$K = $1;
				$V = qq!$Global{CGI_URL}/$Global{Main_Prog}?action=GetHelp&Page=$K&Lang=$Global{Language}!;
				$Out =~ s/<!--CLASS::Help:$K-->/$V/g;
	}
	#------------------------------------------------------
	while ($Out =~ m/<!--CLASS::(.*?)(?:\:|-->)/gs) {
		$K = $1;
		$Out =~ s/<!--CLASS::$K-->/$Plugins{$K}/;
	}
	#p("Benchmark: " . &GetBenchmark . " , Line:" . __LINE__." , File: " . __FILE__ );
	print "Content-type: text/html\n\n";
	print "$Out";
}
#==========================================================
1;