=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Server_Test{
my ($Help);
	$Help = &Help_Link("Server_Configuration");
	&Print_Page(&Get_Server_Test, "Server Configuration", $Help);
}
#==========================================================
sub Commander1{
my ($Command, $Output, @Commands);
my ($Out, $CWD);

	$Help = &Help_Link("Commander");

   if ($@) {
		   $CWD = "$Global{CGI_Dir}>";
   }
   else {
			$CWD = Cwd::cwd;
   }

	if (!$Param{CWD}) {$Param{CWD} = $CWD;}

	if ($Param{CWD}) {chdir ($Param{CWD});}

	$Output = "";
	$Command = "";
	if ($Demo) {$Param{Command} = "ls -R -l" ; $Param{CWD} = $Global{CGI_Dir};}

	if (defined $Param{Command}) {
		@Commands = split(/\n/, $Param{Command});
		foreach $Command (@Commands) {
			$Command=~ s/\n//g;
			$Command=~ s/\cM//g;
			if ($Command) {
				system("$Command  > $Global{Temp_Dir}/command.txt");
				open(FILE,"$Global{Temp_Dir}/command.txt");
				@Out = <FILE>;
				$Output .= join("", @Out);
				close(FILE);
				#$Output .= `$Command`;
			}
		}
	}
	
	chdir ($Global{CGI_Dir});

	$Output = &Encode_HTML($Output);
	$Output =~ s/\n/<br>/g;
	$Output =~ s/\&lt;br\&gt;/<br>/ig;
	#$Output=~ s/\cM/<br>/g;
	$Param{Command} = join("\n", @Commands);
	&Print_Page(&Commander_Form($Param{Command}, $Output, $Param{CWD}), "Telnet Commander", $Help);
}
#==========================================================
sub Commander{
my ($Command, $Output, @Commands);
my ($Out, $CWD);

	$Help = &Help_Link("Commander");
   if ($Global{CGI_Dir} && -d $Global{CGI_Dir}) {
		   $CWD = $Global{CGI_Dir};
   }
   else {
			$CWD = &Cwd::cwd;
			if (!-d $CWD) {$CWD = ".";	}
   }

	$Param{CWD} =~ s/^\s+//;
	$Param{CWD} =~ s/\s+$//;
	$Param{CWD} ||= $CWD;
	$Param{Command} ||= "";

	if ($Demo) {$Param{Command} = "ls -R -l" ; $Param{CWD} = $Global{CGI_Dir};}

	@Temp = split(/\n/, $Param{Command});
	undef @Commands;

	foreach $Command (@Temp) {
			$Command =~ s/\n//g;
			$Command =~ s/\cM//g;
			$Command =~ s/^\s+//;
			$Command =~ s/\s+$//;
			if (!$Command) {next;}
			push @Commands, $Command;
	}

	$Output = "";
	foreach $Command (@Commands) {
			if ($Param{CWD}) {chdir ($Param{CWD});}
			$Output .=  "[[Command::X]]" . $Command . "[[Command::Y]]<BR>";
			#$Command = "perl -c $File 2> $Temp_File";
			system("$Command  > $Global{Temp_Dir}/command.txt");
			open(FILE,"$Global{Temp_Dir}/command.txt");
			@Out = <FILE>;
			$Output .= join("", @Out);
			close(FILE);
	}
	
	chdir ($Global{CGI_Dir});

	$Output = &Encode_HTML($Output);
	$Output =~ s/\n/<br>/g;
	$Output =~ s/\&lt;br\&gt;/<br>/ig;

	$Output =~ s|\[\[Command::X\]\]|\<FONT SIZE\=\"4\" COLOR\=\"RED\"\>\<B\>|g;
	$Output =~ s|\[\[Command::Y\]\]|\<\/B\>\<\/FONT\>|g;
	
	$Param{Command} = join("\n", @Commands);
	&Print_Page(&Commander_Form($Param{Command}, $Output, $Param{CWD}), "Telnet Commander", $Help);
}
#==========================================================
sub Commander_Form{
my($Command, $Output, $CWD) = @_;
my($Out);

$Out=<<HTML;
<FORM NAME="Command" METHOD="POST" ACTION="$Script_URL">
<INPUT TYPE="hidden" NAME="action" VALUE="Commander">
<INPUT TYPE="hidden" NAME="CWD" VALUE="$CWD">
<table border="0" width="100%" cellpadding="0" >
  <tr>
    <td width="100%"><a name="commander">
	Please Enter Your System Commands to Run (One Command per line):<br>
      $CWD>
	<TEXTAREA ROWS="8" NAME="Command" COLS="88">$Command</TEXTAREA>
	  <br>
	  <input type="submit" value="Do it!">
      <input type="reset" value="Reset"> 
	  </td>
  </tr>
  <tr>
    <td width="100%" >
      <div align="center">
        <center>
        <table border="1" width="100%" cellpadding="3" $Global{Admin_Table_Attr}>
          <tr>
            <td width="100%" >
              <p align="center"><font size="4" face="Tahoma">O u t p u t</font></td>
          </tr>
          <tr>
            <td width="100%">
			
			$Output
			
			</td>
          </tr>
        </table>
        </center>
      </div>
    </td>
  </tr>
  <tr>
    <td width="100%"  align="center">
	<p align="center">
	<a href="#commander">Top of Page</a>
  </td>
  </tr>
</table>
</form>
   <SCRIPT>
   <!--
   document.Command.Command.focus()
   // -->
   </SCRIPT>

HTML
	return $Out;
}
#==========================================================
sub Reset_Permissions {
my($Out);

	$Out= "<center><b><font color=red size=3>Setting System Permissions</font></b></center><BR><BR>\n";

	$Out .="<p align=\"left\">";
	$Out .= "<font color=blue>1)- Main CGI Directory            ...Finished</font><BR>\n";
	$Out .= `chmod -R 755  $Global{CGI_Dir}/*.*`;

	$Out.= "<font color=blue>2)- Lib Directory            ...Finished</font><BR>\n";
	$Out .= `chmod -R 740 $Global{CGI_Dir}/lib*.*`;

	$Out.= "<font color=blue>3)- Data Directory            ...Finished</font><BR>\n";
	$Out .= `chmod -R 740 $Global{Data_Dir}/*.*`;

	$Out.= "<font color=blue>5)- Languages Directories            ...Finished</font><BR>\n";
	$Out .= `chmod -R 740 $Global{Data_Dir}/language/*.*`;

	$Out.="<font color=blue>6)- HTML Directories            ...Finished</font><BR>\n";
	$Out .= `chmod -R 740 $Global{HTML_Dir}/download/*.*`;
	$Out .= `chmod -R 740 $Global{HTML_Dir}/upload/*.*`;
	$Out .= `chmod -R 740 $Global{HTML_Dir}/backup/*.*`;

	$Out.="<BR><font color=Green>If you are on Windows system, or non Unix System, this function will not work for you, Please check your server manual for setting permisssions or try from your server control panel.</font><BR>\n";
	
	$Out.= qq!<I><CENTER><A HREF="javascript:history.go(-1)">Back to Previous Page</A></I></CENTER>!;

	&Print_Page($Out);

 }
#==========================================================
sub Get_Program_Exec_Directories{
my(@Exec);

	@Exec = qw (
								data
								data/database
								data/language
								data/lib
								data/lock
								data/logs
								data/temp
								data/templates
							);

	return @Exec;
 }
#==========================================================
sub Get_Program_Docs_Directories{
my(@Docs);

	@Docs = qw (
							images
							theme
							);

 }
#==========================================================
sub Check_Program_Directory{
my($Dir, $Perkey, $PerValue) = @_;
my($Action, $Status, $Result, $Permissions, $Row, $Result);

	$Action = "-";
	
	if (!-d $Dir) {
			&Create_Directory_Path($Dir, $PerValue);
			chmod($PerValue, $Dir);
			if (!-d $Dir) {
					$Action = "Can't create";
			}
			else{
					$Action = "Created";
			}
	}
	
	if (-d $Dir) {
			$Status = "OK";
	}
	else{
			$Status = "Error";
			$Result .= "Failed to create directory: $Dir <BR>";
	}
	
	if ($Perkey eq "x") {
			if (!-x $Dir) {chmod($PerValue, $Dir);}
	}
	if ($Perkey eq "w") {
			if (!-w $Dir) {chmod($PerValue, $Dir);}
	}

	if ($Perkey eq "x") {
			if (-x $Dir) {
					$Permissions = "OK";
			}
			else{
					$Permissions = "Error";
					$Result .= "Failed to change permissions to executable: $Dir.<BR>";
							$Result .= "Failed to change permissions to writable: $Dir.<BR>";
			}
	}

	if ($Perkey eq "w") {
			if (-w $Dir) {
					$Permissions = "OK";
			}
			else{
					$Permissions = "Error";
					$Result .= "Failed to change permissions to writable: $Dir.<BR>";
			}
	}

	$Row .= qq|<TR><TD>$Dir</TD><TD ALIGN="center">$Status</TD><TD ALIGN="center">$Permissions</TD><TD ALIGN="center">$Action&nbsp;</TD></TR>|;
	return ($Result, $Row);
 }
#==========================================================
sub Check_Program_Directories{
my(@Dirs, $Msg, $Out, $Results, $Table, $Row);
my($Help);

	$Help = &Help_Link("Check_Program_Directories");

	$Table = "";
	$Results = "";
	
	($Result, $Row) = &Check_Program_Directory("$Global{CGI_Dir}", "x", 0755);
	$Table .= $Row;
	$Results .= $Result;
	($Result, $Row) = &Check_Program_Directory("$Global{HTML_Dir}", "x", 0755);
	$Table .= $Row;
	$Results .= $Result;

	@Dirs = &Get_Program_Exec_Directories;
	foreach $Dir(@Dirs) {
		($Result, $Row) = &Check_Program_Directory("$Global{CGI_Dir}/$Dir", "w", 0744);
		$Table .= $Row;
		$Results .= $Result;
	}

	@Dirs = &Get_Program_Docs_Directories;
	foreach $Dir(@Dirs) {
		($Result, $Row) = &Check_Program_Directory("$Global{HTML_Dir}/$Dir", "w", 0744);
		$Table .= $Row;
		$Results .= $Result;
	}
	($Result, $Row) = &Check_Program_Directory("$Global{HTML_Dir}/images", "x", 0755);
	$Table .= $Row;
	$Results .= $Result;
	
	if (($^O =~ /win/i)) {
			$Msg = qq!!;
	}
	
	if (!$Results) {
			$Results = "<B>Congratulations, All tests passed.</B>";
	}

$Out=<<HTML;
<BR><BR>
<FORM METHOD="POST" ACTION="$Script_URL">
  <INPUT TYPE="hidden" NAME="action" VALUE="Do_Server_Backup">
  <DIV ALIGN="center">
    <CENTER>
    <TABLE BORDER="1" WIDTH="100%" CELLSPACING="0" CELLPADDING="3" $Global{Admin_Table_Attr}>
	<TR><TD BGCOLOR="#FDF2CE"><B>Directory</B></TD><TD ALIGN="center" BGCOLOR="#FDF2CE"><B>Status</B></TD><TD ALIGN="center" BGCOLOR="#FDF2CE"><B>Permissions</B></TD><TD ALIGN="center" BGCOLOR="#FDF2CE"><B>Action</B></TD></TR>
	$Table
      </TR>
    </TABLE>
    </CENTER>
  </DIV>
</FORM>
	$Results
HTML

	&Print_Page($Out, "Check Program Directories", $Help);

 }
#==========================================================
sub Check_Program_Files_Permissions{
my(@Dirs, $Out, $Table, $Dir, $Read, $Write, $Execute, $Filename);
my($Help);

	$Help = &Help_Link("Check_Program_Directories");

	$Table = "";
	@Files = &Scan_Directory_Files($Global{CGI_Dir});

	foreach $File(@Files) {
			$Read = "&nbsp;";
			$Write = "&nbsp;";
			$Execute = "&nbsp;";
			if (-r "$File") {$Read = "Yes";}
			if (-w "$File") {$Write = "Yes";}
			if (-x "$File") {$Execute = "Yes";}
			$Filename = $File;
			$Filename =~ s/^$Global{CGI_Dir}//;
			if (-d $File) {$Filename = qq!<FONT COLOR="red"><B>$Filename</B></FONT>!;}
			$Table .= qq|<TR><TD>$Filename</TD><TD ALIGN="center">$Read</TD><TD ALIGN="center">$Write</TD><TD ALIGN="center">$Execute</TD></TR>|;
	}

	@Files = &Scan_Directory_Files($Global{HTML_Dir});

	foreach $File(@Files) {
			$Read = "";
			$Write = "";
			$Execute = "";
			if (-r "$File") {$Read = "Yes";}
			if (-w "$File") {$Write = "Yes";}
			if (-x "$File") {$Execute = "Yes";}
			$Filename = $File;
			$Filename =~ s/^$Global{HTML_Dir}//;
			if (-d $File) {$Filename = qq!<FONT COLOR="red"><B>$Filename</B></FONT>!;}
			$Table .= qq|<TR><TD>$Filename</TD><TD ALIGN="center">$Read</TD><TD ALIGN="center">$Write</TD><TD ALIGN="center">$Execute</TD></TR>|;
	}

$Out=<<HTML;
<BR><BR>
<FORM METHOD="POST" ACTION="$Script_URL">
  <INPUT TYPE="hidden" NAME="action" VALUE="Do_Server_Backup">
  <DIV ALIGN="center">
    <CENTER>
    <TABLE BORDER="1" WIDTH="100%" CELLSPACING="0" CELLPADDING="3" $Global{Admin_Table_Attr}>
	<TR><TD BGCOLOR="#FDF2CE"><B>File</B></TD><TD ALIGN="center" BGCOLOR="#FDF2CE"><B>Read</B></TD><TD ALIGN="center" BGCOLOR="#FDF2CE"><B>Write</B></TD><TD ALIGN="center" BGCOLOR="#FDF2CE"><B>Execute</B></TD></TR>
	$Table
      </TR>
    </TABLE>
    </CENTER>
  </DIV>
</FORM>
HTML

	&Print_Page($Out, "Check Program Files Permissions", $Help);

}
#==========================================================
sub Scan_Directory_Files{
my($Directory)=@_;
my($File, $Temp, @Directories, @Files, $Current_Directory, @Found);

	undef @Directories;
	undef @Files;
	undef @Found;

	if (!$Directory) {$Directory = Cwd::cwd();}

	push @Directories, $Directory;
	
	while (@Directories) {
						   $Current_Directory = shift (@Directories);
						   opendir (DIR, $Current_Directory) || return undef;
						   @Files = readdir (DIR);
						   closedir (DIR);
						   foreach $File (@Files) {
									$Temp = "$Current_Directory/$File";
									$Temp =~ s|\/\/|\/|;
									  if (-d $Temp && $File ne "." && $File ne "..") {
												unshift @Directories, $Temp;
												push @Found, $Temp;
												next;
									  }
									  else{
											 if ($File ne "." && $File ne "..") {
													push @Found, $Temp;
											 }
									  }
							}
	}

	return sort @Found;
}
#==========================================================
1;
