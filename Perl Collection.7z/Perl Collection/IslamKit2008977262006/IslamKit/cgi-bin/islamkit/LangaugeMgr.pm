=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Language_Manager{
my ($Help);

	$Help = &Help_Link("Language_Manager");
	&Print_Page(&Language_Admin_Form, "Language Manager",  $Help);

}
#==========================================================
sub Language_Admin_Form{
my($Out, $List, $Languages, $Edit_Languages);
my($Inherit_Languages, $Initialize_Language);

	$List = &Language_List($Global{Language});

	$Languages = qq!<select SIZE="1" NAME="Language">!;
	$Languages .= $List . qq!</select>!;

	$Edit_Languages = qq!<select SIZE="1" NAME="Language">!;
	$Edit_Languages .= $List . qq!</select>!;

	$Delete_Languages = qq!<select SIZE="1" NAME="Language">!;
	$Delete_Languages .=  $List . qq!</select>!;

	$Inherit_Languages = qq!<select SIZE="1" NAME="Inherit_Language">!;
	$Inherit_Languages .=  $List . qq!</select>!;

	$Files_Menu = qq!<select SIZE="1" NAME="Filename">!;
	$Files_Menu .= &List_Language_Files;
	$Files_Menu .= qq!</select>!;

	$Initialize_Language = qq!$Global{G1_Bullet} <A HREF="$Script_URL?action=Initialize_Language"><B>Prepare All Available Languages</B></A>!;

$Out=<<HTML;
<BR>
 &nbsp;$Initialize_Language
<BR><BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200" ALIGN="center" ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Set Default Language</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
<TABLE BORDER="0" CELLSPACING="0" CELLPADDING="8" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL">
		<INPUT TYPE="hidden" NAME="action" VALUE="Set_Default_Language">
      <TD NOWRAP WIDTH="25%">Select Language:</TD>
      <TD WIDTH="75%">
			$Languages
			<INPUT TYPE="submit" VALUE="Submit" NAME="Submit" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
	</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200" ALIGN="center" ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Edit Language</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL">
		<INPUT TYPE="hidden" NAME="action" VALUE="Edit_Language_File">
      <TD NOWRAP>Select Language:</TD>
      <TD WIDTH="90%">$Edit_Languages</TD>
    </TR>
    <TR>
      <TD NOWRAP>Select File:</TD>
      <TD WIDTH="90%">
			$Files_Menu
			<INPUT TYPE="submit" VALUE="Edit" NAME="Submit" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
 </FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200" ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Search Language</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
 <TABLE BORDER="0"CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL">
		<INPUT TYPE="hidden" NAME="action" VALUE="Search_Language">
      <TD NOWRAP>Language to search:</TD>
      <TD>$Languages</TD>
    </TR>
    <TR>
      <TD NOWRAP>Search for text: <br>Search for variable:</TD>
      <TD WIDTH="100%">
			<INPUT TYPE="text" NAME="Terms" SIZE="40">
			<INPUT TYPE="text" NAME="FindVariable" SIZE="40">
	</TD>
    </TR>
    
	<TR><TD NOWRAP colspan="2" align="center">
			<INPUT TYPE="submit" VALUE="Search" NAME="Submit" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
	</FORM>
    </TR>

	</TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200" ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Replace Text</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
 <TABLE BORDER="0"CELLSPACING="0" CELLPADDING="3" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL">
		<INPUT TYPE="hidden" NAME="action" VALUE="Replace_Language">
      <TD NOWRAP>Language to replace:</TD>
      <TD>$Languages</TD>
    </TR>
    <TR><TD NOWRAP>Search for text:</TD>
      <TD WIDTH="100%">
			<INPUT TYPE="text" NAME="FindText" SIZE="40">
	</TD>
    </TR>
    <TR><TD NOWRAP>Replace with text:</TD>
      <TD WIDTH="100%">
			<INPUT TYPE="text" NAME="ReplaceWith" SIZE="40">
	</TD>
    </TR>
    <TR><TD NOWRAP colspan="2" align="center">
			<INPUT TYPE="submit" VALUE="Replace" NAME="Submit" STYLE="color: #000080; border-style: ridge">
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
	</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200"  ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Delete Language</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL" NAME="Delete_Language">
		<INPUT TYPE="hidden" NAME="action" VALUE="Delete_Language">
      <TD NOWRAP>Select Language:</TD>
      <TD WIDTH="90%">
			$Delete_Languages
			<INPUT TYPE="submit" VALUE="Delete" NAME="Submit" onClick="Delete_Language_Confirm(document.Delete_Language.Language[document.Delete_Language.Language.selectedIndex].value); return false;" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<TABLE WIDTH="500" CELLPADDING="0" CELLSPACING="0" BORDER="0">
<TR><TD WIDTH="200"  ALIGN="center" BACKGROUND="$Global{Images_URL}/lh1.gif" HEIGHT="22">&nbsp;&nbsp;&nbsp;&nbsp;<B>Create New Language</B></TD><TD>&nbsp;</TD></TR>
</TABLE>

<TABLE BORDER="1" WIDTH="500" BGCOLOR="#FDF2CE" CELLSPACING="0" CELLPADDING="0" BORDERCOLOR="#804000" STYLE="BORDER: 0 SOLID #804000; PADDING: 0">
<TR><TD WIDTH="100%">
  <TABLE BORDER="0" CELLSPACING="0" CELLPADDING="4" $Global{Admin_Table_Attr}>
    <TR>
		<FORM METHOD="POST" ACTION="$Script_URL">
		<INPUT TYPE="hidden" NAME="action" VALUE="Create_New_Language">
      <TD NOWRAP>Copy From Language:</TD>
      <TD WIDTH="90%">$Inherit_Languages</TD>
    </TR>
    <TR>
      <TD NOWRAP>New Language Name:</TD>
      <TD WIDTH="90%">
			<INPUT TYPE="text" NAME="New_Language_Name" SIZE="20">
			<INPUT TYPE="submit" VALUE="Create" NAME="Submit" STYLE="color: #000080; border-style: ridge">&nbsp;
			<INPUT TYPE="reset" VALUE="Reset" NAME="Reset" STYLE="color: #000080; border-style: ridge">
	</TD>
    </TR>
    <TR>
      <TD WIDTH="100%" COLSPAN="2" ALIGN="center">
	  </TD>
	</FORM>
    </TR>
  </TABLE>
	</TD>
</TR>
</TABLE>
<BR>

<SCRIPT LANGUAGE="JavaScript">
<!--
function Delete_Language_Confirm(Language) {
	var agree=confirm("Are you sure you want to delete this language?\\nLanguage: "+Language+"\\n");
	if (agree){
			var agree=confirm("Please note once the language deleted, you will not be able to recover it again\\nAre you sure you still want to delete this language?\\nLanguage: "+Language+"\\n");
			if (agree){
					window.location = "$Script_URL?action=Delete_Language&Language=" +Language;
			}
	}
	//document.Delete_Language.submit();
}
-->
</SCRIPT>

HTML
return $Out;

}
#==========================================================
sub Language_List{
my ($Language) = @_;
my($x, $Out, @Files, $File, $Selected);

	undef @Files;
	opendir(Dir, "$Global{Language_Dir}");
	foreach $File (readdir(Dir)) {
			push (@Files, "$File");
    }

	closedir(Dir);

	for $x(0..$#Files) {
		$File = $Files[$x];
		if (-d "$Global{Language_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
			$Selected = "";
			if (lc($File) eq lc($Language)) {$Selected="SELECTED";}
				 $Out .= qq!<OPTION VALUE="$File" $Selected>$File</OPTION>!;
		}

	}

	return $Out;

 }
#==========================================================
sub Set_Default_Language{
my(%Config);

	undef %Config;
	$Config{Language} = $Param{Language};
	&Update_Configuration(%Config);

	&Language_Manager;
}
#==========================================================
sub Delete_Language{
my ($Dir, @Files, @Directories);

	$Dir = "$Global{Language_Dir}/$Param{Language}";
	undef @Files;

	@Directories = &Scan_Directory_Tree($Dir);
	@Directories  = sort @Directories;
	
	foreach $Directory (@Directories) {
			@Files = &Scan_Directory($Directory);
			if (@Files) {
				unlink (@Files) or &Exit("Can't remove language files @Files: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			}
			rmdir ("$Directory") or &Exit( "Can't remove language directory $Directory: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	}

	@Files = &Scan_Directory($Dir);
	if (@Files) {
		unlink (@Files) or &Exit("Can't remove language files @Files: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	}
	rmdir ("$Dir") or &Exit( "Can't remove language directory $Dir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);

	&Initialize_Language;

}
#==========================================================
sub Create_New_Language {
my $Base_Language;
my $Dir;
my $File;

	$Dir="$Global{Language_Dir}/$Param{New_Language_Name}";
	mkdir ($Dir, 0777) or &Exit("Can't creat language directory $Dir: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	$Base_Language="$Global{Language_Dir}/$Param{Inherit_Language}";
	opendir(Base_Lang_Dir, "$Base_Language");
	foreach $File (  readdir(Base_Lang_Dir)  ) {
			if ($File eq "." || $File eq "..") {next;}
			copy("$Base_Language/$File",	"$Dir/$File");
    }

	closedir(Base_Lang_Dir);
	chmod (0755, $Dir);
	
	&Initialize_Language;
}
#==========================================================
sub Initialize_Language{
my(@Files, $file, $Langs);
my(%Config);

	undef @Files;
	opendir(Dir, "$Global{Language_Dir}");
	foreach $File (readdir(Dir)) {
			push (@Files, "$File");
    }

	closedir(Dir);

	@Files =sort @Files;
	
	$Langs = "";
	foreach $File(@Files) {
		if (-d "$Global{Language_Dir}/$File" && $File ne "." && $File ne ".." && $File !~ m/^\_/) { 
					$Langs .= "|$File";
		}
 
	}
	$Langs =~ s/^\|//g;
	
	undef %Config;
	$Config{Languages} = $Langs;
	&Update_Configuration(%Config);
	&Language_Manager;
}
#==========================================================
sub List_Language_Files{
my ($Filename) = @_;
my(%Title, $Dir, $Counter, @Files, $File, $Out, $Line, $Key, $Value);

	#----------------------------------------------------------------
	undef %Title;
	open (FILE, "$Global{Data_Dir}/LanguageFiles.pm") || &Exit("Cannot open file $Global{Data_Dir}/LanguageFiles.pm: $!\n"."<br>Line ". __LINE__ . ", File ". __FILE__);
	@All = <FILE>;
	close(FILE);
	foreach $Line(@All){
			chomp $Line;
			next if (!$Line);
			($Key, $Value) = split(/\=/ , $Line);
			next if (!$Key);
			$Title{$Key} = $Value;
	}
	#----------------------------------------------------------------
	$Dir = "$Global{Language_Dir}/$Global{Language}";
	
	undef @Files;
	opendir(Dir, "$Dir");
	@Files = sort readdir(Dir);
	closedir(Dir);

	$Out = "";
	$Counter = 1;

	foreach $File (@Files) {
			if ($File eq "." || $File eq "..") {next;}
			if (!$Title{$File}) {$Title{$File} = $File;}
			if ($File =~ m/\.pm$/i && (-f  "$Dir/$File")) {
					$Selected = "";
					if ($File eq $Filename) {$Selected = "SELECTED";}
					$Title{$File} =~ s/\.page\.pm$//;
					$Out .= qq!<option value="$File" $Selected>$Counter- $Title{$File}</option>!;
					   $Counter++;
			}
	}

	return $Out;
 }
#==========================================================
sub Edit_Language_File{
my ($Message) = @_;
my($Help);

	$Help = &Help_Link("Language_Manager");
	&Print_Page(&Edit_Language_File_Form($Message), "Edit Language File", $Help);
}
#==========================================================
sub Encode_Form{
my $Temp =shift;

	$Temp =~ s/\"/\&quot\;/g;
    $Temp =~ s/\'/\&\#39\;/g;	
	$Temp =~ s/\</\&lt\;/g;
	$Temp =~ s/\>/\&gt\;/g;

	return $Temp;
}
#==========================================================
sub Load_Language_File{
my ($Filename, $Line, $delimiter, @Variables);
my ($Out, $Key, $Value, $Count, %Var, %Cats, @Subs, $Sub, $Key1);
my (@KeysDigits, @KeysChars);

	$Filename="$Global{Language_Dir}/$Param{Language}/$Param{Filename}";

	if (! -e $Filename) {
			open (FILE, ">$Filename") || &Exit("Cannot create language file $Filename: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);
			close (FILE);
	}

	undef @Variables;
	undef %Var;

	open(FILE,"$Filename") || &Exit( "Error: Can't open file $Filename: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	@Variables = <FILE>;
	close(FILE);

	#$/="\n";
	 $Out=qq!<tr><td align="right"><b><font color="#003046" size="4"> \#</font></b></td>
					<td nowrap><b><font color="#003046" size="3">Delete</b></font></td>
					<td nowrap><b><font color="#003046" size="3">Variable Name</font></b></td>
					<td width="100%"><b><font color="#003046" size="3">Variable Value (HTML Allowed)</font></b></td>
					</tr>!;
	
	#@Variables= sort @Variables;	
	$Counter=0;

	foreach $Line (@Variables) {
		chomp($Line);
		($Key, $Value) = split('~==~', $Line);
		$Key || next;
		#$Key =~ s/\_/ /g;
		$Objects{$Key} = &Encode_Form($Value);
	}
	
	@Keys= sort  {$a <=> $b || lc ($a) cmp lc($b)} keys %Objects;
	
	foreach $Key (@Keys) {
		$Value=$Objects{$Key};
		$Key1= $Key; 
		$Key2 = &Web_Encode($Key);

		$Counter++;

        if( length($Value) >= 60) { 
           if( length($Value) >= (60)) { $Row=4;}
           if( length($Value) >= (60*3) ){ $Row=5;}
           if( length($Value) >= (60*5) ){ $Row=8;}
           if( length($Value) >= (60*7)) { $Row=10;}
           if( length($Value) >= (60*15)) { $Row=20;}
           if( length($Value) >= (60*25)) { $Row=30;}
		   
           $Out .= qq!<tr>
									<td nowrap align="right" nowrap><b>$Counter-</b></td>
									<td nowrap align="right"><input type="checkbox" name="X_Del\:\:$Key2" value="1" style="BORDER-RIGHT: 0px solid; PADDING-RIGHT: 0px; BORDER-TOP: 0px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; BORDER-LEFT: 0px solid; PADDING-TOP: 0px; BORDER-BOTTOM: 0px solid; BACKGROUND-COLOR: #FFFFFF"></td>
									<td nowrap><B>$Key1</b></td>
									<td width="100%"><textarea name="$Key2" rows=$Row cols="52" wrap="virtual">$Value</textarea></td>
							</tr>!;
        }
        else { 
           $Out .= qq!<tr>
								<td nowrap align="right"><b>$Counter-</b></td>
								<td nowrap align="right"><input type="checkbox" name="X_Del\:\:$Key2" value="1" style="BORDER-RIGHT: 0px solid; PADDING-RIGHT: 0px; BORDER-TOP: 0px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; BORDER-LEFT: 0px solid; PADDING-TOP: 0px; BORDER-BOTTOM: 0px solid; BACKGROUND-COLOR: #FFFFFF"></td>
								<td nowrap><b>$Key1</b></td>
								<td  width="100%"><input type="text" name="$Key" value="$Value" size="60"></td>
							</tr>!;
        }

	}

	$Out.=qq!<tr><td colspan="4"  align="center" height="40">
								<input type="submit" value="Save Changes"> &nbsp;<input type="reset" value="Restore">
					     </td>
					  </tr>!;


	$Counter++;
	$Out .= qq!<tr><td colspan="4" align="center" nowrap><B>Add New Language Variable to This File</b></td></tr>
					  <tr>
					  <td align="center" colspan="3" valign="top" nowrap>Variable Name (Case Sensitive)<br>
                       <input name="New_Variable" size="40" > </TD>
					   <td width="100%">Variable Text Value (HTML is allowed)<br>
							<textarea rows="4" name="New_Value" COLS="52"></textarea>	
					   </td></tr>!;

	return $Out;
	
}
#==========================================================
sub Save_Language_File{
my ($Filename, $Key, $Value, @Keys, %Param1);

	$Filename="$Global{Language_Dir}/$Param{Language}/$Param{Filename}";
	open(FILE,">$Filename") or &Exit( "Error: Can't open file $Filename: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
	#----------------------------------------------------------------
	%Param1 = %Param;
	delete $Param1{action};
	delete $Param1{Filename};
	delete $Param1{Language};
	delete $Param1{New_Variable};
	delete $Param1{New_Value};
	delete $Param1{CatA_ID};
	delete $Param1{CatB_ID};
	delete $Param1{Cat_ID};
	#----------------------------------------------------------------
	foreach $Key (keys %Param1){
			 if ($Key =~ /^X_Del\:\:/) {
					($Temp, $K) = split(/\:\:/, $Key);
					delete $Param1{$Key};
					 $K = &Web_Decode($K);
					delete $Param1{$K};
					next;
			 }
	}

	@Keys = sort { $a <=> $b} keys %Param1;

	foreach $Key (@Keys){
			$Value = $Param{$Key};
			 $Key1 = &Web_Decode($Key);

					 $Value =~ s/\n/ /g;
					 $Value =~ s/\r/ /g;
					 $Value =~ s/\cM/ /g;
					 $Key = &Web_Decode($Key);
					 print FILE "$Key~==~$Value\n";
   }

   if ($Param{New_Variable}) { 
			$Param{New_Value} =~ s/^\s+//;
			$Param{New_Value} =~ s/\s+$//;
			$Param{New_Value} =~ s/\n/ /g;
			$Param{New_Value} =~ s/\r/ /g;
			$Param{New_Value} =~ s/\cM/ /g;
			print FILE "$Param{New_Variable}~==~$Param{New_Value}\n";
   }

	close(FILE);
	
	#&Admin_Msg("File Saved", "Language File Successfully Saved.",2);
	&Edit_Language_File(qq!<font color="red"><b>Language File Successfully Saved.</b></font>!);
}
#==========================================================
sub Edit_Language_File_Form{
my ($Message) = @_;
my ($Variables, $Langfile, $FilesList, $LangList, $BarTop);

	$Variables = &Load_Language_File;
	$Langfile = $Param{Filename};
	$Langfile =~ s/\.pm//g;
	
#$Param{Language}/$Param{Filename}
	$LangList = &Language_List($Param{Language});
	$FilesList = &List_Language_Files($Param{Filename});

	$BarTop = qq!<a href="$Script_URL?action=Language_Manager">Language Manager</a>!;

$Out=<<HTML;
<table border="0" cellspacing="1" cellpadding="3" width="100%">
<tr>
<form method="post" action="$Script_URL">
 <input type="hidden" name="action" value="Edit_Language_File">
	<td nowrap>$BarTop\:\:</td>
	<td nowrap><select SIZE="1" NAME="Language">$LangList</select></td>
	<td nowrap><select name="Filename" size="1">$FilesList</select></td>
	<td width="100%" align="left"><input type="submit" name="b1" value="Load"></td>
	</form>
	</tr>
</table>

<table border="0" cellspacing="0" cellpadding="1" width="100%">
<tr><td align="center">$Message</td></tr>
</table>

<form method="post" action="$Script_URL">
<input type="hidden" name="action" value="Save_Language_File">
<input type="hidden" name="Filename" value="$Param{Filename}">
<input type="hidden" name="Language" value="$Param{Language}">

<table border="0" width="100%" cellspacing="1" cellpadding="2" $Global{Admin_Table_Attr}>
  <tr><td width="100%">
		<table width="100%" border="1" cellspacing="0" cellpadding="2" $Global{Admin_Table_Attr}>
		  $Variables
		</table>
	</td>
  </tr>
  <tr><td width="100%" colspan="4" align="center">
			<input type="submit" value="Create New Variable"> &nbsp;
			<input type="reset" value="Reset">&nbsp;
	  </td>
  </tr>
		  
</table>
</form>
HTML
	return $Out;
};
#==========================================================
sub Scan_Directory_Tree{
my($Directory) = @_;
my(@Directories, %Found);

	%Found = &Scan_Dir($Directory);
	undef @Directories;
	while (($Key, $Value)= each %Found) {
			if ($Value) {
				push @Directories, $Key;
			}
	}
	return @Directories;
}
#==========================================================
sub Scan_Directory{
my($Directory)=@_;
my(@Files, %Found);

	%Found = ();
	@Files = ();
	my $CRLF = "\015\012"; # how lines should be terminated; "\r\n" is not correct on all systems, for instance MacPerl defines it to "\012\015"
	%Found = &Scan_Dir($Directory);
	while (($Key, $Value)= each %Found) {
			if (!$Value) {
				push @Files, $Key;
			}
	}
	return @Files;
}
#==========================================================
sub Scan_Dir{
my($Directory)=@_;
my(@Directories, @Files, %Found);
my($Current_Directory);

	undef @Directories;
	undef %Found;
	undef @Files;
	if (!$Directory) {$Directory = '.';}
	push @Directories, $Directory;
	while (@Directories) {
		   $Current_Directory = shift (@Directories);
		   opendir (DIR, "$Current_Directory") 
					or &Exit( "Cannot open directory $Current_Directory: $!\n"."<BR>Line ". __LINE__ . ", File ". __FILE__);
		   @Files = readdir (DIR);
		   closedir (DIR);
		   foreach $File (@Files) {
					$Temp = "$Current_Directory/$File";
					  if (-d $Temp && $File ne "." && $File ne "..") {
								push @Directories, $Temp;
								$Found{$Temp} = 1;
								next;
					  }
					  else{
								if ($File ne "." && $File ne "..") {
										$Found{$Temp} = 0;
								}
					  }
			}
	}
	return %Found;
}
#==========================================================
sub Search_Language{
my ($Help);

	$Param{Terms} ||= ""; 
	$Param{FindVariable} ||= "";
	if ((!$Param{Terms} && !$Param{FindVariable}) || !$Param{Language}) {&Language_Manager; return;}

	$Help = &Help_Link("Language_Manager");
	&Print_Page(&Search_Language_Form, "Search Language",  $Help);
}
#==========================================================
sub Search_Language_Form{
my ($Dir, %Lang, @Files, $File, $Out, $Terms, $Key);
my ($Result, $Found, $Counter, @Keys, $Value, $Variable);

	$Dir = "$Global{Language_Dir}/$Param{Language}";
	
	undef @Files;
	opendir(Dir, "$Dir");
	foreach $File(readdir(Dir)) {
		if ($File =~ m/\.pm$/i && (-f  "$Dir/$File")) {
			push (@Files, "$File");
		}
    }
	closedir(Dir);
	@Files = sort @Files;

	$Out = "";
	$Terms = $Param{Terms};
	$Terms =~ s/\$//g;
	$Terms =~ s/\?//g; 
	$Terms =~ s/\(//g;
	$Terms =~ s/\)//g;
	$Terms =~ s/\[//g;
	$Terms =~ s/\]//g;

	$Terms = lc($Terms);
	$Terms =~ s/^\s+//;
	$Terms =~ s/\s+$//;
	$Terms =~ s/\'/\\'/g;
	
	$Variable = lc($Param{FindVariable});
	$Variable =~ s/^\s+//;
	$Variable =~ s/\s+$//;
	$Variable =~ s/\'/\\'/g;
	
	$Out = "";

	foreach $File (@Files) {
			undef %Lang;
			%Lang = &Get_Language_File("$Dir/$File");
			@Keys= sort keys %Lang;
			
			$Result = "";
			$Found = 0;
			$Counter = 1;
			foreach $Key (@Keys) {
					$Value = $Lang{$Key};
					if (($Terms && $Value =~ /$Terms/i) || ($Variable && lc($Key) eq $Variable)) {
							$Found ++;
							$Result .= "#$Counter: $Key, ";
					}
					$Counter++;
			}
			$Result =~ s/\,\s*$//;
			if ($Found) {
				$Out .= qq!&nbsp;<A HREF="$Script_URL?action=Edit_Language_File&Language=$Param{Language}&Filename=$File" target="_blank"><U>$File</U></A>!;
				$Out .=  qq!: $Found matches found<BR>!;
				$Out .=  qq!&nbsp;Variables: $Result<BR><BR>!;
			}
	}
	
	if (!$Out) {$Out = "<BR><B>No match results found.</B><BR><BR>";	}
	$Out ="<BR><B>&nbsp;Search results for <I><FONT COLOR=\"RED\">$Terms $Param{FindVariable}</FONT></I></B><BR><BR>$Out";
	return $Out;

}
#==========================================================
sub Replace_Language{
my($Help);

	$Param{FindText} ||= "";
	$Param{ReplaceWith} ||= "";

	if (!$Param{FindText} || !$Param{Language}) {&Language_Manager; return;}

	$Help = &Help_Link("Language_Manager");
	&Print_Page(&Replace_Language_Form, "Search Language",  $Help);

}
#==========================================================
sub Replace_Language_Form{
my ($Dir, %Lang, @Files, $File, $Out, $Terms, $Key);
my ($Result, $Found, $Counter, @Keys, $Value, $Replace);

	$Dir = "$Global{Language_Dir}/$Param{Language}";
	
	undef @Files;
	opendir(Dir, "$Dir");
	foreach $File(readdir(Dir)) {
		if ($File =~ m/\.pm$/i && (-f  "$Dir/$File")) {
			push (@Files, "$File");
		}
    }
	closedir(Dir);
	@Files = sort @Files;

	$Terms = $Param{FindText};
	$Terms =~ s/\$//g;
	$Terms =~ s/\?//g; 
	$Terms =~ s/\(//g;
	$Terms =~ s/\)//g;
	$Terms =~ s/\[//g;
	$Terms =~ s/\]//g;

	#$Terms = lc($Terms);
	$Terms =~ s/^\s+//;
	$Terms =~ s/\s+$//;
	$Terms =~ s/\'/\\'/g;
	
	$Replace = $Param{ReplaceWith};

	$Out = "";

	foreach $File (@Files) {
			undef %Lang;
			%Lang = &Get_Language_File("$Dir/$File");
			@Keys = sort keys %Lang;
			
			$Result = "";
			$Found = 0;
			$Counter = 1;

			foreach $Key (@Keys) {
					chomp ($Lang{$Key});
					$Value = $Lang{$Key};
					if ($Value =~ /$Terms/) {
							$Lang{$Key} =~ s/$Terms/$Replace/g;
							$Found ++;
							$Result .= "#$Counter: $Key, ";
					}
					$Counter++;
			}

			$Result =~ s/\,\s*$//;

			if ($Found > 0) {
				open (OUT, ">$Dir/$File") || &Exit("Can't create language file $Dir/$File: $!"."<BR>Line ". __LINE__ . ", File ". __FILE__);
				foreach $Key (@Keys) {
						print OUT "$Key~==~$Lang{$Key}\n";
				}
				close OUT;

				$Out .= qq!&nbsp;<A HREF="$Script_URL?action=Edit_Language_File&Language=$Param{Language}&Filename=$File" target="_blank"><U>$File</U></A>!;
				$Out .=  qq!: $Found matches found<BR>!;
				$Out .=  qq!&nbsp;Variables: $Result<BR><BR>!;
			}
	}
	
	if (!$Out) {$Out = "<BR><B>No match results found.</B><BR><BR>";	}
	$Out ="<BR><B>&nbsp;Search results for <I><FONT COLOR=\"RED\">$Terms</FONT></I></B><BR><BR>$Out";
	return $Out;

}
#==========================================================

1;