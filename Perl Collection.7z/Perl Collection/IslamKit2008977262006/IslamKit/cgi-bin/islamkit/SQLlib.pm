=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub GetQuranNamesAll {
my ($Query, $sth, @Name, $Temp);

	$Query = qq!SELECT Name FROM QuranConfig ORDER BY Sort, Name !;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef @Name;
	while (($Temp) = $sth->fetchrow_array){
		push @Name, $Temp;
	}
	$sth->finish;
	return @Name;
}
#==========================================================
sub GetQuranNames {
my ($Type) = @_;
my ($Query, $sth, @Name, $Temp);
	
	$Type ||= 0;
	$Query = qq!SELECT Name FROM QuranConfig WHERE Type=$Type AND Active=1 ORDER BY Sort, Name !;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef @Name;
	while (($Temp) = $sth->fetchrow_array){
		push @Name, $Temp;
	}
	$sth->finish;
	return @Name;
}
#==========================================================
sub GetQuranConfig {
my ($Name) = @_;
my ($Query, $sth, %Info, $Temp);
	
	$Name = $dbh->quote($Name);
	$Query = qq!SELECT * FROM QuranConfig WHERE Name=$Name!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Info;
	while ($Temp = $sth->fetchrow_hashref){%Info = %{$Temp}; last;}
	$sth->finish;
	return %Info;
}
#==========================================================
sub GetQuranName {
my ($Name) = @_;
my ($Query, $sth,  $Temp);
	
	$Lang = $dbh->quote($Global{Language});
	$Name = $dbh->quote($Name);
	$Query = qq!SELECT LangName FROM QuranName WHERE Name=$Name AND Language=$Lang!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$Name = "";
	while (($Temp) = $sth->fetchrow_array){$Name = $Temp; last;}
	$sth->finish;
	return $Name;
}
#==========================================================
sub GetQuranLangName {
my ($Name, $Lang) = @_;
my ($Query, $sth,  $Temp);
	
	$Lang = $dbh->quote($Lang);
	$Name = $dbh->quote($Name);
	$Query = qq!SELECT LangName FROM QuranName WHERE Name=$Name AND Language=$Lang!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$Name = "";
	while (($Temp) = $sth->fetchrow_array){$Name = $Temp; last;}
	$sth->finish;
	return $Name;
}
#==========================================================
sub GetAyahQuran {
my ($Name, $Type, $Surah, $Ayah) = @_;
my ($Query, $sth, $Quran, $Temp);
	
	$Name = $dbh->quote($Name);
	$Query = qq!SELECT Quran FROM Quran$Type WHERE Name=$Name AND Surah=$Surah AND Ayah=$Ayah!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$Quran = "";
	while (($Temp) = $sth->fetchrow_array){$Quran = $Temp; last;}
	$sth->finish;
	return $Quran;
}
#==========================================================
sub GetQuranSurahNames {
my ($Name) = @_;
my ($Query, $sth, %Names, $Temp);
	
	$Name = $dbh->quote($Name);
	$Query = qq!SELECT Surah,  SurahName FROM SurahName WHERE Name=$Name!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Names;
	while (($Surah,  $SurahName) = $sth->fetchrow_array){
		$Names{$Surah} = $SurahName;
	}
	$sth->finish;
	return %Names;
}
#==========================================================
sub GetRecitersID {
my ($Query, $sth, @ID, $Temp);

	$Query = qq!SELECT ID FROM Reciters ORDER BY Reciter!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef @ID;
	while (($Temp) = $sth->fetchrow_array){
		push @ID, $Temp;
	}
	$sth->finish;
	return @ID;
}
#==========================================================
sub GetSurahRecitersID {
	return &GetRecitersByType(1);
}
#==========================================================
sub GetAyahRecitersID {
	return &GetRecitersByType(2);
}
#==========================================================
sub GetRecitersByType {
my ($Type) = @_;
my ($Query, $sth, @ID, $Temp);

	$Query = qq!SELECT ID FROM Reciters WHERE Type=$Type ORDER BY Reciter!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef @ID;
	while (($Temp) = $sth->fetchrow_array){
		push @ID, $Temp;
	}
	$sth->finish;
	return @ID;
}
#==========================================================
sub GetReciter {
my ($ID) = @_;
my ($Query, $sth,  $Temp, %Reciter);
	
	$ID || return undef;
	$Query = qq!SELECT * FROM Reciters WHERE ID=$ID!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Reciter;
	while ($Temp = $sth->fetchrow_hashref){%Reciter = %{$Temp}; last;}
	$sth->finish;
	return %Reciter;
}
#==========================================================
sub GetReciterByName {
my ($Reciter, $Type) = @_;
my ($Query, $sth,  $Temp, %Reciter);
	
	$Reciter = $dbh->quote($Reciter);
	$Query = qq!SELECT * FROM Reciters WHERE Reciter=$Reciter AND Type=$Type!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Reciter;
	while ($Temp = $sth->fetchrow_hashref){%Reciter = %{$Temp}; last;}
	$sth->finish;
	return %Reciter;
}
#==========================================================
sub GetReciterByFolder {
my ($Folder, $Type) = @_;
my ($Query, $sth,  $Temp, %Reciter);
	
	$Folder || return undef;
	$Folder = $dbh->quote($Folder);
	$Query = qq!SELECT * FROM Reciters WHERE Folder=$Folder AND Type=$Type!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	undef %Reciter;
	while ($Temp = $sth->fetchrow_hashref){%Reciter = %{$Temp}; last;}
	$sth->finish;
	return %Reciter;
}
#==========================================================
sub GetReciterName {
my ($Reciter) = @_;
my ($Query, $sth,  $Temp, $Name);
	
	$Lang = $dbh->quote($Global{Language});
	$Query = qq!SELECT Name FROM ReciterName WHERE ID=$Reciter AND Language=$Lang!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$Name = "";
	while (($Temp) = $sth->fetchrow_array){$Name = $Temp; last;}
	$sth->finish;
	return $Name;
}
#==========================================================
sub GetReciterLangName {
my ($Reciter, $Lang) = @_;
my ($Query, $sth,  $Temp, $Name);
	
	$Lang = $dbh->quote($Lang);
	$Query = qq!SELECT Name FROM ReciterName WHERE ID=$Reciter AND Language=$Lang!;
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$Name = "";
	while (($Temp) = $sth->fetchrow_array){$Name = $Temp; last;}
	$sth->finish;
	return $Name;
}
#==========================================================
#==========================================================
sub Import_Table{
my ($Table, $Delimiter, $Escape, $EOLine, $File)=@_;
my ($Query, $sth);

	$File = $dbh->quote($File);
    $Delimiter = $dbh->quote($Delimiter);
    $Escape = $dbh->quote($Escape);
	$EOLine = "'" . $EOLine . "'";

	$Query = qq!LOAD DATA INFILE $File INTO TABLE $Table
						FIELDS 
						TERMINATED BY $Delimiter 
						ESCAPED BY $Escape
						LINES TERMINATED BY $EOLine!;
        
    $sth = $dbh->do($Query);
}
#==========================================================
sub Export_Table{
my ($Table, $Delimiter, $Escape, $EOLine, $File)=@_;
my ($Query, $sth);

	$File = $dbh->quote($File);
    $Delimiter = $dbh->quote($Delimiter);
    $Escape = $dbh->quote($Escape);
	$EOLine = "'" . $EOLine . "'";

	$Query = qq!SELECT * INTO OUTFILE $File FIELDS TERMINATED BY $Delimiter 	ESCAPED BY $Escape LINES TERMINATED BY $EOLine FROM $Table!;
        
	#$sth = $dbh->do($Query);
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	#while(@Row = $sth->fetchrow_array) {
	#	print "@Row <br>";
	#}

	$sth->finish;

}
#==========================================================
sub Get_Table_Fields{
my($Table) = shift;
my (@Fields, $Query, $sth);
my($Field, $type, $null, $key, $default, $extra);
return;
	$Query = qq!SHOW COLUMNS FROM $Table!;
	$sth=&DB_Query($Query);

	while(($Field, $type, $null, $key, $default, $extra) = $sth->fetchrow_array) {
			push(@Fields, $Field);
	}

	return @Fields;
}
#==========================================================
sub Get_Col_Type{   
my $Table = shift;
my ($sth, $Query, @array, @Type);
# Gets the type each field/column of the table specified.

    $Query = "DESCRIBE $Table";
    $sth = &DB_Query($Query);
    
	while (@array = $sth->fetchrow_array()) {
        #push (@Type, $array[0]); #Filed Name
		push (@Type, $array[1]); #Field type
    }

    $sth->finish();
    return @Type;
}
#==========================================================
sub Get_PRI_Key{
my $Table = shift;
my ($sth, $Query, @array, @PRI_Key);
# Gets the primary key of the table specified.
    
    @PRI_Key = ();
    $Query = "DESCRIBE $Table";
    $sth = &DB_Query($Query);
    while (@array = $sth->fetchrow_array) {
        if ($array[3] eq 'PRI') { push(@PRI_Key, $array[0]); }
    }
    $sth->finish();

    return @PRI_Key;
}
#==========================================================
sub DB_Connect{
my ($Driver);

	if ($Global{DB_Driver} =~ m/ODBC/i) {
		$dbh = DBI->connect("DBI:ODBC:$Global{DB_DSN}", $Global{DB_UserID}, $Global{DB_Password}) || &DB_Exit("DBI:ODBC:$Global{DB_DSN} <br>Line ".__LINE__ . ", File ". __FILE__);
		return;
	}

   $DSN = "DBI:$Global{DB_Driver}:database=$Global{DB_Name};host=$Global{DB_Host};port=$Global{DB_Port}";
   $dbh = DBI->connect($DSN, $Global{DB_UserID}, $Global{DB_Password}) || &DB_Exit("$DSN");
}
#==========================================================
sub DB_Start{

	&DB_Connect();

	#SELECT * FROM pet WHERE name REGEXP "^b"; case sensitive
	#SELECT * FROM pet WHERE name REGEXP "^[bB]";
	#SELECT * FROM pet WHERE name REGEXP BINARY "^b";
	#SELECT * FROM pet WHERE name REGEXP "fy$";
	#SELECT * FROM pet WHERE name REGEXP "w";
	#SELECT * FROM pet WHERE name REGEXP "^.....$";
	#SELECT * FROM pet WHERE name REGEXP "^.{5}$";
	# Let SQL use temp disk tables instead of temp memory tables, slower but no errors
	#$SQL = qq!SET OPTION SQL_BIG_TABLES=1!;
	#$dbh->do($SQL);
	#------------------------------------------------------
}
#==========================================================
sub DB_Disconnect{
   $sth->finish if($sth);
   $dbh->disconnect if($dbh);
}
#==========================================================
sub DB_Query{
my $Query = shift;
my ($sth);
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__); 
	return $sth;
}
#==========================================================
sub Get_DB_List{
my($Query, $DB_Name );

	if ($Global{DB_Server} eq "MS_SQL") {
			$Query = "SELECT table_name FROM information_schema.tables";
	}
	else{
			$Query = "SHOW DATABASES";
	}

	$sth = &DB_Query($Query);
	while ($DB=$sth->fetchrow_array){
			push (@DB_Name, $DB);
	}
	$sth->finish;

	return @DB_Name;
}
#==========================================================
sub DB_Create{
my ($DB_Name) = shift;
my ($Query, $sth);

	#$Query = "CREATE DATABASE IF NOT EXISTS $DB_Name";
	$Query = "CREATE DATABASE $DB_Name";
	$sth = &DB_Query($Query);
	$sth->finish;

}
#==========================================================
sub DB_Drop{
my ($DB_Name) = shift;
my ($Query, $sth);

	#$Query = "DROP DATABASE IF EXISTS $DB_Name";
	$Query = "DROP DATABASE $DB_Name";
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Variables{
my ($Query, $sth, $Var, $Value, %Var);

	if ($Global{DB_Server} eq "MS_SQL") {
			$Query = "SELECT table_name FROM information_schema.tables";
	}
	else{
			$Query = "SHOW VARIABLES";
	}
	
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__); 
	
	undef %Var;

	while (($Var, $Value) = $sth->fetchrow_array) {
		$Var{$Var} = $Value;
    }

	$sth->finish;

	return %Var;
}
#==========================================================
sub DB_Show_Table{
my($Table) = shift;
my ($Query, $sth, %Var, $Var, @Row, $x);

	$Table = $dbh->quote($Table);

	if ($Global{DB_Server} eq "MS_SQL") {
			$Query = "SELECT * FROM information_schema.columns WHERE table_name=$Table";
	}
	else{
			$Query = qq!SHOW TABLE STATUS LIKE $Table!;
	}

	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__); 

	undef %Var;
	$x = 0;

	if ($Global{DB_Server} eq "MS_SQL") {
				while (@Row=$sth->fetchrow_array){
						$Var{$x++} = join " ", @Row;
				}
	}
	else{
				if (@Row = $sth->fetchrow_array){
						for (my $i = 0; $i < $sth->{NUM_OF_FIELDS}; $i++) {
							$Var{$sth->{NAME}->[$i]} = $Row[$i];
						}
				}
	}

	$sth->finish;
	return %Var;
}
#==========================================================
sub DB_STATUS{
my ($Query, $sth, $Var, $Value, %Var);

	if ($Global{DB_Server} eq "MS_SQL") {
			$Query = "SELECT table_name FROM information_schema.tables";
	}
	else{
			$Query = "SHOW STATUS";
	}
	
	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute() || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__); 
	
	undef %Var;

	while (($Var, $Value) = $sth->fetchrow_array) {
		$Var{$Var} = $Value;
    }

	$sth->finish;

	return %Var;
}
#==========================================================
sub DB_Show_Tables{
my ($Query, $sth, @DB_Tables, @Row);

	#@Servers = ("MySQL", "MS_SQL");
	if ($Global{DB_Server} eq "MS_SQL") {
			$Query = "SELECT table_name FROM information_schema.tables";
	}
	else{
			$Query = "SHOW TABLES";
	}

	$sth = $dbh->prepare($Query) || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);
	$sth->execute || &DB_Exit($Query."<br>Line ". __LINE__ . ", File ". __FILE__);

	undef @DB_Tables;
	while (@Row=$sth->fetchrow_array){
			push (@DB_Tables, $Row[0]);
	}

	$sth->finish;

	return @DB_Tables;
}
#==========================================================
sub DB_Drop_Table{
my ($Table) = shift;
my ($Query, $sth);

	$Query = "DROP TABLE $Table";
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Optimize_Table{
my ($Table) = shift;
my ($Query, $sth);

	$Query = "OPTIMIZE TABLE $Table";
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Empty_Table{
my ($Table) = shift;
my ($Query, $sth);

	$Query = "DELETE FROM $Table";
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Drop_Col{
my ($Table, $Column) = @_;
my ($Query, $sth);

	$Query = "ALTER TABLE $Table DROP $Column";
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Rename_Table{
my ($Old_Name, $New_Name) = @_;
my ($Query, $sth);

	$Query ="ALTER TABLE $Old_Name RENAME AS $New_Name";
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Delete_Entry{
my ($Table, $Entry_Modifier) = @_;
my ($Query, $sth);
	
	if ($Global{DB_Server} eq "MS_SQL") {
			$Query =  qq!DELETE TOP 1 FROM $Table WHERE $Entry_Modifier!;
	}
	else{
			$Query =  qq!DELETE FROM $Table WHERE $Entry_Modifier LIMIT 1!;
	}

	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Update_Entry{
my ($Table, $Entry_Modifier, @Fields) = @_;
my ($Query, $sth, $New_Entry);

	$New_Entry = join (",", @Fields); #each filed must be 'Field=Value'
	$Query =  "UPDATE $Table SET $New_Entry WHERE $Entry_Modifier";	
	$sth = &DB_Query($Query);
	$sth->finish;
}
#==========================================================
sub DB_Entry_Count{
my ($Table) = shift;
my ($Query, $sth, $Rows);

	$Query =  "SELECT COUNT(*) FROM $Table";	
	$sth = &DB_Query($Query);
	$Rows = $sth->fetchrow();
	$sth->finish;

	return $Rows;
}
#==========================================================
#==========================================================
sub DB_Error_Msg{
my ($Title, $Msg, $Level)=@_;
my $Out;

$Out=<<HTML;
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1252">
<TITLE>IslamWare - www.islamware.com</TITLE>
<STYLE >
<!--
 A:hover {color: #ff3300 ;} 
-->
</STYLE>

<STYLE TYPE="text/css">
<!--
.lwr  a:link    { color: white; }
.lwr  a:visited { color: white; }
.lwr  a:active  { color: #ff3300; }
.lwr  a:hover   { color: red; background-color : yellow;}
.lwr  a{ text-decoration: none }

.lbr  a:link    { color: blue; }
.lbr  a:visited { color: blue; }
.lbr  a:active  { color: #ff3300; }
.lbr  a:hover   { color: red; background-color : #FFFF00;}
.lbr  a{ text-decoration: none }
-->
</STYLE>
</head>

<body bgcolor="#FFFFFF" >
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>

<div class="lbr" align="center">
  <center>

<table border="0" width="405" bgcolor="#005329" >
  <tr>
    <td width="100%" align="center" HEIGHT="19"><b>
	<font color="#FFFF00" FACE="TIMES NEW ROMAN, ARIAL">
	
	$Title
	
	</font></b>
    </td>
  </tr>
  <tr>
    <td width="400">
      <DIV align="center">
      <table border="0" width="400" cellspacing="0" cellpadding="0" bgcolor="#E1E1C4">
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
          <DIV align="center">
            <table width="100%" border="0" cellpadding="3">
              <tr>
                <td width="100%" ALIGN="LEFT">
				
				$Msg
				
				</td>
              </tr>
            </TABLE>
          </DIV>
          </td>
        </tr>
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
		  <FORM>
                <P align="center">

				<input type=button value="--OK--" onClick="history.go(-$Level)">

  		  </FORM>
          </td>
        </tr>
      </TABLE>
      </DIV>
    </td>
  </tr>
</TABLE>
</CENTER>
</DIV>
</body>
</html>
HTML
	return $Out;
}
#==========================================================
sub DB_Exit{
my($Query, $Title, $Level)=@_;
my ($Out, $Message);

	if ($Title eq "") {$Title="SQL Error";}
	if ($Level !~ /^\d+$/) {$Level=1;}
	if (!$Query) {
			$Query = "";
	}
	else{
			$Query="<b>Query</b>: <br>$Query.<br>";
	}
	$Message="SQL Error: $DBI::errstr<br>$Query";
	$Out=&DB_Error_Msg($Title, $Message, $Level);
	print "Content-type: text/html\n\n";
	print "$Out";
	&DB_Disconnect();
	exit (0);
}
#==========================================================
1;
