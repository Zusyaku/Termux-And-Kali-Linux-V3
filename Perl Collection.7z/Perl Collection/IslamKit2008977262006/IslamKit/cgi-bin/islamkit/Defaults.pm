=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Get_General_Classes{

$Global{Header} =<<Header;
<html>
<head>
<title><!--CLASS::Meta_Title--></title>
<meta name="Keywords" content="<!--CLASS::Meta_Keywords-->">
<meta name="Description" content="<!--CLASS::Meta_Description-->">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<!--CLASS::HeadCode-->
<!---------------------------------------->
<script LANGUAGE="JavaScript">
function JS_OnLoad() {
<!--CLASS::JS_Code-->
}
</script>
<!---------------------------------------->
<style type="text/css">
<!--
body    {color: #FFFFFF; font-size: 10pt; FONT-FAMILY: Tahoma,Arial,helvetica,Times,sans-serif;}
td, th, p {font-size: 10pt;}

a            { color: #66FF66; font-family: Arial, Helvetica; text-decoration: underline }
a:hover      { color: #FFFF00; font-family: Arial, Helvetica; text-decoration: none }

.navlnk a    {font-family: Tahoma, Arial, Times, Helvetica; color: #FEFDC5; font-size: 12px; text-decoration: none; font-weight: bold}
.navlnk a:hover {font-family: Tahoma, Arial, Helvetica; color: #A6FFA6; font-size: 12px; text-decoration: underline; font-weight: bold}

.botnavlnk a    { font-family: Tahoma, Arial, Helvetica; color: #FEFBD6; font-size: 12px; text-decoration: none; font-weight: bold}
.botnavlnk a:hover { font-family: Tahoma, Arial, Helvetica; color: #66FF99; font-size: 12px; text-decoration: underline; font-weight: bold}

.navlnkb a    {font-family: Tahoma, Arial, Times, Helvetica; color: #141F1A; font-size: 12px; text-decoration: none; font-weight: bold}
.navlnkb a:hover {font-family: Tahoma, Arial, Helvetica; color: #996633; font-size: 12px; text-decoration: none; font-weight: bold}

.leftnav a    { font-family: Tahoma, Arial, Helvetica; color: #27342E; font-size: 12px; text-decoration: none; font-weight: bold}
.leftnav a:hover { font-family: Tahoma, Arial, Helvetica; color: #009900; font-size: 12px; text-decoration: none; font-weight: bold}

.sidenavbig a    { font-family: Tahoma, Arial, Helvetica; color: #6A2300; font-size: 12px; text-decoration: none; font-weight: bold}
.sidenavbig a:hover { font-family: Tahoma, Arial, Helvetica; color: #FF0000; font-size: 12px; text-decoration: none; font-weight: bold}

.mainlnk a   { font-family: Tahoma, Arial, Helvetica; color: blue; font-size: 12px; text-decoration: none }
.mainlnk a:hover { font-family: Tahoma, Arial, Helvetica; color: blue; font-size: 12px; text-decoration: underline }
.footnote    { font-family: Tahoma, Arial, Helvetica; font-size: 10px; color: #ffbb00 }

.botlnk a    { font-family: Tahoma, Arial, Helvetica; color: #FF8000; font-size: 12px; text-decoration: none }
.botlnk a:hover { font-family: Tahoma, Arial, Helvetica; color: #FFFF99; font-size: 12px; text-decoration: underline }

.dtd         { font-family: Tahoma, verdana, helvetica; color: #99CC00; font-size: 12px; font-weight: bold }
.cat         { font-family: Tahoma, Arial, Helvetica; color: #99CC00; font-size: 10px; font-weight: normal }
.slnk a      { color: #552b00; font-family: Tahoma, Arial, Helvetica; font-size: 12px; text-decoration: underline }
.slnk a:hover { color: #e600e6; font-family: Tahoma, Arial, Helvetica; font-size: 12px; text-decoration: underline }
.wlnk a      { color: #FFFFFF; font-family: Tahoma, Arial, Helvetica; font-size: 12px; text-decoration: underline }
.wlnk a:hover { color: #e600e6; font-family: Tahoma, Arial, Helvetica; font-size: 12px; text-decoration: underline }
textareaX     { background-color: #ffffea; color: #003333; border-color: green;border-width:1px; }
inputX        { background-color:#ffffea; color: #003333;border-color: green;border-width: 1px; border-style: groove; font-size:13px; font-weight: normal;}
buttonX     { background-color:#ffffea; color: #003333;border-color: green;border-width: 1px; border-style: groove; font-size:13px; font-weight: normal;}
optionX      { background-color:#ffffea; color: #003333;border-color: green;border-width: 1px; border-style: groove; font-size:13px; font-weight: normal;}

body {
scrollbar-base-color: #E1AC5B;
}

-->
</style>

</head>
<body [[language_direction]] bgcolor="#8E5C24" onload="JS_OnLoad()" leftmargin="0" topmargin="0" marginheight="0" marginwidth="0">
Header
#----------------------------------------------------------
$Global{Footer} =<<Footer;
<!--CLASS::PoweredBy-->
</body>
</html>
Footer
#----------------------------------------------------------
$Global{PoweredBy} =<<PoweredBy;
<!--
	We request you retain the full copyright notice below including the links to www.islamware.com,
	Unless you buy a license from Islamware or have some agreement to remove this copyright
	noitce, please do NOT remove it or you will be violating this free software license.
	Copyright � 2006 Islamware www.ismalware.com. Donate for Islamware to keep this software
	and other products and developments free for everyone one.
-->
<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
    <tr>
      <td width="100%" align="center"><font size="1">Powered by <a target="_blank" href="http://www.islamware.com">IslamKit</a>. All rights reserved.</font></td>
    </tr>
  </table>
  </center>
</div>
PoweredBy
#----------------------------------------------------------
$Global{Message_Form}=<<HTML;
<DIV align="center">
  <CENTER>
  <table border="0" width="605" bgcolor="#FFFFFF" cellspacing="0" cellpadding="3">
    <tr>
      <td width="100%" align="center">
			<b><font color="red">
		    <!--Title-->
			</font></b>
	</td>
    </tr>

    <tr>
      <td width="600">
        <DIV align="center">
          <table border="0" width="600" cellspacing="0" cellpadding="10" bgcolor="#FFFFFF">
            <tr>
              <td valign="middle" ALIGN="left" width="100%">
				        <!--Message-->
              </td>
            </tr>
            <tr>
              <td valign="middle" align="center" width="100%">
                <FORM>
                  <P align="center">
				  [[ok_message_button]]
                  </P>
                </td>
              </tr>
            </TABLE>
          </DIV>
        </td>
      </tr>
    </TABLE>
  </CENTER>
  </DIV>
HTML
#----------------------------------------------------------
$Global{Error_Form}=<<HTML;
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>IslamWare - www.islamware.com</title>
<STYLE >
<!--
 A:hover {color: #ff3300 ;} 
-->
</STYLE>

<STYLE TYPE="text/css">
<!--
.lwr  a:link    { color: white; }
.lwr  a:visited { color: white; }
.lwr  a:active  { color: #ff3300; }
.lwr  a:hover   { color: red; background-color : yellow;}
.lwr  a{ text-decoration: underline }

.lbr  a:link    { color: blue; }
.lbr  a:visited { color: blue; }
.lbr  a:active  { color: #ff3300; }
.lbr  a:hover   { color: red; background-color : #FFFF00;}
.lbr  a{ text-decoration: underline }
-->
</STYLE>
</HEAD>
<BODY bgcolor="#FFFFFF" >

<div class="lbr" align="center">
  <center>

<table border="0" width="405" bgcolor="#005329" >
  <tr>
    <td width="100%" align="center" HEIGHT="19"><b>
	<font color="#FFFF00" FACE="TIMES NEW ROMAN, ARIAL">
	
	<!--Title-->
	
	</font></b>
    </td>
  </tr>
  <tr>
    <td width="400">
      <DIV align="center">
      <table border="0" width="400" cellspacing="0" cellpadding="0" bgcolor="#E1E1C4">
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
          <DIV align="center">
            <table width="100%" border="0" cellpadding="3">
              <tr>
                <td width="100%" ALIGN="LEFT">
				
				<!--Message-->
				
				</td>
              </tr>
            </TABLE>
          </DIV>
          </td>
        </tr>
        <tr>
          <td valign="middle" align="center" bgcolor="#FFFFD9">
		  <FORM>
				<INPUT TYPE="button" VALUE="--Ok--" onClick="history.go(<!--Level-->)">
  		  </FORM>
          </td>
        </tr>
      </TABLE>
      </DIV>
    </td>
  </tr>
</TABLE>
</CENTER>
</DIV>

</BODY>
</HTML>
HTML
#----------------------------------------------------------
$Global{Top_Navigation} =<<Top_Navigation;
<div align="center">
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFF8CE">
	<tr><td width="100%" height="30" background="<!--CLASS::Theme_Images_URL-->/topnavbg.jpg">
	<table border="0" cellpadding="0" cellspacing="0"  height="30">
	  <tr class="navlnk">
		<td width="20">&nbsp;&nbsp;</td>
		<td align="center" class="navlnk" nowrap><a href="<!--CLASS::Home-->">[[home]]</a>&nbsp;<font color="#76763A" size="2">|</font></td>
		<td align="center" class="navlnk" nowrap><a href="<!--CLASS::Quran-->">[[quran]]</a>&nbsp;<font color="#76763A" size="2">|</font></td>
		<td align="center" class="navlnk" nowrap><a href="<!--CLASS::Language-->">[[set_language]]</a>&nbsp;<font color="#76763A" size="2">|</font></td>
		<td align="center" class="navlnk" nowrap><a href="<!--CLASS::Help-->">[[help]]</a></td>
		<td width="100%" align="center" class="navlnk" nowrap>
				<table border="0" cellpadding="0" cellspacing="0">
						<tr><td></td>
						<td align="center"  width="200">
							<font color="#FFFFCC"><!--[[MarqueeXX]]--></font>
							<marquee style="CURSOR: pointer; font-family: tahoma; font-size: 9pt; color: #990000; font-weight: normal" direction="right" align="middle" scrollamount="1" scrolldelay="90" dir="rtl" id="scroller" onMouseover="this.scrollAmount=this.scrollAmount" alt="Click to Start/Stop" onMouseout="this.scrollAmount=this.scrollAmount" onClick="this.scrollAmount=!this.scrollAmount"> [[nav_center_msg]]</marquee>
						</td>
						<td></td>
						</tr>
				</table>
		</td>
		<td align="right" class="navlnk" nowrap><font color="#FFFFCC"><!--CLASS::Date_Time:11--></font>&nbsp;</td>
	  </tr>
	</table>
	</td></tr>
</table>
</div>
Top_Navigation
#----------------------------------------------------------
$Global{Top_Area}=<<HTMLtop;
<table border="0" width="100%" cellspacing="0" cellpadding="0" height="60">
<tr><td width="100%" align="center" nowrap  background="<!--CLASS::Theme_Images_URL-->/topareabg.jpg">
  <table border="0" width="100%" cellspacing="0" cellpadding="0" height="60">
	<tr>
			<td ><a href="<!--CLASS::Home-->"><img src="<!--CLASS::Theme_Images_URL-->/logo.gif" alt="" border="0"></a></td>
			<td width="100%" align="center" nowrap><img src="<!--CLASS::Theme_Images_URL-->/allah1.gif" alt=""border="0"></td>
			<td><img src="<!--CLASS::Theme_Images_URL-->/topright.gif" alt="" border="0"></td>
	</tr>
  </table>
</td></tr>
</table>
HTMLtop
	#topareabg.jpg
#----------------------------------------------------------
$Global{Welcome_Area}=<<Welcome_Area;
<table border="0" width="100%" bgcolor="#FFCC80" cellspacing="0" cellpadding="2">
  <tr>
	<td width="100%" ALIGN="left"><font color="#000000">&nbsp;</font>
	<font  color="#000000" FACE="TAHOMA, ARIAL, TIMES"><!--CLASS::Welcome_User--></font>
	</td>
	<td align="right" NOWRAP><font color="#000000"><!--CLASS::Date_Time:11--></font>&nbsp;</td>
  </tr>
</TABLE>
<table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td height="1" width="100%" bgcolor="#663300"><img src="<!--CLASS::Theme_Images_URL-->/dot1x1.gif" width="1" height="1" alt border="0"></td></tr></table>
Welcome_Area
#----------------------------------------------------------
$Global{Guide}=<<HTMLdu;
<DIV align="center">
  <table border="0" width="100%" cellspacing="0" cellpadding="2">
	<tr><td ALIGN="left" NOWRAP><!--CLASS::Menu_Bar--></td>
	  <td align="right" NOWRAP></td>
	</tr>
  </TABLE>
</DIV>
HTMLdu
#----------------------------------------------------------
$Global{Bottom_Navigation} =<<Bottom_Navigation;
<div align="center">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr><td width="100%" height="30" background="<!--CLASS::Theme_Images_URL-->/topnavbg.jpg">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
	<td width="10">&nbsp;</td>
	<td align="center" class="botnavlnk" nowrap><a href="<!--CLASS::Home-->">[[home]]</a>&nbsp;<font color="#76763A" size="2">|</font></td>
	<td align="center" class="botnavlnk" nowrap><a href="<!--CLASS::Contact_Us-->">[[contact_us]]</a>&nbsp;<font color="#76763A" size="2">|</font></td>
	<td align="center" class="botnavlnk" nowrap><a href="<!--CLASS::Announcements-->">[[announcements]]</a>&nbsp;<font color="#76763A" size="2">|</font></td>
    <td align="center" class="botnavlnk" nowrap><a href="<!--CLASS::About_Us-->">[[about_us]]</a>&nbsp;</td>
	<td align="center" class="botnavlnk" nowrap width="100%"></td>
  </tr>
</table>
</td></tr>
</table>
</div>
Bottom_Navigation
#----------------------------------------------------------
$Global{Bottom} =<<Bottom;
<table width="100%" cellpadding="1" cellspacing="0" border="0">
<tr>
<td width="100%" align="center" class="botlnk">
<font face="Tahoma, Arial, Helvetica" color="#FFCC66" size="2">[[copyright]]&nbsp;</font>
	<a href="<!--CLASS::Copyright-->">[[copyright_label]]</a>
</td>
</tr>
</table>
Bottom
#----------------------------------------------------------
$Global{Side_Navigation} =<<HTMLe;
<div class="lwr" align="center">
<table border=0 width="100%" align=center valign=middle cellspacing="1" cellpadding="4">
<tr><td width="100%" bgcolor="#FFFFFF" align="center">

</td></tr>
</table>
</div>
HTMLe
#----------------------------------------------------------
$Global{Left_Navigation} =<<HTMLe1;
<div class="lwr" align="center">
<table border=0 width="100%" align=center valign=middle cellspacing="1" cellpadding="4">
<tr><td width="100%" bgcolor="#FFFFFF" align="center">

</td></tr>
</table>
</div>
HTMLe1
#----------------------------------------------------------
$Global{Right_Navigation} =<<HTMLe2;
<div class="lwr" align="center">
<table border=0 width="100%" align=center valign=middlE cellspacing="1" cellpadding="4">
<tr><td width="100%" bgcolor="#FFFFFF" align="center">

</td></tr>
</table>
</div>
HTMLe2
#----------------------------------------------------------
$Global{Announcements_Form}=<<Announcements_Form;
<div align="center"> <center>
<table border="0" width="100%" cellspacing="01" cellpadding="4">

  <tr><td width="100%" bgcolor="#E0E0C2" align="left" colspan="2">
      <b><font color="#660000" size="3"><!--Subject--></font></b></td>
  </tr>

  <tr>
  <td width="150" nowarp><b><font color="#663300">[[announcements_date]]</font></b></td>
	<td><font color="#663300"><!--Date:10--></font></td>
  </tr>

  <tr><td width="150" NOWARP><b><font color="#663300">[[announcements_name]]</font></b></td>
	<td><font color="#663300"><!--Name--></font></td>
  </tr>

  <tr><td width="150" NOWARP><b><font color="#663300">[[announcements_email]]</font></b></td>
	<td><font color="#663300"><a href="mailto: <!--Email-->"><!--Email--></a></font></td>
  </tr>

  <tr><td width="150" NOWARP><b><font color="#663300">[[announcements_url]]</font></b></td>
	<td><font color="#663300"><a href="<!--URL-->" target="_blank"><!--URL--></a></font></td>
  </tr>

  <tr><td width="150" nowarp valign="top"><font color="#663300"><b>[[announcements_message]]</b></font>
	</td><td width="80%"><font color="#663300"><!--Message--></font></td>
  </tr>
</table>
</center>
</div>
Announcements_Form
#----------------------------------------------------------
$Global{General} =<<HTMLg1; 
HTMLg1
#----------------------------------------------------------
$Global{Extra} =<<Extra1;
Extra1
#----------------------------------------------------------
$Global{Set_Language_Form}=<<Set_Language_Form;
<tr><td align="right">
	<input type="radio" value="<!--Language-->" name="Language_Selected" <!--Checked--> >
	</td><td width="100%"><!--Language_Name--></td>
</tr>
Set_Language_Form
$Global{Set_Language_Form1}=<<Set_Language_Form1;
<tr><td align="right">
	<input type="radio" value="<!--Language-->" name="Language_Selected" <!--Checked--> >
	</td><td width="100%" align="left"><!--Language_Name--></td>
</tr>
Set_Language_Form1
#------------------------------------------------------------------------------
$Global{Marquee}=<<Marquee;
<script language="JavaScript">
//Specify the marquee's width (in pixels)
var marqueewidth="200px"
//Specify the marquee's height
var marqueeheight="25px"
//Specify the marquee's marquee speed (larger is faster 1-10)
var marqueespeed=1
//Pause marquee onMousever (0=no. 1=yes)?
var pauseit=1

//Specify the marquee's content (don't delete <nobr> tag)
//Keep all content on ONE line, and backslash any single quotations (ie: that\'s great):

var marqueecontent='<nobr>[[MarqueeText]]</nobr>'


////NO NEED TO EDIT BELOW THIS LINE////////////
marqueespeed=(document.all)? marqueespeed : Math.max(1, marqueespeed-1) //slow speed down by 1 for NS
var copyspeed=marqueespeed
var pausespeed=(pauseit==0)? copyspeed: 0
var iedom=document.all||document.getElementById
if (iedom)
document.write('<span id="temp" style="visibility:hidden;position:absolute;top:-100px;left:-9000px">'+marqueecontent+'</span>')
var actualwidth=''
var cross_marquee, ns_marquee

function populate(){
if (iedom){
cross_marquee=document.getElementById? document.getElementById("iemarquee") : document.all.iemarquee
cross_marquee.style.left=parseInt(marqueewidth)+8+"px"
cross_marquee.innerHTML=marqueecontent
actualwidth=document.all? temp.offsetWidth : document.getElementById("temp").offsetWidth
}
else if (document.layers){
ns_marquee=document.ns_marquee.document.ns_marquee2
ns_marquee.left=parseInt(marqueewidth)+8
ns_marquee.document.write(marqueecontent)
ns_marquee.document.close()
actualwidth=ns_marquee.document.width
}
lefttime=setInterval("scrollmarquee()",20)
}
window.onload=populate

function scrollmarquee(){
if (iedom){
if (parseInt(cross_marquee.style.left)>(actualwidth*(-1)+8))
cross_marquee.style.left=parseInt(cross_marquee.style.left)-copyspeed+"px"
else
cross_marquee.style.left=parseInt(marqueewidth)+8+"px"

}
else if (document.layers){
if (ns_marquee.left>(actualwidth*(-1)+8))
ns_marquee.left-=copyspeed
else
ns_marquee.left=parseInt(marqueewidth)+8
}
}

if (iedom||document.layers){
with (document){
document.write('<table border="0" cellspacing="0" cellpadding="0"><td>')
if (iedom){
write('<div style="position:relative;width:'+marqueewidth+';height:'+marqueeheight+';overflow:hidden">')
write('<div style="position:absolute;width:'+marqueewidth+';height:'+marqueeheight+'" onMouseover="copyspeed=pausespeed" onMouseout="copyspeed=marqueespeed">')
write('<div id="iemarquee" style="position:absolute;left:0px;top:0px"></div>')
write('</div></div>')
}
else if (document.layers){
write('<ilayer width='+marqueewidth+' height='+marqueeheight+' name="ns_marquee"'+'>')
write('<layer name="ns_marquee2" left=0 top=0 onMouseover="copyspeed=pausespeed" onMouseout="copyspeed=marqueespeed"></layer>')
write('</ilayer>')
}
document.write('</td></table>')
}
}
</script>
Marquee
#------------------------------------------------------------------------------
$Global{MarqueeRTL}=<<MarqueeRTL;
MarqueeRTL
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
$Global{QuranTheme1}=<<QuranTheme1;
\n<table border="0" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
<!--ThemeForm-->
</table>
QuranTheme1

$Global{QuranThemeForm1}=<<QuranThemeForm1;
<!--QuranForm--><!--TranslitForm--><!--TranslatForm--><!--InterpertForm-->
<tr><td><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td height="1" width="100%" bgcolor="#E8D0AC"><img src="<!--CLASS::Theme_Images_URL-->/dot1x1.gif" width="1" height="1" alt border="0"></td></tr></table></td></tr>
QuranThemeForm1

$Global{QuranForm1}=<<QuranForm1;
<tr><td><!--AyahForm--></td></tr>
QuranForm1
$Global{TranslitForm1}=<<TranslitForm1;
<tr><td><!--AyahForm--></td></tr>
TranslitForm1
$Global{TranslatForm1}=<<TranslatForm1;
<tr><td><!--AyahForm--></td></tr>
TranslatForm1
$Global{InterpertForm1}=<<InterpertForm1;
<tr><td><!--AyahForm--></td></tr>
InterpertForm1
#------------------------------------------------------------------------------
$Global{QuranTheme2}=<<QuranTheme2;
<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#ECC897" width="100%">
<!--ThemeForm-->
</table>
QuranTheme2

$Global{QuranThemeForm2}=<<QuranThemeForm2;
<tr><!--QuranForm--><!--TranslitForm--><!--TranslatForm--><!--InterpertForm--></tr>
QuranThemeForm2

$Global{QuranForm2}=<<QuranForm2;
<td width="25%" valign="top"><!--AyahForm--></td>
QuranForm2
$Global{TranslitForm2}=<<TranslitForm2;
<td width="25%" valign="top"><!--AyahForm--></td>
TranslitForm2
$Global{TranslatForm2}=<<TranslatForm2;
<td width="25%" valign="top"><!--AyahForm--></td>
TranslatForm2
$Global{InterpertForm2}=<<InterpertForm2;
<td width="25%" valign="top"><!--AyahForm--></td>
InterpertForm2
#------------------------------------------------------------------------------
$Global{QuranTheme3}=<<QuranTheme3;
<!--ThemeForm-->
QuranTheme3

$Global{QuranThemeForm3}=<<QuranThemeForm3;
<!--QuranForm--><!--TranslitForm--><!--TranslatForm--><!--InterpertForm-->
QuranThemeForm3

$Global{QuranForm3}=<<QuranForm3;
<!--AyahForm-->
QuranForm3

$Global{TranslitForm3}=<<TranslitForm3;
<!--AyahForm-->
TranslitForm3
$Global{TranslatForm3}=<<TranslatForm3;
<!--AyahForm-->
TranslatForm3
$Global{InterpertForm3}=<<InterpertForm3;
<!--AyahForm-->
InterpertForm3
#------------------------------------------------------------------------------
$Global{QuranTheme4}=<<QuranTheme4;
\n<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
<!--ThemeForm-->
</table>
QuranTheme4

$Global{QuranThemeForm4}=<<QuranThemeForm4;
<!--QuranForm--><!--TranslitForm--><!--TranslatForm--><!--InterpertForm-->
<tr><td><table width="400%" border="0" cellspacing="0" cellpadding="0"><tr><td height="1" width="400%" bgcolor="#E8D0AC"><img src="<!--CLASS::Theme_Images_URL-->/dot4x4.gif" width="1" height="1" alt border="0"></td></tr></table></td></tr>
QuranThemeForm4

$Global{QuranForm4}=<<QuranForm4;
<tr><td bgcolor="#FFF2DF"><!--AyahForm--></td></tr>
QuranForm4
$Global{TranslitForm4}=<<TranslitForm4;
<tr><td bgcolor="#FFEACA"><!--AyahForm--></td></tr>
TranslitForm4
$Global{TranslatForm4}=<<TranslatForm4;
<tr><td bgcolor="#FFE2B7"><!--AyahForm--></td></tr>
TranslatForm4
$Global{InterpertForm4}=<<InterpertForm4;
<tr><td bgcolor="#FFDBA6"><!--AyahForm--></td></tr>
InterpertForm4
#------------------------------------------------------------------------------
$Global{QuranTheme5}=<<QuranTheme5;
<table border="1" cellpadding="3" cellspacing="0" style="border-collapse: collapse" bordercolor="#ECC897" width="100%">
<!--ThemeForm-->
</table>
QuranTheme5

$Global{QuranThemeForm5}=<<QuranThemeForm5;
<tr><!--QuranForm--><!--TranslitForm--><!--TranslatForm--><!--InterpertForm--></tr>
QuranThemeForm5

$Global{QuranForm5}=<<QuranForm5;
<td width="25%" valign="top" bgcolor="#FFF2DF"><!--AyahForm--></td>
QuranForm5
$Global{TranslitForm5}=<<TranslitForm5;
<td width="25%" valign="top" bgcolor="#FFEACA"><!--AyahForm--></td>
TranslitForm5
$Global{TranslatForm5}=<<TranslatForm5;
<td width="25%" valign="top" bgcolor="#FFE2B7"><!--AyahForm--></td>
TranslatForm5
$Global{InterpertForm5}=<<InterpertForm5;
<td width="25%" valign="top" bgcolor="#FFDBA6"><!--AyahForm--></td>
InterpertForm5
#------------------------------------------------------------------------------
$Global{DefaultAyahForm}=<<DefaultAyahForm;
<span dir="ltr" align="justify" lang="eng-us" style="font-family: Times, Tahoma, verdana, helvetica; font-size: 18px; font-weight: normal; line-height: 150%;">
<a name="Ayah<!--Ayah-->"><a><!--Quran--><!--Sajdah--> (<!--AyahNum-->)
</span>
DefaultAyahForm
$Global{DefaultAyahFormArabic}=<<DefaultAyahFormArabic;
<span dir="rtl" align="justify" lang="ar-eg" style="font-family: Simplified Arabic,Arabic Transparent,Traditional Arabic,Times, Tahoma, verdana, helvetica; font-size: 24px; font-weight: normal; line-height: 150%;">
<a name="Ayah<!--Ayah-->"><a><!--Quran--><!--Sajdah--> &#64831;<!--AyahNum-->&#64830; <img src="<!--CLASS::Theme_Images_URL-->/listen.gif" border="0" onClick="<!--ReciteAyah-->" style="CURSOR: pointer">
</span>
DefaultAyahFormArabic

}
#==========================================================
#==========================================================
sub Default_Parameters{
	
	&Get_General_Classes;
	#&Get_Banner_Defaults;
	#----------------------------------------------------------
	# Configuration Menu	
	$Global{DB_Server} = "MySQL";
	$Global{DB_Driver} = "mysql";
	$Global{DB_Host} = "localhost";
	$Global{DB_Port} = 3306;
	$Global{DB_DSN} = "";
	$Global{DB_Name} = "islamkit";
	$Global{DB_UserID} = "root";
	$Global{DB_Password} = "";
	$Global{Languages} = "English";
	$Global{Themes} = "English:Default";

	$Global{Site_Name} = "Site_Name";
	$Global{Mail_Program_Type} = 0;
	$Global{Mail_Program_Or_SMTP_Server} = "/usr/lib/sendmail";
	$Global{Email_Status} = 1; # 0 = disbale all emails
	$Global{Admin_Help_Window_Width} = 620;
	$Global{Admin_Help_Window_Height} = 450;
	
	$Global{IslamKitAdminUserID} = "";
	$Global{IslamKitAdminPassword} = "";

	$Global{Webmaster_Email} = "Webmaster <webmaster\@islamware.com>";
	$Global{Contact_Us_Email} = "Contact Us <info\@islamware.com>";
	$Global{Account_Confirmation_Email} = "Account Confirmation <webmaster\@islamware.com>";
	$Global{Support_Email} = "Support <support\@islamware.com>";
	$Global{GMT_Offset} = 3;
	#----------------------------------------------------------
	$Global{Whos_Online_Time_Out} = 300;
	$Global{Maximum_Search_Results} = 0;
	$Global{Search_Prefix} = qq!<font style="color: red; background-color: #66FF00;">!;
	$Global{Search_Suffix} = qq!</font>!;
	#----------------------------------------------------------
	#----------------------------------------------------------
	#General options
	$Global{Secure_Key} = "IsLaMwArETiGeRhErE";
	$Global{Email_X_Priority} = 1;
	$Global{Email_Format} = 1;
	#----------------------------------------------------------
	$Global{Meta_Title} = "IslamKit";
	$Global{Meta_Description} = "Holy Quran database, Quran Translations, Quran Transliterations, Quran Interpertaions, Prayer Times, Qibla direction, and Sunrise calculator.";
	$Global{Meta_Keywords} = "Quran, Quran data, Holy Quran Database,Quran Translations, Quran Transliterations, Quran Interpertaions, Islam,Musilm,Qibla, Qibla direction, Qibla calculator, Qibla direction calculator, Sunrise, Sunrise calculator, Paryer Times, Prayer times calculator, Pray Times, Pray Time Caculator.";
	#----------------------------------------------------------
	# System Defaults
	$Global{Language} = "English";
	$Global{Email_X_Mailer} = qq!Islamware!;
	#----------------------------------------------------------
	$Global{Forbidden_Remote_Hosts} ="66.0.106.55, 66.35.208.60, 66.7.131.131, 66.7.131.135, 66.7.131.139";
	$Global{Admin_Table_Attr} = qq! style="border: 0 outset #F7F7F7" bordercolor="#F7F7F7"!;
	#----------------------------------------------------------
	# Editor options
	$Global{AdminEditorRows} = 25;
	$Global{AdminEditorColumns} = 80;
	$Global{AdminEditorBackground} = '#FFFFCC';
	$Global{AdminEditorForeground} = 'BLACK';
	#----------------------------------------------------------
	$Global{DB_File_Priv} = 0;
	#----------------------------------------------------------
	#<title>Islamware - www.islamware.com</title>
	#<meta name="description" content="Provides Islamic Software Products and Development Tools for Muslims and Islamic Developers">
	#<meta name="keywords" content="Islam, Quran, Qibla, Holy Quran, Pray, Islam, Musilm,">

	$Global{AdminQuranEditorAyahs} = 10;

	$Global{DefaultSurah} = 1;
	$Global{DefaultAyah} = 1;
	$Global{DefaultPage} = 1;
	$Global{DefaultAyahs} = 50;
	$Global{DefaultPart} = 1;
	$Global{DefaultQuranName} = 'Arabic';
	$Global{DefaultTranslation} = '';
	$Global{DefaultTransliteration} = '';
	$Global{DefaultInterpertation} = '';
	$Global{DefaultLayout} = 4;
	$Global{DefaultSurahReciter} = "Jibreal";
	$Global{DefaultAyahReciter} = "Huzify";

	$Global{DefaultType} = 0;
	$Global{AdminUploadReciterFiles} = 5;
	$Global{DefaultAyahRepeat} = 0;
	$Global{DefaultAyahLoop} = 0;
	$Global{PageViews} = 0;
}
#==========================================================
1;