=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Contact_Us{
my ($Template, $Temp);

	&Read_Language_File($Global{Language_Contact_Us_File});
	$Template =&Translate_File($Global{Contact_Us_Template});
	$Template =~ s/<!--Action-->/$Script_URL/;
	$Template =~ s/<!--Language-->/$Global{Language}/;
	
	$Template =~ s/<!--IP-->/$ENV{REMOTE_ADDR}/g;
	$Temp = &Get_IP_Hostname($ENV{REMOTE_ADDR});
	$Template =~ s/<!--Host-->/$Temp/g;

	$Plugins{Bar_Action} = $Language{contact_us_menu_label};
	$Plugins{Menu_Bar} = "";

	$Plugins{Body}="";
    &Display($Template,1);
}
#==========================================================
sub Send_Contact_Us{
my ($Msg, $Temp);

	&Read_Language_File($Global{Language_Contact_Us_File});

	$Msg = "";

	if (!&Check_Email_Address($Param{Email})) {
			$Msg .= $Language{invalid_email};
	}

	$Param{Name} =~ s/^\s+//;
	$Param{Name} =~ s/\s+$//;
	$Param{Name} =~ s/\s+/ /g;
	$Param{Name} =~ s/\cM//g;
	
	$Param{Subject} =~ s/^\s+//;
	$Param{Subject} =~ s/\s+$//;
	$Param{Subject} =~ s/\s+/ /g;
	$Param{Subject} =~ s/\cM//g;

	$Param{Phone} =~ s/^\s+//;
	$Param{Phone} =~ s/\s+$//;
	$Param{Phone} =~ s/\s+/ /g;
	$Param{Phone} =~ s/\cM//g;

	$Param{Email} =~ s/^\s+//;
	$Param{Email} =~ s/\s+$//;
	$Param{Email} =~ s/\s+/ /g;
	$Param{Email} =~ s/\cM//g;

	$Param{Message} =~ s/^\s+//;
	$Param{Message} =~ s/\s+$//;
	$Param{Message} =~ s/\cM//g;
	$Param{Message} =~ s/\n/\<br\>/g;

	if (!$Param{Name}) {$Msg .= $Language{error_name};}
	if (!$Param{Phone}) {$Msg .= $Language{error_phone};}
	if (!$Param{Subject}) {$Msg .= $Language{error_subject};}
	if (!$Param{Message}) { $Msg .= $Language{error_message};}
	if (!$Param{Email}) { $Msg .= $Language{error_email};}

	$Param{Message} =~ s/[\>]\s*\n/\> /g;
	$Param{Message} =~ s/\n/\<br\>/g;

	if ($Msg) {
					$Plugins{Body} = &Msg($Language{missing_information}, $Msg, 1);
					&Display($Global{General_Template});
					return;
	}

	$Msg = $Language{contact_email_body};
	$Msg =~ s/<!--Name-->/$Param{Name}/g;
	$Msg =~ s/<!--Email-->/$Param{Email}/g;
	$Msg =~ s/<!--Phone-->/$Param{Phone}/g;
	$Msg =~ s/<!--Subject-->/$Param{Subject}/g;
	$Msg =~ s/<!--Message-->/$Param{Message}/g;
	$Msg =~ s/<!--Contact-->/$Param{Contact}/g;
	$Msg =~ s/<!--IP-->/$ENV{REMOTE_ADDR}/g;
	$Temp = &Get_Host;
	$Msg =~ s/<!--IP-->/$Temp/g;
	
	$Temp = &Get_IP_Hostname($ENV{REMOTE_ADDR});
	$Msg =~ s/<!--Host-->/$Temp/g;

	&Email($Param{Email}, $Global{Contact_Us_Email}, $Language{contact_us_email_subject}, $Msg);

	$Plugins{Body} = &Msg($Language{contact_us_received}, $Language{contact_us_received_description}, 2);
    &Display($Global{General_Template});
}
#==========================================================
1;