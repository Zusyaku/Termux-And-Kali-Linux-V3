=Copyright Infomation
==========================================================
Program Name    : IslamWare IslamKit
Program Author   : Elsheshtawy, A. A.
Home Page          : http://www.islamware.com
Copyrights � 2006 IslamWare. All rights reserved.
==========================================================
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
==========================================================
=cut
#==========================================================
sub Program_Start{

	use General;
	use DisplayMgr;
	use Main;
	use IslamWare;
	use SQLlib;

	#use DBD::oracle;
	&ModLoad("DBI", "DBD::mysql", "Time::Local");
	
	eval "use Time::HiRes qw(gettimeofday);";
	if ($@) {
			$Global{TimeHiRes} = 0;
	}
	else{
			$Global{TimeHiRes} = 1;
	}

	&Initialize_Program;

	$Script_URL = &Get_Script_URL;
	$Script_URL_HTTP = "$Global{CGI_URL}/$Global{Main_Prog}";
	$Script_URL_SSL = "$Global{SSL_URL}/$Global{Main_Prog}";

	&Read_Language_File($Global{Language_General_File});
	&DB_Start;
	&ReadConfiguration;
}
#==========================================================
1;