Title: ipcounter
Description: a cgi script written in Perl for a Unix host.
logs unique ip/host per day to give a reasonable idea of actual visitors to your site.
a unique ip is only blocked for one day, allowing
the visitor to be recounted another day.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=257&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
