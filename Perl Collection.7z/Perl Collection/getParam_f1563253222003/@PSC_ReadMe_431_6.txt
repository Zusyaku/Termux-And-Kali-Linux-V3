Title: getParam for subroutines
Description: By using the 'getParam' and passing 'Hashes/Associative Arrays' to your subs, you don't have to worry about the order of the parameters. Please excuse this little program, I can't really show the usefulness of passing a HASH to a single sub used once in a small program. But, imagine a larger program, with many subs - all called many times throughout. Now think about changing one of those subs... AARRGGHHH! Well, that's what happened to me, and I spent more time trying to match up the '@_' list in each and every call than the actual change of the routine.
Look closely and the two subs, they both do the same thing, and both use the same information, but I changed the order of the parameters in the second one --- and it still works! Try It Yourself!

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=431&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
