Title: WWW FTP Client
Description: WWW FTP Client is a perl cgi script providing ftp client capabilities with the user interface in your browser. Just install it on a remote server and whether you are on a computer with no ordinary ftp client installed or you are connected to the internet through a firewall or a proxy not allowing ftp connections, WWW FTP client allows you to quickly and easily perform all your ftp tasks.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=388&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
