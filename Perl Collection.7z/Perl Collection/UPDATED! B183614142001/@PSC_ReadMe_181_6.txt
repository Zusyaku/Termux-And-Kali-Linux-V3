Title: UPDATED! Basic Chat (WEB BASED)
Description: I forgot some files from before... all fixed now. These three scripts and one HTML file will allow anyone on any system that has a web browser to chat to one another. Future versions will implement chat rooms,logins and images as userid's. I wrote this because some of my systems are 486 systems with old web browsers that dont benefit from the use of newer Java/script and PHP.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=181&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
