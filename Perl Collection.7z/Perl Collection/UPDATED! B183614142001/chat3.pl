#!perl
# Mollensoft COLISEUM CHAT ENGINE
#
# This is a Working Prototype (so dont expect much!)
#
# This is used to on win32 and linux.
# Complete Freeware Just Like Perl... By Mollensoft Software
#
# FOR BIGAL... 
#
# Needs: ... still needs Separate rooms, login for username and add javascript buttons
###########################################################################################################

use CGI;
use Fcntl;

$co = new CGI;

open(HISTORY, "chathistory.dat") or die "could not open data file";
@text1 = <HISTORY>;
@reversed = reverse (@text1); 
close HISTORY;

print 
$co->header,
"<meta HTTP-EQUIV=\"Refresh\" CONTENT=\"5\">",
$co->start_html(
	-title=>'Chat Server',
	-author=>'BigAL',
	-target=>'_history',
	-BGCOLOR=>'LIGHTBLUE',
	-LINK=>'red'
),
#$co->center(@reversed),
$co->h5({-align=>left},"@reversed"), 


$co->end_html;
exit;


