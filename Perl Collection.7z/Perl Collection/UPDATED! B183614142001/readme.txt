Colesium Chat Program 


This is a Alpha level suite of code that I am working on to implement a completely perl/http based chat server for use across many platforms. This is specifically designed to allow people with older browser to chat amongst themselves without using complicated chat systems or introducing java which older browser do not support (I.E. Army Intel Systems like the ASAS Remote Work Station).

To Install...

1. Place the Html file in your servers documents directory.
2. place chat1.dat, chat2.dat, chathistory.dat, chat2.pl, chat3.pl and chat4.pl into your servers "cgi-bin"
3. call "chat.htm" from your web browser

As always.. please let me know if you make this FREE code better! or have an idea to try.

Also, NO WARRANTY, for now.

BigAl Sends........

Mark Alan Mollenkopf
Mollensoft Freeware!
mmollenkopf@hot.rr.com