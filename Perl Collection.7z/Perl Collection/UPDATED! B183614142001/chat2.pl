#!perl
# Mollensoft COLISEUM CHAT ENGINE
#
# This is a Working Prototype (so dont expect much!)
#
# This is used to on win32 and linux.
# Complete Freeware Just Like Perl... By Mollensoft Software
#
# FOR BIGAL... 
#
# Needs: ... still needs Separate rooms, login for username and add javascript buttons
###########################################################################################################

use CGI;
use Fcntl;

$Date = localtime();
$co = new CGI;
if ($co->param()) {
	$name = $co->param('username');
	$name =~ s/</&lt/;
	$text = $co->param('textarea');
	$text =~ s/</&lt/;
	if ($text) {
		my $oldtext;
		open (OLDDATA, "<chat2.dat") or die "Cant OPEN FIle";
		$oldtext = <OLDDATA>;
		close OLDDATA;
		
		open (DATA, ">chat1.dat") or die "Could not open File";
		print DATA $oldtext;
		close DATA;

		open (NEWDATA, ">chat2.dat") or die "Could Not Open File";
		print NEWDATA "<FONT COLOR = Red> On $Date </FONT>", "<B>", $name, " Said; ", "</B>", $text;
		close NEWDATA
		}
	}

#create Scrollable chat history

open (INFILE2, "chat2.dat") ||
       die ("Cannot open input file merge2\n");
open (OUTFILE3, ">>chathistory.dat") ||
       die ("Cannot open input file merge2\n");
       
$line2 = <INFILE2>;
$line2 = "$line2\n";
while ($line2 ne "") {
               if ($line2 ne "") {
               print OUTFILE3 ("$line2<BR>");
                $line2 = <INFILE2>;
        }

 }
 

close INFILE2;
close OUTFILE3;



&printpage;

sub printpage
	{
		print
		$co->header,
		$co->start_html(
			-title=>'Mollensoft Chat Server',
			-author=>'BigAL',
			-BGCOLOR=>'Green',
			-LINK=>'red'
			),
		$co->startform,
            $co->h3({-align=>left},'To Send a message... Type In Your Name   then Message and click Send Text'), 
            $co->h3({-align=>left},'USERNAME | MESSAGE'), 
	   # {-align=>center},
	#For Future dev
    #$co->center, h1("Please Select Your User Name: "),
	      $co->textfield(
                    	-name=>'username',
                      -default=>'',
				-override=>1,
				-size=>20,
				-maxlenght=>20
                          ),
         
			$co->textfield(
				-name=>'textarea',
				-default=>'',
				-override=>1,
				-size=>50,
				-maxlenght=>80
				),
		
		    	$co->submit(-value=>'Send Text'),
		
				   

		$co->hidden(-name=>'hiddendata'),
		$co->endform,
		$co->end_html;
	}