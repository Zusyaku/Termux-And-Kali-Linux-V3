#!perl
# Mollensoft COLISEUM CHAT ENGINE
#
# This is a Working Prototype (so dont expect much!)
#
# This is used to on win32 platforms (and linux).
# Complete Freeware Just Like Perl... By Mollensoft Software
#
# FOR BIGAL... 
#
# Needs: ... still needs Separate rooms, login for username and add javascript buttons
###########################################################################################################

use CGI;
use Fcntl;

$co = new CGI;

print 
$co->start_html(
	-title=>'Chat Server',
	-author=>'BigAL',
	-target=>'_display',
	-BGCOLOR=>'LIGHTGREEN',
	-LINK=>'red'
),
$co->center($co->h1('Welcome to Coliseum Chat')),
$co->end_html;
exit;



