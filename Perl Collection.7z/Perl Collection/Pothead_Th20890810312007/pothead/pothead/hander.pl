#!/usr/bin/perl

sub notice {
 $raw = $_;
 @user = split(/ :/,$raw,2); 
    	$msg = $user[1];
        @asdf = split(" NOTICE ", $user[0],2);
        @zxcv = split("!", $asdf[0], 2);
        @poiu = split("@", $zxcv[1], 2);
        
        $user_talk=$zxcv[0];
        $user_host =$poiu[1];
        $user_ident = $poiu[0];
        if ($msg =~ /This nickname is owned by someone else/){
                print $socket "PRIVMSG nickserv :IDENTIFY $nickpasswd\n";
        } 
}

sub msg {
$raw = $_;
@user = split(/ :/,$raw,2); 
    	/^:(.*?)!/;
        @asdf = split(" PRIVMSG ", $user[0],2);
        @zxcv = split("!", $asdf[0], 2);
        @poiu = split("@", $zxcv[1], 2);
        
        $user_tal=$zxcv[0];
        $user_talk = substr $user_tal, 1;
        $user_host =$poiu[1];
        $user_ident = $poiu[0];
    	s/^:.*@* PRIVMSG (.*?)\s.*?://;
        $channel_talk=$asdf[1];
        
        
        $talk = $user[1];
        if ($channel_talk eq $nick){
             $channel_talk = $user_talk;
        }
            
            if ($talk =~ /^VERSION/){
                 print $socket "NOTICE $user_talk :POTHEAD The 2nd Version 1.0 Beta\n";   
            }
            if ($talk =~ /^TIME/){
                 $time = localtime(time);
                 print $socket "NOTICE $user_talk :$time\n";
            }
            if ($talk =~ /^PING/){
                 print $socket "NOTICE $user_talk :$talk\n";
            }

            if ($talk =~ /^!help/i) {
    		    chelp($user_talk);
                }
            if ($talk =~ /^!join/i) {
                    cjoin($user_host,$user_ident,$talk);
    		}
            if ($talk =~ /^!leave/i) {
                    cleave($user_host,$user_ident,$talk);
    		}

            if ($talk =~ /^!speak/i) {
                    cspeak($user_host,$user_ident,$talk);
    		}
            
            if ($talk =~ /^!die/i) {
                    cdie($user_host,$user_ident,$user_talk);
    	        }
            if ($talk =~ /^!login/i) {
                    clogin($talk, $user_talk);
    		}
            if ($talk =~ /^!stone2pound/i){
                cstone2pound($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!pound2stone/i){
                cpound2stone($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!kilo2pound/i){
                ckilo2pound($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!pound2kilo/i){
                cpound2kilo($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!kilo2stone/i){
                ckilo2stone($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!stone2kilo/i){
                cstone2kilo($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!datematch/i){
                cdatematch($user_talk, $channel_talk, $talk);
            } 
            if ($talk =~ /^!learn/i){
                clearn($user_talk, $channel_talk, $talk);
            }
            if ($talk =~ /^!whatis/i){
                cwhatis($user_talk, $channel_talk, $talk);
            }
             
                   
}

1;
