#!/usr/bin/perl

sub admincheck {


$userhost = $_[0];
$userident = $_[1];

open(DAT,"./include/admin.dat") || die("Cannot Open File"); 
               my @admins = <DAT>; 
               close(DAT); 
               chop(@admins);
               foreach(@admins){
                   @admin = split(":", $_, 3);
                   
                         if ($userhost eq $admin[1]){
                            if ($userident eq $admin[0]){ 
                                return "yes";
                            }
                         }
                     
               }

}

sub cjoin {
    $user_host = $_[0];
    $user_ident = $_[1];
    $talk = $_[2];
    $channel= substr $talk, 6;
    my $allow = admincheck($user_host, $user_ident);
    if ($allow eq "yes"){
    	print $socket "JOIN $channel\n";
    }

}

sub cleave {
    $user_host = $_[0];
    $user_ident = $_[1];
    $talk = $_[2];
    $channel= substr $talk, 7;
    my $allow = admincheck($user_host, $user_ident);
    if ($allow eq "yes"){
    	print $socket "PART $channel\n";
    }
}

sub cspeak {
    $user_host = $_[0];
    $user_ident = $_[1];
    $talk = $_[2];
    my $allow = admincheck($user_host, $user_ident);
    if ($allow eq "yes"){
       my $talk2 = substr $talk, 7;
       @speak = split(':',$talk2,2);
       $channel=$speak[0];
       $msg = $speak[1];
       print $socket "PRIVMSG $channel :$msg\n";
    }

}

sub cdie {
    $user_host = $_[0];
    $user_ident = $_[1];
    $user_talk = $_[2];
    my $allow = admincheck($user_host, $user_ident);
    if ($allow eq "yes"){
        print $socket "QUIT I am away to buy dope!\n";
    }
    else
    {
        print $socket "PRIVMSG $channel_talk :$user_talk, I am not silly your not my Admin. Shame on you.\n";
    }
}

sub clogin{
    $talk = $_[0]; 
    $user_talk = $_[1];
    my $password = substr $talk, 7;
    chop($password);
    if ($password eq $adminpassword) {
       print $socket "NOTICE $user_talk :You are now Admin over me.\n";
       open(DAT,">>./include/admin.dat") || die("Cannot Open File"); 
       print DAT "$user_ident:$user_host\n"; 
       close(DAT); 
    }
    else
    {
       print $socket "PRIVMSG $user_talk :$user_talk, you are a damn fool. Worng password.\n";
    }

}
1;
