#!/usr/bin/perl

###################
# Pothead the 2nd
# Iain "Backdraft" Cambridge
# wackiebackie@gmail.com
###################


use IO::Socket;
require "./hander.pl";
require "./admin.pl";
require "./commands.pl";


print "Loading...\n";



do "bot.conf" or die " $mfail (bot.conf -- $!)\n";

$socket = IO::Socket::INET->new(PeerAddr => $server,
    				PeerPort => $port,
    				Proto => "tcp",
    				Type => SOCK_STREAM);

print $socket "user $username\n";
print $socket "nick $nick\n";
print $socket "join $channels\n";

open(LOG,">log.dat") || die("Cannot Open File"); 


while (<$socket>){
        chop($_);
      
    	pong($_);
    	print "$_\n";
        
        
   $raw = $_;
   if ($raw =~ /NOTICE/){
      notice($raw);
   }
   if ($raw =~ /PRIVMSG/){
      msg($raw);
   }    

}
close(LOG);

#############
# Basic Stuff
#############

sub pong {
    	$message = $_[0];
    	if ($message =~ /^ping/i) {
    		$message =~ s/^ping\s+://;
    		print $socket "PONG :$_";
}

}



