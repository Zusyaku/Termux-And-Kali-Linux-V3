#!/usr/bin/perl


sub chelp{
   $user_talk = $_[0];
   print $socket "NOTICE $user_talk :!stone2kilo [num], !kilo2stone [num], !stone2pound [num], !pound2stone [num], !pound2kilo [num], !kilo2pound [num]\n";
   print $socket "NOTICE $user_talk :!datematch [your frist name] [gf/bf frist name]\n";
   print $socket "NOTICE $user_talk :That is all.\n";
    		
}

sub ckilo2pound{
    $user_talk = $_[0];
    $channel_talk = $_[1];
    $talk = $_[2];
    my $weight = substr $talk, 12;
    chop($weight);
    my $pweight = $weight * 2.2;
    print $socket "PRIVMSG $channel_talk :$user_talk, $weight kilos is $pweight in pounds\n";
}

sub cpound2kilo {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   my $weight = substr $talk, 12;
   chop($weight);
   my $sweight = $weight / 2.2;
   print $socket "PRIVMSG $channel_talk :$user_talk, $weight pounds is $sweight in kilos\n";
}

sub cpound2stone {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   my $weight = substr $talk, 13;
   chop($weight);
   my $sweight = $weight / 14;
   print $socket "PRIVMSG $channel_talk :$user_talk, $weight pounds is $sweight in stones\n";
}

sub cstone2pound {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   my $weight = substr $talk, 13;
   chop($weight);
   my $pweight = $weight * 14;
   print $socket "PRIVMSG $channel_talk :$user_talk, $weight stones is $pweight in pounds\n";
}

sub ckilo2stone {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   my $weight = substr $talk, 12;
   chop($weight);
   my $pweight = $weight /  6.36;
   print $socket "PRIVMSG $channel_talk :$user_talk, $weight kilos is $pweight in stones\n";

}

sub cstone2kilo {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   my $weight = substr $talk, 12;
   chop($weight);
   my $sweight = $weight *  6.36;
   print $socket "PRIVMSG $channel_talk :$user_talk, $weight stones is $sweight in kilos\n";
}

sub cdatematch {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   open(DATE, "./include/date.log") || die("Where is the file\n");
   @matches = <DATE>;
   $names = substr $talk, 11;
   if ($name eq ""){
     print $socket "PRIVMSG $channel_talk :$user_talk, you need to put in your name and your bf/gf's name\n";
   }
   else
   {
     @name = split (' ',$names);
     chop(@matches);
     foreach(@matches)
      {
        @matchs = split(":", $_);
        if ($name[0] eq $matchs[0])
          {    
           if ($name[1] eq $matchs[1])
               {
                 $match = $matchs[2];
               }     
          }
  
      }
     close DATE;
     if ($match eq ""){
        open(DATE, ">>./include/date.log") || die("Where is the file\n");        
        $match = int(rand(100));
        print DATE "$name[0]:$name[1]:$match\n"; 
     }
      @zero=(
      "$name[1] is away having there wicked way with someone right now, $name[0] get rid of them asap",
      "$name[1] is bad news, $name[0] get them hunted!",
      "$name[0] relationship $name[1] is as cold as ice!",
      "$name[1] and $name[0] aren't going to last."
       );
     @thirty=("$name[0] and $name[1] are just not ment to be together!",
       "$name[1] and $name[0] are like haggis curry just not right!",
       "$name[0] and $name[1] passion is all gone.",
       "$name[1] is dragging there feet in this relationship"
       );
     @sixty=("$name[0] and $name[1] are a randy couple!",
      "$name[1] is all over $name[0] non-stop",
       "$name[0] is on cloud nine with $name[1]",
       "$name[1] has the lovebug for $name[0]"
       );
     @ninty=("$name[0] and $name[1] are on fire!!!",
       "NEWSFLASH!! $name[0] wants $name[1] soo bad!",
       "$name[1] can't stop thinking about $name[0]!",
       "$name[0] is in a dream world!!"
       );
     if ($match < 30){
         @comments = @zero;
     }
     if ($match > 30 && $match < 60){
         @comments = @thirty;
     }
     if ($match > 60 && $match < 90){
         @comments = @sixty;
     }
     if ($match > 90){
         @comments = @ninty;
     }
     $i = 0;
   
   
     foreach (@comments)
     {
      $i++;
     }
     $i--;
     $num = int(rand($i));
   
     print $socket "PRIVMSG $channel_talk :$user_talk, $name[1] and $name[0] have a $match% match rating\n";
     print $socket "PRIVMSG $channel_talk :$comments[$num]\n";
     print $comments[$num];
     $match = "";
   }
}


sub clearn {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   $talk = substr $talk, 7;
   chop($talk); 
   @data = split(":",$talk);
   $topic = $data[0];
   $info = $data[1];
   if ($info eq "")
   {
      print $socket "PRIVMSG $channel_talk :$user_talk, you need to give me some data to add to the database\n";
      exit;
   }
   open(DATA, "./include/data.dat");
   @data = <DATA>;
   chop(@data);
   foreach (@data){
        @newdata = split(":", $_);
        if ($topic eq $newdata[0]){
            print $socket "PRIVMSG $channel_talk :$user_talk, the topic of which you had decided to insert information about has already been done. Thank you!\n";
            exit;
        }
       
   }
   close DATA;
   open(DATA, ">>./include/data.dat");
   print DATA "$topic:$info\n";
   print $socket "PRIVMSG $channel_talk :$user_talk, thank you for adding data into my database!\n";
}

sub cwhatis {
   $user_talk = $_[0];
   $channel_talk = $_[1];
   $talk = $_[2];
   $topic = substr $talk, 8;
   chop($topic);
   open(DATA, "./include/data.dat");
   @data = <DATA>;
   foreach (@data){
       @newdata = split(":", $_);
       if ($topic eq $newdata[0]){
          print $socket "PRIVMSG $channel_talk :$user_talk, $topic: $newdata[1]\n";
       }
   } 
}

1;
