Title: Pothead The 2nd
Description: Pothead The 2nd is an ircbot. It has a weight converter, a date matching system to tell people if there relationship is hot or not. It has a learning database to allow users to add information into a database about a topic. It also replys to ctcp time, version and ping.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=765&lngWId=6

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
