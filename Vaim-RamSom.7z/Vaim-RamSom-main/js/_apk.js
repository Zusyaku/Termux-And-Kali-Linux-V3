
      
var redButton = document.getElementById("redButton");

redButton.addEventListener("click", Redirect);


function Redirect() {

//replace



}
   
