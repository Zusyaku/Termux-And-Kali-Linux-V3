# BeefAuto

<p align="center">
  <img src="https://github.com/youhacker55/BeefAuto/blob/main/icon.png" alt="Logo" width="300" height="300">
</p>
<p align="center">
  <b> Follow on Social Media Platforms </b>
</p>


<p align="center">
<p align="center">
<a href="https://www.facebook.com/achihemek.achihemek/"><img title="GitHub version" src="https://img.shields.io/badge/-Facebook-blue" ></a> 
</p>

<a href="https://wikipedia.org/wiki/Python_(programming_language)">
    <img src="https://img.shields.io/badge/language-python-blue.svg">
 </a>
 

python script Automate Beef  And Configure it to use overwan by using ngrok to open ports
# ScreenShots

![](/Screenshot/beef.png)

![](/Screenshot/beef32.png)



# INSTALLATION [ KALI ]
* git clone https://github.com/youhacker55/BeefAuto
* cd BeefAuto
* sudo pip3 install -r requirements.txt
* sudo bash install.sh
* sudo python3 main.py
# TESTED ON FOLLOWING:-
* Kali Linux

# How To UPDATE
* sudo bash update.sh

# LANGUAGE 
* Python

## Features
<p>In this tool I added two automatic webpage templates for engaged target on webpage to keep target on the hooked webpage while attacker exploit him</p>
<ul>
  <li>Super Mario Game</li>
  <li>YT Video</li>
  <li>More Will be Added (Maybe..)</li>
</ul>

# Updates
* Added SuperMario Game to Distract Target while attacker do hist work
 ![](/Screenshot/image.png)
 ![](/Screenshot/SuperBeef.png)
* Added Function to obfuscate Url and Make it Less suspicious
 ![](/Screenshot/0bfuscated.png)
* Added Webpage that show target yt Video in order to keep him in the webpage
 ![](/Screenshot/yt-dis.png)
* Added Fake CloudFlare Page to make hooked website more trusted by target 
 ![](/Screenshot/CloudFlare.png)
* Added Simple Function to Delete Beef Zombies Since beef-xss -x dosen t work 
 ![](/Screenshot/Delete.png)
* Added Another Game to distract target
 ![](/Screenshot/anothergame.png)

<h2>Video</h2>
<a href="https://www.youtube.com/watch?v=-8519PsTjf4"><img src="https://www.upload.ee/image/13252442/BeefAuto.jpg" style="max-width:100%;"></a>

# Credits
* [@jihedkdiss](https://github.com/jihedkdiss)
   For Making Icon for BeefAuto
* [@MohamedAmine](https://github.com/mohamedamine-tarhouni)
    For Making the SuperMario Game
* @youhacker55
   For Making this Tool



# DISCLAIMER
                                       TO BE USED FOR Education Purpose

The use of the BeefAuto COMPLETE RESPONSIBILITY of the END-USER. Developers assume NO liability and are NOT responsible for any misuse or damage caused by this program. 
