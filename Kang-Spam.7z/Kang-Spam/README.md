# Kang Spam
```
Tools ini dibuat untuk ngerjain
Kang Ripper atau boleh juga buat
nyepam Mantan Lu awokawokwkwk:v
```
![Sanz](https://github.com/Sxp-ID/Kang-Spam/blob/main/.Tools%20Kang%20Spam%20by%20Sanz.png)
> Script ini sewaktu-waktu bisa jadi limit ataupun coid jadi jangan salahin author nya ya goblok.
## How to it?
```python
$ cd Kang-Spam
$ bash install.sh
```
> Get Token [click here](https://bit.ly/TokenKangSp4m)
## Support Me On
<b>• [Facebook](https://m.facebook.com/dhasilva.junior.3)</b>
<br>
<b>• [Youtube](https://www.youtube.com/channel/UCLRXFyMN0L8yH9F-xxOd7Og)</b>
</br>
