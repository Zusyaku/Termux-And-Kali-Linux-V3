pkg install jq
pkg install curl
pip install -r requirements.txt
python main.py
