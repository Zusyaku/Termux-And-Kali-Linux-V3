There is no __init__.py in this directory, so pkg2.a refers to ../a.py, not this.
